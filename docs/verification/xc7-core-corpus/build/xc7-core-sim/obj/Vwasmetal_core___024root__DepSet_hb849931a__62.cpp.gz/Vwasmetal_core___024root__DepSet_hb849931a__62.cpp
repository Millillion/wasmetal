#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__12(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__12\n"); );
    // Body
    vlSelf->__VdfgTmp_h7b0cb704__0 = (((IData)(vlSelf->wasmetal_core__DOT___012124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012123_));
    vlSelf->__VdfgTmp_hfe9a1cba__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d));
    vlSelf->__VdfgTmp_hc16275c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010977_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6a47c3d1__0)));
    vlSelf->wasmetal_core__DOT___010750_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he68aaf0c__0)))));
    vlSelf->wasmetal_core__DOT___009651_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he68aaf0c__0)))));
    vlSelf->wasmetal_core__DOT___061505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061502_))));
    vlSelf->wasmetal_core__DOT___062158_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062139_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28180847__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h703df812__0))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0))))))))))))))))));
    vlSelf->wasmetal_core__DOT___019337_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055040_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055039_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055038_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055037_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff33330f0f5555ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055051_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h84a7ba42__0))))))))))));
    vlSelf->wasmetal_core__DOT___055031_ = (1U & (0xeeeefff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055026_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055019_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___055022_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___055021_))))))))));
    vlSelf->wasmetal_core__DOT___053680_ = (1U & (0xaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051611_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb6137419__0))));
    vlSelf->wasmetal_core__DOT___053689_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((1U 
                                                                  >> 
                                                                  (1U 
                                                                   & (0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051612_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb6137419__0))))));
    vlSelf->wasmetal_core__DOT___048673_ = (1U & (0xc000aU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0))))));
    vlSelf->__VdfgTmp_h951148c2__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hce73595f__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0))))));
    vlSelf->__VdfgTmp_h6a1d65be__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hce73595f__0))))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127552___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005823_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023480_ = ((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127569___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013780_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023601_ = ((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___047949_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0))))));
    vlSelf->wasmetal_core__DOT___050692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050691_))));
    vlSelf->wasmetal_core__DOT___063925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h61f75715__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063909_))));
    vlSelf->wasmetal_core__DOT___061507_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061496_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061474_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061469_)))));
    vlSelf->__VdfgTmp_hce2b20fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___047872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047871_));
    vlSelf->__VdfgTmp_hb4c65051__0 = (((IData)(vlSelf->wasmetal_core__DOT___047871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047946_));
    vlSelf->wasmetal_core__DOT___049747_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049697_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049746_))));
    vlSelf->wasmetal_core__DOT___049698_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049697_))));
    vlSelf->wasmetal_core__DOT___050827_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_he957a5af__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0))))));
    vlSelf->wasmetal_core__DOT___049055_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he957a5af__0))))));
    vlSelf->wasmetal_core__DOT___049615_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049116_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfbafed17__0))))));
    vlSelf->wasmetal_core__DOT___019232_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff000000bf00bfULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055958_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055957_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055428_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055319_))))))))))));
    vlSelf->wasmetal_core__DOT___050047_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0))))));
    vlSelf->wasmetal_core__DOT___050790_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0))))));
    vlSelf->wasmetal_core__DOT___049499_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049498_))));
    vlSelf->wasmetal_core__DOT___050851_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6896023__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0))))));
    vlSelf->wasmetal_core__DOT___051906_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6896023__0))))));
    vlSelf->wasmetal_core__DOT___049120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049116_))));
    vlSelf->wasmetal_core__DOT___047951_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0))))));
    vlSelf->wasmetal_core__DOT___048589_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048581_))));
    vlSelf->wasmetal_core__DOT___049056_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6896023__0))))));
    vlSelf->wasmetal_core__DOT___049616_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf502c6b2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049117_))));
    vlSelf->wasmetal_core__DOT___050046_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0))))));
    vlSelf->wasmetal_core__DOT___050787_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0))))));
    vlSelf->wasmetal_core__DOT___049500_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048582_))));
    vlSelf->wasmetal_core__DOT___051433_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0))))));
    vlSelf->wasmetal_core__DOT___051905_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0))))));
    vlSelf->wasmetal_core__DOT___049121_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049119_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf502c6b2__0))))));
    vlSelf->wasmetal_core__DOT___047952_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0))))));
    vlSelf->wasmetal_core__DOT___048590_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048587_))));
    vlSelf->__VdfgTmp_h36cbed8c__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd6896023__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)))))));
    vlSelf->wasmetal_core__DOT___049057_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0))))));
    vlSelf->wasmetal_core__DOT___049617_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049142_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049119_))));
    vlSelf->wasmetal_core__DOT___050058_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___050788_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___049504_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049503_))));
    vlSelf->wasmetal_core__DOT___051426_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha4843895__0))))));
    vlSelf->wasmetal_core__DOT___051904_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))));
    vlSelf->wasmetal_core__DOT___049144_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049142_))));
    vlSelf->wasmetal_core__DOT___049370_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___049700_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049503_))));
    vlSelf->wasmetal_core__DOT___063926_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063923_))));
    vlSelf->__VdfgTmp_h5a2cc5a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0))));
    vlSelf->wasmetal_core__DOT___049159_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049158_))));
    vlSelf->wasmetal_core__DOT___049312_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049158_))));
    vlSelf->wasmetal_core__DOT___065621_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065075_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065620_)))));
    vlSelf->wasmetal_core__DOT___065076_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063833_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065075_)))));
    vlSelf->wasmetal_core__DOT___064741_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064735_))));
    vlSelf->wasmetal_core__DOT___065309_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065308_)))));
    vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028664_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004374_));
    vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029054_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028976_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d));
    vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001475_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001475_)
            : (IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045365_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b32__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b18dcfd__0))))))));
    vlSelf->wasmetal_core__DOT___045377_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b34__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b33__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028734_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->__VdfgTmp_h8134fe6e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___053990_)))));
    vlSelf->__VdfgTmp_h57cd27d4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                             >> 2U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054047_)))));
    vlSelf->wasmetal_core__DOT___045331_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052418_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052192_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052191_)))))))));
    vlSelf->wasmetal_core__DOT___045343_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052192_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052191_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052418_)))))))));
    vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026707_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026631_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___054323_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054325_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054321_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O)))));
    vlSelf->wasmetal_core__DOT___054327_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027177_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027101_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026584_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001875_));
    vlSelf->wasmetal_core__DOT___054322_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054320_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054326_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026977_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026901_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___045917_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052254_))))))));
    vlSelf->wasmetal_core__DOT___045929_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052254_)))))))));
    vlSelf->wasmetal_core__DOT___045399_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdb6fbe09__0)))))));
    vlSelf->wasmetal_core__DOT___045411_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003208_)))))))));
    vlSelf->wasmetal_core__DOT___045860_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003270_))))));
    vlSelf->wasmetal_core__DOT___045884_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003190_))))));
    vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026766_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___064514_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___128663___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001475_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hf16ebcc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__1__KET__) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___064511_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064509_)))));
    vlSelf->wasmetal_core__DOT___063995_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063994_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063993_)))));
    vlSelf->wasmetal_core__DOT___064929_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064925_)))));
    vlSelf->wasmetal_core__DOT___064759_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064758_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064757_)))));
    vlSelf->wasmetal_core__DOT___065196_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064509_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064497_)))));
    vlSelf->wasmetal_core__DOT___065079_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063993_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063981_)))));
    vlSelf->wasmetal_core__DOT___065421_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064925_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064922_)))));
    vlSelf->wasmetal_core__DOT___065315_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064757_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064753_)))));
    vlSelf->wasmetal_core__DOT___064498_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064496_)))));
    vlSelf->wasmetal_core__DOT___063982_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063980_)))));
    vlSelf->wasmetal_core__DOT___064923_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064922_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064921_)))));
    vlSelf->wasmetal_core__DOT___064754_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064752_)))));
    vlSelf->wasmetal_core__DOT___065194_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064490_)))));
    vlSelf->wasmetal_core__DOT___065077_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063980_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063974_)))));
    vlSelf->wasmetal_core__DOT___065313_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064750_)))));
    vlSelf->wasmetal_core__DOT___065419_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064921_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064919_)))));
    vlSelf->wasmetal_core__DOT___065314_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064751_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___064755_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064751_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064750_)))));
    vlSelf->wasmetal_core__DOT___065078_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063975_))));
    vlSelf->wasmetal_core__DOT___063983_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063975_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063974_)))));
    vlSelf->wasmetal_core__DOT___064924_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064920_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064919_)))));
    vlSelf->wasmetal_core__DOT___065420_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064920_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___065195_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064491_))));
    vlSelf->wasmetal_core__DOT___064499_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064491_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064490_)))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030093_) 
           | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030221_) 
           | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___068963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068962_)))));
    vlSelf->__VdfgTmp_hb27da868__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068790_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___068892_))))));
    vlSelf->__VdfgTmp_h280fcf30__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068936_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___069034_))))));
    vlSelf->wasmetal_core__DOT___068791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068790_)))));
    vlSelf->__VdfgTmp_h10281295__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068845_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___068936_))))));
    vlSelf->wasmetal_core__DOT___068698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068599_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068697_)))));
    vlSelf->wasmetal_core__DOT___068846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068746_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068845_)))));
    vlSelf->wasmetal_core__DOT___068747_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068649_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068746_)))));
    vlSelf->wasmetal_core__DOT___068600_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068473_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068599_)))));
    vlSelf->wasmetal_core__DOT___068650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068547_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068649_)))));
    vlSelf->wasmetal_core__DOT___068474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068473_)))));
    vlSelf->wasmetal_core__DOT___068397_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068287_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068396_)))));
    vlSelf->wasmetal_core__DOT___068548_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068547_)))));
    vlSelf->wasmetal_core__DOT___068288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068149_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068287_)))));
    vlSelf->wasmetal_core__DOT___068421_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068341_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068420_)))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___056635_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011719_));
        vlSelf->wasmetal_core__DOT___012981_ = vlSelf->wasmetal_core__DOT___012039_;
        vlSelf->wasmetal_core__DOT___057065_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d))))));
        vlSelf->wasmetal_core__DOT___056644_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d))))));
    } else {
        vlSelf->wasmetal_core__DOT___056635_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d))))));
        vlSelf->wasmetal_core__DOT___012981_ = vlSelf->wasmetal_core__DOT___011719_;
        vlSelf->wasmetal_core__DOT___057065_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012039_));
        vlSelf->wasmetal_core__DOT___056644_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d))))));
    }
    vlSelf->wasmetal_core__DOT___068150_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068149_)))));
    vlSelf->wasmetal_core__DOT___068342_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068234_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068341_)))));
    vlSelf->wasmetal_core__DOT___068074_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068073_)))));
    vlSelf->wasmetal_core__DOT___068235_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068098_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068234_)))));
    vlSelf->wasmetal_core__DOT___068099_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068025_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068098_)))));
    vlSelf->wasmetal_core__DOT___067816_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067815_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h958b2749__0))))));
    vlSelf->wasmetal_core__DOT___067969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067815_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067968_)))));
    vlSelf->wasmetal_core__DOT___068026_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067902_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068025_)))));
    vlSelf->wasmetal_core__DOT___067755_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067754_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd78cc544__0))))));
    vlSelf->wasmetal_core__DOT___067903_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067902_)))));
    vlSelf->wasmetal_core__DOT___067731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h958b2749__0))))))));
    vlSelf->wasmetal_core__DOT___067593_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067447_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067592_)))));
    vlSelf->wasmetal_core__DOT___067665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067496_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd78cc544__0))))))));
    vlSelf->wasmetal_core__DOT___067448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067300_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067447_)))));
    vlSelf->wasmetal_core__DOT___067301_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067145_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067300_)))));
    vlSelf->wasmetal_core__DOT___067146_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067145_)))));
    vlSelf->wasmetal_core__DOT___066963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066843_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066962_)))));
    vlSelf->wasmetal_core__DOT___066844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066638_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066843_)))));
    vlSelf->wasmetal_core__DOT___066639_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066516_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066638_)))));
    vlSelf->wasmetal_core__DOT___067497_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067330_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067496_)))));
    vlSelf->wasmetal_core__DOT___066517_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066304_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066516_)))));
    vlSelf->wasmetal_core__DOT___067331_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067186_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067330_)))));
    vlSelf->wasmetal_core__DOT___066305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066304_)))));
    vlSelf->wasmetal_core__DOT___067187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067067_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067186_)))));
    vlSelf->wasmetal_core__DOT___067068_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066884_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067067_)))));
    vlSelf->wasmetal_core__DOT___066117_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065925_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066116_)))));
    vlSelf->wasmetal_core__DOT___066885_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066760_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066884_)))));
    vlSelf->wasmetal_core__DOT___066761_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066760_)))));
    vlSelf->wasmetal_core__DOT___065926_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065793_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065925_)))));
    vlSelf->wasmetal_core__DOT___066594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066390_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066593_)))));
    vlSelf->wasmetal_core__DOT___065794_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065793_)))));
    vlSelf->wasmetal_core__DOT___066391_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066260_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066390_)))));
    vlSelf->wasmetal_core__DOT___066261_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066070_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066260_)))));
    vlSelf->wasmetal_core__DOT___065596_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065291_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065595_)))));
    vlSelf->wasmetal_core__DOT___065292_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065070_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065291_)))));
    vlSelf->wasmetal_core__DOT___066071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065889_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066070_)))));
    vlSelf->wasmetal_core__DOT___065890_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065691_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065889_)))));
    vlSelf->wasmetal_core__DOT___065692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065404_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065691_)))));
    vlSelf->wasmetal_core__DOT___065405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065175_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065404_)))));
    vlSelf->wasmetal_core__DOT___065071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064723_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065070_)))));
    vlSelf->wasmetal_core__DOT___065176_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065175_)))));
    vlSelf->wasmetal_core__DOT___064891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064482_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064890_)))));
    vlSelf->wasmetal_core__DOT___064483_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064482_))));
    vlSelf->wasmetal_core__DOT___064724_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063827_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064723_)))));
    vlSelf->wasmetal_core__DOT___063829_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063827_))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028307_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028242_));
    vlSelf->wasmetal_core__DOT___049152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049151_))));
    vlSelf->wasmetal_core__DOT___049321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049151_))));
    vlSelf->wasmetal_core__DOT___064478_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___065201_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064470_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065200_)))));
    vlSelf->wasmetal_core__DOT___065426_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064902_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065425_)))));
    vlSelf->wasmetal_core__DOT___064903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064902_))));
    vlSelf->wasmetal_core__DOT___063835_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84f9890b__0))));
    vlSelf->wasmetal_core__DOT___064771_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2e505808__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063872_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063921_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063915_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063901_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063902_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61f75715__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___064748_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2e505808__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x4fff00ff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0791be06__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063872_)))));
    vlSelf->__VdfgTmp_hbbb75ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0791be06__0))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___011604_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010976_)));
        vlSelf->wasmetal_core__DOT___011869_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011004_)));
        vlSelf->wasmetal_core__DOT___010340_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c506bbe__0)));
        vlSelf->wasmetal_core__DOT___011658_ = (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c506bbe__0)));
        vlSelf->wasmetal_core__DOT___011472_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010761_)));
        vlSelf->wasmetal_core__DOT___011380_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010983_)));
        vlSelf->wasmetal_core__DOT___011538_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010911_)));
        vlSelf->wasmetal_core__DOT___011530_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010918_)));
        vlSelf->wasmetal_core__DOT___056722_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcbffb3b6__0)));
        vlSelf->wasmetal_core__DOT___011920_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcbffb3b6__0)));
        vlSelf->wasmetal_core__DOT___011379_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010989_)));
        vlSelf->wasmetal_core__DOT___011870_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010958_)));
        vlSelf->wasmetal_core__DOT___010574_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010590_)));
        vlSelf->wasmetal_core__DOT___011470_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010773_)));
        vlSelf->wasmetal_core__DOT___011858_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010892_)));
        vlSelf->wasmetal_core__DOT___011381_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010999_)));
        vlSelf->wasmetal_core__DOT___012125_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010552_)));
        vlSelf->wasmetal_core__DOT___011388_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010755_)));
        vlSelf->wasmetal_core__DOT___012729_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010755_)));
        vlSelf->wasmetal_core__DOT___010575_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010584_)));
        vlSelf->wasmetal_core__DOT___056595_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011017_))));
    } else {
        vlSelf->wasmetal_core__DOT___011604_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010977_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6a47c3d1__0))))));
        if (vlSelf->wasmetal_core__DOT___007693_) {
            vlSelf->wasmetal_core__DOT___011869_ = 
                (1U & (0xff35U >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hdea69a06__0)))));
            vlSelf->wasmetal_core__DOT___010340_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h14ad002b__0)));
            vlSelf->wasmetal_core__DOT___011658_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h14ad002b__0)));
            vlSelf->wasmetal_core__DOT___011538_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_hc43f9106__0)));
            vlSelf->wasmetal_core__DOT___011530_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_h7edccd87__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011869_ = 
                (1U & (0xdU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011003_))));
            vlSelf->wasmetal_core__DOT___010340_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h6df87d4d__0)));
            vlSelf->wasmetal_core__DOT___011658_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h6df87d4d__0)));
            vlSelf->wasmetal_core__DOT___011538_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010272_)))));
            vlSelf->wasmetal_core__DOT___011530_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010253_)))));
        }
        vlSelf->wasmetal_core__DOT___011472_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_he4fe919e__0))));
        vlSelf->wasmetal_core__DOT___011380_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_haef445c6__0)))));
        vlSelf->wasmetal_core__DOT___056722_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb37e0c87__0)));
        vlSelf->wasmetal_core__DOT___011920_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb37e0c87__0)));
        vlSelf->wasmetal_core__DOT___011379_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h1d2a78cf__0)))));
        vlSelf->wasmetal_core__DOT___011870_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h034bd5a0__0)))));
        vlSelf->wasmetal_core__DOT___010574_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h97dd8594__0))));
        vlSelf->wasmetal_core__DOT___011470_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1110fffU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((0xf011U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___007678_))))) 
                                                                 << 2U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h724ed7d2__0)))))));
        vlSelf->wasmetal_core__DOT___011858_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010893_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hde094a0f__0))))));
        vlSelf->wasmetal_core__DOT___011381_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd610ba85__0)))));
        vlSelf->wasmetal_core__DOT___012125_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h25073b9c__0))));
        vlSelf->wasmetal_core__DOT___011388_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf1d7bcdf__0))))));
        vlSelf->wasmetal_core__DOT___012729_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h304fb1ba__0))))));
        vlSelf->wasmetal_core__DOT___010575_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc09bd195__0))));
        vlSelf->wasmetal_core__DOT___056595_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011122_)));
    }
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027355_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b2__05d));
    vlSelf->__VdfgTmp_hcdf58d3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_hcf2773b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hc8e63fc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hffde1553__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hcf316312__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O)))))));
    vlSelf->__VdfgTmp_hba4cc4c7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_h9fccfed0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022537_));
    vlSelf->wasmetal_core__DOT___069138_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048850_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcf8aa4a8__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___054966_ = (1U & (0xeeeefff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054947_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054940_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___054943_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054942_))))))))));
    vlSelf->wasmetal_core__DOT___059202_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051506_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051505_))))));
    vlSelf->wasmetal_core__DOT___059159_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051506_))));
    vlSelf->__VdfgTmp_h22ba1a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h170507c4__0)));
    vlSelf->wasmetal_core__DOT___048832_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h170507c4__0))))));
    vlSelf->__VdfgTmp_h5b64371c__0 = ((2U & ((IData)(
                                                     (0x330f5500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h89619cd0__0)))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001781_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___001850_))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002811_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h73960028__0)))));
        vlSelf->wasmetal_core__DOT___002564_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                    ? 
                                                   (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h73960028__0))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001784_)))));
        vlSelf->wasmetal_core__DOT___002893_ = vlSelf->wasmetal_core__DOT___001849_;
    } else {
        vlSelf->wasmetal_core__DOT___002811_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___001785_)))))));
        vlSelf->wasmetal_core__DOT___002564_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001785_)))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___001783_))))));
        vlSelf->wasmetal_core__DOT___002893_ = vlSelf->wasmetal_core__DOT___002111_;
    }
    vlSelf->wasmetal_core__DOT___048771_ = ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                            & (IData)(
                                                      (0x3300f00055ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h804cf86b__0)))))));
    vlSelf->__VdfgTmp_hb4d5b900__0 = ((2U & ((IData)(
                                                     (0x33f05500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h804cf86b__0)))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000921_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___000924_))));
    vlSelf->wasmetal_core__DOT___016197_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006898_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006899_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051557_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___016206_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006918_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006919_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006932_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006933_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006951_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006959_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006966_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006969_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051542_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051541_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___016297_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022643_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022630_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022629_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013505_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057706_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057702_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015781_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015696_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015695_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015707_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015708_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015717_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013558_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013559_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013547_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013548_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015612_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015747_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015750_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015621_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015622_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015630_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015629_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015638_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015651_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013589_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013565_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013581_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013602_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013605_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013599_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057729_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057730_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057728_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015650_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023445_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023431_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023430_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023429_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023428_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___068897_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048861_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048862_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___061712_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->__VdfgTmp_ha9e2ef67__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___051502_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051504_));
    vlSelf->wasmetal_core__DOT___058693_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051502_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051504_))))));
    vlSelf->wasmetal_core__DOT___051508_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051504_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051502_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006238_)))))));
    vlSelf->wasmetal_core__DOT___061477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061474_))));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010597_)));
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010091_)));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010152_)));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010142_)));
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010132_)));
    } else if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010597_)));
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010091_)));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010152_)));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010142_)));
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010132_)));
    } else {
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010781_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hdc4dab2d__0))))));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hfc864313__0))))));
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010091_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb57f307c__0))))));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010152_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha7c061ef__0))))));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010142_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h53247725__0))))));
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010132_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h143507db__0))))));
    }
    vlSelf->wasmetal_core__DOT___011992_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdc4dab2d__0))))));
    vlSelf->__VdfgTmp_h249647a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h470ae9e3__0));
    vlSelf->__VdfgTmp_h73f89ba5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___009833_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc864313__0))))));
    vlSelf->__VdfgTmp_h2544c7bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011003_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hdea69a06__0)));
    vlSelf->wasmetal_core__DOT___054747_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccccaaaaf0f0ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054727_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xffff3355fffff0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha89e6386__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffff3355fffff0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3265141f__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hffdded68__0))))))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xc000aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h014e1215__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054714_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054713_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054721_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054720_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061639_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061627_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061621_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___061620_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52d73039__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h27ece1ce__0))))))))))));
    vlSelf->wasmetal_core__DOT___009842_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056201_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf00001111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007510_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007509_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae0eb281__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010229_)))))))));
    vlSelf->__VdfgTmp_h02606b30__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hd163f969__0))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010229_));
    vlSelf->__VdfgTmp_h6dac888a__0 = (((IData)(vlSelf->wasmetal_core__DOT___002933_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7357dd51__0));
    vlSelf->wasmetal_core__DOT___019240_ = (1U & (IData)(
                                                         (0xf000000eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060712_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h12bbe12d__0))))));
    vlSelf->wasmetal_core__DOT___055997_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h12bbe12d__0))));
    vlSelf->wasmetal_core__DOT___019201_ = (1U & (IData)(
                                                         (0x554400000f0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055863_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048284_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055864_)))))))));
    vlSelf->wasmetal_core__DOT___019277_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055864_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055863_))))));
    vlSelf->wasmetal_core__DOT___055013_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0eeeeff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054986_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054976_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc326eb38__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054977_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054978_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054993_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054992_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054991_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6adb13e__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___055992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055990_))));
    vlSelf->wasmetal_core__DOT___062075_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___049528_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb043089c__0))))));
    vlSelf->wasmetal_core__DOT___049814_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb043089c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0))))));
    vlSelf->wasmetal_core__DOT___051366_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051365_))));
    vlSelf->wasmetal_core__DOT___050253_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006114_))));
    vlSelf->wasmetal_core__DOT___050175_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0))))));
    vlSelf->wasmetal_core__DOT___050260_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050141_))));
    vlSelf->wasmetal_core__DOT___050138_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0))))));
    vlSelf->wasmetal_core__DOT___050164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050153_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050167_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050142_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050141_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127453___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003805_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___005770_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022667_ = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___001898_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002272_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002271_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb0eb761__0))))))));
    vlSelf->__VdfgTmp_h9934c93f__0 = (((IData)(vlSelf->wasmetal_core__DOT___002509_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002510_));
    vlSelf->wasmetal_core__DOT___002475_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xffff4444fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002510_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002509_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h703a7a56__0)))))))));
    vlSelf->wasmetal_core__DOT___002393_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he278c168__0)))))));
    vlSelf->wasmetal_core__DOT___050848_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0))))));
    vlSelf->__VdfgTmp_hbd292e75__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)))))));
    vlSelf->wasmetal_core__DOT___051346_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051345_))));
    vlSelf->__VdfgTmp_hb62f452d__0 = (((IData)(vlSelf->wasmetal_core__DOT___002324_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb54a817c__0));
    vlSelf->__VdfgTmp_h81d9e1ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___002730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002729_));
    vlSelf->__VdfgTmp_h0da24f1d__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                          ? (IData)(vlSelf->wasmetal_core__DOT___001850_)
                                          : (IData)(vlSelf->wasmetal_core__DOT___001849_)));
    vlSelf->__VdfgTmp_hfd6c95b6__0 = ((4U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hc6bfb5bb__0));
    vlSelf->__VdfgTmp_h5a517e30__0 = ((4U & ((IData)(
                                                     (0x33000f0055ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h89619cd0__0)))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h5e317429__0));
    vlSelf->wasmetal_core__DOT___049526_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0))))));
    vlSelf->wasmetal_core__DOT___049815_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0))))));
    vlSelf->wasmetal_core__DOT___049382_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb043089c__0))))));
    vlSelf->wasmetal_core__DOT___050849_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0))))));
    vlSelf->__VdfgTmp_hf09b90d7__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0)))))));
    vlSelf->wasmetal_core__DOT___049440_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0))))));
    vlSelf->wasmetal_core__DOT___049227_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0))))));
    vlSelf->wasmetal_core__DOT___051056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049884_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0))))));
    vlSelf->wasmetal_core__DOT___051288_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0))))));
    vlSelf->wasmetal_core__DOT___051326_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051325_))));
    vlSelf->wasmetal_core__DOT___051113_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051112_))));
    vlSelf->wasmetal_core__DOT___058694_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058692_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5e920d5f__0)))));
    vlSelf->wasmetal_core__DOT___017220_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017324_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017226_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017333_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017318_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017312_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017241_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057889_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023566_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023552_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023551_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023550_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048717_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023549_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___002113_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9be80f53__0))))))));
    vlSelf->wasmetal_core__DOT___018281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005738_))));
    vlSelf->wasmetal_core__DOT___018334_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    vlSelf->__VdfgTmp_h0073f5c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he9e11b30__0));
    vlSelf->wasmetal_core__DOT___010022_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_he9e11b30__0))))));
    vlSelf->wasmetal_core__DOT___002112_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048815_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002143_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002142_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1e7febb9__0))))))));
    vlSelf->wasmetal_core__DOT___002759_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xeULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hcf8aa4a8__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9be80f53__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1e7febb9__0)))))));
    vlSelf->wasmetal_core__DOT___049024_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049021_))));
    vlSelf->wasmetal_core__DOT___049450_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049248_))));
    vlSelf->__VdfgTmp_h94c83f35__0 = (((IData)(vlSelf->wasmetal_core__DOT___049360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049359_));
    vlSelf->__VdfgTmp_h3b672e02__0 = (((IData)(vlSelf->wasmetal_core__DOT___049081_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049125_));
    vlSelf->wasmetal_core__DOT___002075_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048831_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002106_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002105_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdf798121__0))))))));
    vlSelf->wasmetal_core__DOT___052690_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052687_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050365_))))));
    vlSelf->wasmetal_core__DOT___052703_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h568bee24__0))));
    vlSelf->wasmetal_core__DOT___002352_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048778_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002142_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002382_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hea3488cd__0))))))));
    if (vlSelf->wasmetal_core__DOT___000170_) {
        if (vlSelf->wasmetal_core__DOT___000169_) {
            vlSelf->wasmetal_core__DOT___002841_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_he2ba16db__0))));
            vlSelf->wasmetal_core__DOT___002680_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h95b0aa6a__0))));
            vlSelf->wasmetal_core__DOT___002641_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hc6bfb5bb__0))));
            vlSelf->wasmetal_core__DOT___002923_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7357dd51__0))));
            vlSelf->wasmetal_core__DOT___002593_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hd61aa5bc__0))));
            vlSelf->wasmetal_core__DOT___002316_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hb54a817c__0))));
        } else {
            vlSelf->wasmetal_core__DOT___002841_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hea3488cd__0))));
            vlSelf->wasmetal_core__DOT___002680_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002689_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002688_)))));
            vlSelf->wasmetal_core__DOT___002641_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002650_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002649_)))));
            vlSelf->wasmetal_core__DOT___002923_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002932_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002931_)))));
            vlSelf->wasmetal_core__DOT___002593_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001721_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___001720_)))));
            vlSelf->wasmetal_core__DOT___002316_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001337_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___001336_)))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___002841_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___002853_))));
        vlSelf->wasmetal_core__DOT___002680_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))))))));
        vlSelf->wasmetal_core__DOT___002641_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))))))));
        vlSelf->wasmetal_core__DOT___002923_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002933_)))));
        vlSelf->wasmetal_core__DOT___002593_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002601_)))));
        vlSelf->wasmetal_core__DOT___002316_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002324_)))));
    }
    vlSelf->wasmetal_core__DOT___002430_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048786_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002105_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002460_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae207145__0))))))));
    vlSelf->wasmetal_core__DOT___002392_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048770_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002382_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002225_)) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002688_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002689_)))))))));
    vlSelf->wasmetal_core__DOT___049042_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049040_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049039_))));
    vlSelf->wasmetal_core__DOT___049452_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049280_))));
    vlSelf->__VdfgTmp_hdfb5cdf6__0 = (((IData)(vlSelf->wasmetal_core__DOT___049352_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049351_));
    vlSelf->wasmetal_core__DOT___049491_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049071_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049078_))));
    vlSelf->wasmetal_core__DOT___002515_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048742_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002460_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___001770_)) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002649_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002650_)))))))));
    vlSelf->wasmetal_core__DOT___069651_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069647_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069645_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))))))));
    vlSelf->wasmetal_core__DOT___069718_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069714_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069713_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069712_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d)))))))));
    vlSelf->wasmetal_core__DOT___069740_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069735_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069734_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))))))));
    vlSelf->wasmetal_core__DOT___069762_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069758_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069757_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069756_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))))))));
    vlSelf->wasmetal_core__DOT___069783_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069779_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069778_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069777_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d)))))))));
    vlSelf->wasmetal_core__DOT___069805_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069799_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))))))));
    vlSelf->wasmetal_core__DOT___069827_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069823_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))))))));
    vlSelf->wasmetal_core__DOT___069972_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069968_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069967_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069966_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d)))))))));
    vlSelf->wasmetal_core__DOT___069992_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069988_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069986_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d)))))))));
    vlSelf->wasmetal_core__DOT___069411_ = (1U & (0xff4f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069407_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x70U 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0x7077000070777077ULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & vlSelf->insn_imm[2U]) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 5U))))))))) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048278_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))));
    vlSelf->wasmetal_core__DOT___069556_ = (1U & (0xff4f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069552_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x70U 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0x7077000070777077ULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & (vlSelf->insn_imm[2U] 
                                                                                >> 6U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 8U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU))))))))) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048278_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))));
    vlSelf->wasmetal_core__DOT___053365_ = (1U & (IData)(
                                                         (0x10ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053354_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052849_)))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9c6bfb0c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)))))))))));
    vlSelf->wasmetal_core__DOT___063469_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063464_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063477_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063472_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063485_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063493_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063488_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))))))));
    vlSelf->wasmetal_core__DOT___063501_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063496_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063509_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063504_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063517_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063512_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063460_ = (1U & (IData)(
                                                         (0xf3f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063452_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))))))))));
    vlSelf->wasmetal_core__DOT___063369_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063822_ = (1U & (IData)(
                                                         (0x33305550fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052902_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3cb924f__0))))))));
    vlSelf->wasmetal_core__DOT___050448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063398_ = (1U & (0x3050000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052906_)))))));
    vlSelf->__VdfgTmp_h3eb9c9bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050435_));
    vlSelf->wasmetal_core__DOT___063364_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063525_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))))))));
    vlSelf->wasmetal_core__DOT___063533_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063528_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063541_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063549_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063544_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063557_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063552_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))))))));
    vlSelf->wasmetal_core__DOT___063565_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063560_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063573_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063568_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063581_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063576_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 3U))))))));
    vlSelf->__VdfgTmp_h0f244854__0 = (((IData)(vlSelf->wasmetal_core__DOT___052659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050435_));
    vlSelf->wasmetal_core__DOT___063589_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063584_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))))))));
    vlSelf->wasmetal_core__DOT___063597_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063592_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063605_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063600_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063613_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063608_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 3U))))))));
    vlSelf->__VdfgTmp_hb0023997__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___050435_))) 
                                             << 1U)) 
                                      | (1U & (0xfeU 
                                               >> (
                                                   ((IData)(vlSelf->reset) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050389_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0)))))))));
    vlSelf->wasmetal_core__DOT___063621_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063616_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))))))));
    vlSelf->wasmetal_core__DOT___063629_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063624_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063637_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063632_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063645_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063653_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063648_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))))))));
    vlSelf->wasmetal_core__DOT___063661_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063669_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063664_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063677_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063672_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063685_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063680_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))))))));
    vlSelf->wasmetal_core__DOT___063693_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063688_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063701_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063709_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___019789_ = (1U & (IData)(
                                                         (0x23a0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052835_)))))))));
    vlSelf->wasmetal_core__DOT___070157_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070153_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d)))))))));
    vlSelf->wasmetal_core__DOT___070400_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x19U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___070097_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 3U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d)))))))));
    vlSelf->wasmetal_core__DOT___070170_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070165_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d)))))))));
    vlSelf->wasmetal_core__DOT___070184_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070180_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070179_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d)))))))));
    vlSelf->wasmetal_core__DOT___070245_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070241_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070240_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d)))))))));
    vlSelf->wasmetal_core__DOT___070274_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070270_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070269_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d)))))))));
    vlSelf->wasmetal_core__DOT___070286_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070282_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070281_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d)))))))));
    vlSelf->wasmetal_core__DOT___070298_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070294_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070293_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d)))))))));
    vlSelf->wasmetal_core__DOT___070324_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070320_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070319_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d)))))))));
    vlSelf->wasmetal_core__DOT___070336_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x14U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d)))))))));
    vlSelf->wasmetal_core__DOT___070348_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070344_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d)))))))));
    vlSelf->wasmetal_core__DOT___070376_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070372_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x17U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d)))))))));
    vlSelf->wasmetal_core__DOT___070388_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070384_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070383_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x18U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d)))))))));
    vlSelf->wasmetal_core__DOT___070413_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d)))))))));
    vlSelf->wasmetal_core__DOT___070425_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070421_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070420_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d)))))))));
    vlSelf->wasmetal_core__DOT___070438_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070434_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070433_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1cU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d)))))))));
    vlSelf->wasmetal_core__DOT___070450_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___040040_ = (1U & (0xbfb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071471_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy))))));
    vlSelf->wasmetal_core__DOT___040039_ = (1U & (0xa2aeaea2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q)))))));
    vlSelf->wasmetal_core__DOT___040030_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039983_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039978_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039997_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b3__05d)))))))));
    vlSelf->__VdfgTmp_h364b73f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052804_));
    vlSelf->wasmetal_core__DOT___050523_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049040_))));
    vlSelf->wasmetal_core__DOT___049277_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049275_))));
    vlSelf->__VdfgTmp_h6ae5baa5__0 = (((IData)(vlSelf->wasmetal_core__DOT___049608_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049352_));
    vlSelf->wasmetal_core__DOT___049073_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049072_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049071_))));
    vlSelf->wasmetal_core__DOT___055935_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055934_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055681_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055680_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055679_)))))))));
    vlSelf->wasmetal_core__DOT___019202_ = (1U & (IData)(
                                                         (0x554400000f0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055683_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048405_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055684_)))))))));
    vlSelf->wasmetal_core__DOT___055712_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055684_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055683_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127478___O 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___005989_))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                | (IData)(vlSelf->wasmetal_core__DOT___022853_)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022853_)));
    vlSelf->wasmetal_core__DOT___049867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (3U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O)))))));
    vlSelf->wasmetal_core__DOT___050485_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->__VdfgTmp_h1ac2f982__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___057679_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055059_))));
    vlSelf->wasmetal_core__DOT___055061_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055059_))));
    vlSelf->wasmetal_core__DOT___055928_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055927_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055654_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055653_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055652_)))))))));
    vlSelf->__VdfgTmp_hd9c0d0dd__0 = ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                              & (IData)(
                                                        (0xfff0ffff1111ffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001721_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001720_) 
                                                                    << 2U) 
                                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                         ? (IData)(vlSelf->wasmetal_core__DOT___001728_)
                                                                         : (IData)(vlSelf->wasmetal_core__DOT___001727_)) 
                                                                       << 1U) 
                                                                      | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                         & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001729_))))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (0xf00011U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he9d730e6__0))))));
    vlSelf->wasmetal_core__DOT___055917_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055916_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055597_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055596_)))))))));
    vlSelf->wasmetal_core__DOT___001251_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001337_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001336_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001344_)
                                                                             : (IData)(vlSelf->wasmetal_core__DOT___001343_)) 
                                                                           << 1U) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001495_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061711_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061708_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061706_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061705_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048435_)))))));
    vlSelf->wasmetal_core__DOT___055910_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055909_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055522_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055521_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055520_)))))))));
    vlSelf->wasmetal_core__DOT___061951_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055558_))));
    vlSelf->wasmetal_core__DOT___054546_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
    vlSelf->wasmetal_core__DOT___054547_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
    vlSelf->wasmetal_core__DOT___054548_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
    vlSelf->wasmetal_core__DOT___054549_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
    vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001370_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034408_));
    vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028857_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028489_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004448_));
    vlSelf->wasmetal_core__DOT___055903_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055902_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055502_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055501_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055500_)))))))));
    vlSelf->wasmetal_core__DOT___001948_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001964_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001963_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001343_)
                                                                             : (IData)(vlSelf->wasmetal_core__DOT___001859_)) 
                                                                           << 1U) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001342_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055891_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055890_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055431_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055430_)))))))));
    vlSelf->wasmetal_core__DOT___001899_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001935_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001934_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                                                ? 
                                                                               (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001723_)))))
                                                                                : 
                                                                               (0xecU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000666_)
                                                                                 ? (IData)(
                                                                                (0xf0055003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003269_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001937_)))))) 
                                                                              << 1U)) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001726_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001725_))))))))))))))))));
    vlSelf->__VdfgTmp_h51461c8e__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h07a6aef0__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001934_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001935_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hdb0eb761__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___055878_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055877_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055377_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055376_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055375_)))))))));
    vlSelf->wasmetal_core__DOT___049088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048976_))));
    vlSelf->wasmetal_core__DOT___048977_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048976_))));
    vlSelf->wasmetal_core__DOT___001808_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001854_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001853_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                                ? (IData)(vlSelf->wasmetal_core__DOT___001859_)
                                                                                : 
                                                                               (0xc05U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001339_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0ffccffaa000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003189_)))))))))))))) 
                                                                              << 1U)) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001341_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062062_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf89db412__0))))))));
    vlSelf->wasmetal_core__DOT___061941_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf4e23b72__0))))))));
    vlSelf->wasmetal_core__DOT___062118_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb017232__0))))))));
    vlSelf->wasmetal_core__DOT___062179_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde31b2d5__0))))))));
    vlSelf->wasmetal_core__DOT___061873_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7c4aea26__0))))))));
    vlSelf->wasmetal_core__DOT___061686_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054692_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054675_)))))))));
    vlSelf->wasmetal_core__DOT___061990_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3226e594__0))))))));
    vlSelf->wasmetal_core__DOT___061801_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h16ee9b67__0))))))));
    vlSelf->wasmetal_core__DOT___019200_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055872_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055337_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055336_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055335_)))))))));
    vlSelf->wasmetal_core__DOT___049106_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048965_))));
    vlSelf->wasmetal_core__DOT___048966_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048965_))));
    vlSelf->wasmetal_core__DOT___055196_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055192_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055040_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055019_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055020_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055022_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055039_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055038_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055037_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055051_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84a7ba42__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___049105_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048968_))));
    vlSelf->wasmetal_core__DOT___048969_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048968_))));
    vlSelf->wasmetal_core__DOT___055186_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055183_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054982_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054981_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054979_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054993_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054991_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055005_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6adb13e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048994_))));
    vlSelf->wasmetal_core__DOT___048995_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048994_))));
    vlSelf->wasmetal_core__DOT___055177_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055175_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x33330f0f00ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054941_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054955_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054954_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054953_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054952_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054963_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb52e5b74__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049101_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048991_))));
    vlSelf->wasmetal_core__DOT___048992_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048991_))));
    vlSelf->wasmetal_core__DOT___049201_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048986_))));
    vlSelf->wasmetal_core__DOT___048987_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048986_))));
    vlSelf->__VdfgTmp_h826c8569__0 = ((4U & ((0xe8U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4ea6bbba__0)) 
                                             << 2U)) 
                                      | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h563f0a85__0)) 
                                                << 1U)) 
                                         | (1U & (0x2bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h21594217__0)))));
    vlSelf->__VdfgTmp_h2a821aa8__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x69U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h21594217__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha753d377__0)))));
    vlSelf->__VdfgTmp_h4720a72d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha753d377__0)))));
    vlSelf->wasmetal_core__DOT___055147_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054859_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054880_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054879_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054877_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054856_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054870_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a768dd6__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049200_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048983_))));
    vlSelf->wasmetal_core__DOT___048984_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048983_))));
    vlSelf->wasmetal_core__DOT___049194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049193_))));
    vlSelf->wasmetal_core__DOT___049301_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049193_))));
    vlSelf->wasmetal_core__DOT___053516_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053514_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___049197_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049196_))));
    vlSelf->wasmetal_core__DOT___049302_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049196_))));
    vlSelf->wasmetal_core__DOT___049184_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049183_))));
    vlSelf->wasmetal_core__DOT___049295_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049183_))));
    vlSelf->wasmetal_core__DOT___002195_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048755_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                      & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001730_))))))))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002932_)))))))));
    vlSelf->wasmetal_core__DOT___049187_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049186_))));
    vlSelf->wasmetal_core__DOT___049296_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049186_))));
    vlSelf->wasmetal_core__DOT___001740_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048888_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                      & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001496_))))))))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002562_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002563_)))))))));
    vlSelf->wasmetal_core__DOT___049179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049178_))));
    vlSelf->wasmetal_core__DOT___049292_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049178_))));
    if (vlSelf->wasmetal_core__DOT___042177_) {
        vlSelf->wasmetal_core__DOT___042427_ = vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042451_ = vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042131_ = vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042199_ = vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042248_ = vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042272_ = vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042378_ = vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042332_ = vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___042427_ = vlSelf->wasmetal_core__DOT___042354_;
        vlSelf->wasmetal_core__DOT___042451_ = vlSelf->wasmetal_core__DOT___042387_;
        vlSelf->wasmetal_core__DOT___042131_ = vlSelf->wasmetal_core__DOT___042153_;
        vlSelf->wasmetal_core__DOT___042199_ = vlSelf->wasmetal_core__DOT___042208_;
        vlSelf->wasmetal_core__DOT___042248_ = vlSelf->wasmetal_core__DOT___042153_;
        vlSelf->wasmetal_core__DOT___042272_ = vlSelf->wasmetal_core__DOT___042208_;
        vlSelf->wasmetal_core__DOT___042378_ = vlSelf->wasmetal_core__DOT___042387_;
        vlSelf->wasmetal_core__DOT___042332_ = vlSelf->wasmetal_core__DOT___042354_;
    }
    vlSelf->wasmetal_core__DOT___063968_ = (1U & (IData)(
                                                         (0x40007fffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048304_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063967_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___042174_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___042173_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042177_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063965_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048368_)))))))));
    if (vlSelf->wasmetal_core__DOT___042095_) {
        vlSelf->wasmetal_core__DOT___042284_ = vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042307_ = vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042072_ = vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042106_ = vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042403_ = vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042391_ = vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042224_ = vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042212_ = vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___042284_ = vlSelf->wasmetal_core__DOT___042295_;
        vlSelf->wasmetal_core__DOT___042307_ = vlSelf->wasmetal_core__DOT___042317_;
        vlSelf->wasmetal_core__DOT___042072_ = vlSelf->wasmetal_core__DOT___042083_;
        vlSelf->wasmetal_core__DOT___042106_ = vlSelf->wasmetal_core__DOT___042116_;
        vlSelf->wasmetal_core__DOT___042403_ = vlSelf->wasmetal_core__DOT___042317_;
        vlSelf->wasmetal_core__DOT___042391_ = vlSelf->wasmetal_core__DOT___042295_;
        vlSelf->wasmetal_core__DOT___042224_ = vlSelf->wasmetal_core__DOT___042116_;
        vlSelf->wasmetal_core__DOT___042212_ = vlSelf->wasmetal_core__DOT___042083_;
    }
    vlSelf->wasmetal_core__DOT___012933_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012275_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056984_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012007_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012011_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___011752_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___013064_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057573_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012008_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056745_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___012012_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056730_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___011753_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011458_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___056374_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0)))));
    vlSelf->wasmetal_core__DOT___013040_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057571_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___049176_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049175_))));
    vlSelf->wasmetal_core__DOT___049291_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049175_))));
    vlSelf->wasmetal_core__DOT___051509_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051506_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051505_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005663_)))))));
    vlSelf->wasmetal_core__DOT___016296_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005663_))));
    vlSelf->wasmetal_core__DOT___049167_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049166_))));
    vlSelf->wasmetal_core__DOT___049315_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049166_))));
    vlSelf->wasmetal_core__DOT___063365_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7e6b8024__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56f16561__0))));
    vlSelf->wasmetal_core__DOT___052844_ = (1U & (IData)(
                                                         (0xf888000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052836_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h56f16561__0))))))));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___028091_)) 
                 & vlSelf->insn_x));
    vlSelf->wasmetal_core__DOT___061928_ = (1U & (0x60U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061907_)))));
    vlSelf->wasmetal_core__DOT___061919_ = (1U & (0xeee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061908_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061907_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaaaccccf0f0ff00ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061899_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061898_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ae2b9ea__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061653_)))))));
    vlSelf->wasmetal_core__DOT___011900_ = (1U & (IData)(
                                                         (0x33335555f0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011513_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011503_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127850___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026476_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026465_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026454_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026447_ = ((IData)(vlSelf->wasmetal_core__DOT___026479_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d));
    vlSelf->wasmetal_core__DOT___050458_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050406_)))));
    vlSelf->wasmetal_core__DOT___019785_ = (1U & (IData)(
                                                         (0xa03000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048518_)))))))));
    vlSelf->wasmetal_core__DOT___053502_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052655_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050446_)))));
    vlSelf->wasmetal_core__DOT___050464_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050405_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050404_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050403_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050402_)))))))));
    vlSelf->wasmetal_core__DOT___053543_ = (1U & (IData)(
                                                         (0x4040ff4000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050405_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050403_)))))))));
    vlSelf->wasmetal_core__DOT___050729_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049572_))));
    vlSelf->__VdfgTmp_hc497fe80__0 = (((IData)(vlSelf->wasmetal_core__DOT___049160_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049168_));
    vlSelf->wasmetal_core__DOT___050632_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050510_))));
    vlSelf->wasmetal_core__DOT___049465_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049317_))));
    vlSelf->wasmetal_core__DOT___052843_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052840_))));
    vlSelf->wasmetal_core__DOT___053506_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052841_)))))))));
    vlSelf->wasmetal_core__DOT___061866_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___061867_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061863_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x77707770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061855_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007417_)))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061831_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061830_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb587b232__0))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___061653_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061687_)))))))));
    vlSelf->wasmetal_core__DOT___061849_ = (1U & (0x60U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061838_)))));
    vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029126_));
    vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031045_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031012_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___050522_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049039_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049032_))));
    vlSelf->wasmetal_core__DOT___049284_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049279_))));
    vlSelf->__VdfgTmp_h249d4881__0 = (((IData)(vlSelf->wasmetal_core__DOT___049351_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049354_));
    vlSelf->wasmetal_core__DOT___049084_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049078_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049077_))));
    vlSelf->wasmetal_core__DOT___056191_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb57f307c__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_he4fe919e__0)))));
    vlSelf->wasmetal_core__DOT___056284_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___010261_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010273_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc43f9106__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010271_))))))));
    vlSelf->wasmetal_core__DOT___010219_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010254_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7edccd87__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010252_))))))));
    vlSelf->wasmetal_core__DOT___051706_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051613_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hb6137419__0))))))));
    vlSelf->wasmetal_core__DOT___051372_ = (1U & (0xc000aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((0xacU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049529_)))));
    vlSelf->wasmetal_core__DOT___062045_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaa33330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062035_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf0f3355U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xcaU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0))))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebd182eb__0))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee831718__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___053906_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___051689_)) 
                                                            << 1U))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               >> 1U))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))));
    vlSelf->wasmetal_core__DOT___051719_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051630_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___050828_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                              << 1U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049644_))));
    vlSelf->wasmetal_core__DOT___051586_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                              << 1U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___049041_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049031_))));
    vlSelf->wasmetal_core__DOT___050519_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049031_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049022_))));
    vlSelf->wasmetal_core__DOT___049451_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049282_))));
    vlSelf->wasmetal_core__DOT___049283_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049282_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049281_))));
    vlSelf->__VdfgTmp_h4d50854c__0 = (((IData)(vlSelf->wasmetal_core__DOT___049354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049353_));
    vlSelf->__VdfgTmp_h45e6cf8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049360_));
    vlSelf->wasmetal_core__DOT___049490_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049077_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049082_))));
    vlSelf->wasmetal_core__DOT___049083_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049081_))));
    vlSelf->wasmetal_core__DOT___012798_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hadb47ff7__0))))))));
    vlSelf->__VdfgTmp_h52f935f8__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d));
    vlSelf->__VdfgTmp_hcf7ded40__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011124_));
    vlSelf->wasmetal_core__DOT___011973_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d))))));
    vlSelf->__VdfgTmp_he13bfe6a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he89f377b__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he89f377b__0))))));
    vlSelf->wasmetal_core__DOT___056172_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009784_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                    : 
                                                   (0xffff0001U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009782_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009781_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009780_) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xfff00000eeeeULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))))))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009784_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009783_))))));
    vlSelf->__VdfgTmp_hf222e899__0 = (((IData)(vlSelf->wasmetal_core__DOT___009783_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeeeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009782_)));
    vlSelf->__VdfgTmp_h1a6962a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009783_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009782_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcb043302__0)))))));
    vlSelf->wasmetal_core__DOT___062046_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062031_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___062057_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062054_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x5533fffff0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057288_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057289_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057243_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057247_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057290_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062031_)))))))));
    vlSelf->wasmetal_core__DOT___050518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049021_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049014_))));
    vlSelf->wasmetal_core__DOT___049251_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049247_))));
    vlSelf->__VdfgTmp_h57526782__0 = (((IData)(vlSelf->wasmetal_core__DOT___049359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049358_));
    vlSelf->__VdfgTmp_hc0f91dc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___049125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049124_));
    vlSelf->wasmetal_core__DOT___062104_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061705_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___062124_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0xfff05550fff0333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf03fc3ad__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c7215cb__0)))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048419_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061705_)))))))));
    vlSelf->wasmetal_core__DOT___055974_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055972_))));
    vlSelf->__VdfgTmp_had4ae229__0 = ((2U & ((IData)(
                                                     (0xf0f0000aaccULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xbU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff4f400000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056308_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))))))))));
    vlSelf->wasmetal_core__DOT___071992_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xccccaaaaf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010528_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056324_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xccccaaaaf0f0ff00ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0))))))));
    vlSelf->wasmetal_core__DOT___012719_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0))));
    vlSelf->__VdfgTmp_ha8f305c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056379_));
    vlSelf->wasmetal_core__DOT___057011_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___056205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056196_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056195_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___056925_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___011197_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d))))));
    vlSelf->__VdfgTmp_h658ce6a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_ha7c061ef__0));
    vlSelf->wasmetal_core__DOT___056723_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffccaaaaf0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h929b802f__0))));
    vlSelf->wasmetal_core__DOT___011919_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff003355550f0fULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h929b802f__0))));
    vlSelf->wasmetal_core__DOT___010718_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                   ? 
                                                  (0x31U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0))
                                                   : 
                                                  (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010533_)))))));
    vlSelf->wasmetal_core__DOT___056433_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3820fb89__0))));
    vlSelf->__VdfgTmp_hb9280dfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h53247725__0));
    if (vlSelf->wasmetal_core__DOT___010323_) {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
    } else if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2d8d129__0)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2d8d129__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb7b9c3d6__0)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb7b9c3d6__0)));
    }
    vlSelf->__VdfgTmp_hf8199cb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h143507db__0));
    vlSelf->wasmetal_core__DOT___057066_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hafd3f22a__0))))))));
    vlSelf->__VdfgTmp_hbe17c4c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hafd3f22a__0)));
    vlSelf->__VdfgTmp_h00b060af__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0adc7ff6__0)));
    vlSelf->wasmetal_core__DOT___012177_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xaaaaccccff00fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0adc7ff6__0))))))));
    vlSelf->wasmetal_core__DOT___010187_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))));
    vlSelf->__VdfgTmp_h40926396__0 = (((IData)(vlSelf->wasmetal_core__DOT___049566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049849_));
    vlSelf->__VdfgTmp_hfc74b95b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049089_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049098_));
    vlSelf->wasmetal_core__DOT___049836_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048978_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049835_))));
    vlSelf->wasmetal_core__DOT___049459_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049263_))));
    vlSelf->__VdfgTmp_hca8ac9e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___012028_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010495_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h97dd8594__0)))))));
    vlSelf->wasmetal_core__DOT___061878_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff44ff00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f00003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055467_))))))))))));
    vlSelf->wasmetal_core__DOT___054846_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054844_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010045_)))))))));
    vlSelf->wasmetal_core__DOT___051354_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x503U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h79a3c79a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051690_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051689_))));
    vlSelf->wasmetal_core__DOT___012978_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he96324c1__0))))))));
    vlSelf->__VdfgTmp_hf1841993__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he96324c1__0)));
    vlSelf->wasmetal_core__DOT___056896_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))));
    vlSelf->wasmetal_core__DOT___012183_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))));
    vlSelf->wasmetal_core__DOT___056718_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xaaaaccccff00fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h18547ac4__0))))))));
    vlSelf->__VdfgTmp_hb67d963d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010102_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h724ed7d2__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010893_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde094a0f__0))))));
    vlSelf->__VdfgTmp_h6a02124a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056427_));
    vlSelf->__VdfgTmp_hcba8f5cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h45be7681__0 = (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010338_));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010338_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hfa355bbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d 
        = (1U & (IData)((0x11110000000fULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h86da9f86__0))))));
    vlSelf->wasmetal_core__DOT___055118_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054772_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054786_)))))))));
    vlSelf->wasmetal_core__DOT___011198_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010194_)) 
                                                  & (IData)(
                                                            (0xffffff11fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1b8b64b8__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h1b8b64b8__0))));
    vlSelf->wasmetal_core__DOT___011898_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8472195__0))));
    vlSelf->wasmetal_core__DOT___012992_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010518_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25073b9c__0)))))));
    vlSelf->wasmetal_core__DOT___057557_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hddfbd8d3__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010523_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010414_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h304fb1ba__0))))));
    vlSelf->__VdfgTmp_h6748fbc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010242_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010241_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d 
        = (1U & (IData)((0x11110000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010242_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010241_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb5f0d294__0))))))));
    vlSelf->wasmetal_core__DOT___012991_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010500_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc09bd195__0)))))));
    vlSelf->__VdfgTmp_ha4e3e772__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)));
    vlSelf->wasmetal_core__DOT___056500_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011017_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011122_)));
    vlSelf->wasmetal_core__DOT___010209_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010208_))
                                                   : (IData)(
                                                             (0xff00ff00fffefff0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010208_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf939f2bf__0))))))));
}
