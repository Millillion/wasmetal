#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__7(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__7\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___026135_;
    wasmetal_core__DOT___026135_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027710_;
    wasmetal_core__DOT___027710_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029191_;
    wasmetal_core__DOT___029191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029291_;
    wasmetal_core__DOT___029291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029352_;
    wasmetal_core__DOT___029352_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029653_;
    wasmetal_core__DOT___029653_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029822_;
    wasmetal_core__DOT___029822_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029883_;
    wasmetal_core__DOT___029883_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029991_;
    wasmetal_core__DOT___029991_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030565_;
    wasmetal_core__DOT___030565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030756_;
    wasmetal_core__DOT___030756_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031592_;
    wasmetal_core__DOT___031592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031714_;
    wasmetal_core__DOT___031714_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032073_;
    wasmetal_core__DOT___032073_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032164_;
    wasmetal_core__DOT___032164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034761_;
    wasmetal_core__DOT___034761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034894_;
    wasmetal_core__DOT___034894_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035022_;
    wasmetal_core__DOT___035022_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063122_;
    wasmetal_core__DOT___063122_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063128_;
    wasmetal_core__DOT___063128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063134_;
    wasmetal_core__DOT___063134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063140_;
    wasmetal_core__DOT___063140_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128198___O;
    wasmetal_core__DOT____Vcellout___128198___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128199___O;
    wasmetal_core__DOT____Vcellout___128199___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128361___O;
    wasmetal_core__DOT____Vcellout___128361___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128449___O;
    wasmetal_core__DOT____Vcellout___128449___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128517___S;
    wasmetal_core__DOT____Vcellinp___128517___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128579___O;
    wasmetal_core__DOT____Vcellout___128579___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128712___O;
    wasmetal_core__DOT____Vcellout___128712___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128713___O;
    wasmetal_core__DOT____Vcellout___128713___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h169b252f__0;
    __VdfgTmp_h169b252f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ceb6137__0;
    __VdfgTmp_h3ceb6137__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___031803_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031798_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031794_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031790_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031785_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031781_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031776_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031772_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031768_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031763_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031759_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031754_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031750_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031746_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha1f5c117__0))));
    vlSelf->wasmetal_core__DOT___031802_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031797_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031793_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031788_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031784_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031780_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031775_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031771_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031766_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031762_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031758_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031753_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031749_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031808_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf3cdd6fc__0))));
    vlSelf->wasmetal_core__DOT___031801_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031796_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031792_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031787_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031783_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031779_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031774_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031770_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031765_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031761_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031757_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031752_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031748_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT___031807_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf01f7256__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128587___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0));
    if (vlSelf->wasmetal_core__DOT__sp__05b12__05d) {
        wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
    } else {
        wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031875_;
        wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033910_;
        wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032932_;
    }
    vlSelf->wasmetal_core__DOT___053083_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053062_))));
    vlSelf->wasmetal_core__DOT___053066_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053064_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053063_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053062_)))));
    vlSelf->wasmetal_core__DOT___053065_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053063_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053048_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053049_)))));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031968_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___062628_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 1U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062619_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062639_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 2U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062631_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062650_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 3U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062642_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062661_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 4U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062653_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O))))))));
    vlSelf->wasmetal_core__DOT___062672_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 5U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062664_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062683_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 6U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062675_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062694_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 7U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062610_ = (1U & (IData)(
                                                         (0xb0b0b000ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062609_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062603_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052645_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048279_))))))))))));
    vlSelf->wasmetal_core__DOT___053261_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051210_))));
    vlSelf->wasmetal_core__DOT___051218_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051210_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h66357502__0)))))));
    vlSelf->wasmetal_core__DOT___053247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    if (vlSelf->wasmetal_core__DOT__sp__05b13__05d) {
        wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
    } else {
        wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032611_;
        wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___034181_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))));
    vlSelf->wasmetal_core__DOT___034180_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d))));
    vlSelf->wasmetal_core__DOT___034179_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))));
    vlSelf->wasmetal_core__DOT___034178_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___056274_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___033033_)))));
    vlSelf->wasmetal_core__DOT___008495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___008500_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___008017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___007208_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)))));
    vlSelf->wasmetal_core__DOT___063468_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___063476_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___063484_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O))));
    vlSelf->wasmetal_core__DOT____Vcellout___128723___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128723___S) 
           ^ (((4U & (((IData)(vlSelf->wasmetal_core__DOT___003029_)
                        ? (IData)(vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__)
                        : (~ (IData)(vlSelf->wasmetal_core__DOT___003029_))) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035237_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128725___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128725___S) 
           ^ (((4U & (((IData)(vlSelf->wasmetal_core__DOT___003029_)
                        ? (IData)(vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__)
                        : (~ (IData)(vlSelf->wasmetal_core__DOT___003029_))) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035253_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134178___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128723___S) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___003029_)) 
                       | (IData)(vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___036925_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134191___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128725___S) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___003029_)) 
                       | (IData)(vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___037030_)));
    vlSelf->wasmetal_core__DOT___042682_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___042595_)
                                                      ? 
                                                     ((1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hdc23a011__0)))
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___042687_) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___042591_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___042683_))
                                                      : 
                                                     (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___042590_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___070632_))))));
    vlSelf->wasmetal_core__DOT___048117_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042722_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042534_))));
    vlSelf->wasmetal_core__DOT___042642_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042646_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042643_))))));
    vlSelf->wasmetal_core__DOT___042693_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042697_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042694_))))));
    vlSelf->wasmetal_core__DOT___042713_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042606_)
                                                         ? 
                                                        (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                                         : 
                                                        (0xeU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___070631_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___042694_))))))));
    vlSelf->wasmetal_core__DOT___042704_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042707_))));
    vlSelf->wasmetal_core__DOT___042739_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042636_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042740_))))));
    vlSelf->wasmetal_core__DOT___016504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042626_))));
    vlSelf->wasmetal_core__DOT___042749_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042626_))));
    if (vlSelf->wasmetal_core__DOT___042539_) {
        vlSelf->wasmetal_core__DOT___042612_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042554_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042622_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042564_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042601_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042632_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
    } else if (vlSelf->wasmetal_core__DOT___042542_) {
        if (vlSelf->wasmetal_core__DOT___042541_) {
            if (vlSelf->wasmetal_core__DOT___042536_) {
                vlSelf->wasmetal_core__DOT___042612_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042554_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042622_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042564_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042601_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042632_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
            } else {
                vlSelf->wasmetal_core__DOT___042612_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042616_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042643_))));
                vlSelf->wasmetal_core__DOT___042554_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042558_)
                              ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                              : (IData)(vlSelf->wasmetal_core__DOT___042555_)));
                vlSelf->wasmetal_core__DOT___042622_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042626_)
                              ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042673_))));
                vlSelf->wasmetal_core__DOT___042564_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042570_) 
                             | (IData)(vlSelf->wasmetal_core__DOT___042566_)));
                vlSelf->wasmetal_core__DOT___042601_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042606_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042704_))));
                vlSelf->wasmetal_core__DOT___042632_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042636_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042749_))));
            }
        } else {
            vlSelf->wasmetal_core__DOT___042612_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042554_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042622_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042564_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042601_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042632_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___042612_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042554_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042622_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042564_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042601_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042632_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
    }
    vlSelf->wasmetal_core__DOT___042731_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042676_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042673_))))));
    vlSelf->wasmetal_core__DOT___042672_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042676_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042673_))))));
    vlSelf->wasmetal_core__DOT___042662_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042570_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042664_))))));
    vlSelf->wasmetal_core__DOT___042652_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042656_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042653_))))));
    vlSelf->wasmetal_core__DOT___036753_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036785_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5736dc67__0))));
    vlSelf->wasmetal_core__DOT___053586_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031356_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031323_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___062696_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))))));
    vlSelf->wasmetal_core__DOT___062707_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062718_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062729_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT____Vcellinp___128517___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 2U))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O));
        wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O));
        wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O));
    } else {
        wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___135425___DOT__Mr = 
        (0x7ffffffffffULL & VL_MULS_QQQ(43, (0x7ffffffffffULL 
                                             & VL_EXTENDS_QI(43,25, 
                                                             (0x1ffffffU 
                                                              & (vlSelf->insn_y 
                                                                 >> 0x11U)))), 
                                        (0x7ffffffffffULL 
                                         & VL_EXTENDS_QI(43,18, vlSelf->wasmetal_core__DOT____Vcellinp___135426___B))));
    vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0xdU) & (IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x2000U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 0xdU) : (IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128005___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128037___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128158___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128191___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128208___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128373___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128421___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128277___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128225___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128215___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029916_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029915_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029945_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029944_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029911_)))));
    wasmetal_core__DOT___029883_ = ((IData)(vlSelf->wasmetal_core__DOT___029916_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128484___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032868_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032867_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032897_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032896_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032863_)))));
    vlSelf->wasmetal_core__DOT___032836_ = ((IData)(vlSelf->wasmetal_core__DOT___032868_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128949___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127997___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128198___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029747_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029746_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029776_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029775_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029742_)))));
    vlSelf->wasmetal_core__DOT___029714_ = ((IData)(vlSelf->wasmetal_core__DOT___029747_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128198___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128165___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029384_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029383_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029413_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029412_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029379_)))));
    wasmetal_core__DOT___029352_ = ((IData)(vlSelf->wasmetal_core__DOT___029384_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128012___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027803_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027802_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027832_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027831_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027798_)))));
    vlSelf->wasmetal_core__DOT___027771_ = ((IData)(vlSelf->wasmetal_core__DOT___027803_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d));
    vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0xdU) & (IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128149___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029252_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029251_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029218_)))));
    wasmetal_core__DOT___029191_ = ((IData)(vlSelf->wasmetal_core__DOT___029223_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d));
    wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128021___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (vlSelf->function_params >> 0xdU)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128428___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032196_) 
             << 3U) | (IData)(vlSelf->__VdfgTmp_he13e3256__0)) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032191_)))));
    wasmetal_core__DOT___032164_ = ((IData)(vlSelf->wasmetal_core__DOT___032196_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128468___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032676_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032675_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032705_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032704_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032671_)))));
    vlSelf->wasmetal_core__DOT___032644_ = ((IData)(vlSelf->wasmetal_core__DOT___032676_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134210___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037186_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037185_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037214_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037182_)))));
    vlSelf->wasmetal_core__DOT___037155_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037186_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h68654253__0))));
    wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034696_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128712___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035086_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035147_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035146_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035081_)))));
    wasmetal_core__DOT___035022_ = ((IData)(vlSelf->wasmetal_core__DOT___035086_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d));
    wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127836___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026263_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026262_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026292_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026291_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026258_)))));
    vlSelf->wasmetal_core__DOT___026231_ = ((IData)(vlSelf->wasmetal_core__DOT___026263_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127836___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127828___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026167_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026166_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026196_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026195_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026162_)))));
    wasmetal_core__DOT___026135_ = ((IData)(vlSelf->wasmetal_core__DOT___026167_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127844___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026359_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026358_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026388_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026387_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026354_)))));
    vlSelf->wasmetal_core__DOT___026327_ = ((IData)(vlSelf->wasmetal_core__DOT___026359_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d));
    wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032832_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032799_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O)));
    wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128501___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030809_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d));
    wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128337___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128361___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063100_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063097_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063106_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063104_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063103_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063112_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063110_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063109_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063118_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063116_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063115_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128213___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128354___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032536_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128449___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032536_))));
    wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128536___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___053078_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053066_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053073_)))));
    vlSelf->wasmetal_core__DOT___062616_ = (1U & (IData)(
                                                         (0xf0f033aa00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff8fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062610_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062601_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053989_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->cmd_aux))))))))));
    vlSelf->wasmetal_core__DOT___052656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128290___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___030722_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___030721_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030714_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___031960_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b4__05d) {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030679_;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030714_;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031960_;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b14__05d) {
        wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
    } else {
        wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b15__05d) {
        wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___031879_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___033914_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___032936_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
    } else {
        wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031879_ = wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033914_ = wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032936_ = wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034178_) 
           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d));
    vlSelf->wasmetal_core__DOT___007693_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008495_)))));
    vlSelf->wasmetal_core__DOT___010101_ = (1U & (0xf004444U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008495_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008500_)))))));
    vlSelf->wasmetal_core__DOT___007235_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008500_)))));
    vlSelf->wasmetal_core__DOT___007234_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053782_))));
    vlSelf->wasmetal_core__DOT___007204_ = ((IData)(vlSelf->wasmetal_core__DOT___007208_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___007197_)) 
                                               | (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007196_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007207_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007193_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007192_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007195_))))))))));
    vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b5__05d) {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___047991_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042587_))));
    vlSelf->__VdfgTmp_h08bc6edf__0 = (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042612_));
    vlSelf->wasmetal_core__DOT___048118_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048117_)))));
    vlSelf->wasmetal_core__DOT___042703_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042707_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042704_))))));
    vlSelf->wasmetal_core__DOT___048121_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042554_))));
    vlSelf->wasmetal_core__DOT___048130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042576_))));
    vlSelf->wasmetal_core__DOT___042748_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042626_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042749_))))));
    vlSelf->__VdfgTmp_h4702c863__0 = (((IData)(vlSelf->wasmetal_core__DOT___042731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042622_));
    vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036786_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036753_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0))));
    vlSelf->wasmetal_core__DOT___062989_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062974_))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031357_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___062697_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062695_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062708_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062707_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062706_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062719_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062718_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062717_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062730_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062729_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062728_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128517___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128517___S) 
           ^ (((IData)(wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128517___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033129_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        vlSelf->wasmetal_core__DOT___033133_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033227_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033999_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033133_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128517___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033227_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033999_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128525___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128517___S) 
           ^ (((IData)(wasmetal_core__DOT___128525___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128525___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033223_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128602___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128517___S) 
           ^ (((IData)(wasmetal_core__DOT___128602___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128602___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033995_)))));
    vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0xeU) & (IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x4000U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 0xeU) : (IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)
            : (IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d)
            : (IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)
            : (IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029917_)
            ? (IData)(wasmetal_core__DOT___029883_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032869_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032836_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128950___Q) 
           & (IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128198___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063151_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128198___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063157_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128198___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063163_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128198___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029748_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029714_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d));
    wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029385_)
            ? (IData)(wasmetal_core__DOT___029352_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d));
    vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027804_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027771_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b16__05d) {
        wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___032615_ = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
    } else {
        wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032615_ = wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031879_;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033914_;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032936_;
    }
    vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0xeU) & (IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029224_)
            ? (IData)(wasmetal_core__DOT___029191_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d));
    wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
           & (IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0xeU)) & (IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045539_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___045551_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                             >> 2U))))))))));
    wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032197_)
            ? (IData)(wasmetal_core__DOT___032164_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___070640_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032677_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032644_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037187_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037155_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h638a3747__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128679___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034697_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034696_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034691_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034680_)))) 
           ^ (((IData)(wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034733_)))));
    wasmetal_core__DOT___034761_ = ((IData)(vlSelf->wasmetal_core__DOT___034697_) 
                                    & (IData)(wasmetal_core__DOT___128679___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034638_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128712___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___034637_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128712___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d)))));
    vlSelf->wasmetal_core__DOT___034699_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128712___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___034698_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128712___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d)))));
    wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035087_)
            ? (IData)(wasmetal_core__DOT___035022_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128696___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034953_)))));
    wasmetal_core__DOT___034894_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)) 
                                    & (IData)(wasmetal_core__DOT___128696___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127837___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026264_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026231_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d));
    wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026168_)
            ? (IData)(wasmetal_core__DOT___026135_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d));
    vlSelf->wasmetal_core__DOT___063519_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063527_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063535_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063543_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___054493_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054495_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054497_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054499_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026327_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d));
    wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032833_)
                  ? (IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                     >> 1U)));
    wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)
            : (IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128298___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030820_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030809_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030798_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030787_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT___030756_ = ((IData)(vlSelf->wasmetal_core__DOT___030820_)
                                     ? (IData)(wasmetal_core__DOT___128298___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d));
    wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)
            : (IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)
            : (IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032541_)
                  ? (IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032541_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128378___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031778_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031767_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031756_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031745_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT___031714_ = ((IData)(vlSelf->wasmetal_core__DOT___031778_)
                                     ? (IData)(wasmetal_core__DOT___128378___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d));
    vlSelf->__VdfgTmp_h261f62de__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h015c016b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                             >> 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128570___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
           & (IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128402___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___031968_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___031967_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___063457_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O))));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034179_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    vlSelf->__VdfgTmp_h5812bf47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007234_));
    vlSelf->wasmetal_core__DOT____Vcellout___128180___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___029608_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b6__05d) {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___058528_ = (1U & (0xf44U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff007fffffffffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___058525_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)))))))))) 
                                                             << 1U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb9f44c2b__0)))))))))))));
    vlSelf->wasmetal_core__DOT___047992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042564_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___042662_)))));
    vlSelf->wasmetal_core__DOT___048119_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042601_))));
    vlSelf->wasmetal_core__DOT___047995_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042564_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042601_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042703_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042693_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___042554_)))))));
    vlSelf->wasmetal_core__DOT___017940_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048130_)))));
    vlSelf->wasmetal_core__DOT___048131_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042748_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042632_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4702c863__0)))));
    vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036787_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h20c332a4__0))));
    vlSelf->wasmetal_core__DOT___062992_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___062989_)))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___062705_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 8U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062697_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))));
    vlSelf->wasmetal_core__DOT___062716_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 9U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062708_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062727_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xaU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062719_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062738_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xbU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062730_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033133_));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033227_));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033999_));
    }
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128029___O 
        = (0xfU & ((vlSelf->insn_z >> 0xcU) ^ (((IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__2__KET__) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__1__KET__) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__0__KET__) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___027931_))))));
    vlSelf->wasmetal_core__DOT___027935_ = ((vlSelf->insn_z 
                                             >> 0xfU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128269___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0xfU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0xeU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0xdU)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030466_)))));
    vlSelf->wasmetal_core__DOT___030470_ = (1U & ((0x8000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0xfU)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128005___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128005___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027706_)))));
    wasmetal_core__DOT___027710_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128005___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128037___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he965b193__0))) 
           ^ (((IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128037___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027996_)))));
    vlSelf->wasmetal_core__DOT___028000_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d) 
                                            & (IData)(wasmetal_core__DOT___128037___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128158___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h950b0747__0))) 
           ^ (((IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128158___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029287_)))));
    wasmetal_core__DOT___029291_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128158___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128191___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128191___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029649_)))));
    wasmetal_core__DOT___029653_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128191___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128208___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128208___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029818_)))));
    wasmetal_core__DOT___029822_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128208___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128373___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128373___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031588_)))));
    wasmetal_core__DOT___031592_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128373___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128421___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128421___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032069_)))));
    wasmetal_core__DOT___032073_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128421___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128277___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128277___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030561_)))));
    wasmetal_core__DOT___030565_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128277___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128225___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128225___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029987_)))));
    wasmetal_core__DOT___029991_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d) 
                                    & (IData)(wasmetal_core__DOT___128225___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029918_)
            ? (IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032870_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127997___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128951___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128950___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128949___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128948___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127997___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027641_)))));
    vlSelf->wasmetal_core__DOT___027645_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128951___Q) 
                                            & (IData)(wasmetal_core__DOT___127997___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029749_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d));
    wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029386_)
            ? (IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d));
    vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027805_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128258___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128258___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128258___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030349_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b17__05d) {
        vlSelf->wasmetal_core__DOT___030353_ = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030353_ = wasmetal_core__DOT___128258___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032615_;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128053___O 
        = (0xfU & ((vlSelf->insn_x >> 0xcU) ^ (((IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__2__KET__) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__1__KET__) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__0__KET__) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___028157_))))));
    vlSelf->wasmetal_core__DOT___028161_ = ((vlSelf->insn_x 
                                             >> 0xfU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029225_)
            ? (IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128021___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha938949d__0))) 
           ^ (((IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128021___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027867_)))));
    vlSelf->wasmetal_core__DOT___027871_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                            & (IData)(wasmetal_core__DOT___128021___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128317___O 
        = (((8U & ((~ (vlSelf->function_params >> 0xfU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0xeU)) 
                                     << 2U)) | ((2U 
                                                 & (vlSelf->function_params 
                                                    >> 0xcU)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0xcU)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030948_)))));
    vlSelf->wasmetal_core__DOT___030952_ = ((~ (vlSelf->function_params 
                                                >> 0xfU)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032198_)
            ? (IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___070642_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070640_)))))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032678_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037188_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__0__KET__)
                  : (9U >> (IData)(vlSelf->__VdfgTmp_h629179e3__0))));
    wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034698_) 
           & (IData)(wasmetal_core__DOT___034761_));
    wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035088_)
            ? (IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d));
    wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)) 
           & (IData)(wasmetal_core__DOT___034894_));
    wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026265_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127837___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d));
    wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026169_)
            ? (IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d));
    vlSelf->wasmetal_core__DOT___063520_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063519_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063528_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063527_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063536_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063535_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063544_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063543_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___054494_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054493_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054496_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054495_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054498_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054497_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054500_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054499_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026361_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d));
    wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032803_)
                  ? (IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128501___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128501___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032965_)))));
    vlSelf->wasmetal_core__DOT___032969_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)
                                             : (IData)(wasmetal_core__DOT___128501___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030831_)
            ? (IData)(wasmetal_core__DOT___030756_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128337___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___031214_)))) 
           ^ (((IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128337___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031139_)))));
    vlSelf->wasmetal_core__DOT___031167_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___128337___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128361___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031502_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128361___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031427_)))));
    vlSelf->wasmetal_core__DOT___031455_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___128361___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128449___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032542_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032541_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032536_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032525_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128449___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032450_)))));
    vlSelf->wasmetal_core__DOT___032478_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032542_)
                                                   ? (IData)(wasmetal_core__DOT___128449___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032542_))));
    wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031789_)
            ? (IData)(wasmetal_core__DOT___031714_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d));
    vlSelf->__VdfgTmp_h3321aa0d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h7a9a4b36__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                               >> 3U)));
    wasmetal_core__DOT____Vcellout___128579___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
           & (IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128397___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128397___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128397___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128397___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031875_)))));
    vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128461___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128461___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128461___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128461___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032611_)))));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034180_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d));
    vlSelf->__VdfgTmp_hc2fc9f8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5812bf47__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128283___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030679_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b7__05d) {
        vlSelf->wasmetal_core__DOT___030683_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___030718_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___031964_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030683_ = vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030718_ = wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031964_ = vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___048132_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048130_))));
    vlSelf->wasmetal_core__DOT___047994_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x77707770777ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___042672_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042576_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___042534_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___042652_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042554_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047992_))));
    vlSelf->wasmetal_core__DOT___048125_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128723___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((0xff7f7fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134178___O) 
                                                                         << 2U)) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134191___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h08bc6edf__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128725___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017176_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128723___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xff7f7fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134178___O) 
                                                                         << 3U)) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134191___O) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h08bc6edf__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128725___O))))))));
    vlSelf->wasmetal_core__DOT___017171_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff07770777ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                                >> 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                                >> 3U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___017186_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff07770777ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                                >> 2U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017924_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x777U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O))))))));
    vlSelf->wasmetal_core__DOT___017185_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((0x777U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02ewide = (1U 
                                                & (0xff4f4fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x77770007U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h4702c863__0))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xfffdf3ffffffffffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048210_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003033_)))))))))))))));
    vlSelf->wasmetal_core__DOT___032034_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047995_))));
    vlSelf->wasmetal_core__DOT___032033_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047995_))));
    wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036757_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h86617c98__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128347___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031359_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031358_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031357_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031356_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031323_)))));
    vlSelf->wasmetal_core__DOT___031327_ = ((IData)(vlSelf->wasmetal_core__DOT___031359_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128596___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128596___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128596___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128596___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033910_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))) {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128493___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128493___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128493___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128493___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032932_)))));
    vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x10U) & (IData)(vlSelf->wasmetal_core__DOT___027935_));
    vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x10000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x10U)
                  : (IData)(vlSelf->wasmetal_core__DOT___030470_)));
    wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d) 
           & (IData)(wasmetal_core__DOT___027710_));
    vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028000_));
    wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029291_));
    wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029653_));
    wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029822_));
    wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d)
            : (IData)(wasmetal_core__DOT___031592_));
    wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d)
            : (IData)(wasmetal_core__DOT___032073_));
    vlSelf->wasmetal_core__DOT___039835_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xaU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039836_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xbU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039837_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xcU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039851_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)))))));
    wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)
            : (IData)(wasmetal_core__DOT___030565_));
    vlSelf->wasmetal_core__DOT___039806_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039795_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039413_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039789_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d)))))))));
    wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d) 
           & (IData)(wasmetal_core__DOT___029991_));
    wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029919_)
            ? (IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032871_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128952___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027645_));
    vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029750_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d));
    wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029387_)
            ? (IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d));
    wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027806_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d));
    vlSelf->wasmetal_core__DOT___062761_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062772_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062783_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062794_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    if (vlSelf->wasmetal_core__DOT__sp__05b18__05d) {
        vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030353_;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x10U) & (IData)(vlSelf->wasmetal_core__DOT___028161_));
    wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029226_)
            ? (IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d));
    vlSelf->wasmetal_core__DOT___128022___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027871_));
    vlSelf->wasmetal_core__DOT___044762_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                        << 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0xcU)))))))));
    vlSelf->wasmetal_core__DOT___044774_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 9U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128316___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0xbU))))))))));
    vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x10U)) & (IData)(vlSelf->wasmetal_core__DOT___030952_));
    wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032199_)
            ? (IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___044807_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070642_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___044795_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070640_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O))))))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032679_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037189_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h558b9029__0))));
    wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034699_) 
           & (IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035089_)
            ? (IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d));
    wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)) 
           & (IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026266_)
            ? (IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d));
    wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026170_)
            ? (IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026362_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128476___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032804_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032803_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032833_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032832_)))) 
           ^ (((IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032799_)))));
    vlSelf->wasmetal_core__DOT___032772_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032804_)
                                                   ? (IData)(wasmetal_core__DOT___128476___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032808_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032807_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032806_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032805_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O)))));
    vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032969_));
    wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030842_)
            ? (IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d));
    vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031167_));
    vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031455_));
    wasmetal_core__DOT___063122_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128449___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063128_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128449___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063134_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128449___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063140_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128449___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032543_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032478_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032543_))));
    wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031800_)
            ? (IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d));
    __VdfgTmp_h3ceb6137__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___128579___O)) 
                              | (1U & ((IData)(wasmetal_core__DOT____Vcellout___128579___O) 
                                       >> 2U)));
    __VdfgTmp_h169b252f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                     >> 2U)) | (1U 
                                                & (IData)(wasmetal_core__DOT____Vcellout___128579___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128588___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b13__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128171___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___029502_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034151_ = ((IData)(vlSelf->wasmetal_core__DOT___034181_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128623___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034181_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034180_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034179_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034178_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___063492_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___063500_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___063508_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___063516_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029608_));
    if (vlSelf->wasmetal_core__DOT__sp__05b8__05d) {
        vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030683_;
        vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030718_;
    }
    vlSelf->wasmetal_core__DOT___058549_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___018306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___018178_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048131_))));
    vlSelf->wasmetal_core__DOT___063439_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->__VdfgTmp_h2a482fa4__0 = (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048486_));
    vlSelf->wasmetal_core__DOT___048115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___047996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___048397_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___048128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048125_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017176_))));
    vlSelf->__VdfgTmp_h8bd952af__0 = (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_));
    vlSelf->__VdfgTmp_he1590a3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017185_));
    vlSelf->__VdfgTmp_h10c9b581__0 = (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_));
    vlSelf->wasmetal_core__DOT___019044_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018382_))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032033_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134153___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036758_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036757_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036787_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036786_)))) 
           ^ (((IData)(wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036753_)))));
    vlSelf->wasmetal_core__DOT___036726_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036758_)
                                                   ? (IData)(wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031327_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___062740_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))))));
    vlSelf->wasmetal_core__DOT___062751_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062762_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062773_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128518___S 
        = ((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                      >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                << 2U)) 
                                         | ((2U & (
                                                   (~ 
                                                    ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                     >> 3U)) 
                                                   << 1U)) 
                                            | (1U & 
                                               (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                   >> 2U))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O));
    } else {
        vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x11U) & (IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x20000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x11U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d)
            : (IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d)
            : (IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)
            : (IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d) 
           & (IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128216___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029920_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029919_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029918_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029917_)))) 
           ^ (((IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029883_)))));
    vlSelf->wasmetal_core__DOT___029887_ = ((IData)(vlSelf->wasmetal_core__DOT___029920_)
                                             ? (IData)(wasmetal_core__DOT___128216___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128485___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032872_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032871_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032870_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032869_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032836_)))));
    vlSelf->wasmetal_core__DOT___032840_ = ((IData)(vlSelf->wasmetal_core__DOT___032872_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128953___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128199___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029751_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029750_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029749_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029748_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029714_)))));
    vlSelf->wasmetal_core__DOT___029718_ = ((IData)(vlSelf->wasmetal_core__DOT___029751_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128166___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029388_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029387_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029386_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029385_)))) 
           ^ (((IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029352_)))));
    vlSelf->wasmetal_core__DOT___029356_ = ((IData)(vlSelf->wasmetal_core__DOT___029388_)
                                             ? (IData)(wasmetal_core__DOT___128166___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128013___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027807_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027806_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027805_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027804_)))) 
           ^ (((IData)(wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027771_)))));
    vlSelf->wasmetal_core__DOT___027775_ = ((IData)(vlSelf->wasmetal_core__DOT___027807_)
                                             ? (IData)(wasmetal_core__DOT___128013___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b19__05d) {
        wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
    } else {
        wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x11U) & (IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128150___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029227_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029226_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029225_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029224_)))) 
           ^ (((IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029191_)))));
    vlSelf->wasmetal_core__DOT___029195_ = ((IData)(vlSelf->wasmetal_core__DOT___029227_)
                                             ? (IData)(wasmetal_core__DOT___128150___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d));
    wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128022___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x11U)) & (IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128429___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032200_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032199_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032198_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032197_)))) 
           ^ (((IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032164_)))));
    vlSelf->wasmetal_core__DOT___032168_ = ((IData)(vlSelf->wasmetal_core__DOT___032200_)
                                             ? (IData)(wasmetal_core__DOT___128429___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128469___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032680_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_haf0d31b4__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032644_)))));
    vlSelf->wasmetal_core__DOT___032648_ = ((IData)(vlSelf->wasmetal_core__DOT___032680_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134211___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037189_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037187_)))) 
           ^ (((IData)(wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037155_)))));
    vlSelf->wasmetal_core__DOT___037159_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037190_)
                                                   ? (IData)(wasmetal_core__DOT___134211___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h54e5e4c4__0))));
    wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034637_) 
           & (IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128713___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035090_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035089_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035088_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035087_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035022_)))));
    vlSelf->wasmetal_core__DOT___035026_ = ((IData)(vlSelf->wasmetal_core__DOT___035090_)
                                             ? (IData)(wasmetal_core__DOT___128713___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d));
    wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)) 
           & (IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127837___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026267_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026266_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026265_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026264_)))) 
           ^ (((IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127837___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026231_)))));
    vlSelf->wasmetal_core__DOT___026235_ = ((IData)(vlSelf->wasmetal_core__DOT___026267_)
                                             ? (IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127829___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026171_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026170_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026169_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026168_)))) 
           ^ (((IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026135_)))));
    vlSelf->wasmetal_core__DOT___026139_ = ((IData)(vlSelf->wasmetal_core__DOT___026171_)
                                             ? (IData)(wasmetal_core__DOT___127829___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127845___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026363_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026362_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026361_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026360_)))) 
           ^ (((IData)(wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026327_)))));
    vlSelf->wasmetal_core__DOT___026331_ = ((IData)(vlSelf->wasmetal_core__DOT___026363_)
                                             ? (IData)(wasmetal_core__DOT___127845___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__labels_memory__02e0__02e0__ADDRBWRADDR 
        = (0x800fU | ((0x4000U & ((0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                              << 2U) 
                                             | ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
                                                    >> 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                      >> 2U))))) 
                                  << 0xeU)) | ((0x2000U 
                                                & ((0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O)) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                              >> 1U))))) 
                                                   << 0xdU)) 
                                               | ((0x1000U 
                                                   & ((0xcaU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
                                                               << 1U)) 
                                                           | (1U 
                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O))))) 
                                                      << 0xcU)) 
                                                  | ((0x800U 
                                                      & ((0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                                                  >> 2U)) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                    >> 3U))))) 
                                                         << 0xbU)) 
                                                     | ((0x400U 
                                                         & ((0xcaU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                                                     >> 1U)) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                       >> 2U))))) 
                                                            << 0xaU)) 
                                                        | ((0x200U 
                                                            & ((0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                          >> 1U))))) 
                                                               << 9U)) 
                                                           | ((0x100U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O))))) 
                                                                  << 8U)) 
                                                              | ((0x80U 
                                                                  & ((0xcaU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                                >> 3U))))) 
                                                                     << 7U)) 
                                                                 | ((0x40U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                                                                >> 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                                >> 2U))))) 
                                                                        << 6U)) 
                                                                    | ((0x20U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                                >> 1U))))) 
                                                                           << 5U)) 
                                                                       | (0x10U 
                                                                          & ((0xcaU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O))))) 
                                                                             << 4U)))))))))))));
    vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032805_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032772_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O)));
    vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030847_)
            ? (IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d));
    vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063124_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063122_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063121_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128361___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063130_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063128_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063127_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128361___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063136_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063134_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063133_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128361___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063142_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063140_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063139_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128214___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128361___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032544_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032544_))));
    wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031805_)
            ? (IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d));
    vlSelf->wasmetal_core__DOT___064033_ = (1U & (IData)(
                                                         (0x5ffffffffffffff3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(__VdfgTmp_h3ceb6137__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(__VdfgTmp_h169b252f__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128579___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128578___O) 
                                                                                << 2U)) 
                                                                                | ((8U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___128579___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(__VdfgTmp_h3ceb6137__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(__VdfgTmp_h169b252f__0)))))))))))))))))));
    vlSelf->__VdfgTmp_hc47ce573__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128588___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128588___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128537___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b14__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128537___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128291___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030714_)))));
    vlSelf->wasmetal_core__DOT___011157_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011740_))));
    vlSelf->__VdfgTmp_h394cead1__0 = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                             << 3U)) 
                                      | (7U & (~ (7U 
                                                  & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                     >> 1U)))));
    vlSelf->__VdfgTmp_h46d848cb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010077_));
    vlSelf->wasmetal_core__DOT___012929_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010378_))));
    vlSelf->wasmetal_core__DOT___056504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)))));
    vlSelf->wasmetal_core__DOT___056535_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___011976_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___009681_ = (1U & (0x347U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___019019_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016504_))));
    vlSelf->wasmetal_core__DOT___019074_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))));
    vlSelf->wasmetal_core__DOT___070488_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063439_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044240_))))));
    vlSelf->wasmetal_core__DOT___050400_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050399_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___051217_ = (1U & (0x2fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050443_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047994_))))));
    vlSelf->wasmetal_core__DOT___052659_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___050359_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___048133_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048116_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048115_))));
    vlSelf->wasmetal_core__DOT___072273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062496_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063446_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053488_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053435_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072270_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051199_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052895_)))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053487_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053247_))));
    vlSelf->wasmetal_core__DOT___007871_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048394_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h508bc82d__0))))))));
    vlSelf->wasmetal_core__DOT___016506_ = (1U & (0xfe3fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))));
    vlSelf->wasmetal_core__DOT___048960_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___058930_ = (1U & (0x6000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))));
    vlSelf->wasmetal_core__DOT___048129_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___060571_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0))))));
    vlSelf->wasmetal_core__DOT___017174_ = (1U & (IData)(
                                                         (0xc0f01f0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048125_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10c9b581__0))))))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032034_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036759_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036726_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h6265db41__0))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031361_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___062741_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062740_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062739_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062752_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062751_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062750_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062763_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062762_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062761_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062774_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062772_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128518___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128518___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033133_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        vlSelf->wasmetal_core__DOT___033108_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033202_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033974_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033108_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033202_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033974_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128526___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128518___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033227_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128603___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128518___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033999_)))));
    vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0x12U) & (IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x40000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x12U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128159___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d)
            : (IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d)
            : (IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)
            : (IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029921_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029887_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d));
    vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032873_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032840_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128954___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063169_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128199___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063175_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128199___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063181_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128199___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063187_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128199___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029718_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d));
    vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029389_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029356_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d));
    vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027808_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027775_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d));
    wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0x12U) & (IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h93fa449d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)))))))));
    vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029228_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029195_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d));
    wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0x12U)) & (IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045540_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___045552_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128430___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032201_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032168_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___070643_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O))))));
    vlSelf->wasmetal_core__DOT___070646_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032681_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032648_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037191_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037159_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h5f5f5b59__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128680___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034638_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034637_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034699_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034698_)))) 
           ^ (((IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034761_)))));
    vlSelf->wasmetal_core__DOT___034702_ = ((IData)(vlSelf->wasmetal_core__DOT___034638_) 
                                            & (IData)(wasmetal_core__DOT___128680___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034642_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128713___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___034641_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128713___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d)))));
    vlSelf->wasmetal_core__DOT___034640_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128713___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___034639_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128713___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___128714___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035091_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035026_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128697___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034894_)))));
    vlSelf->wasmetal_core__DOT___034898_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)) 
                                            & (IData)(wasmetal_core__DOT___128697___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127838___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026268_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026235_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d));
    vlSelf->__VdfgTmp_he2c88566__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)))))))));
    vlSelf->wasmetal_core__DOT___127830___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026172_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026139_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d));
    vlSelf->wasmetal_core__DOT___054503_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054505_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054507_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___063551_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063559_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063567_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063575_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___054501_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->__VdfgTmp_hd4f12848__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)))))))));
    vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026364_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026331_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d));
    vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032806_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128305___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030848_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030847_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030842_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030831_)))) 
           ^ (((IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030756_)))));
    vlSelf->wasmetal_core__DOT___030784_ = ((IData)(vlSelf->wasmetal_core__DOT___030848_)
                                             ? (IData)(wasmetal_core__DOT___128305___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d));
    vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032482_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032482_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128385___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031806_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031805_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031800_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031789_)))) 
           ^ (((IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031714_)))));
    vlSelf->wasmetal_core__DOT___031742_ = ((IData)(vlSelf->wasmetal_core__DOT___031806_)
                                             ? (IData)(wasmetal_core__DOT___128385___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128571___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b15__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128571___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128403___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031960_)))));
    vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029502_));
    vlSelf->wasmetal_core__DOT___056530_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h394cead1__0))));
    vlSelf->__VdfgTmp_h0812d53d__0 = ((0x10U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                << 4U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h394cead1__0));
    vlSelf->wasmetal_core__DOT___056543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011976_))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050445_ = (1U & (IData)(
                                                         (0x2220fff00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050400_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050399_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
    vlSelf->wasmetal_core__DOT___050406_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050400_))));
    vlSelf->wasmetal_core__DOT___051219_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051217_))));
    vlSelf->wasmetal_core__DOT___052655_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))));
    vlSelf->wasmetal_core__DOT___052660_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052659_))));
    vlSelf->wasmetal_core__DOT___051224_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050443_)))));
    vlSelf->wasmetal_core__DOT___051202_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___051204_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050359_))));
    vlSelf->wasmetal_core__DOT___050364_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050359_))));
    vlSelf->wasmetal_core__DOT___005669_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048960_))));
    vlSelf->wasmetal_core__DOT___014613_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048960_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_)))));
    vlSelf->wasmetal_core__DOT___048134_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017186_)))));
    vlSelf->wasmetal_core__DOT___060573_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060571_))));
    vlSelf->wasmetal_core__DOT___019194_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017174_))));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036760_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbd028268__0))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031331_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___062749_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xcU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062741_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))));
    vlSelf->wasmetal_core__DOT___062760_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xdU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062752_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062771_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xeU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062763_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062782_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xfU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062774_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033108_));
        vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033202_));
        vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033974_));
    }
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128030___O 
        = (0xfU & ((vlSelf->insn_z >> 0x10U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027935_))))));
    vlSelf->wasmetal_core__DOT___027939_ = ((vlSelf->insn_z 
                                             >> 0x13U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128270___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x13U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x12U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x11U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030470_)))));
    vlSelf->wasmetal_core__DOT___030474_ = (1U & ((0x80000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0x13U)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128006___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI) 
           ^ (((IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027710_)))));
    vlSelf->wasmetal_core__DOT___027714_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128006___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128038___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028000_)))));
    vlSelf->wasmetal_core__DOT___028004_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128159___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128159___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128159___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029291_)))));
    vlSelf->wasmetal_core__DOT___029295_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128159___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128192___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029653_)))));
    vlSelf->wasmetal_core__DOT___029657_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128192___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128209___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029822_)))));
    vlSelf->wasmetal_core__DOT___029826_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128209___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128374___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031592_)))));
    vlSelf->wasmetal_core__DOT___031596_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128374___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128422___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032073_)))));
    vlSelf->wasmetal_core__DOT___032077_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128422___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128278___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030565_)))));
    vlSelf->wasmetal_core__DOT___030569_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128278___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128226___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029991_)))));
    vlSelf->wasmetal_core__DOT___029995_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128226___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029922_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d));
    vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032874_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127998___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128955___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128954___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128953___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128952___Q)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027645_)))));
    vlSelf->wasmetal_core__DOT___027649_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128955___Q) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d));
    vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029390_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d));
    vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027809_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128259___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030353_)))));
    vlSelf->wasmetal_core__DOT___030357_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
                                             : (IData)(wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128054___O 
        = (0xfU & ((vlSelf->insn_x >> 0x10U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028161_))))));
    vlSelf->wasmetal_core__DOT___028165_ = ((vlSelf->insn_x 
                                             >> 0x13U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029229_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128022___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128022___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027871_)))));
    vlSelf->wasmetal_core__DOT___027875_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128318___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x13U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x12U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x11U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x10U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030952_)))));
    vlSelf->wasmetal_core__DOT___030956_ = ((~ (vlSelf->function_params 
                                                >> 0x13U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__2__KET__));
}
