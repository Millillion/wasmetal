#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__25(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__25\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___010333_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007370_)))))))));
    vlSelf->wasmetal_core__DOT___007447_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc18298c4__0)))));
    vlSelf->wasmetal_core__DOT___049011_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005572_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h92d236ac__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003055_)))))))));
    vlSelf->wasmetal_core__DOT___061855_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007398_))));
    vlSelf->wasmetal_core__DOT___061487_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007372_))));
    vlSelf->__VdfgTmp_h13e1c0a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007398_));
    vlSelf->__VdfgTmp_he0ff0f52__0 = (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007398_))));
    vlSelf->__VdfgTmp_h5d8e5746__0 = (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055036_));
    vlSelf->wasmetal_core__DOT___007792_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007396_))))));
    vlSelf->__VdfgTmp_h22d02546__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007396_))))));
    vlSelf->wasmetal_core__DOT___051611_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048653_))));
    vlSelf->wasmetal_core__DOT___048659_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048653_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___055807_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___027482_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007366_)))))))));
    vlSelf->__VdfgTmp_hb53fd6c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007729_));
    vlSelf->__VdfgTmp_h5cfad588__0 = (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054959_));
    vlSelf->wasmetal_core__DOT___010553_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2fc9f8d__0))));
    vlSelf->wasmetal_core__DOT___051518_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048599_))));
    vlSelf->wasmetal_core__DOT___048606_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048599_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___027479_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007280_)))))))));
    vlSelf->__VdfgTmp_h1fbedb27__0 = (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054820_));
    vlSelf->wasmetal_core__DOT___051547_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048604_))));
    vlSelf->wasmetal_core__DOT___048605_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048604_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___055779_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___061500_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054821_))));
    vlSelf->wasmetal_core__DOT___027480_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007307_)))))))));
    vlSelf->__VdfgTmp_h15fa30e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054865_));
    vlSelf->wasmetal_core__DOT___051579_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048658_))));
    vlSelf->wasmetal_core__DOT___048660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048658_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->__VdfgTmp_h82899d97__0 = (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054909_));
    vlSelf->wasmetal_core__DOT___010547_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2fc9f8d__0))));
    vlSelf->wasmetal_core__DOT___048617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048616_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051364_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048616_))));
    vlSelf->wasmetal_core__DOT___061673_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3e487a94__0))))));
    vlSelf->wasmetal_core__DOT___055749_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055373_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055375_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055374_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055373_)))));
    vlSelf->__VdfgTmp_hd184a96b__0 = (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054781_));
    vlSelf->wasmetal_core__DOT___061704_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hee831718__0))))));
    vlSelf->wasmetal_core__DOT___055808_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055595_)))));
    vlSelf->wasmetal_core__DOT___055596_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055594_)))));
    vlSelf->wasmetal_core__DOT___027490_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007393_)))))))));
    vlSelf->__VdfgTmp_h997e3a26__0 = (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054998_));
    vlSelf->__VdfgTmp_h29ef1e90__0 = (((IData)(vlSelf->wasmetal_core__DOT___007744_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007743_));
    vlSelf->wasmetal_core__DOT___048618_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048611_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051344_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048611_))));
    vlSelf->wasmetal_core__DOT___060480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048712_))));
    vlSelf->wasmetal_core__DOT___010386_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___048629_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048628_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048628_))));
    vlSelf->wasmetal_core__DOT___061700_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h703df812__0))))));
    vlSelf->wasmetal_core__DOT___055679_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055678_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055677_)))));
    vlSelf->wasmetal_core__DOT___055860_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055675_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055678_)))));
    vlSelf->wasmetal_core__DOT___061499_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054999_))));
    vlSelf->wasmetal_core__DOT___027491_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007420_)))))))));
    vlSelf->__VdfgTmp_hd9dc27af__0 = (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055044_));
    vlSelf->__VdfgTmp_h7e54e6f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007759_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007758_));
    vlSelf->__VdfgTmp_h28d1a2cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054866_));
    vlSelf->__VdfgTmp_h891cd943__0 = (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054861_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007570_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007567_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007568_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007566_)))))))))))))));
    vlSelf->__VdfgTmp_h0761bbb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007568_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007567_));
    vlSelf->wasmetal_core__DOT___010351_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007568_)))))))));
    vlSelf->wasmetal_core__DOT___055431_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055427_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055426_)))));
    vlSelf->wasmetal_core__DOT___061495_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054817_))));
    vlSelf->__VdfgTmp_h98124bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054821_));
    vlSelf->__VdfgTmp_had16ce46__0 = (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054816_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007549_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h797b2590__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007546_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007547_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007544_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007545_)))))))))))))));
    vlSelf->__VdfgTmp_h66742b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007547_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007546_));
    vlSelf->wasmetal_core__DOT___010370_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007546_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007547_)))))))));
    vlSelf->wasmetal_core__DOT___055781_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055494_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055497_)))));
    vlSelf->wasmetal_core__DOT___055501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055496_)))));
    vlSelf->wasmetal_core__DOT___061492_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007453_))));
    vlSelf->__VdfgTmp_hca7cb6a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054860_));
    vlSelf->wasmetal_core__DOT___010280_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007287_)))))))));
    vlSelf->wasmetal_core__DOT___061692_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4ffde934__0))))));
    vlSelf->wasmetal_core__DOT___055793_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055514_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055517_)))));
    vlSelf->wasmetal_core__DOT___055521_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055516_)))));
    vlSelf->wasmetal_core__DOT___054913_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4b751076__0)))));
    vlSelf->__VdfgTmp_hb9c84dcf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h13d2f137__0)));
    vlSelf->wasmetal_core__DOT___054963_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2eb2dfca__0)))));
    vlSelf->wasmetal_core__DOT___061276_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054998_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054987_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054989_))))))))))))));
    vlSelf->__VdfgTmp_h223b6529__0 = (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054995_));
    vlSelf->wasmetal_core__DOT___010242_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007373_)))))))));
    vlSelf->wasmetal_core__DOT___010558_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007743_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007744_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2aa6a52e__0))))));
    vlSelf->__VdfgTmp_h939caa69__0 = (((IData)(vlSelf->wasmetal_core__DOT___007527_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007526_));
    vlSelf->__VdfgTmp_hd4d40399__0 = (((IData)(vlSelf->wasmetal_core__DOT___007510_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007509_));
    vlSelf->__VdfgTmp_ha85bab6c__0 = (((IData)(vlSelf->wasmetal_core__DOT___053788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053787_));
    vlSelf->__VdfgTmp_hfc1711e0__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0))))));
    vlSelf->wasmetal_core__DOT___055336_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055331_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055330_)))));
    if (vlSelf->wasmetal_core__DOT___044036_) {
        if (vlSelf->wasmetal_core__DOT___044035_) {
            if (vlSelf->wasmetal_core__DOT___044034_) {
                if (vlSelf->wasmetal_core__DOT___044033_) {
                    if (vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__) {
                        vlSelf->wasmetal_core__DOT___045623_ = 1U;
                        vlSelf->wasmetal_core__DOT___044026_ 
                            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044039_) 
                                     | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)));
                        vlSelf->wasmetal_core__DOT___044045_ 
                            = (1U & (0xcU >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0)));
                    } else {
                        vlSelf->wasmetal_core__DOT___045623_ = 0U;
                        vlSelf->wasmetal_core__DOT___044026_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__)));
                        vlSelf->wasmetal_core__DOT___044045_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__)));
                    }
                    vlSelf->wasmetal_core__DOT___045632_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___045636_)
                                  ? (1U >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0))
                                  : (IData)(vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__)));
                } else {
                    vlSelf->wasmetal_core__DOT___045623_ = 0U;
                    vlSelf->wasmetal_core__DOT___044026_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044033_)));
                    vlSelf->wasmetal_core__DOT___044045_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044033_)));
                    vlSelf->wasmetal_core__DOT___045632_ = 0U;
                }
            } else {
                vlSelf->wasmetal_core__DOT___045623_ = 0U;
                vlSelf->wasmetal_core__DOT___044026_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044034_)));
                vlSelf->wasmetal_core__DOT___044045_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044034_)));
                vlSelf->wasmetal_core__DOT___045632_ = 0U;
            }
        } else {
            vlSelf->wasmetal_core__DOT___045623_ = 0U;
            vlSelf->wasmetal_core__DOT___044026_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044035_)));
            vlSelf->wasmetal_core__DOT___044045_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044035_)));
            vlSelf->wasmetal_core__DOT___045632_ = 0U;
        }
    } else {
        vlSelf->wasmetal_core__DOT___045623_ = 0U;
        vlSelf->wasmetal_core__DOT___044026_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044036_)));
        vlSelf->wasmetal_core__DOT___044045_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044036_)));
        vlSelf->wasmetal_core__DOT___045632_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___061493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007489_))));
    vlSelf->wasmetal_core__DOT___061343_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055041_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055044_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055033_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055035_))))))))))))));
    vlSelf->__VdfgTmp_h49097fbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055041_));
    vlSelf->wasmetal_core__DOT___009652_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007399_)))))))));
    vlSelf->__VdfgTmp_hce8e9d12__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0ccccff00aaaaULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007419_))))))))) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007759_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007758_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h0fc2ac4f__0)))))))));
    vlSelf->wasmetal_core__DOT___061782_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h84babf9f__0))))));
    vlSelf->wasmetal_core__DOT___055751_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055369_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055372_)))));
    vlSelf->wasmetal_core__DOT___055377_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055370_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055369_)))));
    vlSelf->wasmetal_core__DOT___007232_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hee719ca8__0)))));
    vlSelf->wasmetal_core__DOT___007525_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hee719ca8__0)))));
    vlSelf->wasmetal_core__DOT___048973_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004031_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d95a729__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002281_)))))))));
    vlSelf->wasmetal_core__DOT___054812_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5dd9afa__0)))));
    vlSelf->wasmetal_core__DOT___054857_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he6aadab7__0)))));
    vlSelf->wasmetal_core__DOT___049095_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003889_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he4dfb545__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002317_)))))))));
    vlSelf->wasmetal_core__DOT___007470_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ab1a2ea__0)))));
    vlSelf->wasmetal_core__DOT___063764_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063758_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063757_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063756_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf351ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3b966d55__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h957273a9__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003091_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h585a3ceb__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he0c10a9d__0)))))))))));
    vlSelf->wasmetal_core__DOT___049063_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003369_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hadae1421__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002594_)))))))));
    vlSelf->wasmetal_core__DOT___055810_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055588_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055591_)))));
    vlSelf->wasmetal_core__DOT___055598_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055590_)))));
    vlSelf->__VdfgTmp_h02022f9b__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h642b0391__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h2eb2dfca__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd27b8df6__0)))))));
    vlSelf->wasmetal_core__DOT___054953_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h642b0391__0)))));
    vlSelf->wasmetal_core__DOT___049060_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003301_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd44758f6__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002555_)))))))));
    vlSelf->wasmetal_core__DOT___055654_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055646_)))));
    vlSelf->wasmetal_core__DOT___054992_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h597612ae__0)))));
    vlSelf->wasmetal_core__DOT___054772_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e3b944f__0)))));
    vlSelf->__VdfgTmp_hb4fb5a01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007660_));
    vlSelf->wasmetal_core__DOT___055038_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h72b22246__0)))));
    vlSelf->__VdfgTmp_hd173054d__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h4b751076__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21032c8__0))))));
    vlSelf->__VdfgTmp_hb6cab41b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007718_));
    vlSelf->__VdfgTmp_h2a3772ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007718_))));
    vlSelf->__VdfgTmp_he9d168d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007719_)));
    vlSelf->__VdfgTmp_hbc236300__0 = (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054907_));
    vlSelf->wasmetal_core__DOT___054928_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007720_)))))))));
    vlSelf->__VdfgTmp_h3856dbf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007587_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007588_));
    vlSelf->wasmetal_core__DOT___061410_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054957_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054959_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054949_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054951_)))))))))))));
    vlSelf->__VdfgTmp_hae784e62__0 = (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007729_));
    vlSelf->__VdfgTmp_he182d032__0 = (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007346_));
    vlSelf->__VdfgTmp_hd5551ada__0 = (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007730_)));
    vlSelf->__VdfgTmp_h0d308a29__0 = (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054957_));
    vlSelf->__VdfgTmp_h973345c0__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h372c3d93__0)))))))) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007601_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007602_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007599_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___007600_))))))))));
    vlSelf->wasmetal_core__DOT___054852_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007234_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007602_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007601_)))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007600_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007599_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007603_))))));
    vlSelf->__VdfgTmp_h37a4ed19__0 = (((IData)(vlSelf->wasmetal_core__DOT___007601_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007602_));
    vlSelf->__VdfgTmp_h6e5b7cf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054996_));
    vlSelf->__VdfgTmp_h8d86a2a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007622_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007621_));
    vlSelf->wasmetal_core__DOT___061678_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1d87626c__0))))));
    vlSelf->wasmetal_core__DOT___055957_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f555500ff3333ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055424_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055427_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055426_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055429_))))))))))));
    vlSelf->__VdfgTmp_h949b8002__0 = (((IData)(vlSelf->wasmetal_core__DOT___055429_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055428_));
    vlSelf->wasmetal_core__DOT___060941_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054815_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054818_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054807_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054809_))))))))))))));
    vlSelf->__VdfgTmp_hce304a5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054821_))));
    vlSelf->wasmetal_core__DOT___027486_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007281_)))))))));
    vlSelf->__VdfgTmp_hb63b65e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054818_));
    vlSelf->wasmetal_core__DOT___010090_ = (1U & (IData)(
                                                         (0xaaf0cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054819_)))))))));
    vlSelf->wasmetal_core__DOT___010589_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007688_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007689_)))))))));
    vlSelf->wasmetal_core__DOT___010760_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007691_))))));
    vlSelf->wasmetal_core__DOT___009793_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___007693_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                      ? 
                                                     (0xf1111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007689_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007688_))))))
                                                      : 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007692_))))));
    vlSelf->wasmetal_core__DOT___010289_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007690_)))))));
    vlSelf->wasmetal_core__DOT___061682_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha87b9f86__0))))));
    vlSelf->wasmetal_core__DOT___055780_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055499_)))));
    vlSelf->wasmetal_core__DOT___055500_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055499_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055498_)))));
    vlSelf->wasmetal_core__DOT___061498_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054819_))));
    vlSelf->wasmetal_core__DOT___061026_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054860_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054863_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051493_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051498_))))))))))))));
    vlSelf->__VdfgTmp_h2ac55b8c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054866_))));
    vlSelf->wasmetal_core__DOT___027487_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007308_)))))))));
    vlSelf->__VdfgTmp_h6b627b07__0 = (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054863_));
    vlSelf->wasmetal_core__DOT___010582_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007707_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007706_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h009b2026__0))))))));
    vlSelf->__VdfgTmp_h7619e45d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007707_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007706_));
    vlSelf->wasmetal_core__DOT___054780_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc52c52a3__0)))));
    vlSelf->wasmetal_core__DOT___055136_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc52c52a3__0)))));
    vlSelf->wasmetal_core__DOT___054797_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007526_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007527_)))))))));
    vlSelf->wasmetal_core__DOT___010780_ = (1U & (0xf0110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007663_)))))));
    vlSelf->wasmetal_core__DOT___056201_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007234_))))));
    vlSelf->wasmetal_core__DOT___011622_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054151_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054152_))))));
    vlSelf->wasmetal_core__DOT___054157_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054152_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054151_)))))));
    vlSelf->wasmetal_core__DOT___061631_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ef442fa__0))))));
    vlSelf->wasmetal_core__DOT___054727_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff3355fffff0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hebcfe313__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff3355fffff0f0ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h284fdec6__0))))))))))));
    vlSelf->__VdfgTmp_h3d8d5ec6__0 = ((4U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055330_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___055333_)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___055332_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055319_)));
    vlSelf->wasmetal_core__DOT___055335_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055333_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055332_)))));
    vlSelf->wasmetal_core__DOT___061494_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054997_))));
    vlSelf->__VdfgTmp_hb53c364f__0 = (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055042_));
    vlSelf->__VdfgTmp_hf2283ef8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007643_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007642_));
    vlSelf->__VdfgTmp_hae0eb281__0 = (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007507_));
    vlSelf->__VdfgTmp_h73a9d128__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hebcfe313__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h284fdec6__0)))))));
    vlSelf->wasmetal_core__DOT___055337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055329_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055328_)))));
    vlSelf->wasmetal_core__DOT___060880_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78fd8e0c__0)))));
    vlSelf->wasmetal_core__DOT___054813_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78fd8e0c__0)))));
    vlSelf->wasmetal_core__DOT___060956_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h721400e1__0)))));
    vlSelf->wasmetal_core__DOT___054858_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h721400e1__0)))));
    vlSelf->wasmetal_core__DOT___055794_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055512_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055515_)))));
    vlSelf->wasmetal_core__DOT___055523_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055512_)))));
    vlSelf->__VdfgTmp_hb33d3cb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054898_));
    vlSelf->__VdfgTmp_h496bba40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053918_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaaf0f000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h504ea901__0))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaa0000f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                             << 4U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h2cdc7e5b__0)))))))))));
    vlSelf->__VdfgTmp_h8a3dc284__0 = (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___053918_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                                         & (IData)(
                                                                   (0x33ff55ff0fff0fffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h6277318a__0))))))) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                       & (IData)(
                                                                 (0x33ff55ff0fff0fffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hbaaa25aa__0))))))))));
    vlSelf->wasmetal_core__DOT___061126_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h112f9280__0)))));
    vlSelf->wasmetal_core__DOT___054954_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h112f9280__0)))));
    vlSelf->wasmetal_core__DOT___062098_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h401bf3cf__0))))));
    vlSelf->wasmetal_core__DOT___055655_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055645_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055644_)))));
    vlSelf->wasmetal_core__DOT___061208_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h24bf73d0__0)))));
    vlSelf->wasmetal_core__DOT___054993_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h24bf73d0__0)))));
    vlSelf->wasmetal_core__DOT___060794_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7d64f39__0)))));
    vlSelf->wasmetal_core__DOT___054773_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7d64f39__0)))));
    vlSelf->__VdfgTmp_h86442115__0 = (((IData)(vlSelf->wasmetal_core__DOT___054893_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054894_));
    vlSelf->__VdfgTmp_he26aa999__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054142_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054141_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054140_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054139_))))));
    vlSelf->wasmetal_core__DOT___061612_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2142849a__0))))));
    vlSelf->wasmetal_core__DOT___060688_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3265141f__0)))));
    vlSelf->wasmetal_core__DOT___055089_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3265141f__0)))));
    vlSelf->__VdfgTmp_h1f7f3a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___055326_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055329_));
    vlSelf->wasmetal_core__DOT___055338_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055326_)))));
    vlSelf->wasmetal_core__DOT___061483_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061480_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054706_)))))))));
    vlSelf->wasmetal_core__DOT___060701_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he97c005b__0)))));
    vlSelf->wasmetal_core__DOT___055039_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he97c005b__0)))));
    vlSelf->__VdfgTmp_h8ecdfd77__0 = (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052833_));
    vlSelf->__VdfgTmp_h7e6b8024__0 = (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052833_));
    vlSelf->wasmetal_core__DOT___055682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055672_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055671_)))));
    vlSelf->wasmetal_core__DOT___061296_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h064a3607__0)))));
    vlSelf->wasmetal_core__DOT___055040_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h064a3607__0)))));
    vlSelf->__VdfgTmp_h6a47c3d1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007418_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007769_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007659_)));
    vlSelf->wasmetal_core__DOT___061846_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8be24d75__0))))));
    vlSelf->wasmetal_core__DOT___055433_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055422_)))));
    vlSelf->wasmetal_core__DOT___060904_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd8d7c51__0)))));
    vlSelf->wasmetal_core__DOT___054814_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd8d7c51__0)))));
    vlSelf->wasmetal_core__DOT___060974_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd70fe4ce__0)))));
    vlSelf->wasmetal_core__DOT___054859_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd70fe4ce__0)))));
    vlSelf->wasmetal_core__DOT___061979_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2014cd64__0))))));
    vlSelf->__VdfgTmp_ha17fb340__0 = (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054899_));
    vlSelf->__VdfgTmp_hcb043302__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055073_) 
                                                     << 3U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         & (IData)(
                                                                   (0xccaaf0f000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                      << 5U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6ab1a2ea__0))))) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054338_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054339_))))));
    vlSelf->__VdfgTmp_h2cfd74cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054339_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054338_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaa0000f0f0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h7678d7b9__0)))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h3c09d3eb__0))))))))));
    vlSelf->wasmetal_core__DOT___061142_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb17ca10__0)))));
    vlSelf->wasmetal_core__DOT___054955_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb17ca10__0)))));
    vlSelf->wasmetal_core__DOT___061482_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061479_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061478_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054709_)))))))));
    vlSelf->wasmetal_core__DOT___061235_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d98d40a__0)))));
    vlSelf->wasmetal_core__DOT___054994_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d98d40a__0)))));
    vlSelf->wasmetal_core__DOT___060821_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he2e8a11a__0)))));
    vlSelf->wasmetal_core__DOT___054774_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he2e8a11a__0)))));
    vlSelf->wasmetal_core__DOT___009830_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011712_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf00001111ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd5802a9c__0))))))))))))));
    vlSelf->__VdfgTmp_hdeccdd32__0 = (((IData)(vlSelf->wasmetal_core__DOT___054739_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054738_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___053789_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053784_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053783_) 
                                                                              << 2U) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                & (IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528a2190__0))))) 
                                                                                << 1U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h38ad22b9__0))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053788_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053787_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053786_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053785_)))))))))))))));
    vlSelf->__VdfgTmp_hbc09f2bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053786_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053785_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___053783_))))));
    vlSelf->__VdfgTmp_hcab0eaad__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054140_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054139_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054149_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054150_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054152_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054151_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054142_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___054141_))))))))));
    vlSelf->__VdfgTmp_h2966a39c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054150_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054149_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaa0000f0f0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h81bae7c4__0)))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hc859778d__0))))))))));
    vlSelf->wasmetal_core__DOT___061666_ = (1U & (0xa0c0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73281823__0))));
    vlSelf->__VdfgTmp_h703a7a56__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___002235_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___000181_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000180_));
    vlSelf->wasmetal_core__DOT___055857_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055665_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055672_)))));
    vlSelf->wasmetal_core__DOT___055020_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0)))));
    vlSelf->wasmetal_core__DOT___051648_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048663_))));
    vlSelf->wasmetal_core__DOT___048669_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048663_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___014611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017194_))));
    vlSelf->wasmetal_core__DOT___064538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063903_))));
    vlSelf->__VdfgTmp_h75b63843__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063903_));
    vlSelf->__VdfgTmp_h65785f77__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((9U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001168_)))) 
                                             << 1U)) 
                                      | (1U & (0x41000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001146_))))))));
    vlSelf->__VdfgTmp_h67b52d18__0 = ((2U & ((0x40U 
                                              >> ((4U 
                                                   & ((9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d)))) 
                                             << 1U)) 
                                      | (1U & (0x41000000U 
                                               >> (
                                                   (0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d))))))));
    vlSelf->wasmetal_core__DOT___042177_ = (1U & (0x90090000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001146_)))))));
    vlSelf->wasmetal_core__DOT___058927_ = (1U & (0xbeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___006248_ = (1U & (0x444fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))));
    vlSelf->wasmetal_core__DOT___051628_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048668_))));
    vlSelf->wasmetal_core__DOT___048670_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048668_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->__VdfgTmp_h5e920d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___048711_)))));
    vlSelf->wasmetal_core__DOT___061696_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1f51ea8e__0))))));
    vlSelf->wasmetal_core__DOT___055829_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055652_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055650_)))));
    vlSelf->wasmetal_core__DOT___061421_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055001_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055000_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054988_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054990_)))))))))))));
    vlSelf->__VdfgTmp_h5d11eb70__0 = (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055001_));
    vlSelf->wasmetal_core__DOT___027483_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055001_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007392_)))))))));
    vlSelf->__VdfgTmp_hacafe368__0 = (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054997_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055001_))));
    vlSelf->__VdfgTmp_h9c4c7506__0 = (((IData)(vlSelf->wasmetal_core__DOT___055001_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055000_));
    vlSelf->wasmetal_core__DOT___007824_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007624_))))));
    vlSelf->wasmetal_core__DOT___010332_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007621_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007622_)))))))));
    vlSelf->wasmetal_core__DOT___053069_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044039_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e8d73de__0))));
    vlSelf->wasmetal_core__DOT___053071_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e8d73de__0))));
    vlSelf->wasmetal_core__DOT___061761_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055047_))));
    vlSelf->wasmetal_core__DOT___061501_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055001_))));
    vlSelf->__VdfgTmp_hde31b2d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055047_));
    vlSelf->wasmetal_core__DOT___027484_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007419_)))))))));
    vlSelf->__VdfgTmp_hfe0abeab__0 = (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055047_))));
    vlSelf->__VdfgTmp_haef34542__0 = (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055046_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007645_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2df8dd7f__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007642_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007643_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007640_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007641_)))))))))))))));
    vlSelf->wasmetal_core__DOT___010311_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007642_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007643_)))))))));
    vlSelf->wasmetal_core__DOT___060188_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006215_))));
    vlSelf->wasmetal_core__DOT___054981_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb79381c2__0)))));
    vlSelf->wasmetal_core__DOT___055989_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f555500ff3333ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055645_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055644_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055647_))))))))))));
    vlSelf->__VdfgTmp_hb3f3e4b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___060152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006144_))));
    vlSelf->__VdfgTmp_h29c4951c__0 = (((IData)(vlSelf->wasmetal_core__DOT___001711_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001712_));
    vlSelf->wasmetal_core__DOT___054941_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdf1f98b8__0)))));
    vlSelf->wasmetal_core__DOT___060128_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006171_))));
    vlSelf->__VdfgTmp_h419b9e2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___001316_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8eb0ad88__0)))))));
    vlSelf->wasmetal_core__DOT___001786_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8eb0ad88__0)))));
    vlSelf->__VdfgTmp_h07c00df2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007340_));
    vlSelf->__VdfgTmp_h1c7a54d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008445_));
    vlSelf->wasmetal_core__DOT___051502_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006159_))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002853_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___002234_))))));
        vlSelf->wasmetal_core__DOT___002769_ = vlSelf->wasmetal_core__DOT___002148_;
        vlSelf->wasmetal_core__DOT___002729_ = vlSelf->wasmetal_core__DOT___002111_;
        vlSelf->wasmetal_core__DOT___002852_ = vlSelf->wasmetal_core__DOT___002147_;
        vlSelf->wasmetal_core__DOT___002271_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___000721_));
        vlSelf->wasmetal_core__DOT___000167_ = vlSelf->wasmetal_core__DOT___000722_;
    } else {
        vlSelf->wasmetal_core__DOT___002853_ = (1U 
                                                & (0xc0005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002390_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002233_)))))));
        vlSelf->wasmetal_core__DOT___002769_ = vlSelf->wasmetal_core__DOT___002147_;
        vlSelf->wasmetal_core__DOT___002729_ = vlSelf->wasmetal_core__DOT___002110_;
        vlSelf->wasmetal_core__DOT___002852_ = vlSelf->wasmetal_core__DOT___002387_;
        vlSelf->wasmetal_core__DOT___002271_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000574_))))));
        vlSelf->wasmetal_core__DOT___000167_ = vlSelf->wasmetal_core__DOT___000721_;
    }
    vlSelf->__VdfgTmp_h47d0b828__0 = (((IData)(vlSelf->wasmetal_core__DOT___002234_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002233_));
    vlSelf->wasmetal_core__DOT___054879_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2577a83c__0)))));
    vlSelf->wasmetal_core__DOT___060081_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006099_))));
    vlSelf->wasmetal_core__DOT___059201_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006022_))))))))))));
    vlSelf->wasmetal_core__DOT___051507_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006099_))));
    vlSelf->__VdfgTmp_h0c779906__0 = (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___054834_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd69bf43a__0)))));
    vlSelf->__VdfgTmp_ha93fec6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___048703_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006116_))));
    vlSelf->__VdfgTmp_hd0a40acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001711_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001709_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001710_))))));
    vlSelf->wasmetal_core__DOT___054761_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he43dd87d__0)))));
    vlSelf->wasmetal_core__DOT___060563_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___001314_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h78a92bf8__0)))))));
    vlSelf->wasmetal_core__DOT___001784_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78a92bf8__0)))));
    vlSelf->wasmetal_core__DOT___061473_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007253_))));
    vlSelf->__VdfgTmp_h91a424ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007771_));
    vlSelf->wasmetal_core__DOT___027492_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007771_)))))))));
    vlSelf->__VdfgTmp_h4a046d69__0 = (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008408_));
    vlSelf->wasmetal_core__DOT___010594_ = (1U & (IData)(
                                                         (0xf000f0000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054894_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054893_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007204_)))))))));
    vlSelf->wasmetal_core__DOT___055725_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055320_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055327_)))));
    vlSelf->wasmetal_core__DOT___060549_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___051501_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d))));
    vlSelf->__VdfgTmp_he648fa65__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___000924_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000920_))))));
    vlSelf->__VdfgTmp_he7245d4a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000922_));
    vlSelf->__VdfgTmp_hea36c42a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h28180847__0));
    vlSelf->wasmetal_core__DOT___055669_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055665_)))));
    vlSelf->wasmetal_core__DOT___055019_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2225d234__0)))));
    vlSelf->wasmetal_core__DOT___060535_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___059973_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___001850_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001302_))))));
    vlSelf->wasmetal_core__DOT___054982_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0)))));
    vlSelf->wasmetal_core__DOT___055642_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055640_)))));
    vlSelf->__VdfgTmp_h7c7215cb__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0));
    vlSelf->wasmetal_core__DOT___048630_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048623_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051286_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048623_))));
    vlSelf->wasmetal_core__DOT___060521_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005962_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hb70db301__0 = (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___054853_ = vlSelf->wasmetal_core__DOT___007659_;
        vlSelf->wasmetal_core__DOT___009649_ = vlSelf->wasmetal_core__DOT___007504_;
        vlSelf->wasmetal_core__DOT___009791_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b8e4425__0)));
        vlSelf->wasmetal_core__DOT___010981_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1e9537b6__0)));
        vlSelf->wasmetal_core__DOT___010287_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha44be0e2__0)));
        vlSelf->wasmetal_core__DOT___009795_ = vlSelf->wasmetal_core__DOT___007717_;
        vlSelf->wasmetal_core__DOT___010987_ = vlSelf->wasmetal_core__DOT___007584_;
        vlSelf->wasmetal_core__DOT___010279_ = vlSelf->wasmetal_core__DOT___007469_;
        vlSelf->wasmetal_core__DOT___009814_ = vlSelf->wasmetal_core__DOT___007739_;
        vlSelf->wasmetal_core__DOT___054850_ = vlSelf->wasmetal_core__DOT___007618_;
        vlSelf->wasmetal_core__DOT___010251_ = vlSelf->wasmetal_core__DOT___007488_;
        vlSelf->wasmetal_core__DOT___009781_ = vlSelf->wasmetal_core__DOT___007754_;
        vlSelf->wasmetal_core__DOT___010956_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007639_));
        vlSelf->wasmetal_core__DOT___010239_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h02da39da__0)));
        vlSelf->wasmetal_core__DOT___010213_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3297ffb7__0)));
        vlSelf->wasmetal_core__DOT___010191_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h65d58b23__0)));
        vlSelf->wasmetal_core__DOT___010359_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007338_))))));
        vlSelf->wasmetal_core__DOT___010089_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007260_))))));
    } else {
        vlSelf->wasmetal_core__DOT___054853_ = vlSelf->wasmetal_core__DOT___007504_;
        vlSelf->wasmetal_core__DOT___009649_ = vlSelf->wasmetal_core__DOT___007422_;
        vlSelf->wasmetal_core__DOT___009791_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1e9537b6__0)));
        vlSelf->wasmetal_core__DOT___010981_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha44be0e2__0)));
        vlSelf->wasmetal_core__DOT___010287_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007283_));
        vlSelf->wasmetal_core__DOT___009795_ = vlSelf->wasmetal_core__DOT___007584_;
        vlSelf->wasmetal_core__DOT___010987_ = vlSelf->wasmetal_core__DOT___007469_;
        vlSelf->wasmetal_core__DOT___010279_ = vlSelf->wasmetal_core__DOT___007310_;
        vlSelf->wasmetal_core__DOT___009814_ = vlSelf->wasmetal_core__DOT___007618_;
        vlSelf->wasmetal_core__DOT___054850_ = vlSelf->wasmetal_core__DOT___007488_;
        vlSelf->wasmetal_core__DOT___010251_ = vlSelf->wasmetal_core__DOT___007369_;
        vlSelf->wasmetal_core__DOT___009781_ = vlSelf->wasmetal_core__DOT___007639_;
        vlSelf->wasmetal_core__DOT___010956_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h02da39da__0)));
        vlSelf->wasmetal_core__DOT___010239_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007395_));
        vlSelf->wasmetal_core__DOT___010213_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h65d58b23__0)));
        vlSelf->wasmetal_core__DOT___010191_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd9d6cde__0)));
        vlSelf->wasmetal_core__DOT___010359_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007339_))))));
        vlSelf->wasmetal_core__DOT___010089_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007778_));
    }
    vlSelf->wasmetal_core__DOT___059942_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(vlSelf->wasmetal_core__DOT___005770_));
    if (vlSelf->wasmetal_core__DOT___000181_) {
        vlSelf->wasmetal_core__DOT___002601_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___001710_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001709_)))));
        vlSelf->wasmetal_core__DOT___002068_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hca6242ab__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___002601_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___001712_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001711_)))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___001708_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001707_)))));
        vlSelf->wasmetal_core__DOT___002068_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001846_));
    }
    vlSelf->wasmetal_core__DOT___002770_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001707_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001708_)))))))));
    vlSelf->wasmetal_core__DOT___002851_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000920_)))))))));
    vlSelf->wasmetal_core__DOT___001930_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000822_))))));
    vlSelf->__VdfgTmp_hdfa295b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8de67bd6__0)));
    vlSelf->wasmetal_core__DOT___055601_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8de67bd6__0)))));
    vlSelf->wasmetal_core__DOT___054940_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaeadd36__0)))));
    vlSelf->__VdfgTmp_h0286ce7d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0));
    vlSelf->wasmetal_core__DOT___048641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048640_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051111_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048640_))));
    vlSelf->wasmetal_core__DOT___058690_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048725_))));
    vlSelf->wasmetal_core__DOT___060507_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___059917_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003806_))));
    vlSelf->__VdfgTmp_h83434591__0 = (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->wasmetal_core__DOT___003129_ = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                            & (IData)(
                                                      (0x8000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003805_)))))))));
    vlSelf->wasmetal_core__DOT___001312_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had66fb55__0)))))));
    vlSelf->wasmetal_core__DOT___001781_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had66fb55__0)))));
    vlSelf->__VdfgTmp_h4ad5bd42__0 = (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb8ee9e15__0)));
    vlSelf->wasmetal_core__DOT___055525_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb8ee9e15__0)))));
    vlSelf->__VdfgTmp_hd03398e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007340_))));
    vlSelf->__VdfgTmp_h91f4b3ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008370_));
    vlSelf->wasmetal_core__DOT___010150_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007338_)))))))));
    vlSelf->wasmetal_core__DOT___009782_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007339_)))))))));
    vlSelf->wasmetal_core__DOT___048642_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048635_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051054_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048635_))));
    vlSelf->__VdfgTmp_h678017d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048717_));
    vlSelf->wasmetal_core__DOT___060493_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___050141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005896_))));
    vlSelf->__VdfgTmp_h3500bf27__0 = (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005830_));
    vlSelf->__VdfgTmp_h21922827__0 = (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hed924a08__0 = (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf10e2308__0)));
    vlSelf->wasmetal_core__DOT___055505_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf10e2308__0)))));
    vlSelf->wasmetal_core__DOT___054880_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68f6955f__0)))));
    vlSelf->wasmetal_core__DOT___047927_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047926_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___050690_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047926_))));
    vlSelf->wasmetal_core__DOT___060463_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))));
    vlSelf->__VdfgTmp_he55adf41__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___005816_));
    vlSelf->wasmetal_core__DOT___055420_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055418_)))));
    vlSelf->wasmetal_core__DOT___054835_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb1732b67__0)))));
    vlSelf->wasmetal_core__DOT___047928_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047919_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049883_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047919_))));
    vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___014245_));
    vlSelf->wasmetal_core__DOT___042349_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c2489b5__0))))))));
    vlSelf->wasmetal_core__DOT___042148_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c2489b5__0))))))));
    vlSelf->__VdfgTmp_haf785b2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4d3bb7ef__0)));
    vlSelf->wasmetal_core__DOT___055380_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d3bb7ef__0)))));
    vlSelf->wasmetal_core__DOT___054762_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7f579a2__0)))));
    vlSelf->wasmetal_core__DOT___047945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047936_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049794_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047936_))));
    vlSelf->wasmetal_core__DOT___055323_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055320_)))));
    vlSelf->wasmetal_core__DOT___061471_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007254_))));
    vlSelf->wasmetal_core__DOT___027478_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007772_)))))))));
    vlSelf->__VdfgTmp_h1b99479d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008333_));
    vlSelf->__VdfgTmp_hcc135002__0 = (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007772_));
    vlSelf->__VdfgTmp_hd5b4e54d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007770_))))));
    vlSelf->wasmetal_core__DOT___009818_ = (1U & (IData)(
                                                         (0xff00f0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054895_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007772_)))))))));
    vlSelf->wasmetal_core__DOT___047946_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047944_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049746_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047944_))));
    vlSelf->wasmetal_core__DOT___063901_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0))))));
    vlSelf->__VdfgTmp_h9cfb7302__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x6996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (6U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4a43881d__0))))))))));
    vlSelf->wasmetal_core__DOT___055670_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055663_)))));
    vlSelf->wasmetal_core__DOT___055858_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055663_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055666_)))));
    vlSelf->wasmetal_core__DOT___055022_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h92b02c04__0)))));
    vlSelf->__VdfgTmp_h42c557be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010309_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010308_));
    vlSelf->wasmetal_core__DOT___047870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005525_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005526_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047867_))))))))))));
    vlSelf->wasmetal_core__DOT___014037_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048898_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047867_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___042348_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h503e9cd3__0))))))));
    vlSelf->wasmetal_core__DOT___042147_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h503e9cd3__0))))))));
    vlSelf->wasmetal_core__DOT___054979_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8565eee7__0)))));
    vlSelf->wasmetal_core__DOT___055828_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055638_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055641_)))));
    vlSelf->wasmetal_core__DOT___055643_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055638_)))));
    vlSelf->wasmetal_core__DOT___047872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047860_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049613_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047860_))));
    vlSelf->wasmetal_core__DOT___054943_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0)))));
    vlSelf->wasmetal_core__DOT___070514_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010319_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010320_)))));
    vlSelf->__VdfgTmp_h95b8e055__0 = (((IData)(vlSelf->wasmetal_core__DOT___010320_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010319_));
    vlSelf->wasmetal_core__DOT___047851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047842_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049497_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047842_))));
    vlSelf->wasmetal_core__DOT___054916_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0)))));
    vlSelf->wasmetal_core__DOT___047852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047850_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049115_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047850_))));
    vlSelf->wasmetal_core__DOT___013739_ = (1U & (0xf0fbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048900_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048899_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha2b229ae__0))))));
    vlSelf->__VdfgTmp_h7357dd51__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002231_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001705_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000821_))))))))));
    vlSelf->__VdfgTmp_h95b0aa6a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002387_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___002231_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000822_))))))))));
    vlSelf->wasmetal_core__DOT___063916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))));
    vlSelf->wasmetal_core__DOT___042347_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))))));
    vlSelf->wasmetal_core__DOT___042146_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))))));
    vlSelf->wasmetal_core__DOT___054877_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0)))));
    vlSelf->wasmetal_core__DOT___047909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047900_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047900_))));
    vlSelf->wasmetal_core__DOT___055421_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055416_)))));
    vlSelf->wasmetal_core__DOT___055764_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055416_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055419_)))));
    vlSelf->wasmetal_core__DOT___054832_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0)))));
    vlSelf->wasmetal_core__DOT___047910_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047908_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047908_))));
    vlSelf->__VdfgTmp_h097d2f7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013737_));
    vlSelf->__VdfgTmp_h4e2d279b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he0af74c9__0)))));
    vlSelf->wasmetal_core__DOT___054759_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0)))));
    vlSelf->wasmetal_core__DOT___047891_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047890_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048579_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047890_))));
    vlSelf->wasmetal_core__DOT___042346_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae598e91__0))))))));
    vlSelf->wasmetal_core__DOT___042145_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae598e91__0))))))));
    vlSelf->wasmetal_core__DOT___055726_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055317_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055321_)))));
    vlSelf->wasmetal_core__DOT___055324_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055317_)))));
    vlSelf->wasmetal_core__DOT___061469_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061467_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061466_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007338_)))))))));
    vlSelf->wasmetal_core__DOT___061621_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5ad8b1f1__0))));
    vlSelf->wasmetal_core__DOT___009806_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5ad8b1f1__0))))))));
    vlSelf->wasmetal_core__DOT___054720_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0)))));
    vlSelf->wasmetal_core__DOT___047892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047882_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048580_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047882_))));
    vlSelf->wasmetal_core__DOT___063915_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0))))));
    vlSelf->wasmetal_core__DOT___055021_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0)))));
    vlSelf->wasmetal_core__DOT___047831_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047822_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048583_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047822_))));
    vlSelf->__VdfgTmp_hb54a817c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001290_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001289_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001299_))))))))));
    vlSelf->wasmetal_core__DOT___042168_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063961_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___054980_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0)))));
    vlSelf->wasmetal_core__DOT___047832_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047830_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048584_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047830_))));
    vlSelf->__VdfgTmp_h7faa2984__0 = (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013785_));
    vlSelf->__VdfgTmp_hd61aa5bc__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001705_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___000722_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000820_))))))))));
    vlSelf->wasmetal_core__DOT___042345_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46a92a2b__0))))))));
    vlSelf->wasmetal_core__DOT___042144_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46a92a2b__0))))))));
    vlSelf->wasmetal_core__DOT___054942_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0)))));
    vlSelf->wasmetal_core__DOT___047813_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047812_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048585_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047812_))));
    vlSelf->wasmetal_core__DOT___054917_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h29bca591__0)))));
    vlSelf->wasmetal_core__DOT___047814_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047804_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048586_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047804_))));
    vlSelf->__VdfgTmp_h162766a7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___000719_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0fd3d582__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002385_))));
    vlSelf->__VdfgTmp_h4408f503__0 = (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hec35f81b__0));
    vlSelf->wasmetal_core__DOT___063922_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h101b2914__0))))));
    vlSelf->__VdfgTmp_h1065bf0b__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_he0af74c9__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_ha0d25e26__0))));
    vlSelf->wasmetal_core__DOT___054878_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0)))));
    vlSelf->wasmetal_core__DOT___048689_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048688_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049141_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048688_))));
    vlSelf->wasmetal_core__DOT___042344_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8c76b9e6__0))))))));
    vlSelf->wasmetal_core__DOT___042143_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8c76b9e6__0))))))));
    vlSelf->wasmetal_core__DOT___054833_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0)))));
    vlSelf->wasmetal_core__DOT___049365_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049138_))));
    vlSelf->wasmetal_core__DOT___048929_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013798_)))))));
    vlSelf->__VdfgTmp_h81ac2e72__0 = (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013795_));
    vlSelf->wasmetal_core__DOT___063814_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063799_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___026814_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___026813_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h10697dc9__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)))))))))));
    vlSelf->wasmetal_core__DOT___054760_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0)))));
    vlSelf->wasmetal_core__DOT___049366_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049136_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049136_))));
    vlSelf->__VdfgTmp_h958b2749__0 = (((IData)(vlSelf->wasmetal_core__DOT___067729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067663_));
    vlSelf->wasmetal_core__DOT___048702_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005711_)))))));
    vlSelf->wasmetal_core__DOT___054721_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69457925__0)))));
    vlSelf->wasmetal_core__DOT___049367_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049129_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049130_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049129_))));
    vlSelf->__VdfgTmp_hed5eddc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013770_));
    vlSelf->__VdfgTmp_h471ef662__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001286_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcbbf7a95__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002181_))));
    vlSelf->wasmetal_core__DOT___063921_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0))))));
    vlSelf->__VdfgTmp_hd78cc544__0 = (((IData)(vlSelf->wasmetal_core__DOT___067663_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067591_));
    vlSelf->wasmetal_core__DOT___063815_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063811_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_heb8a147e__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h51befd44__0))))))));
    vlSelf->wasmetal_core__DOT___055028_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0)))));
    vlSelf->__VdfgTmp_h2e505808__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063867_));
    vlSelf->wasmetal_core__DOT___064014_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff00fff1ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0)))))))))))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d)))))))))))));
    vlSelf->wasmetal_core__DOT___042142_ = (1U & (0x8ecf0c8eU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___070494_)))))));
    vlSelf->__VdfgTmp_h607fca11__0 = ((2U & ((0x40U 
                                              >> ((4U 
                                                   & ((9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)))) 
                                             << 1U)) 
                                      | (1U & (0x4000U 
                                               >> (
                                                   (8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d)))))));
    vlSelf->__VdfgTmp_hff973d2d__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((9U 
                                                          >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___000657_)))) 
                                             << 1U)) 
                                      | (1U & (0x4000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
    vlSelf->wasmetal_core__DOT___042343_ = (1U & (0xbf233b02U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)))))))));
    vlSelf->wasmetal_core__DOT___042166_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063964_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he88617ec__0))))));
    vlSelf->wasmetal_core__DOT___042095_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063937_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)))))));
    vlSelf->__VdfgTmp_h0033f05e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf0c7a5d6__0)))));
    vlSelf->wasmetal_core__DOT___022503_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022501_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022500_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022499_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022495_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022494_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022493_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022490_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022489_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab846b7c__0))));
    vlSelf->wasmetal_core__DOT___022488_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022487_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022486_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha45fb011__0))));
    vlSelf->wasmetal_core__DOT___022485_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022484_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbacebd3b__0))));
    vlSelf->wasmetal_core__DOT___022483_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022482_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0283b263__0))));
    vlSelf->wasmetal_core__DOT___022481_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd64632c9__0))));
    vlSelf->wasmetal_core__DOT___022480_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fed8b62__0))));
    vlSelf->wasmetal_core__DOT___022479_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3cb929d5__0))));
    vlSelf->wasmetal_core__DOT___022478_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfa88dfaf__0))));
    vlSelf->wasmetal_core__DOT___022477_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022476_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89d79bf3__0))));
    vlSelf->wasmetal_core__DOT___022475_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7ef4e0e__0))));
    vlSelf->wasmetal_core__DOT___022474_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13911493__0))));
    vlSelf->wasmetal_core__DOT___022473_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022472_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6c88546__0))));
    vlSelf->wasmetal_core__DOT___054978_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7102b895__0)))));
    vlSelf->wasmetal_core__DOT___026494_ = (1U & (0x8080ff80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071972_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071911_)))))));
    vlSelf->wasmetal_core__DOT___026585_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071972_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071965_))))));
    vlSelf->wasmetal_core__DOT___049020_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049019_))));
    vlSelf->wasmetal_core__DOT___049122_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049019_))));
    vlSelf->wasmetal_core__DOT___001720_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff00ff55ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000717_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000574_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000573_)))))))));
    vlSelf->wasmetal_core__DOT___002144_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000573_))))));
    vlSelf->wasmetal_core__DOT___054937_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h584cbf3b__0)))));
    vlSelf->__VdfgTmp_h99cee8a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->wasmetal_core__DOT___052700_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->__VdfgTmp_h301f8c5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->wasmetal_core__DOT___049017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049016_))));
    vlSelf->wasmetal_core__DOT___049080_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049016_))));
    vlSelf->__VdfgTmp_hf20b3c9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001660_));
    vlSelf->wasmetal_core__DOT___054914_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h169cd931__0)))));
    vlSelf->__VdfgTmp_h436041ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000572_));
    vlSelf->wasmetal_core__DOT___055966_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055782_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055783_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055784_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055785_)))))))));
    vlSelf->wasmetal_core__DOT___054875_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2596a796__0)))));
    vlSelf->wasmetal_core__DOT___026493_ = (1U & (IData)(
                                                         (0xccfcaafa00f000f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071970_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_had9a86ff__0))))))));
    vlSelf->wasmetal_core__DOT___026583_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071970_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071963_))))));
    vlSelf->wasmetal_core__DOT___026586_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071973_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071967_))))));
    vlSelf->wasmetal_core__DOT___026581_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071967_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071959_))))));
    vlSelf->wasmetal_core__DOT___042104_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7da480c4__0))));
    vlSelf->wasmetal_core__DOT___042185_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7da480c4__0))))));
    vlSelf->__VdfgTmp_h8bf08b0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001657_));
    vlSelf->wasmetal_core__DOT___054828_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h03e9ae47__0)))));
    vlSelf->wasmetal_core__DOT___049035_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049034_))));
    vlSelf->wasmetal_core__DOT___049076_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049034_))));
    vlSelf->__VdfgTmp_h8c923865__0 = (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000179_));
    vlSelf->wasmetal_core__DOT___055949_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055752_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055753_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055754_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055755_)))))))));
    vlSelf->__VdfgTmp_h2ba92b9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6deef1cd__0)));
    vlSelf->wasmetal_core__DOT___049038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049037_))));
    vlSelf->wasmetal_core__DOT___049070_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049037_))));
    vlSelf->wasmetal_core__DOT___067203_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067083_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067202_)))));
    vlSelf->wasmetal_core__DOT___001853_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001656_)))))))));
    vlSelf->wasmetal_core__DOT___001773_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001656_))))));
    vlSelf->wasmetal_core__DOT___054713_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc63c8631__0)))));
    vlSelf->wasmetal_core__DOT___050430_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050427_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050426_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h48afdd44__0))))));
    vlSelf->wasmetal_core__DOT___049274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049068_))));
    vlSelf->wasmetal_core__DOT___049069_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049068_))));
    vlSelf->wasmetal_core__DOT___067162_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067161_)))));
    vlSelf->wasmetal_core__DOT___048735_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000178_)))))))));
    vlSelf->wasmetal_core__DOT___001734_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000178_))))));
    vlSelf->__VdfgTmp_hf07ddd26__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0));
    vlSelf->wasmetal_core__DOT___055058_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0))))));
    vlSelf->__VdfgTmp_h4f4f4420__0 = (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h78e7e4d8__0)));
    vlSelf->wasmetal_core__DOT___055667_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78e7e4d8__0)))));
    vlSelf->wasmetal_core__DOT___055027_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8562240__0)))));
    vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           | (IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___067084_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066897_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067083_)))));
    vlSelf->wasmetal_core__DOT___048828_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001655_)))))))));
    vlSelf->wasmetal_core__DOT___001659_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001655_))))));
    vlSelf->__VdfgTmp_hb0afff05__0 = (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd9d9e38d__0)));
    vlSelf->wasmetal_core__DOT___055656_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd9d9e38d__0)))));
    vlSelf->wasmetal_core__DOT___054977_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf0027c26__0)))));
    vlSelf->__VdfgTmp_hf03fc3ad__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0));
    vlSelf->wasmetal_core__DOT___055012_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0))))));
    vlSelf->wasmetal_core__DOT___026582_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071969_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071961_))))));
    vlSelf->wasmetal_core__DOT___026580_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071965_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071957_))))));
    vlSelf->wasmetal_core__DOT___066980_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066979_)))));
    vlSelf->wasmetal_core__DOT___048815_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000177_)))))))));
    vlSelf->wasmetal_core__DOT___000184_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000177_))))));
    vlSelf->__VdfgTmp_h7c0fb6b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h90a7e66d__0)));
    vlSelf->wasmetal_core__DOT___055600_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h90a7e66d__0)))));
    vlSelf->wasmetal_core__DOT___054938_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0)))));
    vlSelf->__VdfgTmp_h70e31548__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h9e64b929__0));
    vlSelf->wasmetal_core__DOT___054971_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9e64b929__0))))));
    vlSelf->wasmetal_core__DOT___066898_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066773_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066897_)))));
    vlSelf->wasmetal_core__DOT___048831_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001654_)))))))));
    vlSelf->wasmetal_core__DOT___001658_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001654_))))));
    vlSelf->__VdfgTmp_h64c25376__0 = (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc06d6619__0)));
    vlSelf->wasmetal_core__DOT___055524_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc06d6619__0)))));
    vlSelf->wasmetal_core__DOT___054915_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0)))));
    vlSelf->__VdfgTmp_h2447f2cc__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0));
    vlSelf->wasmetal_core__DOT___054924_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0))))));
    vlSelf->wasmetal_core__DOT___049093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049092_))));
    vlSelf->wasmetal_core__DOT___049261_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049092_))));
    vlSelf->wasmetal_core__DOT___066861_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066860_)))));
    vlSelf->wasmetal_core__DOT___048778_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000176_)))))))));
    vlSelf->wasmetal_core__DOT___000183_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000176_))))));
    vlSelf->__VdfgTmp_h782ee59f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9a7588ae__0)));
    vlSelf->wasmetal_core__DOT___055504_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9a7588ae__0)))));
    vlSelf->wasmetal_core__DOT___054876_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0)))));
    vlSelf->wasmetal_core__DOT___054889_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_habef704b__0))))));
    vlSelf->wasmetal_core__DOT___026579_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071963_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071955_))))));
    vlSelf->wasmetal_core__DOT___026575_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071955_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071947_))))));
    vlSelf->wasmetal_core__DOT___026577_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071959_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071951_))))));
    vlSelf->wasmetal_core__DOT___026572_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071951_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071943_))))));
    vlSelf->wasmetal_core__DOT___066774_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066610_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066773_)))));
    vlSelf->wasmetal_core__DOT___048786_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001498_)))))))));
    vlSelf->wasmetal_core__DOT___001896_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001498_))))));
    vlSelf->__VdfgTmp_h528d6985__0 = (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h384cc7f9__0)));
    vlSelf->wasmetal_core__DOT___055434_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h384cc7f9__0)))));
    vlSelf->wasmetal_core__DOT___054829_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0)))));
    vlSelf->wasmetal_core__DOT___054842_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcd50fd36__0))))));
    vlSelf->wasmetal_core__DOT___026578_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071961_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071953_))))));
    vlSelf->wasmetal_core__DOT___066652_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066529_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066651_)))));
    vlSelf->__VdfgTmp_h4598addd__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf0c7a5d6__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h66324e1d__0)))));
    vlSelf->wasmetal_core__DOT___048770_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001731_)))))))));
    vlSelf->__VdfgTmp_h2135b46c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001731_))));
    vlSelf->__VdfgTmp_he2d6a2af__0 = (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfa99a91b__0)));
    vlSelf->wasmetal_core__DOT___055379_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa99a91b__0)))));
    vlSelf->wasmetal_core__DOT___054758_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0)))));
    vlSelf->wasmetal_core__DOT___002244_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048760_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048757_)))))))));
    vlSelf->wasmetal_core__DOT___066611_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066403_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066610_)))));
    vlSelf->wasmetal_core__DOT___063880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063877_))));
    vlSelf->wasmetal_core__DOT___048742_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001497_)))))))));
    vlSelf->__VdfgTmp_h8fa00ac2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001497_))));
    vlSelf->__VdfgTmp_he798fe47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9ea6e74c__0)));
    vlSelf->wasmetal_core__DOT___055343_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9ea6e74c__0)))));
    vlSelf->wasmetal_core__DOT___054714_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h84d44246__0)))));
    vlSelf->wasmetal_core__DOT___002041_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048820_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048818_)))))))));
    vlSelf->wasmetal_core__DOT___026576_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071957_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071949_))))));
    vlSelf->wasmetal_core__DOT___026571_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071949_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071941_))))));
    vlSelf->wasmetal_core__DOT___026574_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071953_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071945_))))));
    vlSelf->wasmetal_core__DOT___066530_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066323_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066529_)))));
    vlSelf->wasmetal_core__DOT___069097_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x8000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0))))));
    vlSelf->wasmetal_core__DOT___019400_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8926b37c__0))));
    vlSelf->wasmetal_core__DOT___002143_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001730_))))));
    vlSelf->wasmetal_core__DOT___055017_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69142c13__0)))));
    vlSelf->wasmetal_core__DOT___002477_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048733_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048732_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048731_)))))))));
    vlSelf->wasmetal_core__DOT___066404_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066266_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066403_)))));
    vlSelf->wasmetal_core__DOT___002106_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001496_))))));
    vlSelf->wasmetal_core__DOT___019268_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0))))));
    vlSelf->wasmetal_core__DOT___054976_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0)))));
    vlSelf->wasmetal_core__DOT___002153_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048826_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048825_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048823_)))))))));
    vlSelf->wasmetal_core__DOT___066324_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066131_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066323_)))));
    vlSelf->wasmetal_core__DOT___002142_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001729_))))));
    vlSelf->wasmetal_core__DOT___019257_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h744f9b35__0))))));
    vlSelf->wasmetal_core__DOT___054934_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h744f9b35__0)))));
    vlSelf->wasmetal_core__DOT___002116_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048813_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048812_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048810_)))))))));
    vlSelf->wasmetal_core__DOT___066267_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066266_)))));
    vlSelf->wasmetal_core__DOT___002105_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001495_))))));
    vlSelf->wasmetal_core__DOT___054896_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h413b142d__0)))));
    vlSelf->wasmetal_core__DOT___002079_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048836_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048834_)))))))));
    vlSelf->wasmetal_core__DOT___066132_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065929_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066131_)))));
    vlSelf->__VdfgTmp_h4ea6bbba__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d)))) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3a315b1c__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072034_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0))))))))));
    vlSelf->wasmetal_core__DOT___002382_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001726_))))));
    vlSelf->wasmetal_core__DOT___019245_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h64194573__0))))));
    vlSelf->wasmetal_core__DOT___054873_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h64194573__0)))));
    vlSelf->wasmetal_core__DOT___002356_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048775_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048773_)))))))));
    vlSelf->wasmetal_core__DOT___053512_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044526_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052677_))))));
    vlSelf->wasmetal_core__DOT___053511_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052677_))));
    vlSelf->wasmetal_core__DOT___052836_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044526_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052677_))));
    vlSelf->wasmetal_core__DOT___052678_ = (1U & (IData)(
                                                         (0x7fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052677_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052676_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052675_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052021_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052020_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052019_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b87__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b86__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b80__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052013_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052012_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052011_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b55__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b48__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052005_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052004_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b119__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b118__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b112__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___066075_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065905_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066074_)))));
    vlSelf->wasmetal_core__DOT___002460_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001342_))))));
    vlSelf->wasmetal_core__DOT___054830_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h67f18e55__0)))));
    vlSelf->wasmetal_core__DOT___002434_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048783_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048782_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048780_)))))))));
    vlSelf->wasmetal_core__DOT___026569_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071945_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071937_))))));
    vlSelf->wasmetal_core__DOT___026565_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071937_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071929_))))));
    vlSelf->wasmetal_core__DOT___026567_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071941_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071933_))))));
    vlSelf->wasmetal_core__DOT___026563_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071933_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071925_))))));
    vlSelf->wasmetal_core__DOT___065930_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065929_)))));
    vlSelf->wasmetal_core__DOT___065810_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065619_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065809_)))));
    vlSelf->wasmetal_core__DOT___002225_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001725_))))));
    vlSelf->wasmetal_core__DOT___054757_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h83053a2d__0)))));
    vlSelf->wasmetal_core__DOT___002396_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048768_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048767_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048765_)))))))));
    vlSelf->wasmetal_core__DOT___026568_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071943_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071935_))))));
    vlSelf->wasmetal_core__DOT___026564_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071927_))))));
    vlSelf->wasmetal_core__DOT___026566_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071939_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071931_))))));
    vlSelf->wasmetal_core__DOT___065906_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065707_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065905_)))));
    vlSelf->wasmetal_core__DOT___063894_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063891_))));
    vlSelf->wasmetal_core__DOT___001770_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001341_))))));
    vlSelf->wasmetal_core__DOT___002519_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048740_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048739_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048737_)))))))));
    vlSelf->wasmetal_core__DOT___001728_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001726_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001724_))))));
    vlSelf->wasmetal_core__DOT___002199_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048753_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048752_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048750_)))))))));
    vlSelf->wasmetal_core__DOT___065708_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065424_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065707_)))));
    vlSelf->wasmetal_core__DOT___001859_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001340_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x33550f0fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hf4328824__0)))))))))));
    vlSelf->wasmetal_core__DOT___001344_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001342_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001340_))))));
    vlSelf->wasmetal_core__DOT___001744_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048893_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048892_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048890_)))))))));
    vlSelf->wasmetal_core__DOT___065620_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065307_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065619_)))));
    vlSelf->wasmetal_core__DOT___065308_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065307_)))));
    vlSelf->wasmetal_core__DOT___042178_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063948_))));
    vlSelf->wasmetal_core__DOT___042097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063948_))));
    vlSelf->wasmetal_core__DOT___001727_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001725_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001723_))))));
    vlSelf->wasmetal_core__DOT___063745_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063739_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063738_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063737_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((6U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h63306680__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)))))))))));
    vlSelf->wasmetal_core__DOT___011103_ = (1U & (0xff4f4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aecec62__0)))));
    vlSelf->wasmetal_core__DOT___010084_ = (1U & (0xff4f4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aecec62__0)))));
    vlSelf->wasmetal_core__DOT___001679_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048885_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048883_)))))))));
    vlSelf->wasmetal_core__DOT___003130_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbbe1bed2__0)))));
    vlSelf->wasmetal_core__DOT___065425_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065199_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065424_)))));
    vlSelf->wasmetal_core__DOT___001343_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001341_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001339_))))));
    vlSelf->wasmetal_core__DOT___010085_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->wasmetal_core__DOT___001254_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048877_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048875_)))))))));
    vlSelf->wasmetal_core__DOT___052835_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044492_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052833_))));
    vlSelf->wasmetal_core__DOT___053250_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044492_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052833_)))))));
    vlSelf->wasmetal_core__DOT___045805_ = ((IData)(vlSelf->wasmetal_core__DOT___045828_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045837_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045836_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045835_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045834_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045833_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045832_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045831_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045830_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045829_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045827_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045815_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045817_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045818_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045819_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045820_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045821_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045822_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045823_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045824_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045825_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045816_));
    vlSelf->wasmetal_core__DOT___049164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049163_))));
    vlSelf->wasmetal_core__DOT___049316_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049163_))));
    vlSelf->__VdfgTmp_hfa759b39__0 = (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010722_));
    vlSelf->wasmetal_core__DOT___010396_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_)))));
    vlSelf->wasmetal_core__DOT___061905_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061899_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061898_)))));
    vlSelf->__VdfgTmp_hfd1fc688__0 = (((IData)(vlSelf->wasmetal_core__DOT___010349_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010348_));
    vlSelf->wasmetal_core__DOT___026593_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071931_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071923_))))));
    vlSelf->wasmetal_core__DOT___049156_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049155_))));
    vlSelf->wasmetal_core__DOT___049311_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049155_))));
    vlSelf->wasmetal_core__DOT___065200_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064901_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065199_)))));
    vlSelf->wasmetal_core__DOT___054831_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hef814ba9__0)))));
    vlSelf->wasmetal_core__DOT___010395_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001874_)))));
    vlSelf->wasmetal_core__DOT___061837_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061831_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061830_)))));
    vlSelf->wasmetal_core__DOT___050394_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044280_))));
    vlSelf->wasmetal_core__DOT___010182_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___061762_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaaaaccccf0f0ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061759_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061758_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h422a580d__0)))))))))));
    vlSelf->wasmetal_core__DOT___061767_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061759_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061758_)))));
    vlSelf->wasmetal_core__DOT___001902_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048808_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048807_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048805_)))))))));
    vlSelf->wasmetal_core__DOT___064734_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h769a413d__0))));
    vlSelf->wasmetal_core__DOT___042175_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063934_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063930_))));
    vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001476_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___028871_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___028868_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___028857_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___028846_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028487_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028454_)
            : (IData)(vlSelf->wasmetal_core__DOT___004522_));
    vlSelf->wasmetal_core__DOT____Vcellout___128094___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028662_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028659_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028648_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028637_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028630_ = ((IData)(vlSelf->wasmetal_core__DOT___028662_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004744_));
    vlSelf->wasmetal_core__DOT____Vcellout___128121___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028974_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028971_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028960_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028949_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028942_ = ((IData)(vlSelf->wasmetal_core__DOT___028974_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d));
    vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001437_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001437_)
            : (IData)(vlSelf->wasmetal_core__DOT___032283_));
    vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028763_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026465_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d));
    vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026685_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027155_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d));
    vlSelf->wasmetal_core__DOT___026591_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071927_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071919_))))));
    vlSelf->wasmetal_core__DOT___026587_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071919_)))));
    vlSelf->wasmetal_core__DOT___026589_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071923_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071915_))))));
    vlSelf->wasmetal_core__DOT___026573_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071915_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071912_)))));
    vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026955_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___002649_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2b3c1bbf__0)))))));
    vlSelf->__VdfgTmp_hbd418077__0 = (((IData)(vlSelf->wasmetal_core__DOT___002289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002288_));
    vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h78b443e9__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___060726_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h014e1215__0)))));
    vlSelf->__VdfgTmp_h03ce55f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3c2b613a__0)));
    vlSelf->__VdfgTmp_hcbffb3b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf37b3ae8__0)));
    vlSelf->__VdfgTmp_h3f5e9baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2f9ca2ed__0)));
    vlSelf->__VdfgTmp_h3c35c9c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->__VdfgTmp_h3c506bbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->__VdfgTmp_ha1796962__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___061460_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061459_))) 
                                             << 1U)) 
                                      | (1U & (8U >> (IData)(vlSelf->__VdfgTmp_h4dc07bf4__0))));
    vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001437_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034541_));
    vlSelf->wasmetal_core__DOT___064500_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))));
    vlSelf->wasmetal_core__DOT___063986_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11b4d04e__0))));
    vlSelf->wasmetal_core__DOT___064502_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46c82ccf__0))));
    vlSelf->wasmetal_core__DOT___064501_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))));
    vlSelf->wasmetal_core__DOT___063985_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h425ce738__0))));
    vlSelf->wasmetal_core__DOT___063984_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf2f5c69c__0))));
    vlSelf->wasmetal_core__DOT___064506_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadcc7972__0))));
    vlSelf->wasmetal_core__DOT___063990_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42e273c2__0))));
    vlSelf->wasmetal_core__DOT___064505_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfdfbee0__0))));
    vlSelf->wasmetal_core__DOT___063989_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e67285f__0))));
    vlSelf->wasmetal_core__DOT___064508_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09210432__0))));
    vlSelf->wasmetal_core__DOT___063992_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hea943ba9__0))));
    vlSelf->wasmetal_core__DOT___064507_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89e0a965__0))));
    vlSelf->wasmetal_core__DOT___063991_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h688ac52f__0))));
    vlSelf->wasmetal_core__DOT___064493_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h061491a4__0))));
    vlSelf->wasmetal_core__DOT___063977_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd14327b4__0))));
    vlSelf->wasmetal_core__DOT___064492_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5145bf91__0))));
    vlSelf->wasmetal_core__DOT___063976_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))));
    vlSelf->wasmetal_core__DOT___064495_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1479cba4__0))));
    vlSelf->wasmetal_core__DOT___063979_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19f2f351__0))));
    vlSelf->wasmetal_core__DOT___064494_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c78c397__0))));
    vlSelf->wasmetal_core__DOT___063978_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cc94077__0))));
    vlSelf->wasmetal_core__DOT___064489_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9e2f527__0))));
    vlSelf->wasmetal_core__DOT___063973_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc0b7a98__0))));
    vlSelf->wasmetal_core__DOT___064488_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd466e7f__0))));
    vlSelf->wasmetal_core__DOT___063972_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h992e16df__0))));
    vlSelf->wasmetal_core__DOT___063970_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha86315e0__0))));
    vlSelf->wasmetal_core__DOT___064486_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15099632__0))));
    vlSelf->wasmetal_core__DOT___063971_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0))));
    vlSelf->wasmetal_core__DOT___064487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)))));
    vlSelf->wasmetal_core__DOT___063832_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063830_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063828_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 1U))))))));
    vlSelf->__VdfgTmp_hc07dc041__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->__VdfgTmp_he7d93b5b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->__VdfgTmp_h0817566b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                       << 2U) | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)));
    vlSelf->__VdfgTmp_h30dbdcaa__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)));
    vlSelf->wasmetal_core__DOT___063826_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O))))))));
    vlSelf->wasmetal_core__DOT___007866_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007854_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007865_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___044396_ = ((IData)(vlSelf->wasmetal_core__DOT___044442_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044441_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044439_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044438_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044437_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044436_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044435_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044434_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044433_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044432_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044431_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044430_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044450_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044449_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044448_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044447_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044446_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044445_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044444_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044443_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044440_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044429_) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___044405_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044416_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044419_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044420_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044421_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044422_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044423_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044424_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044425_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044426_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044406_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044407_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044408_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044409_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044410_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044411_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044412_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044413_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044414_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044415_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044417_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044418_));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028285_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___028220_));
    vlSelf->wasmetal_core__DOT___001811_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048797_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048796_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048794_)))))))));
    vlSelf->wasmetal_core__DOT___064469_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))));
    vlSelf->wasmetal_core__DOT___063833_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___042082_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___042140_)))));
    vlSelf->wasmetal_core__DOT___063865_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))))));
    vlSelf->wasmetal_core__DOT___042294_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)))))));
    vlSelf->wasmetal_core__DOT___042094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063930_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))))));
    vlSelf->wasmetal_core__DOT___063728_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00fff1ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab155f14__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___064522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hab155f14__0))))));
    vlSelf->__VdfgTmp_hb39b7a55__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hab155f14__0))));
    vlSelf->wasmetal_core__DOT___072045_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab155f14__0))));
    vlSelf->__VdfgTmp_h982d8c02__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h3a315b1c__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96696996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0)) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hab155f14__0))))))));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027333_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__access_base__05b0__05d));
    vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029153_));
    vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031072_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031039_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___054825_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf131a410__0)))));
    vlSelf->wasmetal_core__DOT___049027_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049026_))));
    vlSelf->wasmetal_core__DOT___049075_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049026_))));
    vlSelf->wasmetal_core__DOT___054811_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c85186d__0)))));
    vlSelf->__VdfgTmp_h41c2ec0e__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___007778_)
                                               : (0xc0aU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7b8e4425__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                         & (IData)(
                                                   (0xf0f0aaaaff00ccccULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h05980b33__0)))))))));
    vlSelf->wasmetal_core__DOT___049030_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049029_))));
    vlSelf->wasmetal_core__DOT___049079_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049029_))));
    vlSelf->wasmetal_core__DOT___054856_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h08beb063__0)))));
    vlSelf->__VdfgTmp_h4ec1ed59__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007308_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007287_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007782_))));
    vlSelf->__VdfgTmp_h25286e3d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h37472320__0)))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007782_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007717_)));
}
