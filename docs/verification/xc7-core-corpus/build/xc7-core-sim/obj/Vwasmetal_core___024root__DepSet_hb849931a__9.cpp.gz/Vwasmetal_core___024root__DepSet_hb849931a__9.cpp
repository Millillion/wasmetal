#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__15(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__15\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___067661_;
    wasmetal_core__DOT___067661_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067727_;
    wasmetal_core__DOT___067727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068971_;
    wasmetal_core__DOT___068971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069093_;
    wasmetal_core__DOT___069093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069142_;
    wasmetal_core__DOT___069142_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069161_;
    wasmetal_core__DOT___069161_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069236_;
    wasmetal_core__DOT___069236_ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___068609_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068658_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068706_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068755_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068753_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068799_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068797_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068854_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068852_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068901_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068899_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___067760_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067751_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067750_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf98ad324__0))))))));
    vlSelf->wasmetal_core__DOT___019403_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068022_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068021_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068020_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94bf9d34__0))))))));
    vlSelf->wasmetal_core__DOT___068085_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068081_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068080_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068079_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ee6a0be__0))))))));
    vlSelf->wasmetal_core__DOT___068161_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068157_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068156_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h38fb75d8__0))))))));
    vlSelf->wasmetal_core__DOT___068246_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068242_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068241_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068240_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d1b60d2__0))))))));
    vlSelf->wasmetal_core__DOT___068299_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068295_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068294_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h598b279f__0))))))));
    vlSelf->wasmetal_core__DOT___068353_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068349_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068348_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068347_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1fd76cb3__0))))))));
    vlSelf->wasmetal_core__DOT___068408_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068404_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068403_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2cbbdbef__0))))))));
    wasmetal_core__DOT___067727_ = (1U & (IData)((0x3faf00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067726_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067725_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))))));
    vlSelf->wasmetal_core__DOT___019398_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067812_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067811_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h20a4ea67__0))))))));
    vlSelf->wasmetal_core__DOT___068432_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068428_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068427_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068426_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h97b1be8c__0))))))));
    vlSelf->wasmetal_core__DOT___068487_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068480_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068479_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068478_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfec86816__0))))))));
    wasmetal_core__DOT___067661_ = (1U & (0x3faf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___067658_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))));
    vlSelf->wasmetal_core__DOT___068110_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068106_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068105_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068104_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe166c9c__0))))))));
    vlSelf->wasmetal_core__DOT___068945_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068943_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___069043_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069093_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069091_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069142_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069140_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___068971_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___068969_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069236_ = (1U & (0x3faf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069233_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))));
    wasmetal_core__DOT___069161_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069159_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___055430_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h949b8002__0))));
    vlSelf->wasmetal_core__DOT___055890_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055421_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055434_)))))))));
    vlSelf->wasmetal_core__DOT___055958_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf0f555500ff3333ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055418_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055423_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055422_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055425_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055764_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055761_)))))));
    vlSelf->wasmetal_core__DOT___055777_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055764_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055418_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055423_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf5f3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008048_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055761_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055422_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055425_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055424_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055427_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x330fff55U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055426_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h949b8002__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055872_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055324_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055323_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055338_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055343_)))))))));
    vlSelf->wasmetal_core__DOT___019211_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00bbbbf0f0ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055727_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d8d5ec6__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055726_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055723_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f05533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055725_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f7f3a50__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055732_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055726_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055725_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf5f3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008032_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055723_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x5533f0f0U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055727_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f7f3a50__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0bbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h3d8d5ec6__0))))))))))));
    vlSelf->wasmetal_core__DOT___055364_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055338_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055337_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055335_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055324_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055323_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055343_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007946_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055877_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055379_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055381_)))))))));
    vlSelf->wasmetal_core__DOT___055949_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055752_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055753_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055754_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055755_)))))))));
    vlSelf->wasmetal_core__DOT___055759_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055751_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055750_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055749_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055753_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008040_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055755_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055754_)))))))))))));
    vlSelf->wasmetal_core__DOT___055411_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055377_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055375_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055379_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007954_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055381_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055380_)))))))))))));
    vlSelf->wasmetal_core__DOT___055902_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055503_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055506_)))))))));
    vlSelf->wasmetal_core__DOT___055966_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055782_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055783_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055784_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055785_)))))))));
    vlSelf->wasmetal_core__DOT___019243_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055782_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055781_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055780_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055779_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055783_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008056_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055785_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055784_)))))))))))));
    vlSelf->wasmetal_core__DOT___055510_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055502_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055501_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055500_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055504_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007970_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055505_)))))))))))));
    vlSelf->wasmetal_core__DOT___055909_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055523_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055524_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055526_)))))))));
    vlSelf->wasmetal_core__DOT___055971_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055794_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055795_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055796_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055797_)))))))));
    vlSelf->wasmetal_core__DOT___055805_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055794_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055793_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055792_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055791_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055795_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008069_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055797_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055796_)))))))))))));
    vlSelf->wasmetal_core__DOT___055558_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055523_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055520_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055524_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007983_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055526_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055525_)))))))))))));
    vlSelf->wasmetal_core__DOT___055916_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055599_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055600_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055601_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055602_)))))))));
    vlSelf->wasmetal_core__DOT___055978_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055810_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055811_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055812_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055813_)))))))));
    vlSelf->wasmetal_core__DOT___019255_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055807_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055811_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008077_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055813_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055812_)))))))))))));
    vlSelf->wasmetal_core__DOT___055606_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055599_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055598_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055597_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055596_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055600_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007991_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055602_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055601_)))))))))))));
    vlSelf->wasmetal_core__DOT___055927_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055642_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055655_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055656_)))))))));
    vlSelf->wasmetal_core__DOT___019266_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f0cc55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055644_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055647_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b713560__0))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055829_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f05533U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055828_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055640_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055645_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055832_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008085_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055660_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055655_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055654_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055653_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055652_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055643_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055642_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055656_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007999_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055684_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055670_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055669_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf5f3U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008007_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055667_)))))))));
    vlSelf->wasmetal_core__DOT___055934_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055670_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055669_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055682_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055667_)))))))));
    vlSelf->wasmetal_core__DOT___055864_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055857_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf5f3U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008093_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055855_)))))))));
    vlSelf->wasmetal_core__DOT___055683_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055682_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055681_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055680_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055679_)))))))));
    vlSelf->wasmetal_core__DOT___055863_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055862_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055861_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055860_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055859_)))))))));
    vlSelf->wasmetal_core__DOT___055990_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055989_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x5300U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055828_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055832_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055829_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaacc0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055830_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b713560__0))))))))))))))));
    vlSelf->__VdfgTmp_h12bbe12d__0 = (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xaaaaf0f0ff00ccccULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055858_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055857_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055862_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___055855_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___055859_))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (0x3500U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055861_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___055860_)))))))));
    vlSelf->wasmetal_core__DOT___054831_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hef814ba9__0)))));
    vlSelf->wasmetal_core__DOT___055105_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055089_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha89e6386__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h284fdec6__0)))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf5533ffU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xc0aU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0)))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((0xc0aU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebcfe313__0)))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xc0aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___054766_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054762_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054761_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054760_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054759_)))))))));
    vlSelf->wasmetal_core__DOT___055130_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054830_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054829_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054828_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054833_)))))))));
    vlSelf->wasmetal_core__DOT___055144_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054876_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054878_)))))))));
    vlSelf->wasmetal_core__DOT___055153_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054896_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054914_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054917_)))))))));
    vlSelf->__VdfgTmp_h8cc03967__0 = (((IData)(vlSelf->wasmetal_core__DOT___054938_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054937_));
    vlSelf->wasmetal_core__DOT___054939_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___054934_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___054686_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h57efbd27__0))))))));
    vlSelf->wasmetal_core__DOT___054947_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054941_))));
    vlSelf->wasmetal_core__DOT___055175_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054938_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054937_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054934_)))))))));
    vlSelf->wasmetal_core__DOT___055183_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054977_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054978_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054980_)))))))));
    vlSelf->wasmetal_core__DOT___054986_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054982_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054981_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054980_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054979_)))))))));
    vlSelf->wasmetal_core__DOT___055032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff33ff550f0f0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055017_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h57d78adc__0)))))))))));
    vlSelf->wasmetal_core__DOT___055026_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055020_))));
    vlSelf->wasmetal_core__DOT___055192_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055017_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055027_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055028_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055021_)))))))));
    vlSelf->__VdfgTmp_ha587a88f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                       << 2U) | ((2U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055028_))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___055027_))))));
    vlSelf->__VdfgTmp_h5aecec62__0 = (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (~ (IData)(vlSelf->wasmetal_core__DOT___035269_)))));
    vlSelf->wasmetal_core__DOT___011102_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (~ (IData)(vlSelf->wasmetal_core__DOT___035269_))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___034181_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))));
    vlSelf->wasmetal_core__DOT___034180_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d))));
    vlSelf->wasmetal_core__DOT___010722_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                                   >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___034179_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))));
    vlSelf->wasmetal_core__DOT___034178_ = (1U & (7U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___010721_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___010531_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008974_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___056274_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___033033_)))));
    vlSelf->wasmetal_core__DOT___008495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___008500_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___008017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___007208_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)))));
    vlSelf->wasmetal_core__DOT___063835_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84f9890b__0))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030104_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030232_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___064478_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___065076_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063833_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065075_)))));
    vlSelf->wasmetal_core__DOT___064741_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064735_))));
    vlSelf->wasmetal_core__DOT___064903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064902_))));
    vlSelf->wasmetal_core__DOT___065201_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064470_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065200_)))));
    vlSelf->wasmetal_core__DOT___065621_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065075_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065620_)))));
    vlSelf->wasmetal_core__DOT___065309_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065308_)))));
    vlSelf->wasmetal_core__DOT___063965_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___042099_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___042102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042101_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042097_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042103_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042098_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042095_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x8000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063935_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063934_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7da480c4__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042094_))))))))))))));
    vlSelf->wasmetal_core__DOT___065426_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064902_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065425_)))));
    vlSelf->wasmetal_core__DOT___064748_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2e505808__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x4fff00ff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0791be06__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063872_)))));
    vlSelf->wasmetal_core__DOT___065709_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065200_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065708_)))));
    vlSelf->wasmetal_core__DOT___065811_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065308_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065810_)))));
    vlSelf->wasmetal_core__DOT___065907_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065906_)))));
    vlSelf->wasmetal_core__DOT___065931_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065620_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065930_)))));
    vlSelf->wasmetal_core__DOT___066076_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065708_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066075_)))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___048888_ = vlSelf->wasmetal_core__DOT___001770_;
        vlSelf->wasmetal_core__DOT___048755_ = vlSelf->wasmetal_core__DOT___002225_;
        vlSelf->wasmetal_core__DOT___001935_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___000183_));
        vlSelf->wasmetal_core__DOT___001964_ = vlSelf->wasmetal_core__DOT___001658_;
        vlSelf->wasmetal_core__DOT___000163_ = vlSelf->wasmetal_core__DOT___000184_;
        vlSelf->wasmetal_core__DOT___001337_ = vlSelf->wasmetal_core__DOT___001659_;
        vlSelf->wasmetal_core__DOT___002932_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000179_))))));
        vlSelf->wasmetal_core__DOT___001721_ = vlSelf->wasmetal_core__DOT___001734_;
        vlSelf->wasmetal_core__DOT___002650_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001657_))))));
        vlSelf->wasmetal_core__DOT___002563_ = vlSelf->wasmetal_core__DOT___001773_;
        vlSelf->wasmetal_core__DOT___002510_ = vlSelf->wasmetal_core__DOT___001930_;
        vlSelf->wasmetal_core__DOT___001854_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001896_));
    } else {
        vlSelf->wasmetal_core__DOT___048888_ = vlSelf->wasmetal_core__DOT___001344_;
        vlSelf->wasmetal_core__DOT___048755_ = vlSelf->wasmetal_core__DOT___001728_;
        vlSelf->wasmetal_core__DOT___001935_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2135b46c__0)));
        vlSelf->wasmetal_core__DOT___001964_ = vlSelf->wasmetal_core__DOT___001896_;
        vlSelf->wasmetal_core__DOT___000163_ = vlSelf->wasmetal_core__DOT___000183_;
        vlSelf->wasmetal_core__DOT___001337_ = vlSelf->wasmetal_core__DOT___001658_;
        vlSelf->wasmetal_core__DOT___002932_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001734_));
        vlSelf->wasmetal_core__DOT___001721_ = vlSelf->wasmetal_core__DOT___000184_;
        vlSelf->wasmetal_core__DOT___002650_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001773_));
        vlSelf->wasmetal_core__DOT___002563_ = vlSelf->wasmetal_core__DOT___001659_;
        vlSelf->wasmetal_core__DOT___002510_ = vlSelf->wasmetal_core__DOT___002148_;
        vlSelf->wasmetal_core__DOT___001854_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8fa00ac2__0)));
    }
    vlSelf->wasmetal_core__DOT___066133_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065810_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066132_)))));
    vlSelf->wasmetal_core__DOT___063995_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063994_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063993_)))));
    vlSelf->wasmetal_core__DOT___066268_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065906_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066267_)))));
    vlSelf->__VdfgTmp_h21594217__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4ea6bbba__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x96U 
                                                 >> 
                                                 ((4U 
                                                   & ((6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072046_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___072045_)))) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h982d8c02__0)))));
    vlSelf->__VdfgTmp_ha753d377__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h66324e1d__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h982d8c02__0)))));
    vlSelf->__VdfgTmp_hbbb75ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0791be06__0))));
    vlSelf->wasmetal_core__DOT___064498_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064496_)))));
    vlSelf->wasmetal_core__DOT___064754_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064752_)))));
    vlSelf->wasmetal_core__DOT___064923_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064922_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064921_)))));
    vlSelf->wasmetal_core__DOT___065077_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063980_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063974_)))));
    if (vlSelf->wasmetal_core__DOT___042104_) {
        if (vlSelf->wasmetal_core__DOT___042103_) {
            if (vlSelf->wasmetal_core__DOT___042102_) {
                if (vlSelf->wasmetal_core__DOT___042101_) {
                    if (vlSelf->wasmetal_core__DOT___042100_) {
                        if (vlSelf->wasmetal_core__DOT___042099_) {
                            if (vlSelf->wasmetal_core__DOT___042098_) {
                                if (vlSelf->wasmetal_core__DOT___042097_) {
                                    if (vlSelf->wasmetal_core__DOT___042096_) {
                                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                            = ((IData)(vlSelf->wasmetal_core__DOT___042094_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042294_));
                                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                            = ((IData)(vlSelf->wasmetal_core__DOT___042094_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042082_));
                                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                            = ((~ (IData)(vlSelf->wasmetal_core__DOT___042094_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___042294_));
                                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                            = ((~ (IData)(vlSelf->wasmetal_core__DOT___042094_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___042082_));
                                    } else {
                                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042296_;
                                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042084_;
                                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042296_;
                                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042084_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042297_;
                                    vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042085_;
                                    vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042297_;
                                    vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042085_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042298_;
                                vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042086_;
                                vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042298_;
                                vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042086_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042299_;
                            vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042087_;
                            vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042299_;
                            vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042087_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042300_;
                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042088_;
                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042300_;
                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042088_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042301_;
                    vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042089_;
                    vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042301_;
                    vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042089_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042302_;
                vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042090_;
                vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042302_;
                vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042090_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042303_;
            vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042091_;
            vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042303_;
            vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042091_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042304_;
        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042092_;
        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042304_;
        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042092_;
    }
    if (vlSelf->wasmetal_core__DOT___042176_) {
        if (vlSelf->wasmetal_core__DOT___042174_) {
            if (vlSelf->wasmetal_core__DOT___042173_) {
                if (vlSelf->wasmetal_core__DOT___042172_) {
                    if (vlSelf->wasmetal_core__DOT___042171_) {
                        if (vlSelf->wasmetal_core__DOT___042170_) {
                            if (vlSelf->wasmetal_core__DOT___042169_) {
                                if (vlSelf->wasmetal_core__DOT___042168_) {
                                    if (vlSelf->wasmetal_core__DOT___042167_) {
                                        if (vlSelf->wasmetal_core__DOT___042166_) {
                                            if (vlSelf->wasmetal_core__DOT___042165_) {
                                                if (vlSelf->wasmetal_core__DOT___042185_) {
                                                    if (vlSelf->wasmetal_core__DOT___042184_) {
                                                        if (vlSelf->wasmetal_core__DOT___042183_) {
                                                            if (vlSelf->wasmetal_core__DOT___042182_) {
                                                                if (vlSelf->wasmetal_core__DOT___042181_) {
                                                                    if (vlSelf->wasmetal_core__DOT___042180_) {
                                                                        if (vlSelf->wasmetal_core__DOT___042179_) {
                                                                            if (vlSelf->wasmetal_core__DOT___042178_) {
                                                                                if (vlSelf->wasmetal_core__DOT___042175_) {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & ((~ 
                                                                                (9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))) 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042140_)));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                ((~ 
                                                                                (9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042140_));
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)));
                                                                                } else {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042352_));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042151_));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042151_;
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042352_));
                                                                                }
                                                                            } else {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042355_));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042154_));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042154_;
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042355_));
                                                                            }
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042356_));
                                                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042155_));
                                                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042155_;
                                                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042356_));
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042357_));
                                                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042156_));
                                                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                            = vlSelf->wasmetal_core__DOT___042156_;
                                                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042357_));
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042358_));
                                                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042157_));
                                                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                        = vlSelf->wasmetal_core__DOT___042157_;
                                                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042358_));
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042359_));
                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042158_));
                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                    = vlSelf->wasmetal_core__DOT___042158_;
                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042359_));
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042360_));
                                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042159_));
                                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                = vlSelf->wasmetal_core__DOT___042159_;
                                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042360_));
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042361_));
                                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042160_));
                                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                            = vlSelf->wasmetal_core__DOT___042160_;
                                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042361_));
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042362_));
                                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042161_));
                                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                        = vlSelf->wasmetal_core__DOT___042161_;
                                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042362_));
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042342_));
                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042141_));
                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                    = vlSelf->wasmetal_core__DOT___042141_;
                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042342_));
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042343_));
                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042142_));
                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                = vlSelf->wasmetal_core__DOT___042142_;
                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042343_));
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042344_));
                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042143_));
                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042143_;
                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042344_));
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042345_));
                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042144_));
                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042144_;
                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042345_));
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042346_));
                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042145_));
                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042145_;
                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042346_));
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042347_));
                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042146_));
                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                = vlSelf->wasmetal_core__DOT___042146_;
                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042347_));
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042348_));
                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042147_));
                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                            = vlSelf->wasmetal_core__DOT___042147_;
                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042348_));
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042349_));
                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042148_));
                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                        = vlSelf->wasmetal_core__DOT___042148_;
                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042349_));
                }
            } else {
                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042350_));
                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042149_));
                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                    = vlSelf->wasmetal_core__DOT___042149_;
                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042350_));
            }
        } else {
            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042351_));
            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042150_));
            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                = vlSelf->wasmetal_core__DOT___042150_;
            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042351_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042353_));
        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042152_));
        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___042152_;
        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042353_));
    }
    vlSelf->wasmetal_core__DOT___065194_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064490_)))));
    vlSelf->wasmetal_core__DOT___001934_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8c923865__0))))))));
    vlSelf->wasmetal_core__DOT___065313_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064750_)))));
    vlSelf->wasmetal_core__DOT___001963_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8bf08b0f__0))))))));
    vlSelf->wasmetal_core__DOT___001336_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff0fff0033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001662_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf20b3c9b__0))))))));
    vlSelf->__VdfgTmp_hdf798121__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hca6242ab__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___001846_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf20b3c9b__0)))))));
    vlSelf->wasmetal_core__DOT___065419_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064921_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064919_)))));
    vlSelf->wasmetal_core__DOT___064924_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064920_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064919_)))));
    vlSelf->wasmetal_core__DOT___065195_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064491_))));
    vlSelf->wasmetal_core__DOT___064499_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064491_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064490_)))));
    vlSelf->wasmetal_core__DOT___000164_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff0fff0033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000574_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h436041ff__0))))))));
    vlSelf->__VdfgTmp_hea3488cd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0fd3d582__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___002385_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h436041ff__0)))))));
    if (vlSelf->wasmetal_core__DOT___000181_) {
        vlSelf->wasmetal_core__DOT___002689_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___002144_));
        vlSelf->wasmetal_core__DOT___002324_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___001315_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001314_)))));
        vlSelf->wasmetal_core__DOT___002933_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (0xcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h47d0b828__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___002689_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8c923865__0)))));
        if (vlSelf->wasmetal_core__DOT___000180_) {
            vlSelf->wasmetal_core__DOT___002324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___001317_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001316_))));
            vlSelf->wasmetal_core__DOT___002933_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___002235_)));
        } else {
            vlSelf->wasmetal_core__DOT___002324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___001313_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001312_))));
            vlSelf->wasmetal_core__DOT___002933_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he7245d4a__0))));
        }
    }
    vlSelf->__VdfgTmp_h1e7febb9__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___000718_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hec35f81b__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002144_))));
    vlSelf->wasmetal_core__DOT___066271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065420_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065314_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064751_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___064755_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064751_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064750_)))));
    vlSelf->wasmetal_core__DOT___065078_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063975_))));
    vlSelf->wasmetal_core__DOT___063983_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063975_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063974_)))));
    vlSelf->wasmetal_core__DOT___063926_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063923_))));
    vlSelf->__VdfgTmp_hc6bfb5bb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002465_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001780_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001301_))))))))));
    vlSelf->__VdfgTmp_h2ac6c9b8__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001780_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001290_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001300_))))))))));
    vlSelf->wasmetal_core__DOT___001849_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001301_))))));
    vlSelf->wasmetal_core__DOT___002730_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001314_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001315_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001312_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001313_)))))))));
    vlSelf->__VdfgTmp_h5e317429__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002110_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___002465_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001302_))))))))));
    vlSelf->wasmetal_core__DOT___002509_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002234_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002233_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he7245d4a__0))))))));
    vlSelf->wasmetal_core__DOT___064771_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2e505808__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063872_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063921_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063915_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063901_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063902_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61f75715__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___063925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h61f75715__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063909_))));
    vlSelf->__VdfgTmp_h170507c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001316_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001317_));
    vlSelf->__VdfgTmp_hcd5a09ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001316_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001317_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001314_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001315_))))));
    vlSelf->wasmetal_core__DOT___002894_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001786_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001785_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001783_)))))))));
    vlSelf->__VdfgTmp_h89619cd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001786_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001785_)));
    vlSelf->__VdfgTmp_h73960028__0 = (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001786_));
    vlSelf->__VdfgTmp_hcf8aa4a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h29c4951c__0)));
    vlSelf->wasmetal_core__DOT___048816_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h29c4951c__0))))));
    vlSelf->wasmetal_core__DOT___068941_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048841_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048842_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->__VdfgTmp_hdb0eb761__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                          ? (IData)(vlSelf->wasmetal_core__DOT___000924_)
                                          : (IData)(vlSelf->wasmetal_core__DOT___001930_)));
    vlSelf->wasmetal_core__DOT___069039_ = (1U & (0xccf000aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002853_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048684_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048685_)))))));
    vlSelf->__VdfgTmp_h804cf86b__0 = (((IData)(vlSelf->wasmetal_core__DOT___002390_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h47d0b828__0));
    vlSelf->wasmetal_core__DOT___065421_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064925_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064922_)))));
    vlSelf->wasmetal_core__DOT___064929_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064925_)))));
    vlSelf->wasmetal_core__DOT___065196_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064509_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064497_)))));
    vlSelf->wasmetal_core__DOT___064511_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064509_)))));
    vlSelf->wasmetal_core__DOT___066325_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066324_)))));
    vlSelf->wasmetal_core__DOT___066653_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066324_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066652_)))));
    vlSelf->wasmetal_core__DOT___066862_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066530_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066861_)))));
    vlSelf->wasmetal_core__DOT___066531_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066530_)))));
    vlSelf->wasmetal_core__DOT___066612_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066267_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066611_)))));
    vlSelf->wasmetal_core__DOT___066899_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066611_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066898_)))));
    vlSelf->wasmetal_core__DOT___066405_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066075_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066404_)))));
    vlSelf->wasmetal_core__DOT___066775_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066404_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066774_)))));
    vlSelf->wasmetal_core__DOT___065315_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064757_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064753_)))));
    vlSelf->wasmetal_core__DOT___064759_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064758_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064757_)))));
    vlSelf->wasmetal_core__DOT___065079_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063993_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063981_)))));
    vlSelf->wasmetal_core__DOT___063982_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063980_)))));
    vlSelf->__VdfgTmp_h5a2cc5a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0))));
    vlSelf->wasmetal_core__DOT___002649_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2b3c1bbf__0)))))));
    vlSelf->__VdfgTmp_hae207145__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2b3c1bbf__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___002181_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8bf08b0f__0)))))));
    vlSelf->wasmetal_core__DOT___002931_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4408f503__0)))))));
    vlSelf->wasmetal_core__DOT___002688_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4408f503__0)))))));
    vlSelf->__VdfgTmp_h07a6aef0__0 = (((IData)(vlSelf->wasmetal_core__DOT___002272_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002271_));
    vlSelf->__VdfgTmp_ha952ad99__0 = (((IData)(vlSelf->wasmetal_core__DOT___002069_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002068_));
    vlSelf->__VdfgTmp_hbd418077__0 = (((IData)(vlSelf->wasmetal_core__DOT___002289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002288_));
    vlSelf->__VdfgTmp_he278c168__0 = ((4U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h95b0aa6a__0));
    vlSelf->__VdfgTmp_h343b1824__0 = (((IData)(vlSelf->wasmetal_core__DOT___000168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000167_));
    vlSelf->__VdfgTmp_he9d730e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___002601_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd61aa5bc__0));
    vlSelf->__VdfgTmp_he2ba16db__0 = (((IData)(vlSelf->wasmetal_core__DOT___002852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002851_));
    vlSelf->wasmetal_core__DOT___002476_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048735_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                          ? 
                                                                         (0xc0aU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2135b46c__0))
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___002143_)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h162766a7__0))))))));
    vlSelf->__VdfgTmp_h9be80f53__0 = (((IData)(vlSelf->wasmetal_core__DOT___002770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002769_));
    vlSelf->__VdfgTmp_h4f306e5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___069133_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069084_));
    vlSelf->__VdfgTmp_h8025ed93__0 = (((IData)(vlSelf->wasmetal_core__DOT___069084_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069033_));
    vlSelf->__VdfgTmp_h958b2749__0 = (((IData)(vlSelf->wasmetal_core__DOT___067729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067663_));
    vlSelf->__VdfgTmp_hd78cc544__0 = (((IData)(vlSelf->wasmetal_core__DOT___067663_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067591_));
    vlSelf->wasmetal_core__DOT___067596_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063836_))));
    vlSelf->wasmetal_core__DOT___063838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063836_))));
    vlSelf->wasmetal_core__DOT___069034_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068961_)))));
    vlSelf->wasmetal_core__DOT___068962_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068961_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068935_)))));
    vlSelf->wasmetal_core__DOT___068892_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068844_)))));
    vlSelf->wasmetal_core__DOT___068790_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068789_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068745_)))));
    vlSelf->wasmetal_core__DOT___068936_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068935_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068891_)))));
    vlSelf->wasmetal_core__DOT___068697_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068696_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068648_)))));
    vlSelf->wasmetal_core__DOT___068845_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068789_)))));
    vlSelf->wasmetal_core__DOT___068599_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068598_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068546_)))));
    vlSelf->wasmetal_core__DOT___068746_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068745_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068696_)))));
    vlSelf->wasmetal_core__DOT___068649_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068598_)))));
    vlSelf->wasmetal_core__DOT___068473_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068472_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068419_)))));
    vlSelf->wasmetal_core__DOT___068547_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068546_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068472_)))));
    vlSelf->wasmetal_core__DOT___068396_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068395_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068340_)))));
    vlSelf->wasmetal_core__DOT___068287_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068286_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068233_)))));
    vlSelf->wasmetal_core__DOT___068420_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068395_)))));
    vlSelf->wasmetal_core__DOT___068149_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068097_)))));
    vlSelf->wasmetal_core__DOT___068341_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068286_)))));
    vlSelf->wasmetal_core__DOT___068073_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068024_)))));
    vlSelf->wasmetal_core__DOT___068234_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068148_)))));
    vlSelf->wasmetal_core__DOT___067968_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067901_)))));
    vlSelf->wasmetal_core__DOT___068098_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068097_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068072_)))));
    vlSelf->wasmetal_core__DOT___068025_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068024_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067967_)))));
    vlSelf->wasmetal_core__DOT___067815_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067814_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067753_)))));
    vlSelf->wasmetal_core__DOT___067902_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067901_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067814_)))));
    vlSelf->wasmetal_core__DOT___067754_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067729_)))));
    vlSelf->wasmetal_core__DOT___067592_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___067447_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2bd8c9ed__0))));
    vlSelf->wasmetal_core__DOT___067496_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0))));
    vlSelf->wasmetal_core__DOT___067300_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_had26118d__0))));
    vlSelf->wasmetal_core__DOT___067145_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4e6deac__0))));
    vlSelf->wasmetal_core__DOT___066962_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4438b1a5__0))));
    vlSelf->wasmetal_core__DOT___066843_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a3dbf89__0))));
    vlSelf->wasmetal_core__DOT___066638_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h898e287a__0))));
    vlSelf->wasmetal_core__DOT___066516_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e6b526c__0))));
    vlSelf->wasmetal_core__DOT___067330_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h717e9861__0))));
    vlSelf->wasmetal_core__DOT___066304_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h238b010e__0))));
    vlSelf->wasmetal_core__DOT___067186_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdba97a87__0))));
    vlSelf->wasmetal_core__DOT___066116_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9040377d__0))));
    vlSelf->wasmetal_core__DOT___067067_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))));
    vlSelf->wasmetal_core__DOT___066884_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))));
    vlSelf->wasmetal_core__DOT___065925_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd9104ee__0))));
    vlSelf->wasmetal_core__DOT___066760_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b010904__0))));
    vlSelf->wasmetal_core__DOT___066593_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))));
    vlSelf->wasmetal_core__DOT___065793_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h06dc5af9__0))));
    vlSelf->wasmetal_core__DOT___066390_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he924c244__0))));
    vlSelf->wasmetal_core__DOT___065595_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))));
    vlSelf->wasmetal_core__DOT___066260_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7dd7d539__0))));
    vlSelf->wasmetal_core__DOT___066070_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))));
    vlSelf->wasmetal_core__DOT___065291_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbfd77ec1__0))));
    vlSelf->wasmetal_core__DOT___065070_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))));
    vlSelf->wasmetal_core__DOT___065889_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9d768121__0))));
    vlSelf->wasmetal_core__DOT___065691_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa154e86__0))));
    vlSelf->wasmetal_core__DOT___065404_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h03893f91__0))));
    vlSelf->wasmetal_core__DOT___065175_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h776ad714__0))));
    vlSelf->wasmetal_core__DOT___064723_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___064890_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4328824__0))));
    vlSelf->wasmetal_core__DOT___064482_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))));
    vlSelf->wasmetal_core__DOT___063827_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063826_))));
    vlSelf->wasmetal_core__DOT___049032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049279_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049027_))));
    vlSelf->wasmetal_core__DOT___049354_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049075_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049077_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049075_))));
    vlSelf->wasmetal_core__DOT___049022_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049017_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049281_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049017_))));
    vlSelf->wasmetal_core__DOT___049360_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049080_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049081_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049080_))));
    vlSelf->wasmetal_core__DOT___049021_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049020_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049248_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049020_))));
    vlSelf->wasmetal_core__DOT___049359_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049122_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049125_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049122_))));
    vlSelf->wasmetal_core__DOT___053680_ = (1U & (0xaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051611_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb6137419__0))));
    vlSelf->wasmetal_core__DOT___053689_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((1U 
                                                                  >> 
                                                                  (1U 
                                                                   & (0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051706_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051613_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hb6137419__0))))))));
    vlSelf->wasmetal_core__DOT___051650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051612_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb6137419__0))))));
    vlSelf->wasmetal_core__DOT___051372_ = (1U & (0xc000aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((0xacU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049529_)))));
    vlSelf->wasmetal_core__DOT___048673_ = (1U & (0xc000aU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0))))));
    vlSelf->__VdfgTmp_h951148c2__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hce73595f__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0))))));
    vlSelf->__VdfgTmp_h6a1d65be__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hce73595f__0))))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)))))));
    vlSelf->wasmetal_core__DOT___053906_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___051689_)) 
                                                            << 1U))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               >> 1U))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))));
    vlSelf->wasmetal_core__DOT___051690_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051689_))));
    vlSelf->wasmetal_core__DOT___051719_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051630_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051631_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051630_))));
    vlSelf->wasmetal_core__DOT___050828_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                              << 1U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049644_))));
    vlSelf->wasmetal_core__DOT___051354_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x503U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h79a3c79a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051586_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                              << 1U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___049014_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049009_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049247_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049009_))));
    vlSelf->wasmetal_core__DOT___049358_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049123_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049124_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049123_))));
    vlSelf->__VdfgTmp_habccd4be__0 = (((IData)(vlSelf->wasmetal_core__DOT___049161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049152_));
    vlSelf->wasmetal_core__DOT___049464_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049314_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049321_))));
    vlSelf->__VdfgTmp_hc4ac601e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049366_));
    vlSelf->__VdfgTmp_h2b3afffd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049365_));
    vlSelf->__VdfgTmp_h0a02dc0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049140_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049139_));
    vlSelf->wasmetal_core__DOT___049501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049140_))));
    vlSelf->__VdfgTmp_hebb238d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___049161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049160_));
    vlSelf->__VdfgTmp_hd698a5e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049314_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049313_));
    vlSelf->wasmetal_core__DOT___050729_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049572_))));
    vlSelf->__VdfgTmp_hc497fe80__0 = (((IData)(vlSelf->wasmetal_core__DOT___049160_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049168_));
    vlSelf->wasmetal_core__DOT___050632_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050510_))));
    vlSelf->wasmetal_core__DOT___049465_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049317_))));
    vlSelf->wasmetal_core__DOT___049853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049096_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049096_))));
    vlSelf->wasmetal_core__DOT___049839_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049260_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049262_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049260_))));
    vlSelf->wasmetal_core__DOT___049574_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049572_))));
    vlSelf->__VdfgTmp_hef58fdbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049168_));
    vlSelf->wasmetal_core__DOT___050514_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050510_))));
    vlSelf->wasmetal_core__DOT___049319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049317_))));
    vlSelf->wasmetal_core__DOT___049852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049064_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049066_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049064_))));
    vlSelf->wasmetal_core__DOT___049838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049271_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049271_))));
    vlSelf->wasmetal_core__DOT___049530_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049528_))));
    vlSelf->wasmetal_core__DOT___009520_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050848_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79a3c79a__0))));
    vlSelf->wasmetal_core__DOT___051582_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051346_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051581_))));
    vlSelf->wasmetal_core__DOT___051614_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051613_))));
    vlSelf->wasmetal_core__DOT___051550_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051549_))));
    vlSelf->wasmetal_core__DOT___049854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049065_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049061_))));
    vlSelf->wasmetal_core__DOT___049841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049270_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049270_))));
    vlSelf->wasmetal_core__DOT___050523_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049040_))));
    vlSelf->wasmetal_core__DOT___049277_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049275_))));
    vlSelf->__VdfgTmp_h6ae5baa5__0 = (((IData)(vlSelf->wasmetal_core__DOT___049608_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049352_));
    vlSelf->wasmetal_core__DOT___049073_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049072_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049071_))));
    vlSelf->wasmetal_core__DOT___049042_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049040_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049039_))));
    vlSelf->wasmetal_core__DOT___049452_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049280_))));
    vlSelf->__VdfgTmp_hdfb5cdf6__0 = (((IData)(vlSelf->wasmetal_core__DOT___049352_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049351_));
    vlSelf->wasmetal_core__DOT___049491_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049071_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049078_))));
    vlSelf->wasmetal_core__DOT___050625_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049571_))));
    vlSelf->__VdfgTmp_ha51ab883__0 = (((IData)(vlSelf->wasmetal_core__DOT___049169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049181_));
    vlSelf->wasmetal_core__DOT___050633_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050513_))));
    vlSelf->wasmetal_core__DOT___049466_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049294_))));
    vlSelf->wasmetal_core__DOT___050058_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___050788_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___049504_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049503_))));
    vlSelf->wasmetal_core__DOT___049575_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049570_))));
    vlSelf->__VdfgTmp_h2121b61a__0 = (((IData)(vlSelf->wasmetal_core__DOT___049181_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049180_));
    vlSelf->wasmetal_core__DOT___050515_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050513_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050512_))));
    vlSelf->wasmetal_core__DOT___049300_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049294_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049293_))));
    vlSelf->wasmetal_core__DOT___049057_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0))))));
    vlSelf->wasmetal_core__DOT___049617_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049142_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049119_))));
    vlSelf->wasmetal_core__DOT___050624_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049559_))));
    vlSelf->wasmetal_core__DOT___049518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049180_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049189_))));
    vlSelf->wasmetal_core__DOT___050620_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050505_))));
    vlSelf->wasmetal_core__DOT___049472_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049293_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049298_))));
    vlSelf->wasmetal_core__DOT___047952_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0))))));
    vlSelf->wasmetal_core__DOT___048590_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048587_))));
    vlSelf->__VdfgTmp_h15ceac3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___049357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049367_));
    vlSelf->wasmetal_core__DOT___049132_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049130_))));
    vlSelf->wasmetal_core__DOT___049563_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049558_))));
    vlSelf->__VdfgTmp_hcb165b79__0 = (((IData)(vlSelf->wasmetal_core__DOT___049189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049188_));
    vlSelf->wasmetal_core__DOT___050509_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050504_))));
    vlSelf->__VdfgTmp_hf18161ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___049298_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049297_));
    vlSelf->wasmetal_core__DOT___051433_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0))))));
    vlSelf->wasmetal_core__DOT___051905_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0))))));
    vlSelf->wasmetal_core__DOT___049121_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049119_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf502c6b2__0))))));
    vlSelf->wasmetal_core__DOT___050627_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049561_))));
    vlSelf->wasmetal_core__DOT___049517_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049188_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049199_))));
    vlSelf->wasmetal_core__DOT___050619_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050504_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050507_))));
    vlSelf->wasmetal_core__DOT___049471_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049304_))));
    vlSelf->wasmetal_core__DOT___050046_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0))))));
    vlSelf->wasmetal_core__DOT___050787_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0))))));
    vlSelf->wasmetal_core__DOT___049500_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048582_))));
    vlSelf->wasmetal_core__DOT___049562_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049560_))));
    vlSelf->__VdfgTmp_h10a4b2d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049199_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049198_));
    vlSelf->wasmetal_core__DOT___050508_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050507_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050506_))));
    vlSelf->wasmetal_core__DOT___049308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049304_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049303_))));
    vlSelf->__VdfgTmp_h36cbed8c__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd6896023__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)))))));
    vlSelf->wasmetal_core__DOT___049056_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6896023__0))))));
    vlSelf->wasmetal_core__DOT___049616_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf502c6b2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049117_))));
    vlSelf->wasmetal_core__DOT___050626_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049560_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049553_))));
    vlSelf->wasmetal_core__DOT___049516_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049198_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049203_))));
    vlSelf->wasmetal_core__DOT___050608_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048989_))));
    vlSelf->wasmetal_core__DOT___049470_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049306_))));
    vlSelf->wasmetal_core__DOT___047951_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0))))));
    vlSelf->wasmetal_core__DOT___048589_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048581_))));
    vlSelf->__VdfgTmp_h2cac88ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___049553_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049552_));
    vlSelf->wasmetal_core__DOT___049204_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049203_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049202_))));
    vlSelf->wasmetal_core__DOT___048999_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048988_))));
    vlSelf->wasmetal_core__DOT___049307_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049305_))));
    vlSelf->wasmetal_core__DOT___050851_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6896023__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0))))));
    vlSelf->wasmetal_core__DOT___051906_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6896023__0))))));
    vlSelf->wasmetal_core__DOT___049120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049116_))));
    vlSelf->__VdfgTmp_h92ec5796__0 = (((IData)(vlSelf->wasmetal_core__DOT___049552_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049555_));
    vlSelf->__VdfgTmp_h97f76463__0 = (((IData)(vlSelf->wasmetal_core__DOT___049202_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049104_));
    vlSelf->wasmetal_core__DOT___050607_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048997_))));
    vlSelf->wasmetal_core__DOT___049469_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049305_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049257_))));
    vlSelf->wasmetal_core__DOT___050047_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0))))));
    vlSelf->wasmetal_core__DOT___050790_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0))))));
    vlSelf->wasmetal_core__DOT___049499_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049498_))));
    vlSelf->__VdfgTmp_hd0aa9c81__0 = (((IData)(vlSelf->wasmetal_core__DOT___049555_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049554_));
    vlSelf->__VdfgTmp_hf7ec4412__0 = (((IData)(vlSelf->wasmetal_core__DOT___049104_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049103_));
    vlSelf->wasmetal_core__DOT___048998_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048996_))));
    vlSelf->wasmetal_core__DOT___049259_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049256_))));
    vlSelf->wasmetal_core__DOT___050827_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_he957a5af__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0))))));
    vlSelf->wasmetal_core__DOT___049055_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he957a5af__0))))));
    vlSelf->wasmetal_core__DOT___049615_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049116_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfbafed17__0))))));
    vlSelf->__VdfgTmp_h6f0935bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___049554_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049565_));
    vlSelf->__VdfgTmp_h337a7e76__0 = (((IData)(vlSelf->wasmetal_core__DOT___049103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049108_));
    vlSelf->wasmetal_core__DOT___050602_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048971_))));
    vlSelf->wasmetal_core__DOT___049457_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049256_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049255_))));
    vlSelf->wasmetal_core__DOT___047950_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0))))));
    vlSelf->wasmetal_core__DOT___049699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049698_))));
    vlSelf->__VdfgTmp_hd992aaf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___049565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049564_));
    vlSelf->wasmetal_core__DOT___049109_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049107_))));
    vlSelf->wasmetal_core__DOT___048981_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048971_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048970_))));
    vlSelf->wasmetal_core__DOT___049258_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049254_))));
    vlSelf->wasmetal_core__DOT___050850_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he957a5af__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0))))));
    vlSelf->wasmetal_core__DOT___049226_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_he957a5af__0))))));
    vlSelf->wasmetal_core__DOT___049748_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfbafed17__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049747_))));
    vlSelf->__VdfgTmp_h65c50ed7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049567_));
    vlSelf->wasmetal_core__DOT___049485_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049107_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049090_))));
    vlSelf->wasmetal_core__DOT___049837_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048970_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048979_))));
    vlSelf->wasmetal_core__DOT___049456_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049254_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049265_))));
    vlSelf->wasmetal_core__DOT___049527_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0))))));
    vlSelf->wasmetal_core__DOT___050789_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0))))));
    vlSelf->wasmetal_core__DOT___049796_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049795_))));
    vlSelf->__VdfgTmp_h15d2df15__0 = (((IData)(vlSelf->wasmetal_core__DOT___049567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049566_));
    vlSelf->wasmetal_core__DOT___049100_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049090_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049089_))));
    vlSelf->wasmetal_core__DOT___048980_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048978_))));
    vlSelf->__VdfgTmp_h32efca0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___049265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049264_));
    vlSelf->wasmetal_core__DOT___049645_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0))))));
    vlSelf->wasmetal_core__DOT___049054_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0))))));
    vlSelf->wasmetal_core__DOT___049885_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049747_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049884_))));
    vlSelf->__VdfgTmp_h40926396__0 = (((IData)(vlSelf->wasmetal_core__DOT___049566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049849_));
    vlSelf->__VdfgTmp_hfc74b95b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049089_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049098_));
    vlSelf->wasmetal_core__DOT___049836_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048978_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049835_))));
    vlSelf->wasmetal_core__DOT___049459_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049263_))));
    vlSelf->wasmetal_core__DOT___049526_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0))))));
    vlSelf->wasmetal_core__DOT___049815_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0))))));
    vlSelf->wasmetal_core__DOT___047949_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0))))));
    vlSelf->wasmetal_core__DOT___050849_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0))))));
    vlSelf->__VdfgTmp_hf09b90d7__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0)))))));
    vlSelf->wasmetal_core__DOT___049440_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0))))));
    vlSelf->wasmetal_core__DOT___049227_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0))))));
    vlSelf->wasmetal_core__DOT___051056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049884_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0))))));
    vlSelf->wasmetal_core__DOT___051288_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0))))));
    vlSelf->wasmetal_core__DOT___051113_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051112_))));
    vlSelf->wasmetal_core__DOT___050692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050691_))));
    vlSelf->wasmetal_core__DOT___063468_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___063476_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___063484_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O))));
    vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030679_));
    vlSelf->wasmetal_core__DOT____Vcellout___128723___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128723___S) 
           ^ (((4U & (((IData)(vlSelf->wasmetal_core__DOT___003029_)
                        ? (IData)(vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__)
                        : (~ (IData)(vlSelf->wasmetal_core__DOT___003029_))) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035237_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128725___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128725___S) 
           ^ (((4U & (((IData)(vlSelf->wasmetal_core__DOT___003029_)
                        ? (IData)(vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__)
                        : (~ (IData)(vlSelf->wasmetal_core__DOT___003029_))) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035253_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134178___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128723___S) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___003029_)) 
                       | (IData)(vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___036925_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134191___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128725___S) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___003029_)) 
                       | (IData)(vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___037030_)));
    vlSelf->wasmetal_core__DOT___042682_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___042595_)
                                                      ? 
                                                     ((1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hdc23a011__0)))
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___042687_) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___042591_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___042683_))
                                                      : 
                                                     (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___042590_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___070632_))))));
    vlSelf->wasmetal_core__DOT___048117_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042722_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042534_))));
    if (vlSelf->wasmetal_core__DOT___042539_) {
        vlSelf->wasmetal_core__DOT___042612_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042554_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042622_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042564_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
    } else if (vlSelf->wasmetal_core__DOT___042542_) {
        if (vlSelf->wasmetal_core__DOT___042541_) {
            if (vlSelf->wasmetal_core__DOT___042536_) {
                vlSelf->wasmetal_core__DOT___042612_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042554_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042622_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042564_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
            } else {
                vlSelf->wasmetal_core__DOT___042612_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042616_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042643_))));
                vlSelf->wasmetal_core__DOT___042554_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042558_)
                              ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                              : (IData)(vlSelf->wasmetal_core__DOT___042555_)));
                vlSelf->wasmetal_core__DOT___042622_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042626_)
                              ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042673_))));
                vlSelf->wasmetal_core__DOT___042564_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042570_) 
                             | (IData)(vlSelf->wasmetal_core__DOT___042566_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT___042612_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042554_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042622_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042564_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___042612_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042554_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042622_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042564_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
    }
    vlSelf->wasmetal_core__DOT___042642_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042646_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042643_))))));
    vlSelf->wasmetal_core__DOT___042693_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042697_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042694_))))));
    vlSelf->wasmetal_core__DOT___042713_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042606_)
                                                         ? 
                                                        (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                                         : 
                                                        (0xeU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___070631_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___042694_))))))));
    vlSelf->wasmetal_core__DOT___042704_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042707_))));
    vlSelf->wasmetal_core__DOT___042739_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042636_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042740_))))));
    vlSelf->wasmetal_core__DOT___016504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042626_))));
    vlSelf->wasmetal_core__DOT___042749_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042626_))));
    vlSelf->wasmetal_core__DOT___042731_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042676_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042673_))))));
    vlSelf->wasmetal_core__DOT___042672_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042676_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042673_))))));
    vlSelf->wasmetal_core__DOT___042662_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042570_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042664_))))));
    vlSelf->wasmetal_core__DOT___042652_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042656_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042653_))))));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026465_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d));
    vlSelf->wasmetal_core__DOT___036753_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036785_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5736dc67__0))));
    vlSelf->wasmetal_core__DOT___063096_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063102_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063108_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063114_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028311_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028278_)
            : (IData)(vlSelf->wasmetal_core__DOT___028246_));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026573_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003269_));
    vlSelf->wasmetal_core__DOT___045061_ = ((IData)(vlSelf->wasmetal_core__DOT___045107_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045106_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045104_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045103_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045102_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045101_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045100_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045099_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045098_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045097_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045096_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045095_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045115_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045114_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045113_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045112_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045111_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045110_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045109_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045108_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045105_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045094_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045070_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045081_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045084_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045085_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045086_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045087_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045088_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045089_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045090_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045091_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045071_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045072_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045073_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045074_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045075_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045076_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045077_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045078_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045079_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045080_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045082_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045083_));
    vlSelf->wasmetal_core__DOT___053586_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___045039_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071908_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___071264_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071263_))));
    vlSelf->wasmetal_core__DOT___071273_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071272_))));
    vlSelf->wasmetal_core__DOT___071278_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071277_))));
    vlSelf->wasmetal_core__DOT___071293_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071292_))));
    vlSelf->wasmetal_core__DOT___071298_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071297_))));
    vlSelf->wasmetal_core__DOT___071313_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071312_))));
    vlSelf->wasmetal_core__DOT___071318_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071317_))));
    vlSelf->wasmetal_core__DOT___071333_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071332_))));
    vlSelf->wasmetal_core__DOT___071338_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071337_))));
    vlSelf->wasmetal_core__DOT___071268_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071267_))));
    vlSelf->wasmetal_core__DOT___071283_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071282_))));
    vlSelf->wasmetal_core__DOT___071288_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071287_))));
    vlSelf->wasmetal_core__DOT___071303_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071302_))));
    vlSelf->wasmetal_core__DOT___071308_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071307_))));
    vlSelf->wasmetal_core__DOT___071323_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071322_))));
    vlSelf->wasmetal_core__DOT___071328_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071327_))));
    vlSelf->wasmetal_core__DOT___071265_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054095_))));
    vlSelf->__VdfgTmp_h8134fe6e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___053990_)))));
    vlSelf->__VdfgTmp_h57cd27d4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                             >> 2U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054047_)))));
    vlSelf->__VdfgTmp_h77f7c585__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054071_)))));
    vlSelf->__VdfgTmp_hbe940684__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054083_)))));
    vlSelf->__VdfgTmp_h8a76b5de__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                             >> 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054059_)))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031356_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031323_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___054185_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128138___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___CO) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034314_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034482_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___135425___DOT__Mr = 
        (0x7ffffffffffULL & VL_MULS_QQQ(43, (0x7ffffffffffULL 
                                             & VL_EXTENDS_QI(43,25, 
                                                             (0x1ffffffU 
                                                              & (vlSelf->insn_y 
                                                                 >> 0x11U)))), 
                                        (0x7ffffffffffULL 
                                         & VL_EXTENDS_QI(43,18, vlSelf->wasmetal_core__DOT____Vcellinp___135426___B))));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027333_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__access_base__05b0__05d));
    vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0xdU) & (IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x2000U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 0xdU) : (IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128484___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032868_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032867_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032897_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032896_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032863_)))));
    vlSelf->wasmetal_core__DOT___032836_ = ((IData)(vlSelf->wasmetal_core__DOT___032868_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___068567_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068545_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068544_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128012___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027803_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027802_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027832_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027831_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027798_)))));
    vlSelf->wasmetal_core__DOT___027771_ = ((IData)(vlSelf->wasmetal_core__DOT___027803_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d));
    vlSelf->wasmetal_core__DOT___065604_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065602_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065802_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065800_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065700_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065698_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065898_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065896_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0xdU) & (IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028121_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028088_)
                  : (vlSelf->insn_x >> 8U)));
    vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (vlSelf->function_params >> 0xdU)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128468___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032676_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032675_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032705_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032704_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032671_)))));
    vlSelf->wasmetal_core__DOT___032644_ = ((IData)(vlSelf->wasmetal_core__DOT___032676_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134210___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037186_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037185_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037214_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037182_)))));
    vlSelf->wasmetal_core__DOT___037155_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037186_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h68654253__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127844___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026359_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026358_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026388_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026387_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026354_)))));
    vlSelf->wasmetal_core__DOT___026327_ = ((IData)(vlSelf->wasmetal_core__DOT___026359_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d));
    vlSelf->wasmetal_core__DOT___053078_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053066_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053073_)))));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___062616_ = (1U & (IData)(
                                                         (0xf0f033aa00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff8fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062610_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062601_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053989_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->cmd_aux))))))))));
    vlSelf->wasmetal_core__DOT___052656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128290___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___030722_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___030721_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030714_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___054902_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51b5ea87__0)))));
    vlSelf->wasmetal_core__DOT___055005_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h223b6529__0)))));
    vlSelf->wasmetal_core__DOT___061209_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e5b7cf0__0)))));
    vlSelf->wasmetal_core__DOT___062118_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb017232__0))))))));
    vlSelf->wasmetal_core__DOT___062084_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))));
    vlSelf->__VdfgTmp_hcf41fd11__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9c4c7506__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h61af7368__0))))));
    vlSelf->wasmetal_core__DOT___054991_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h61af7368__0)))));
    vlSelf->wasmetal_core__DOT___061127_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0d308a29__0)))));
    vlSelf->wasmetal_core__DOT___062062_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf89db412__0))))))));
    vlSelf->wasmetal_core__DOT___062025_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))));
    vlSelf->wasmetal_core__DOT___054952_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8993186__0)))));
    vlSelf->__VdfgTmp_hcb315704__0 = (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb53fd6c1__0)));
    vlSelf->__VdfgTmp_hb1a6f4d3__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5cfad588__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8993186__0))))));
    vlSelf->__VdfgTmp_hb52e5b74__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h0d308a29__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd27b8df6__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5cfad588__0)))))));
    vlSelf->wasmetal_core__DOT___061063_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h988afe01__0)))));
    vlSelf->wasmetal_core__DOT___054903_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h988afe01__0)))));
    vlSelf->wasmetal_core__DOT___061062_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha17fb340__0)))));
    vlSelf->wasmetal_core__DOT___054904_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha17fb340__0)))));
    vlSelf->wasmetal_core__DOT___061990_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3226e594__0))))))));
    vlSelf->wasmetal_core__DOT___061965_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))));
    vlSelf->wasmetal_core__DOT___061045_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb33d3cb7__0)))));
    vlSelf->wasmetal_core__DOT___054905_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb33d3cb7__0)))));
    vlSelf->wasmetal_core__DOT___061046_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbc236300__0)))));
    vlSelf->wasmetal_core__DOT___061975_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))));
    vlSelf->__VdfgTmp_h87c0b1ab__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h82899d97__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51b5ea87__0))))));
    vlSelf->__VdfgTmp_h4481aac1__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbc236300__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf21032c8__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h82899d97__0)))))));
    vlSelf->wasmetal_core__DOT___054870_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hca7cb6a3__0)))));
    vlSelf->wasmetal_core__DOT___060957_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h891cd943__0)))));
    vlSelf->wasmetal_core__DOT___061941_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf4e23b72__0))))))));
    vlSelf->wasmetal_core__DOT___054856_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h08beb063__0)))));
    vlSelf->__VdfgTmp_h85e16522__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h15fa30e3__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h08beb063__0))))));
    vlSelf->wasmetal_core__DOT___054825_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf131a410__0)))));
    vlSelf->wasmetal_core__DOT___060881_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had16ce46__0)))));
    vlSelf->wasmetal_core__DOT___061873_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7c4aea26__0))))))));
    vlSelf->wasmetal_core__DOT___054811_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c85186d__0)))));
    vlSelf->__VdfgTmp_h805d75e1__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1fbedb27__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c85186d__0))))));
    vlSelf->__VdfgTmp_hc1ae2972__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5e3b944f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5ce4c910__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h028c74de__0)))))));
    vlSelf->wasmetal_core__DOT___054786_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5ce4c910__0)))));
    vlSelf->wasmetal_core__DOT___061801_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h16ee9b67__0))))))));
    vlSelf->wasmetal_core__DOT___054771_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hab146f1e__0)))));
    vlSelf->wasmetal_core__DOT___061778_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))));
    vlSelf->wasmetal_core__DOT___054793_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))));
    vlSelf->__VdfgTmp_h743eef07__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd184a96b__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hab146f1e__0))))));
    vlSelf->__VdfgTmp_h5e28409c__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hff6b6a1f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h028c74de__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd184a96b__0)))))));
    vlSelf->wasmetal_core__DOT___062094_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))));
    vlSelf->__VdfgTmp_h0fd3f1c4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h597612ae__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h223b6529__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h997e3a26__0)))))));
    vlSelf->__VdfgTmp_hc6adb13e__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6e5b7cf0__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h997e3a26__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9c4c7506__0)))))));
    vlSelf->wasmetal_core__DOT___061912_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))));
    vlSelf->__VdfgTmp_hc0fd2d13__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he6aadab7__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hca7cb6a3__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6b627b07__0)))))));
    vlSelf->__VdfgTmp_h9a768dd6__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h891cd943__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6b627b07__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h15fa30e3__0)))))));
    vlSelf->wasmetal_core__DOT___061842_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))));
    vlSelf->__VdfgTmp_h0f4209a4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc5dd9afa__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf131a410__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb63b65e7__0)))))));
    vlSelf->__VdfgTmp_hafe0013c__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_had16ce46__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb63b65e7__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1fbedb27__0)))))));
    vlSelf->wasmetal_core__DOT___061496_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061493_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061492_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054692_)))))))));
    vlSelf->wasmetal_core__DOT___055051_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h49097fbe__0)))));
    vlSelf->wasmetal_core__DOT___061490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061482_))));
    vlSelf->wasmetal_core__DOT___061497_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061495_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061494_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054778_)))))))));
    vlSelf->wasmetal_core__DOT___061489_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054699_)))))))));
    vlSelf->wasmetal_core__DOT___062150_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))));
    vlSelf->wasmetal_core__DOT___055037_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5d8e5746__0)))));
    vlSelf->wasmetal_core__DOT___061908_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061649_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007301_)))))))));
    vlSelf->wasmetal_core__DOT___061503_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061500_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054675_)))))))));
    vlSelf->wasmetal_core__DOT___062179_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde31b2d5__0))))))));
    vlSelf->__VdfgTmp_h415259f4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_haef34542__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5d8e5746__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb53c364f__0)))))));
    vlSelf->wasmetal_core__DOT___061502_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061499_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061498_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054683_)))))))));
    vlSelf->wasmetal_core__DOT___055062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027491_))));
    vlSelf->wasmetal_core__DOT___062139_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))));
    vlSelf->__VdfgTmp_h88cf509b__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h72b22246__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd9dc27af__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h49097fbe__0)))))));
    vlSelf->__VdfgTmp_h84a7ba42__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb53c364f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd9dc27af__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haef34542__0)))))));
    vlSelf->wasmetal_core__DOT___061668_ = (1U & (IData)(
                                                         (0xff00fff0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061666_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h73a9d128__0)))))));
    vlSelf->wasmetal_core__DOT___061773_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061767_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h422a580d__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061838_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061837_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hb587b232__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054844_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054842_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h107cea9f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061907_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061905_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4ae2b9ea__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054890_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054889_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e79b823__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054931_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054924_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd03398e3__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055014_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))))))))))));
    vlSelf->wasmetal_core__DOT___062058_ = (1U & (IData)(
                                                         (0xfff05550fff0333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061855_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h70e31548__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0286ce7d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061511_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha1796962__0)))))));
    vlSelf->wasmetal_core__DOT___061477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061474_))));
    vlSelf->wasmetal_core__DOT___054747_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccccaaaaf0f0ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054727_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xffff3355fffff0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha89e6386__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffff3355fffff0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3265141f__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hffdded68__0))))))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xc000aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h014e1215__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054714_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054713_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054721_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054720_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061639_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061627_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061621_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___061620_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52d73039__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h27ece1ce__0))))))))))));
    vlSelf->wasmetal_core__DOT___055059_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055058_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28180847__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))))))))))));
    vlSelf->wasmetal_core__DOT___062164_ = (1U & (IData)(
                                                         (0xfff05550fff0333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf07ddd26__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea36c42a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067736_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb00000U 
                                                                         >> 
                                                                         (((IData)(wasmetal_core__DOT___067727_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84433958__0))))))));
    vlSelf->wasmetal_core__DOT___067670_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___067661_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067660_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067659_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2ae5a25__0))))))));
    vlSelf->wasmetal_core__DOT___069099_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc23ff14f__0))))))));
    vlSelf->wasmetal_core__DOT___069147_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069142_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069141_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h26fdb0d9__0))))))));
    vlSelf->wasmetal_core__DOT___068975_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___068971_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068970_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99cf87be__0))))))));
    vlSelf->wasmetal_core__DOT___069239_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069236_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069234_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h965c3061__0))))))));
    vlSelf->wasmetal_core__DOT___069167_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069161_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069160_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf266c674__0))))))));
    vlSelf->wasmetal_core__DOT___055467_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055433_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055432_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055430_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055420_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055434_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007962_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055891_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055890_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055431_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055430_)))))))));
    vlSelf->wasmetal_core__DOT___019232_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff000000bf00bfULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055958_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055957_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055428_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055319_))))))))))));
    vlSelf->wasmetal_core__DOT___019200_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055872_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055337_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055336_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055335_)))))))));
    vlSelf->wasmetal_core__DOT___061712_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___055878_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055877_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055377_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055376_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055375_)))))))));
    vlSelf->wasmetal_core__DOT___055950_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055949_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055751_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055750_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055749_)))))))));
    vlSelf->wasmetal_core__DOT___061727_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___055903_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055902_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055502_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055501_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055500_)))))))));
    vlSelf->wasmetal_core__DOT___055967_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055966_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055780_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055779_)))))))));
    vlSelf->wasmetal_core__DOT___061882_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___055910_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055909_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055522_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055521_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055520_)))))))));
    vlSelf->wasmetal_core__DOT___055972_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055793_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055792_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055791_)))))))));
    vlSelf->wasmetal_core__DOT___061956_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___061951_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055558_))));
    vlSelf->wasmetal_core__DOT___055917_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055916_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055597_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055596_)))))))));
    vlSelf->wasmetal_core__DOT___055979_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055978_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055809_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055808_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055807_)))))))));
    vlSelf->wasmetal_core__DOT___062016_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___055928_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055927_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055654_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055653_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055652_)))))))));
    vlSelf->wasmetal_core__DOT___062075_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___055935_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055934_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055681_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055680_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055679_)))))))));
    vlSelf->wasmetal_core__DOT___019202_ = (1U & (IData)(
                                                         (0x554400000f0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055683_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048405_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055684_)))))))));
    vlSelf->wasmetal_core__DOT___055712_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055684_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055683_))))));
    vlSelf->wasmetal_core__DOT___019201_ = (1U & (IData)(
                                                         (0x554400000f0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055863_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048284_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055864_)))))))));
}
