#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__38(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__38\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006817_;
    wasmetal_core__DOT___006817_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013815_;
    wasmetal_core__DOT___013815_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016358_;
    wasmetal_core__DOT___016358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016368_;
    wasmetal_core__DOT___016368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016385_;
    wasmetal_core__DOT___016385_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016471_;
    wasmetal_core__DOT___016471_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016488_;
    wasmetal_core__DOT___016488_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016489_;
    wasmetal_core__DOT___016489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016490_;
    wasmetal_core__DOT___016490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017915_;
    wasmetal_core__DOT___017915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017925_;
    wasmetal_core__DOT___017925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018349_;
    wasmetal_core__DOT___018349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027435_;
    wasmetal_core__DOT___027435_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033456_;
    wasmetal_core__DOT___033456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043038_;
    wasmetal_core__DOT___043038_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043042_;
    wasmetal_core__DOT___043042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043050_;
    wasmetal_core__DOT___043050_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043058_;
    wasmetal_core__DOT___043058_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043064_;
    wasmetal_core__DOT___043064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___046641_;
    wasmetal_core__DOT___046641_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050119_;
    wasmetal_core__DOT___050119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050120_;
    wasmetal_core__DOT___050120_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___054468_;
    wasmetal_core__DOT___054468_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___054472_;
    wasmetal_core__DOT___054472_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058429_;
    wasmetal_core__DOT___058429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058431_;
    wasmetal_core__DOT___058431_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058442_;
    wasmetal_core__DOT___058442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058446_;
    wasmetal_core__DOT___058446_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058476_;
    wasmetal_core__DOT___058476_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058481_;
    wasmetal_core__DOT___058481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058482_;
    wasmetal_core__DOT___058482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058495_;
    wasmetal_core__DOT___058495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058536_;
    wasmetal_core__DOT___058536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058537_;
    wasmetal_core__DOT___058537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059077_;
    wasmetal_core__DOT___059077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059977_;
    wasmetal_core__DOT___059977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062975_;
    wasmetal_core__DOT___062975_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062985_;
    wasmetal_core__DOT___062985_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062998_;
    wasmetal_core__DOT___062998_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062999_;
    wasmetal_core__DOT___062999_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127476___O;
    wasmetal_core__DOT____Vcellout___127476___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127977___O;
    wasmetal_core__DOT____Vcellout___127977___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hdd7f22ed__0;
    __VdfgTmp_hdd7f22ed__0 = 0;
    CData/*1:0*/ __VdfgTmp_hde068c37__0;
    __VdfgTmp_hde068c37__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd5198b33__0;
    __VdfgTmp_hd5198b33__0 = 0;
    CData/*3:0*/ __VdfgTmp_hf7f66e14__0;
    __VdfgTmp_hf7f66e14__0 = 0;
    CData/*1:0*/ __VdfgTmp_h103fe912__0;
    __VdfgTmp_h103fe912__0 = 0;
    CData/*2:0*/ __VdfgTmp_h27477f57__0;
    __VdfgTmp_h27477f57__0 = 0;
    CData/*4:0*/ __VdfgTmp_hcfc69af2__0;
    __VdfgTmp_hcfc69af2__0 = 0;
    CData/*4:0*/ __VdfgTmp_hdfa5ed14__0;
    __VdfgTmp_hdfa5ed14__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha692919d__0;
    __VdfgTmp_ha692919d__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2de7cdff__0;
    __VdfgTmp_h2de7cdff__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4fc19847__0;
    __VdfgTmp_h4fc19847__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9598b43__0;
    __VdfgTmp_hf9598b43__0 = 0;
    CData/*3:0*/ __VdfgTmp_h1b5253bd__0;
    __VdfgTmp_h1b5253bd__0 = 0;
    CData/*3:0*/ __VdfgTmp_hbbab100a__0;
    __VdfgTmp_hbbab100a__0 = 0;
    CData/*3:0*/ __VdfgTmp_h90b76d4b__0;
    __VdfgTmp_h90b76d4b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5bac664e__0;
    __VdfgTmp_h5bac664e__0 = 0;
    CData/*2:0*/ __VdfgTmp_h84b4ffe6__0;
    __VdfgTmp_h84b4ffe6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4f0a13d1__0;
    __VdfgTmp_h4f0a13d1__0 = 0;
    CData/*5:0*/ __VdfgTmp_hadd1132f__0;
    __VdfgTmp_hadd1132f__0 = 0;
    CData/*5:0*/ __VdfgTmp_h7bed2ca0__0;
    __VdfgTmp_h7bed2ca0__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5fca0975__0;
    __VdfgTmp_h5fca0975__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbd290b9b__0;
    __VdfgTmp_hbd290b9b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9c980b03__0;
    __VdfgTmp_h9c980b03__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034322_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___071299_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071298_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d)))))))));
    wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026698_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127877___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    vlSelf->wasmetal_core__DOT___070737_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054400_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d)))))));
    wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027168_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127928___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d));
    vlSelf->__VdfgTmp_hf5578d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___045469_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___045321_));
    vlSelf->wasmetal_core__DOT___062972_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___062970_)))))));
    __VdfgTmp_h103fe912__0 = (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044280_));
    __VdfgTmp_hf7f66e14__0 = (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)));
    vlSelf->wasmetal_core__DOT___052691_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052644_))));
    vlSelf->wasmetal_core__DOT___070840_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054399_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d)))))));
    wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026968_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127911___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127894___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128657___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034487_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034486_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034484_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034540_)))));
    vlSelf->wasmetal_core__DOT___034545_ = ((IData)(vlSelf->wasmetal_core__DOT___034487_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135428___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046636_)))));
    wasmetal_core__DOT___046641_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030251_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d));
    wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127960___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027365_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027364_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027363_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027362_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027296_)))));
    vlSelf->wasmetal_core__DOT___027300_ = ((IData)(vlSelf->wasmetal_core__DOT___027365_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b39__05d));
    vlSelf->__VdfgTmp_haeb15d33__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h85009285__0)));
    vlSelf->__VdfgTmp_hbca1455c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h85009285__0)))));
    wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022481_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127635___O 
        = ((6U | (IData)(vlSelf->wasmetal_core__DOT___024134_)) 
           ^ (0xeU & ((- (IData)((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___024134_))))) 
                      << 1U)));
    vlSelf->wasmetal_core__DOT___014610_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___002961_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15b2e0c0__0))))));
    vlSelf->wasmetal_core__DOT___000132_ = ((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                            & (IData)(
                                                      (0x7fffffffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h15b2e0c0__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127632___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024022_)))));
    wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023762_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127616___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023895_)))));
    vlSelf->wasmetal_core__DOT___023899_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) {
        vlSelf->wasmetal_core__DOT___024026_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024026_ = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023899_;
    }
    __VdfgTmp_h84b4ffe6__0 = (((IData)(vlSelf->wasmetal_core__DOT___006816_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0));
    __VdfgTmp_hcfc69af2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0))));
    __VdfgTmp_ha692919d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0));
    vlSelf->wasmetal_core__DOT___058514_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058489_))));
    vlSelf->wasmetal_core__DOT___058543_ = (1U & (IData)(
                                                         (0x7fffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058489_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2327e099__0))))))));
    wasmetal_core__DOT___058495_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016250_)) 
                                          & (IData)(
                                                    (0xff00ffeefff0fff0ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016249_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf4bdf179__0)))))))));
    __VdfgTmp_h5bac664e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016249_));
    vlSelf->wasmetal_core__DOT___058503_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (0x3333f0f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016348_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))
                                                : (0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8cd41eba__0)))));
    __VdfgTmp_h2de7cdff__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0));
    __VdfgTmp_hbbab100a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0)));
    __VdfgTmp_h27477f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___016173_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0));
    vlSelf->wasmetal_core__DOT___058488_ = (1U & (IData)(
                                                         (0xff33f0aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016342_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058448_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058469_)))))))));
    vlSelf->wasmetal_core__DOT___058471_ = (1U & (IData)(
                                                         (0xffffcc55f0f0ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016268_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058468_)))))))));
    wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036996_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060582_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018964_))))));
    vlSelf->wasmetal_core__DOT___016503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018964_))));
    vlSelf->wasmetal_core__DOT___060166_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036996_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h307b9eba__0))));
    vlSelf->wasmetal_core__DOT___058484_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058445_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf4bdf179__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016336_)))))))));
    vlSelf->wasmetal_core__DOT___016492_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058494_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___006821_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                      ? 
                                                     (0x3bU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016392_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016315_))))
                                                      : 
                                                     (0xf0fafcfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016392_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hce0a7704__0))))))));
    wasmetal_core__DOT___058476_ = (1U & (0xf100U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016316_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___016315_))))));
    wasmetal_core__DOT___016385_ = (1U & (IData)((0x11000f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hecea8d31__0)))));
    wasmetal_core__DOT___058482_ = (1U & (IData)((0xf3f300fa00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016331_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016228_)))))))));
    __VdfgTmp_hf9598b43__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016331_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016228_)));
    vlSelf->wasmetal_core__DOT___058473_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016300_))));
    vlSelf->wasmetal_core__DOT___058491_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058489_)))));
    vlSelf->wasmetal_core__DOT___058480_ = (1U & (IData)(
                                                         (0xf3f300fa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016328_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016173_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058502_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b12__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058449_))))));
    vlSelf->wasmetal_core__DOT___058477_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016325_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006816_))))));
    wasmetal_core__DOT___016368_ = (1U & (0x5030000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h0d217f15__0))));
    wasmetal_core__DOT___006817_ = (1U & (0x5030000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h0d217f15__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058511_))));
    vlSelf->wasmetal_core__DOT___058505_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                ? (0x33a0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016315_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016313_)))))
                                                : (0x5300U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0)))));
    vlSelf->wasmetal_core__DOT___058456_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016315_)))
                                                    : 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h8d40b9ee__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   & (0x53U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0))))));
    wasmetal_core__DOT___058429_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                              ? (0xff00fff1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016250_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h76f112be__0))))
                                              : (0xcdU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016250_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016249_)))))));
    vlSelf->wasmetal_core__DOT___058466_ = (1U & (IData)(
                                                         (0xf1f100ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016249_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h76f112be__0)))))));
    vlSelf->__VdfgTmp_h99986d68__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058427_));
    vlSelf->__VdfgTmp_h1bc2f6b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058463_));
    vlSelf->wasmetal_core__DOT___058465_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0f0553300000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006888_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006891_)))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016240_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058463_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    wasmetal_core__DOT___016488_ = (1U & (0xf4000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0)))));
    wasmetal_core__DOT___058481_ = (1U & (IData)((0xb00ff00ff00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0)))))));
    __VdfgTmp_h4fc19847__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0));
    __VdfgTmp_h90b76d4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016301_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_hdd3525a7__0));
    __VdfgTmp_h1b5253bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___016354_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_hdd3525a7__0));
    wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022807_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0))));
    vlSelf->wasmetal_core__DOT___059204_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059199_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059198_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x700000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059188_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059187_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059186_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059164_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059163_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059162_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059146_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059145_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051505_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051507_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059159_)))))))))))))));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034323_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045029_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071299_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045005_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071299_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054193_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071297_))))));
    wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026699_)
            ? (IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    vlSelf->wasmetal_core__DOT___070739_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054398_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)))))))))));
    vlSelf->wasmetal_core__DOT___070738_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d)))))))));
    wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027169_)
            ? (IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d));
    vlSelf->wasmetal_core__DOT___053595_ = (1U & (IData)(
                                                         (0xbfbfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052683_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf5578d4c__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052578_)))))))));
    vlSelf->wasmetal_core__DOT___052707_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5578d4c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052703_))));
    wasmetal_core__DOT___062975_ = (1U & (IData)((0xf7000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062964_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062963_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062972_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__decoded_table)))))))));
    vlSelf->wasmetal_core__DOT___019774_ = (1U & (0xf110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h103fe912__0))))));
    vlSelf->wasmetal_core__DOT___054475_ = (1U & (IData)(
                                                         (0x3000a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->done) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_h103fe912__0)))))))))));
    wasmetal_core__DOT___062998_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((1U 
                                                         >> (IData)(__VdfgTmp_h103fe912__0)) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h57a1bcce__0))))));
    vlSelf->wasmetal_core__DOT___053593_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h103fe912__0))))));
    wasmetal_core__DOT___054468_ = (1U & (0x10U >> 
                                          ((4U & ((1U 
                                                   >> (IData)(__VdfgTmp_h103fe912__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052644_)))));
    vlSelf->wasmetal_core__DOT___063009_ = (1U & (IData)(
                                                         (0x8fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054476_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x1000U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((IData)(
                                                                                (0x1f1100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128899___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___044897_)))))))) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___062992_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062990_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062979_)))))))));
    vlSelf->wasmetal_core__DOT___053594_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052705_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044280_)))))))));
    vlSelf->wasmetal_core__DOT___052692_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___044280_)))))));
    vlSelf->wasmetal_core__DOT___070842_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070840_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)))))))))));
    vlSelf->wasmetal_core__DOT___070841_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070840_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054397_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d)))))))));
    wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026969_)
            ? (IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h483290db__0)))
            ? (IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034488_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034545_));
    vlSelf->wasmetal_core__DOT___030258_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))))));
    vlSelf->wasmetal_core__DOT___030257_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___030256_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))))));
    vlSelf->wasmetal_core__DOT___030255_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))))));
    wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)) 
           & (IData)(wasmetal_core__DOT___046641_));
    wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030252_)
            ? (IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127976___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
           ^ (((IData)(wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027427_)))));
    vlSelf->wasmetal_core__DOT___027431_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063300_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063302_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063304_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063306_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027367_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027300_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b40__05d));
    wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022482_) 
           & (IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128556___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033447_)))));
    vlSelf->wasmetal_core__DOT___033451_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060213_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013805_)))));
    vlSelf->__VdfgTmp_h1b3b7d3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014613_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014610_)))));
    vlSelf->wasmetal_core__DOT___057769_ = (1U & (0xccdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___005683_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & (IData)(
                                                            (0x33333300f3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___005681_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & (IData)(
                                                            (0x33333300f3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O) 
                                                                              >> 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___005677_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000132_)) 
                                                  & (IData)(
                                                            (0xfff3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___051268_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000131_))))));
    vlSelf->wasmetal_core__DOT___017816_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000132_))));
    __VdfgTmp_h7bed2ca0__0 = (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                          << 4U) | 
                                         ((8U & ((0x4fU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                 << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                                 << 1U) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                      >> 2U)))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024026_;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023764_)
            ? (IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d));
    vlSelf->__VdfgTmp_he93f6ca8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005955_));
    vlSelf->__VdfgTmp_h263b1cf5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005788_));
    vlSelf->__VdfgTmp_h7a46858f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005889_));
    vlSelf->__VdfgTmp_h0afc15e4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005795_));
    vlSelf->wasmetal_core__DOT___058506_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h84b4ffe6__0)))))));
    vlSelf->wasmetal_core__DOT___058508_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf0f5330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (IData)(__VdfgTmp_hcfc69af2__0)))));
    vlSelf->wasmetal_core__DOT___058497_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___016268_))
                                                : (0xf0f53300U 
                                                   >> (IData)(__VdfgTmp_hcfc69af2__0))));
    vlSelf->wasmetal_core__DOT___016486_ = (1U & (0x53000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_ha692919d__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058514_))));
    vlSelf->wasmetal_core__DOT___058496_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058495_))));
    vlSelf->wasmetal_core__DOT___016491_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5bac664e__0)))));
    vlSelf->wasmetal_core__DOT___058485_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5bac664e__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058503_))));
    vlSelf->wasmetal_core__DOT___058452_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016348_)))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8cd41eba__0))))));
    vlSelf->wasmetal_core__DOT___058540_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058451_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058449_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b13__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058451_))))));
    vlSelf->wasmetal_core__DOT___016487_ = (1U & (0x53000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h2de7cdff__0)))));
    vlSelf->wasmetal_core__DOT___058472_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0xf0f500003300ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_hbbab100a__0))))));
    __VdfgTmp_hdfa5ed14__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 4U) | (IData)(__VdfgTmp_hbbab100a__0));
    vlSelf->wasmetal_core__DOT___058459_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h27477f57__0)))))));
    wasmetal_core__DOT___016489_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                              & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                  ? 
                                                 (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___016222_))
                                                  : 
                                                 (0xf0fff11U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb91597d0__0))))) 
                                          & (IData)(
                                                    (0xfff0fff0ffaaffccULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (IData)(__VdfgTmp_h27477f57__0))))))));
    vlSelf->__VdfgTmp_h32c10bb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___058488_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058487_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058471_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134187___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036996_) 
                        << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)
                 ? (IData)(wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036992_)))));
    vlSelf->__VdfgTmp_hb0235e8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016503_));
    vlSelf->wasmetal_core__DOT___018963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019037_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019050_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019079_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019120_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___060393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016492_))));
    vlSelf->wasmetal_core__DOT___060014_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058475_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058476_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d 
        = (1U & (0xe1U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(wasmetal_core__DOT___058476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058475_)))));
    vlSelf->wasmetal_core__DOT___058434_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016300_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016299_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016302_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h31cd2dad__0)))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016301_)))));
    vlSelf->wasmetal_core__DOT___058499_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058434_))));
    vlSelf->__VdfgTmp_h45a50d9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058434_)));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058491_))));
    wasmetal_core__DOT___016490_ = (1U & ((~ (IData)(wasmetal_core__DOT___006817_)) 
                                          & (IData)(
                                                    (0xfff0fff0ffaaffccULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (IData)(__VdfgTmp_h84b4ffe6__0))))))));
    vlSelf->wasmetal_core__DOT___051562_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                      ? 
                                                     (0xcdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___006817_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006816_))))
                                                      : 
                                                     (0xf0f0f5f3U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___006817_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h94e3de73__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058505_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b15__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058455_))))));
    vlSelf->wasmetal_core__DOT___058435_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016316_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016316_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016315_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0xacU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0))
                                                    : 
                                                   (7U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h8d40b9ee__0)))));
    vlSelf->__VdfgTmp_h9e4b4f68__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058435_));
    wasmetal_core__DOT___058446_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                               ? (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016336_)))
                                               : (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76f112be__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                              & (1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___016249_))))));
    vlSelf->wasmetal_core__DOT___058447_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058446_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058445_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058438_)))));
    vlSelf->__VdfgTmp_h9aa3e645__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058429_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058466_)))));
    vlSelf->wasmetal_core__DOT___058467_ = (1U & (IData)(
                                                         (0x5505cc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058466_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016336_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058444_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h99986d68__0))));
    vlSelf->__VdfgTmp_ha5a16447__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h99986d68__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1bc2f6b9__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058465_))));
    vlSelf->wasmetal_core__DOT___058512_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016488_))));
    vlSelf->__VdfgTmp_h696b299a__0 = (((IData)(wasmetal_core__DOT___058481_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058482_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(wasmetal_core__DOT___058482_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058481_)))));
    vlSelf->wasmetal_core__DOT___058510_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf1f1ff0000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_h90b76d4b__0))))));
    vlSelf->wasmetal_core__DOT___058474_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0xf1f10000ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_h90b76d4b__0))))));
    vlSelf->wasmetal_core__DOT___058493_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (2U 
                                                   >> (IData)(wasmetal_core__DOT___016385_))
                                                : (IData)(
                                                          (0xffffff00fffffff1ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                             << 5U) 
                                                            | (((IData)(wasmetal_core__DOT___016385_) 
                                                                << 4U) 
                                                               | (IData)(__VdfgTmp_h1b5253bd__0)))))));
    wasmetal_core__DOT___016358_ = (1U & (0xff00fff1U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_h1b5253bd__0))));
    if (vlSelf->wasmetal_core__DOT___006819_) {
        vlSelf->wasmetal_core__DOT___058430_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___016268_))));
        vlSelf->wasmetal_core__DOT___058436_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016325_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006816_)))));
        vlSelf->wasmetal_core__DOT___058501_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016336_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h64b5570f__0))))));
        vlSelf->wasmetal_core__DOT___058439_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016328_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016173_)))));
        vlSelf->wasmetal_core__DOT___058457_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0x32U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 2U) 
                                                     | (((IData)(wasmetal_core__DOT___016368_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___006816_))))
                                                    : 
                                                   (0xf0f0a0cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 3U) 
                                                        | (((IData)(wasmetal_core__DOT___016368_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h94e3de73__0)))))));
        vlSelf->wasmetal_core__DOT___058500_ = (1U 
                                                & (0x32U 
                                                   >> (IData)(__VdfgTmp_hf9598b43__0)));
        wasmetal_core__DOT___058442_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                              & (0xcdU 
                                                 >> (IData)(__VdfgTmp_hf9598b43__0))));
        wasmetal_core__DOT___058431_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___016278_)));
        vlSelf->wasmetal_core__DOT___058454_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                & (IData)(wasmetal_core__DOT___016358_));
    } else {
        vlSelf->wasmetal_core__DOT___058430_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                   & (0xf0f53300U 
                                                      >> (IData)(__VdfgTmp_hcfc69af2__0))));
        vlSelf->wasmetal_core__DOT___058436_ = (1U 
                                                & (0xacffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_ha692919d__0))));
        vlSelf->wasmetal_core__DOT___058501_ = (1U 
                                                & (0xbU 
                                                   >> (IData)(__VdfgTmp_h5bac664e__0)));
        vlSelf->wasmetal_core__DOT___058439_ = (1U 
                                                & (0xacffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h2de7cdff__0))));
        vlSelf->wasmetal_core__DOT___058457_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___016368_)));
        vlSelf->wasmetal_core__DOT___058500_ = (1U 
                                                & (0xbffU 
                                                   >> (IData)(__VdfgTmp_h4fc19847__0)));
        wasmetal_core__DOT___058442_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                              & (0xf400U 
                                                 >> (IData)(__VdfgTmp_h4fc19847__0))));
        wasmetal_core__DOT___058431_ = (1U & (0xf0accffU 
                                              >> (IData)(__VdfgTmp_hdfa5ed14__0)));
        vlSelf->wasmetal_core__DOT___058454_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___016357_));
    }
    wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013648_) 
           & (IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127476___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___022809_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___022807_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___022806_))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___022809_)
                                                          ? (IData)(wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__)
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022774_)))));
    vlSelf->wasmetal_core__DOT___059548_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005745_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059585_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h916673f4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___059834_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059863_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059950_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005855_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059511_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005921_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___018685_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127472___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059896_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060008_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060038_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h36468d91__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060062_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060087_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 2U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060107_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    wasmetal_core__DOT___059977_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((1U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___059635_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006015_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059657_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006085_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbed85956__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059923_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059610_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006092_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059210_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127469___O)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128642___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034324_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034323_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034322_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034321_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034384_)))));
    vlSelf->wasmetal_core__DOT___034388_ = ((IData)(vlSelf->wasmetal_core__DOT___034324_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127877___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026700_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026699_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026698_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026697_)))) 
           ^ (((IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127877___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026630_)))));
    vlSelf->wasmetal_core__DOT___026635_ = ((IData)(vlSelf->wasmetal_core__DOT___026700_)
                                             ? (IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT___045233_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070738_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___045209_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070739_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054400_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054396_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070738_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127928___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027170_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027169_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027168_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027167_)))) 
           ^ (((IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127928___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027100_)))));
    vlSelf->wasmetal_core__DOT___027105_ = ((IData)(vlSelf->wasmetal_core__DOT___027170_)
                                             ? (IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d));
    vlSelf->wasmetal_core__DOT___053509_ = (1U & (IData)(
                                                         (0xefff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052707_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hf7f66e14__0))))));
    wasmetal_core__DOT___062985_ = (1U & (IData)((0xbfbfbf00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062981_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050438_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->insn_valid) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x40ff0000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062979_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((0xd0000U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___062975_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062974_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062970_)))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (0xb00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045321_))))))))))))))))))));
    wasmetal_core__DOT___062999_ = (1U & (IData)((0xf100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062966_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___062998_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h57a1bcce__0))))))));
    vlSelf->wasmetal_core__DOT___063435_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052849_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___054468_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44c20413__0))))));
    vlSelf->wasmetal_core__DOT___054469_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___054468_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053592_))));
    vlSelf->wasmetal_core__DOT___052697_ = (1U & (0xefffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052692_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hf7f66e14__0))));
    vlSelf->wasmetal_core__DOT___044961_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070841_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___044937_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070842_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054399_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054395_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070841_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127911___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026970_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026969_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026968_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026967_)))) 
           ^ (((IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127911___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026900_)))));
    vlSelf->wasmetal_core__DOT___026905_ = ((IData)(vlSelf->wasmetal_core__DOT___026970_)
                                             ? (IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127894___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h483290db__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127894___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026765_)))));
    vlSelf->wasmetal_core__DOT___026770_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)))
                                             ? (IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034489_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)) 
           & (IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128254___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030253_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030252_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030251_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030250_)))) 
           ^ (((IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030185_)))));
    vlSelf->wasmetal_core__DOT___030189_ = ((IData)(vlSelf->wasmetal_core__DOT___030253_)
                                             ? (IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d));
    vlSelf->wasmetal_core__DOT___044847_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h93b91d72__0)))))))))));
    vlSelf->wasmetal_core__DOT___044871_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h93b91d72__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d)))))))));
    vlSelf->__VdfgTmp_h8c284b8e__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027431_));
    vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027368_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b41__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127428___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022480_)))) 
           ^ (((IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022536_)))));
    vlSelf->wasmetal_core__DOT___022541_ = ((IData)(vlSelf->wasmetal_core__DOT___022483_) 
                                            & (IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033451_));
    vlSelf->wasmetal_core__DOT___060214_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060213_))));
    vlSelf->wasmetal_core__DOT___040077_ = (1U & (IData)(
                                                         (0x2a2a2aeaeaeaea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060213_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___060218_ = (1U & (0x7d00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060213_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005669_))))));
    vlSelf->wasmetal_core__DOT___057772_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057769_))));
    vlSelf->__VdfgTmp_hff203b22__0 = (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057769_));
    wasmetal_core__DOT___043038_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x4fU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051268_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___024134_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___051266_)))))))));
    vlSelf->wasmetal_core__DOT___017813_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051268_)))));
    wasmetal_core__DOT___043042_ = (1U & ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O))
                                           ? ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))
                                               ? (0x104U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017895_)))))
                                               : (IData)(
                                                         (0xc000100c0003200ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0))))
                                           : ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))
                                               ? (IData)(
                                                         (0xc000004c00000c8ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0)))
                                               : (IData)(
                                                         (0xc000400c000c800ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127598___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023765_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023764_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023762_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023761_)))) 
           ^ (((IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023697_)))));
    vlSelf->wasmetal_core__DOT___023702_ = ((IData)(vlSelf->wasmetal_core__DOT___023765_)
                                             ? (IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d));
    vlSelf->wasmetal_core__DOT___058796_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0))))));
    vlSelf->wasmetal_core__DOT___023769_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he93f6ca8__0))));
    vlSelf->wasmetal_core__DOT___058807_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0))))));
    vlSelf->wasmetal_core__DOT___023768_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h263b1cf5__0))));
    vlSelf->wasmetal_core__DOT___023767_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7a46858f__0))));
    vlSelf->wasmetal_core__DOT___058866_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d))));
    vlSelf->wasmetal_core__DOT___058789_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0))))));
    vlSelf->wasmetal_core__DOT___023766_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0afc15e4__0))));
    vlSelf->__VdfgTmp_hb5f365d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058506_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058508_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058497_))));
    vlSelf->wasmetal_core__DOT___058533_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058430_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058429_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b4__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058430_))));
    vlSelf->__VdfgTmp_h7cadd68e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016486_));
    vlSelf->wasmetal_core__DOT___058478_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058477_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016486_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    vlSelf->wasmetal_core__DOT___058534_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058435_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058436_))))));
    vlSelf->__VdfgTmp_hcb1f4515__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058436_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058496_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016491_))));
    vlSelf->__VdfgTmp_h0a35847a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058501_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058484_)))));
    vlSelf->__VdfgTmp_h49fa4f4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016487_));
    vlSelf->__VdfgTmp_h98e96722__0 = (((IData)(vlSelf->wasmetal_core__DOT___058439_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006821_));
    vlSelf->__VdfgTmp_h8bfce2cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058439_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016278_))))));
    vlSelf->wasmetal_core__DOT___058509_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf0f5330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (IData)(__VdfgTmp_hdfa5ed14__0)))));
    vlSelf->wasmetal_core__DOT___058507_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058459_))));
    vlSelf->wasmetal_core__DOT___058461_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0f0553300000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016219_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006891_)))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016220_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058459_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    vlSelf->__VdfgTmp_ha19857b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016489_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h32c10bb5__0))));
    vlSelf->wasmetal_core__DOT___060612_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018964_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058499_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058457_))));
    vlSelf->wasmetal_core__DOT___016482_ = ((IData)(vlSelf->wasmetal_core__DOT___016492_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___016491_)) 
                                               & (IData)(
                                                         (0x1000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___016490_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016489_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016487_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016486_))))))))));
    vlSelf->__VdfgTmp_h718e5977__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016490_));
    vlSelf->__VdfgTmp_h15403f4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051562_));
    vlSelf->__VdfgTmp_h459e7eca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9e4b4f68__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b11__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058447_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058467_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058512_))));
    wasmetal_core__DOT___058536_ = (1U & (0xeU >> (
                                                   ((IData)(wasmetal_core__DOT___058476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058475_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h696b299a__0)))));
    vlSelf->__VdfgTmp_h27b7e067__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058500_));
    vlSelf->wasmetal_core__DOT___058542_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058442_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058446_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058441_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058445_)))))));
    vlSelf->wasmetal_core__DOT___058443_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058442_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058441_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058438_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058510_))));
    wasmetal_core__DOT___058537_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058473_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016278_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058473_))))));
    vlSelf->wasmetal_core__DOT___058538_ = (1U & (0xf00011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058490_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058489_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h4af9777a__0)))));
    vlSelf->wasmetal_core__DOT___058504_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (IData)(wasmetal_core__DOT___016358_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___016357_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127553___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006092_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005982_)))) 
           ^ (((IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023479_)))));
    vlSelf->wasmetal_core__DOT___023484_ = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                            & (IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127570___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013666_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h41b1ef3d__0))) 
           ^ (((IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023600_)))));
    vlSelf->wasmetal_core__DOT___023605_ = ((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                            & (IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060134_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127476___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060158_ = (1U & (IData)(
                                                         (0xf0fcf0faULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127476___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060190_ = (1U & (IData)(
                                                         (0xf0fcf0fa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7695852b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127476___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059979_ = (1U & (IData)(
                                                         (0xffff44f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059977_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005770_)))))))));
    vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034325_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034388_));
    vlSelf->wasmetal_core__DOT___071303_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071302_))));
    vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026701_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026635_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->wasmetal_core__DOT___054408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054410_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054406_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027171_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027105_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d));
    vlSelf->wasmetal_core__DOT___062988_ = (1U & (IData)(
                                                         (0xf0f0fdf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___062985_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf00bb00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->mem_fault) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___063001_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063000_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053019_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___062999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___062974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)))))))))));
    vlSelf->wasmetal_core__DOT___063012_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128900___Q)))))))));
    vlSelf->wasmetal_core__DOT___063015_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128901___Q)))))))));
    vlSelf->wasmetal_core__DOT___063017_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128902___Q)))))))));
    vlSelf->wasmetal_core__DOT___063019_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128903___Q)))))))));
    vlSelf->wasmetal_core__DOT___062997_ = (1U & (IData)(
                                                         (0xff000f00ff00ee00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062996_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4f4f000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->insn_valid) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xd000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062992_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062991_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062990_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052700_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128897___Q)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062994_)))))))));
    wasmetal_core__DOT___054472_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___054469_))));
    vlSelf->wasmetal_core__DOT___072278_ = (1U & (0xbf00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053494_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072276_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052697_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053491_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053287_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053476_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053422_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053479_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051228_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053366_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053499_)))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053014_))))));
    vlSelf->wasmetal_core__DOT___054407_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054405_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054411_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026971_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026905_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->wasmetal_core__DOT___045074_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071139_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071138_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071137_))))))));
    vlSelf->wasmetal_core__DOT___045098_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071139_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071138_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071137_)))))))));
    vlSelf->wasmetal_core__DOT___045865_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had3e30f3__0)))))));
    vlSelf->wasmetal_core__DOT___045864_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf21c6828__0)))))));
    vlSelf->wasmetal_core__DOT___045889_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003498_)))))))));
    vlSelf->wasmetal_core__DOT___045888_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004462_)))))))));
    vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026770_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034490_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)) 
           & (IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030255_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030189_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d));
    vlSelf->wasmetal_core__DOT___044848_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8c284b8e__0)))))))))));
    vlSelf->wasmetal_core__DOT___044872_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8c284b8e__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d))))))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b42__05d));
    vlSelf->__VdfgTmp_h9bddaa79__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                    >> 1U)));
    vlSelf->__VdfgTmp_h9c9f5aae__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h9be9fa04__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O)));
    vlSelf->wasmetal_core__DOT___023195_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022480_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O))))));
    vlSelf->wasmetal_core__DOT___023194_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022481_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___023193_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022482_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            >> 2U))))));
    __VdfgTmp_h9c980b03__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022484_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022541_));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017834_ = (1U & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                                                      ? 
                                                     (0x355fcaaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                        << 4U) 
                                                       | ((8U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017840_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017839_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___017838_))))))
                                                      : 
                                                     (9U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002473_))))));
    vlSelf->wasmetal_core__DOT___043035_ = ((IData)(wasmetal_core__DOT___043042_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___043041_)
                                                 ? 
                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___043040_)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___043036_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043037_))
                                             : (IData)(wasmetal_core__DOT___043038_));
    vlSelf->wasmetal_core__DOT___059072_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043041_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043040_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___043042_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d;
        vlSelf->wasmetal_core__DOT___023903_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023903_ = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023766_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023702_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb5f365d2__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h7cadd68e__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058478_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b8__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0a35847a__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0))));
    vlSelf->__VdfgTmp_h963234d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058480_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0)))));
    vlSelf->wasmetal_core__DOT___058535_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058457_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h98e96722__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b9__05d 
        = (1U & (0xf10eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058509_))));
    vlSelf->wasmetal_core__DOT___016481_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058497_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058427_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___058431_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___058495_)))))));
    vlSelf->wasmetal_core__DOT___058498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058431_))));
    vlSelf->wasmetal_core__DOT___058432_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058431_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058507_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058461_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha19857b4__0))));
    vlSelf->__VdfgTmp_hadae8e7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha19857b4__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h718e5977__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h27b7e067__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b10__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058443_))));
    vlSelf->wasmetal_core__DOT___016472_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058537_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058467_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058461_)))))))));
    vlSelf->wasmetal_core__DOT___016483_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058505_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058503_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058502_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058504_))));
    vlSelf->wasmetal_core__DOT___058541_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058455_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x11000fU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b14__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x11000fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0))))))));
    vlSelf->wasmetal_core__DOT___049002_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005982_))));
    vlSelf->wasmetal_core__DOT___050100_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___006734_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27384d82__0)))));
    vlSelf->wasmetal_core__DOT___050093_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006092_))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023484_));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013658_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023605_));
    vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034326_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___071304_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071303_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026702_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT___070742_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054406_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___070747_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054412_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027172_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d));
    vlSelf->wasmetal_core__DOT___022439_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128904___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022450_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128905___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022461_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128906___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022464_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128907___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022465_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128908___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022466_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128909___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022467_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128910___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022468_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128911___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022469_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128912___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022470_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128913___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022440_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128914___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022441_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128915___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022442_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128916___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022443_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128917___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022444_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128918___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022445_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128919___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022446_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128920___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022447_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128921___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022448_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128922___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022449_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128923___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022451_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128924___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022452_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128925___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022453_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128926___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022454_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128927___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022455_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128928___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022456_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128929___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022457_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128930___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022458_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128931___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022459_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128932___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022460_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128933___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022462_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128934___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022463_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128935___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___046015_ = (1U & (0xefff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072278_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052659_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050452_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053071_)))))));
    vlSelf->wasmetal_core__DOT___070845_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054405_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___070850_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026972_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128658___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034490_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034489_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034488_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034545_)))));
    vlSelf->wasmetal_core__DOT___034549_ = ((IData)(vlSelf->wasmetal_core__DOT___034491_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135429___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___046641_)))));
    vlSelf->wasmetal_core__DOT___046645_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)) 
                                            & (IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030256_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127945___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027370_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027369_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027368_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027367_)))) 
           ^ (((IData)(wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027300_)))));
    vlSelf->wasmetal_core__DOT___027305_ = ((IData)(vlSelf->wasmetal_core__DOT___027370_)
                                             ? (IData)(wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b43__05d));
    vlSelf->__VdfgTmp_hf628d2c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h9c980b03__0)));
    vlSelf->__VdfgTmp_h04d557bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h9c980b03__0)))));
    vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022485_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___043064_ = (1U & (0x90U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017832_)))));
    wasmetal_core__DOT___043058_ = (1U & (IData)((0xff40ffff4040ff40ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057769_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070587_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017832_)))))))));
    __VdfgTmp_h5fca0975__0 = ((((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                & ((IData)(vlSelf->wasmetal_core__DOT___017833_) 
                                   & (IData)((0x9009000000009009ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___017832_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017830_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h103cd5d4__0))))))))) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017811_) 
                                          << 1U) | 
                                         ((IData)(vlSelf->wasmetal_core__DOT___017863_) 
                                          & ((IData)(
                                                     (0x9009000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___059072_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059071_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0))))))) 
                                             & (IData)(
                                                       (0x8000000000000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___017861_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017860_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017859_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017858_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hb36cd122__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127633___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024026_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d) {
        vlSelf->wasmetal_core__DOT___024030_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d;
        vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024030_ = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023903_;
    }
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127617___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023899_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058498_))));
    wasmetal_core__DOT___016471_ = (1U & (IData)((0xe00000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058535_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058534_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058533_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058432_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058434_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058470_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b5__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058432_))));
    wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0))) 
                 & (9U >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0))));
    __VdfgTmp_h4f0a13d1__0 = ((2U & ((IData)((0x1000000000000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058542_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058541_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058540_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xcc0dULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___051562_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058477_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016486_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058480_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016487_)))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h99986d68__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha19857b4__0)))))))))) 
                                     << 1U)) | (1U 
                                                & (0xeee00000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058538_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058484_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058485_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h32c10bb5__0)))))));
    vlSelf->wasmetal_core__DOT___050121_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049002_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006695_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006676_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050094_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050093_)))))))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013719_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034328_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045030_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071304_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___045006_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071304_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054199_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071302_))))));
    vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026703_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    vlSelf->wasmetal_core__DOT___070744_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054404_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070742_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)))))))))));
    vlSelf->wasmetal_core__DOT___070743_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___070749_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054410_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070747_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)))))))))));
    vlSelf->wasmetal_core__DOT___070748_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070747_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d)))))))));
    wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027173_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d));
    vlSelf->wasmetal_core__DOT___070847_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070845_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)))))))))));
    vlSelf->wasmetal_core__DOT___070846_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070845_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054403_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___070852_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070850_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)))))))))));
    vlSelf->wasmetal_core__DOT___070851_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070850_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054409_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d)))))))));
    wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026973_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hb948b455__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034492_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034549_));
    vlSelf->wasmetal_core__DOT___030262_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))))));
    vlSelf->wasmetal_core__DOT___030261_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))))));
    vlSelf->wasmetal_core__DOT___030260_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))))));
    vlSelf->wasmetal_core__DOT___030259_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))))));
    wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046645_));
    wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030257_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d));
    wasmetal_core__DOT____Vcellout___127977___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027431_)))));
    wasmetal_core__DOT___027435_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063308_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063310_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063312_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063314_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027371_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027305_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b44__05d));
    wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022486_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128542___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011478_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033451_)))));
    wasmetal_core__DOT___033456_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___011478_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___043050_ = ((IData)(wasmetal_core__DOT___043064_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___043063_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___043062_)
                                             ? ((1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb36cd122__0)))
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043060_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___017861_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017860_)
                                                    ? 
                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043059_)) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___043051_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043052_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___043053_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043054_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043055_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043056_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___043057_))
                                     : (IData)(wasmetal_core__DOT___043058_));
    __VdfgTmp_hadd1132f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017815_) 
                               << 5U) | ((0x10U & (
                                                   (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___017813_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h5fca0975__0))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d) {
        vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d;
        wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024030_;
        wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d));
    vlSelf->__VdfgTmp_h7be661a5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005948_));
    vlSelf->__VdfgTmp_h6202353f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005809_));
    vlSelf->__VdfgTmp_hd2dd278c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005882_));
    vlSelf->__VdfgTmp_hdd48e33a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005802_));
    vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__ 
        = ((9U >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
           & (IData)(wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017947_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016474_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                             >> 1U)))))
                                                   ? (IData)(
                                                             (0x7fff0000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((0x4fU 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016496_) 
                                                                   << 4U) 
                                                                  | (((IData)(wasmetal_core__DOT___016471_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016472_) 
                                                                         << 2U) 
                                                                        | (IData)(__VdfgTmp_h4f0a13d1__0)))))))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (1U 
                                                    & (0x4fU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___017946_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016474_)
                                                   ? 
                                                  ((~ 
                                                    (0x4fU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))) 
                                                   & (IData)(
                                                             (0x7fffffff00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016473_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016472_) 
                                                                   << 4U) 
                                                                  | (((IData)(wasmetal_core__DOT___016471_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((0x8000ffffU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058434_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058501_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058435_)))))) 
                                                                             & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016483_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016482_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016481_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40ff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058543_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058436_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058439_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058506_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058508_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058459_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058466_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058463_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058511_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058510_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058509_))))))))))))) 
                                                                            << 2U)) 
                                                                        | (IData)(__VdfgTmp_h4f0a13d1__0))))))))
                                                   : 
                                                  (~ 
                                                   (0x4fU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013701_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128643___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034329_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034328_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034326_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034325_)))) 
           ^ (((IData)(wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034388_)))));
    vlSelf->wasmetal_core__DOT___034393_ = ((IData)(vlSelf->wasmetal_core__DOT___034329_) 
                                            & (IData)(wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127878___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026704_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026703_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026702_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026701_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026635_)))));
    vlSelf->wasmetal_core__DOT___026639_ = ((IData)(vlSelf->wasmetal_core__DOT___026704_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    vlSelf->wasmetal_core__DOT___045234_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070743_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___045210_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070744_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054406_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054402_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070743_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U))))))))))))));
    vlSelf->wasmetal_core__DOT___045235_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070748_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045211_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070749_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054412_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054408_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070748_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127929___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027174_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027173_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027172_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027171_)))) 
           ^ (((IData)(wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027105_)))));
    vlSelf->wasmetal_core__DOT___027109_ = ((IData)(vlSelf->wasmetal_core__DOT___027174_)
                                             ? (IData)(wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d));
    vlSelf->wasmetal_core__DOT___044962_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054401_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___044938_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054405_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054401_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070846_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U))))))))))))));
    vlSelf->wasmetal_core__DOT___044963_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070851_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054407_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___044939_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070852_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054411_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054407_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070851_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127912___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026974_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026973_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026972_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026971_)))) 
           ^ (((IData)(wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026905_)))));
    vlSelf->wasmetal_core__DOT___026909_ = ((IData)(vlSelf->wasmetal_core__DOT___026974_)
                                             ? (IData)(wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127895___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_hb948b455__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5dede88d__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026770_)))));
    vlSelf->wasmetal_core__DOT___026774_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)))
                                             ? (IData)(wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034493_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)) 
           & (IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128240___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030258_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030257_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030256_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030255_)))) 
           ^ (((IData)(wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030189_)))));
    vlSelf->wasmetal_core__DOT___030194_ = ((IData)(vlSelf->wasmetal_core__DOT___030258_)
                                             ? (IData)(wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d));
    __VdfgTmp_hbd290b9b__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d)))));
    vlSelf->__VdfgTmp_h06766dbc__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d)))));
    wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
           & (IData)(wasmetal_core__DOT___027435_));
    wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027372_)
            ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b45__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127429___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022487_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022486_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022484_)))) 
           ^ (((IData)(wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022541_)))));
    vlSelf->wasmetal_core__DOT___022545_ = ((IData)(vlSelf->wasmetal_core__DOT___022487_) 
                                            & (IData)(wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___011738_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff55550f0f3333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)) 
           & (IData)(wasmetal_core__DOT___033456_));
    wasmetal_core__DOT___017915_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043035_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059072_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___043050_))))));
    vlSelf->wasmetal_core__DOT___018081_ = ((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                            & (IData)(
                                                      (0xffffff80ffff0000ULL 
                                                       >> (IData)(__VdfgTmp_hadd1132f__0))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d) {
        wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d;
        wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d;
    } else {
        wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127599___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023769_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023768_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023767_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023766_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023702_)))));
    vlSelf->wasmetal_core__DOT___023706_ = ((IData)(vlSelf->wasmetal_core__DOT___023769_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d));
    vlSelf->wasmetal_core__DOT___058886_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7be661a5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d))));
    vlSelf->wasmetal_core__DOT___023773_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7be661a5__0))));
    vlSelf->wasmetal_core__DOT___023772_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6202353f__0))));
    vlSelf->wasmetal_core__DOT___058867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d))));
    vlSelf->wasmetal_core__DOT___058797_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0))))));
    vlSelf->wasmetal_core__DOT___023771_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2dd278c__0))));
    vlSelf->wasmetal_core__DOT___058790_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0))))));
    vlSelf->wasmetal_core__DOT___023770_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd48e33a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128862___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
                                     << 2U)) | ((2U 
                                                 & ((9U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036426_ = ((9U >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060243_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017945_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127554___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005738_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005875_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023484_)))));
    vlSelf->wasmetal_core__DOT___023488_ = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127571___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013722_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9b9779ca__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023605_)))));
    vlSelf->wasmetal_core__DOT___023609_ = ((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034330_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034393_));
    vlSelf->wasmetal_core__DOT___071313_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071312_))));
    vlSelf->wasmetal_core__DOT___071308_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071307_))));
    vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026705_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026639_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    vlSelf->wasmetal_core__DOT___054420_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054416_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054418_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027175_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027109_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d));
    vlSelf->wasmetal_core__DOT___054419_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054413_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054415_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054417_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026975_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026909_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    vlSelf->wasmetal_core__DOT___045076_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071169_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071168_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071167_))))))));
    vlSelf->wasmetal_core__DOT___045100_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071169_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071168_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071167_)))))))));
    vlSelf->wasmetal_core__DOT___045075_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071154_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071153_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071152_)))))))));
    vlSelf->wasmetal_core__DOT___045099_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071154_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071153_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071152_)))))))));
    vlSelf->wasmetal_core__DOT___045866_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha17b8b2d__0))))));
    vlSelf->wasmetal_core__DOT___045890_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004684_)))))))));
    vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026774_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034494_) 
           & (IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)) 
           & (IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030259_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030194_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d));
    vlSelf->wasmetal_core__DOT___044849_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___127977___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_hbd290b9b__0)))))))))));
    vlSelf->wasmetal_core__DOT___044873_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_hbd290b9b__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d))))))));
    wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027373_)
            ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b46__05d));
    vlSelf->__VdfgTmp_hde33bda2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_hde955cd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O)));
    vlSelf->wasmetal_core__DOT___023190_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022484_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O))))));
    __VdfgTmp_hdd7f22ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___023188_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022486_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                            >> 2U))))));
    __VdfgTmp_hde068c37__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                               >> 3U)));
    if (vlSelf->wasmetal_core__DOT___005715_) {
        vlSelf->wasmetal_core__DOT___023198_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hbca1455c__0))));
        vlSelf->wasmetal_core__DOT___023192_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04d557bc__0))));
        vlSelf->wasmetal_core__DOT___023189_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_hdd7f22ed__0))))))));
        vlSelf->wasmetal_core__DOT___023187_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_hde068c37__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___023198_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_haeb15d33__0)));
        vlSelf->wasmetal_core__DOT___023192_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf628d2c5__0)));
        vlSelf->wasmetal_core__DOT___023189_ = (1U 
                                                & (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hdd7f22ed__0)))));
        vlSelf->wasmetal_core__DOT___023187_ = (1U 
                                                & (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hde068c37__0)))));
    }
    vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022488_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022545_));
    wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)) 
           & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___017925_ = (1U & ((1U & (4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___005711_))))
                                           ? (1U >> 
                                              (1U & 
                                               (8U 
                                                >> (IData)(vlSelf->__VdfgTmp_hff203b22__0))))
                                           : ((1U & 
                                               (0xf800U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043035_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___043050_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___059072_))))))
                                               ? (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017813_)))
                                               : (IData)(
                                                         (0x7f00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017813_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___017915_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5fca0975__0)))))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d) {
        wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d;
        vlSelf->wasmetal_core__DOT___023908_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d;
    } else {
        wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023908_ = wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023770_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023706_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d));
    vlSelf->__VdfgTmp_h9bd72b18__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->__VdfgTmp_h647a213f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->__VdfgTmp_h632fa2db__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->__VdfgTmp_h8e80d283__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O) 
                                                         >> 2U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036426_));
    vlSelf->wasmetal_core__DOT___050162_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049002_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___050119_ = (1U & (0xbb0bU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___050105_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                               << 3U) 
                                              | ((4U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006015_)))))));
    __VdfgTmp_hd5198b33__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_h8c84070d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023488_));
    wasmetal_core__DOT___013815_ = (1U & (0x45cfcfU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___002187_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002190_)))))));
    vlSelf->wasmetal_core__DOT___013824_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000144_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                                     << 2U) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___013821_ = (1U & ((1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O))
                                                   ? (IData)(
                                                             (0xe0e0e0e0eULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___002187_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002469_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002468_))))))))
                                                   : 
                                                  (0x1fU 
                                                   >> 
                                                   ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002187_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002190_))))));
    vlSelf->wasmetal_core__DOT___013754_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000146_)))));
    vlSelf->wasmetal_core__DOT___013760_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___013812_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002471_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000144_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000148_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013694_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023609_));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034331_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___071314_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071313_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___071309_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071308_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026706_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT___070752_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054418_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027176_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d));
    vlSelf->wasmetal_core__DOT___070855_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054417_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026976_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h375e931a__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128659___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034492_)))) 
           ^ (((IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034549_)))));
    vlSelf->wasmetal_core__DOT___034554_ = ((IData)(vlSelf->wasmetal_core__DOT___034495_) 
                                            & (IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135430___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046645_)))));
    vlSelf->wasmetal_core__DOT___046650_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)) 
                                            & (IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030260_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d));
    wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127946___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027374_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027373_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027372_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027371_)))) 
           ^ (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027305_)))));
    vlSelf->wasmetal_core__DOT___027309_ = ((IData)(vlSelf->wasmetal_core__DOT___027374_)
                                             ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b47__05d));
    vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022489_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)) 
           & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060212_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___017185_)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___018857_)
                                                             ? (IData)(
                                                                       (0xefffffff2000a000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                                          << 5U) 
                                                                         | ((0x10U 
                                                                             & ((IData)(
                                                                                (0x7f0000ffffULL 
                                                                                >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                                                                << 4U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___017925_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005711_))))))))
                                                             : 
                                                            (0xeU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))))));
    wasmetal_core__DOT___059077_ = (1U & (IData)((0x3222bfff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017925_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___018081_)))))))));
    vlSelf->__VdfgTmp_h2082f5a2__0 = ((8U & ((IData)(
                                                     (0x7f0000ffffULL 
                                                      >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                          << 2U) | 
                                         (((IData)(wasmetal_core__DOT___017925_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_))));
    wasmetal_core__DOT___018349_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0x7f0000ffffULL 
                                                         >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___017925_)))));
    vlSelf->wasmetal_core__DOT___018082_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___017925_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127619___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024030_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) {
        vlSelf->wasmetal_core__DOT___024035_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d;
        vlSelf->wasmetal_core__DOT___127604___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024035_ = wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127604___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023908_;
    }
    vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023771_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127603___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023903_)))));
    vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___050120_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050104_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050115_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050114_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050102_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___006058_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(__VdfgTmp_hd5198b33__0)))))))))));
    vlSelf->wasmetal_core__DOT___050106_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hd5198b33__0)))));
    vlSelf->wasmetal_core__DOT___006736_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c84070d__0)))));
    vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013733_ = (1U & ((0x1f000000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___057763_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057762_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048789_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___048792_)))))) 
                                                  & ((IData)(
                                                             (0x111511151115333fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048787_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                               >> 2U)) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O))))))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___013815_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013814_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013813_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013763_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013812_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013760_)))))))))));
    vlSelf->wasmetal_core__DOT___013743_ = (1U & (0xd0000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013812_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057761_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xb0bbU 
                                                              >> 
                                                              ((8U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___002635_))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb00ae252__0))))));
    vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013668_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034332_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045032_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071314_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045008_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071314_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054211_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071312_))))));
    vlSelf->wasmetal_core__DOT___045031_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071309_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045007_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071309_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054205_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071307_))))));
    vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026708_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___070754_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054416_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)))))))))));
    vlSelf->wasmetal_core__DOT___070753_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070752_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027178_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d));
    vlSelf->wasmetal_core__DOT___070857_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054415_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)))))))))));
    vlSelf->wasmetal_core__DOT___070856_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070855_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054415_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026978_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h379ad787__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034496_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034554_));
    vlSelf->wasmetal_core__DOT___030267_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___030266_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))))));
    vlSelf->wasmetal_core__DOT___030264_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))))));
    vlSelf->wasmetal_core__DOT___030263_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))))));
    vlSelf->wasmetal_core__DOT___135431___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001327_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046650_));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030261_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127962___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
           ^ (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027435_)))));
    vlSelf->wasmetal_core__DOT___027440_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063316_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063318_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063320_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063322_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027375_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027309_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b48__05d));
    vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022490_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128543___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033456_)))));
    vlSelf->wasmetal_core__DOT___033460_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)) 
                                            & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___059925_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059923_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                : 
                                                                               (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3222bfff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___017925_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018081_)))))))))))))))));
    vlSelf->__VdfgTmp_h3f27e0dd__0 = (((IData)(wasmetal_core__DOT___018349_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018081_)));
    vlSelf->__VdfgTmp_h2b45c525__0 = (((IData)(wasmetal_core__DOT___018349_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018081_)));
    vlSelf->wasmetal_core__DOT___059220_ = (1U & (IData)(
                                                         (0x11fff0ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059210_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017174_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbb0b0bU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___018349_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017185_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___059077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xbeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xffff30f08aaa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017175_)))))))));
    vlSelf->__VdfgTmp_h3c24edc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018080_)));
    vlSelf->wasmetal_core__DOT___127620___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___024035_));
    vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023772_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d));
    vlSelf->__VdfgTmp_h6b40bfd0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006058_));
    vlSelf->__VdfgTmp_h85736cb0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006044_));
    vlSelf->__VdfgTmp_hde857550__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006029_));
    vlSelf->__VdfgTmp_h5220a2be__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006051_));
    vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__2__KET__ 
        = ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h45a50d9d__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050109_ = (1U & (0xd0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050106_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050105_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006672_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___006661_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050121_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050120_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050119_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___006736_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050092_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f1b49a4__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050093_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___006676_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006675_))))))))))));
}
