#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__10(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__10\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___063984_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf2f5c69c__0))));
    vlSelf->wasmetal_core__DOT___064506_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadcc7972__0))));
    vlSelf->wasmetal_core__DOT___063990_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42e273c2__0))));
    vlSelf->wasmetal_core__DOT___064505_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfdfbee0__0))));
    vlSelf->wasmetal_core__DOT___063989_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e67285f__0))));
    vlSelf->wasmetal_core__DOT___064508_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09210432__0))));
    vlSelf->wasmetal_core__DOT___063992_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hea943ba9__0))));
    vlSelf->wasmetal_core__DOT___064507_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89e0a965__0))));
    vlSelf->wasmetal_core__DOT___063991_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h688ac52f__0))));
    vlSelf->wasmetal_core__DOT___064493_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h061491a4__0))));
    vlSelf->wasmetal_core__DOT___063977_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd14327b4__0))));
    vlSelf->wasmetal_core__DOT___064492_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5145bf91__0))));
    vlSelf->wasmetal_core__DOT___063976_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))));
    vlSelf->wasmetal_core__DOT___064495_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1479cba4__0))));
    vlSelf->wasmetal_core__DOT___063979_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19f2f351__0))));
    vlSelf->wasmetal_core__DOT___064494_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c78c397__0))));
    vlSelf->wasmetal_core__DOT___063978_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cc94077__0))));
    vlSelf->wasmetal_core__DOT___064489_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9e2f527__0))));
    vlSelf->wasmetal_core__DOT___063973_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc0b7a98__0))));
    vlSelf->wasmetal_core__DOT___064488_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd466e7f__0))));
    vlSelf->wasmetal_core__DOT___063972_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h992e16df__0))));
    vlSelf->wasmetal_core__DOT___063970_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha86315e0__0))));
    vlSelf->wasmetal_core__DOT___064486_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15099632__0))));
    vlSelf->wasmetal_core__DOT___063971_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0))));
    vlSelf->wasmetal_core__DOT___064487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)))));
    vlSelf->__VdfgTmp_hc07dc041__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->__VdfgTmp_he7d93b5b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->__VdfgTmp_h0817566b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                       << 2U) | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)));
    vlSelf->__VdfgTmp_h30dbdcaa__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)));
    vlSelf->wasmetal_core__DOT___063832_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063830_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063828_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063826_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O))))))));
    vlSelf->wasmetal_core__DOT___007866_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007854_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007865_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028285_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___028220_));
    vlSelf->wasmetal_core__DOT___001811_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048797_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048796_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048794_)))))))));
    vlSelf->wasmetal_core__DOT___064469_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))));
    vlSelf->wasmetal_core__DOT___063833_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___042082_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___042140_)))));
    vlSelf->wasmetal_core__DOT___063865_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))))));
    vlSelf->wasmetal_core__DOT___042294_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)))))));
    vlSelf->wasmetal_core__DOT___042094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063930_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))))));
    vlSelf->wasmetal_core__DOT___063728_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00fff1ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab155f14__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___064522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hab155f14__0))))));
    vlSelf->__VdfgTmp_hb39b7a55__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hab155f14__0))));
    vlSelf->wasmetal_core__DOT___072045_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab155f14__0))));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027333_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__access_base__05b0__05d));
    vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___002649_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2b3c1bbf__0)))))));
    vlSelf->wasmetal_core__DOT___060188_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006215_))));
    vlSelf->wasmetal_core__DOT___054981_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb79381c2__0)))));
    vlSelf->wasmetal_core__DOT___055989_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f555500ff3333ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055645_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055644_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055647_))))))))))));
    vlSelf->__VdfgTmp_hb3f3e4b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___060152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006144_))));
    vlSelf->__VdfgTmp_h29c4951c__0 = (((IData)(vlSelf->wasmetal_core__DOT___001711_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001712_));
    vlSelf->wasmetal_core__DOT___054941_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdf1f98b8__0)))));
    vlSelf->wasmetal_core__DOT___022501_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___070514_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010319_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010320_)))));
    vlSelf->__VdfgTmp_h95b8e055__0 = (((IData)(vlSelf->wasmetal_core__DOT___010320_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010319_));
    vlSelf->wasmetal_core__DOT___060128_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006171_))));
    vlSelf->__VdfgTmp_h419b9e2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___001316_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8eb0ad88__0)))))));
    vlSelf->wasmetal_core__DOT___001786_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8eb0ad88__0)))));
    vlSelf->wasmetal_core__DOT___051502_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006159_))));
    vlSelf->wasmetal_core__DOT___022500_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->__VdfgTmp_h07c00df2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007340_));
    vlSelf->__VdfgTmp_h1c7a54d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008445_));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002853_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___002234_))))));
        vlSelf->wasmetal_core__DOT___002769_ = vlSelf->wasmetal_core__DOT___002148_;
    } else {
        vlSelf->wasmetal_core__DOT___002853_ = (1U 
                                                & (0xc0005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002390_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002233_)))))));
        vlSelf->wasmetal_core__DOT___002769_ = vlSelf->wasmetal_core__DOT___002147_;
    }
    vlSelf->__VdfgTmp_h47d0b828__0 = (((IData)(vlSelf->wasmetal_core__DOT___002234_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002233_));
    vlSelf->__VdfgTmp_hed924a08__0 = (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf10e2308__0)));
    vlSelf->wasmetal_core__DOT___055505_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf10e2308__0)))));
    vlSelf->wasmetal_core__DOT___054879_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2577a83c__0)))));
    vlSelf->wasmetal_core__DOT___022499_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___060081_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006099_))));
    vlSelf->wasmetal_core__DOT___059201_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006022_))))))))))));
    vlSelf->wasmetal_core__DOT___051507_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006099_))));
    vlSelf->__VdfgTmp_h0c779906__0 = (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___055420_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055418_)))));
    vlSelf->wasmetal_core__DOT___054834_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd69bf43a__0)))));
    vlSelf->__VdfgTmp_ha93fec6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___048703_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006116_))));
    vlSelf->__VdfgTmp_hd0a40acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001711_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001709_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001710_))))));
    vlSelf->__VdfgTmp_haf785b2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4d3bb7ef__0)));
    vlSelf->wasmetal_core__DOT___055380_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d3bb7ef__0)))));
    vlSelf->wasmetal_core__DOT___054761_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he43dd87d__0)))));
    vlSelf->wasmetal_core__DOT___060563_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___022497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___001314_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h78a92bf8__0)))))));
    vlSelf->wasmetal_core__DOT___001784_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78a92bf8__0)))));
    vlSelf->wasmetal_core__DOT___055725_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055320_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055327_)))));
    vlSelf->wasmetal_core__DOT___055323_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055320_)))));
    vlSelf->wasmetal_core__DOT___060549_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___051501_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d))));
    vlSelf->__VdfgTmp_he648fa65__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___061473_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007253_))));
    vlSelf->__VdfgTmp_h91a424ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007771_));
    vlSelf->wasmetal_core__DOT___027492_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007771_)))))))));
    vlSelf->wasmetal_core__DOT___009818_ = (1U & (IData)(
                                                         (0xff00f0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054895_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007772_)))))))));
    vlSelf->__VdfgTmp_hd5b4e54d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007770_))))));
    vlSelf->wasmetal_core__DOT___010594_ = (1U & (IData)(
                                                         (0xf000f0000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054894_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054893_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007204_)))))))));
    vlSelf->wasmetal_core__DOT___009806_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5ad8b1f1__0))))))));
    vlSelf->__VdfgTmp_h4a046d69__0 = (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008408_));
    vlSelf->__VdfgTmp_hcc135002__0 = (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007772_));
    vlSelf->wasmetal_core__DOT___000924_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000920_))))));
    vlSelf->__VdfgTmp_he7245d4a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000922_));
    vlSelf->wasmetal_core__DOT___055669_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055665_)))));
    vlSelf->wasmetal_core__DOT___055858_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055663_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055666_)))));
    vlSelf->wasmetal_core__DOT___055019_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2225d234__0)))));
    vlSelf->wasmetal_core__DOT___060535_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___022495_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->__VdfgTmp_hea36c42a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h28180847__0));
    vlSelf->wasmetal_core__DOT___059973_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___001850_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001302_))))));
    vlSelf->wasmetal_core__DOT___054982_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0)))));
    vlSelf->wasmetal_core__DOT___055828_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055638_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055641_)))));
    vlSelf->wasmetal_core__DOT___055642_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055640_)))));
    vlSelf->wasmetal_core__DOT___048630_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048623_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051286_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048623_))));
    vlSelf->wasmetal_core__DOT___060521_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005962_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hb70db301__0 = (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___022494_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->__VdfgTmp_h7c7215cb__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0));
    vlSelf->wasmetal_core__DOT___059942_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(vlSelf->wasmetal_core__DOT___005770_));
    vlSelf->wasmetal_core__DOT___002601_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___001710_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001709_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000180_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___001712_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001711_)))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___001708_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001707_))))));
    vlSelf->wasmetal_core__DOT___002770_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001707_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001708_)))))))));
    vlSelf->wasmetal_core__DOT___002851_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000920_)))))))));
    vlSelf->wasmetal_core__DOT___001930_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000822_))))));
    vlSelf->__VdfgTmp_h7357dd51__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002231_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001705_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000821_))))))))));
    vlSelf->__VdfgTmp_h95b0aa6a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002387_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___002231_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000822_))))))))));
    vlSelf->wasmetal_core__DOT___063815_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063811_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_heb8a147e__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h51befd44__0))))))));
    vlSelf->__VdfgTmp_hdfa295b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8de67bd6__0)));
    vlSelf->wasmetal_core__DOT___055601_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8de67bd6__0)))));
    vlSelf->wasmetal_core__DOT___054940_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaeadd36__0)))));
    vlSelf->wasmetal_core__DOT___048641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048640_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051111_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048640_))));
    vlSelf->wasmetal_core__DOT___058690_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048725_))));
    vlSelf->wasmetal_core__DOT___060507_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___022493_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->__VdfgTmp_h0286ce7d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0));
    vlSelf->wasmetal_core__DOT___059917_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003806_))));
    vlSelf->__VdfgTmp_h83434591__0 = (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->wasmetal_core__DOT___003129_ = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                            & (IData)(
                                                      (0x8000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003805_)))))))));
    vlSelf->wasmetal_core__DOT___001312_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had66fb55__0)))))));
    vlSelf->wasmetal_core__DOT___001781_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had66fb55__0)))));
    vlSelf->__VdfgTmp_h4ad5bd42__0 = (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb8ee9e15__0)));
    vlSelf->wasmetal_core__DOT___055525_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb8ee9e15__0)))));
    vlSelf->wasmetal_core__DOT___048642_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048635_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051054_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048635_))));
    vlSelf->__VdfgTmp_h678017d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048717_));
    vlSelf->wasmetal_core__DOT___060493_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___050141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005896_))));
    vlSelf->__VdfgTmp_h3500bf27__0 = (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005830_));
    vlSelf->__VdfgTmp_h21922827__0 = (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___010150_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007338_)))))))));
    vlSelf->wasmetal_core__DOT___009782_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007339_)))))))));
    vlSelf->__VdfgTmp_hd03398e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007340_))));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___010359_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007338_))))));
        vlSelf->wasmetal_core__DOT___010089_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007260_))))));
        vlSelf->wasmetal_core__DOT___010139_ = vlSelf->wasmetal_core__DOT___007786_;
        vlSelf->wasmetal_core__DOT___010754_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007373_))))));
        vlSelf->wasmetal_core__DOT___010110_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007470_))))));
    } else {
        vlSelf->wasmetal_core__DOT___010359_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007339_))))));
        vlSelf->wasmetal_core__DOT___010089_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007778_));
        vlSelf->wasmetal_core__DOT___010139_ = vlSelf->wasmetal_core__DOT___007739_;
        vlSelf->wasmetal_core__DOT___010754_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007789_));
        vlSelf->wasmetal_core__DOT___010110_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007471_))))));
    }
    vlSelf->__VdfgTmp_h91f4b3ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008370_));
    vlSelf->wasmetal_core__DOT___054978_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7102b895__0)))));
    vlSelf->wasmetal_core__DOT___026494_ = (1U & (0x8080ff80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071972_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071911_)))))));
    vlSelf->wasmetal_core__DOT___026585_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071972_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071965_))))));
    vlSelf->wasmetal_core__DOT___049020_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049019_))));
    vlSelf->wasmetal_core__DOT___049122_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049019_))));
    vlSelf->wasmetal_core__DOT___001720_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff00ff55ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000717_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000574_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000573_)))))))));
    vlSelf->wasmetal_core__DOT___002144_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000573_))))));
    vlSelf->wasmetal_core__DOT___054937_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h584cbf3b__0)))));
    vlSelf->wasmetal_core__DOT___049017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049016_))));
    vlSelf->wasmetal_core__DOT___049080_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049016_))));
    vlSelf->__VdfgTmp_hf20b3c9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001660_));
    vlSelf->wasmetal_core__DOT___054914_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h169cd931__0)))));
    vlSelf->__VdfgTmp_h99cee8a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->wasmetal_core__DOT___052700_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->__VdfgTmp_h301f8c5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->__VdfgTmp_h436041ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000572_));
    vlSelf->wasmetal_core__DOT___055966_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055782_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055783_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055784_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055785_)))))))));
    vlSelf->wasmetal_core__DOT___054875_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2596a796__0)))));
    vlSelf->wasmetal_core__DOT___026493_ = (1U & (IData)(
                                                         (0xccfcaafa00f000f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071970_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_had9a86ff__0))))))));
    vlSelf->wasmetal_core__DOT___026583_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071970_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071963_))))));
    vlSelf->wasmetal_core__DOT___026586_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071973_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071967_))))));
    vlSelf->wasmetal_core__DOT___026581_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071967_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071959_))))));
    vlSelf->wasmetal_core__DOT___042104_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7da480c4__0))));
    vlSelf->wasmetal_core__DOT___042185_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7da480c4__0))))));
    vlSelf->__VdfgTmp_h8bf08b0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001657_));
    vlSelf->wasmetal_core__DOT___054828_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h03e9ae47__0)))));
    vlSelf->wasmetal_core__DOT___049035_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049034_))));
    vlSelf->wasmetal_core__DOT___049076_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049034_))));
    vlSelf->__VdfgTmp_h8c923865__0 = (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000179_));
    vlSelf->wasmetal_core__DOT___055949_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055752_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055753_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055754_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055755_)))))))));
    vlSelf->__VdfgTmp_h2ba92b9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6deef1cd__0)));
    vlSelf->wasmetal_core__DOT___049038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049037_))));
    vlSelf->wasmetal_core__DOT___049070_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049037_))));
    vlSelf->wasmetal_core__DOT___067203_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067083_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067202_)))));
    vlSelf->wasmetal_core__DOT___001853_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001656_)))))))));
    vlSelf->wasmetal_core__DOT___001773_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001656_))))));
    vlSelf->wasmetal_core__DOT___054713_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc63c8631__0)))));
    vlSelf->wasmetal_core__DOT___050430_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050427_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050426_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h48afdd44__0))))));
    vlSelf->wasmetal_core__DOT___049274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049068_))));
    vlSelf->wasmetal_core__DOT___049069_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049068_))));
    vlSelf->wasmetal_core__DOT___067162_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067161_)))));
    vlSelf->wasmetal_core__DOT___048735_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000178_)))))))));
    vlSelf->wasmetal_core__DOT___001734_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000178_))))));
    vlSelf->__VdfgTmp_h4f4f4420__0 = (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h78e7e4d8__0)));
    vlSelf->wasmetal_core__DOT___055667_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78e7e4d8__0)))));
    vlSelf->wasmetal_core__DOT___055027_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8562240__0)))));
    vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           | (IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hf07ddd26__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0));
    vlSelf->wasmetal_core__DOT___055058_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0))))));
    vlSelf->wasmetal_core__DOT___067084_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066897_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067083_)))));
    vlSelf->wasmetal_core__DOT___048828_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001655_)))))))));
    vlSelf->wasmetal_core__DOT___001659_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001655_))))));
    vlSelf->__VdfgTmp_hb0afff05__0 = (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd9d9e38d__0)));
    vlSelf->wasmetal_core__DOT___055656_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd9d9e38d__0)))));
    vlSelf->wasmetal_core__DOT___054977_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf0027c26__0)))));
    vlSelf->__VdfgTmp_hf03fc3ad__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0));
    vlSelf->wasmetal_core__DOT___055012_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0))))));
    vlSelf->wasmetal_core__DOT___026582_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071969_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071961_))))));
    vlSelf->wasmetal_core__DOT___026580_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071965_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071957_))))));
    vlSelf->wasmetal_core__DOT___066980_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066979_)))));
    vlSelf->wasmetal_core__DOT___048815_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000177_)))))))));
    vlSelf->wasmetal_core__DOT___000184_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000177_))))));
    vlSelf->__VdfgTmp_h7c0fb6b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h90a7e66d__0)));
    vlSelf->wasmetal_core__DOT___055600_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h90a7e66d__0)))));
    vlSelf->wasmetal_core__DOT___054938_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0)))));
    vlSelf->__VdfgTmp_h70e31548__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h9e64b929__0));
    vlSelf->wasmetal_core__DOT___054971_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9e64b929__0))))));
    vlSelf->wasmetal_core__DOT___066898_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066773_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066897_)))));
    vlSelf->wasmetal_core__DOT___048831_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001654_)))))))));
    vlSelf->wasmetal_core__DOT___001658_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001654_))))));
    vlSelf->__VdfgTmp_h64c25376__0 = (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc06d6619__0)));
    vlSelf->wasmetal_core__DOT___055524_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc06d6619__0)))));
    vlSelf->wasmetal_core__DOT___054915_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0)))));
    vlSelf->__VdfgTmp_h2447f2cc__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0));
    vlSelf->wasmetal_core__DOT___054924_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0))))));
    vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001476_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___028871_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___028868_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___028857_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___028846_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028487_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028454_)
            : (IData)(vlSelf->wasmetal_core__DOT___004522_));
    vlSelf->wasmetal_core__DOT___049093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049092_))));
    vlSelf->wasmetal_core__DOT___049261_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049092_))));
    vlSelf->wasmetal_core__DOT___066861_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066860_)))));
    vlSelf->wasmetal_core__DOT___048778_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000176_)))))))));
    vlSelf->wasmetal_core__DOT___000183_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000176_))))));
    vlSelf->__VdfgTmp_h782ee59f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9a7588ae__0)));
    vlSelf->wasmetal_core__DOT___055504_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9a7588ae__0)))));
    vlSelf->wasmetal_core__DOT___054876_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0)))));
    vlSelf->wasmetal_core__DOT___054889_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_habef704b__0))))));
    vlSelf->wasmetal_core__DOT___026579_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071963_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071955_))))));
    vlSelf->wasmetal_core__DOT___026575_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071955_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071947_))))));
    vlSelf->wasmetal_core__DOT___026577_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071959_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071951_))))));
    vlSelf->wasmetal_core__DOT___026572_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071951_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071943_))))));
    vlSelf->wasmetal_core__DOT___066774_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066610_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066773_)))));
    vlSelf->wasmetal_core__DOT___048786_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001498_)))))))));
    vlSelf->wasmetal_core__DOT___001896_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001498_))))));
    vlSelf->__VdfgTmp_h528d6985__0 = (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h384cc7f9__0)));
    vlSelf->wasmetal_core__DOT___055434_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h384cc7f9__0)))));
    vlSelf->wasmetal_core__DOT___054829_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0)))));
    vlSelf->wasmetal_core__DOT___054842_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcd50fd36__0))))));
    vlSelf->wasmetal_core__DOT___026578_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071961_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071953_))))));
    vlSelf->wasmetal_core__DOT___066652_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066529_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066651_)))));
    vlSelf->__VdfgTmp_h4598addd__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf0c7a5d6__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h66324e1d__0)))));
    vlSelf->wasmetal_core__DOT___048770_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001731_)))))))));
    vlSelf->__VdfgTmp_h2135b46c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001731_))));
    vlSelf->__VdfgTmp_he2d6a2af__0 = (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfa99a91b__0)));
    vlSelf->wasmetal_core__DOT___055379_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa99a91b__0)))));
    vlSelf->wasmetal_core__DOT___054758_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0)))));
    vlSelf->wasmetal_core__DOT___002244_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048760_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048757_)))))))));
    vlSelf->wasmetal_core__DOT___066611_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066403_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066610_)))));
    vlSelf->wasmetal_core__DOT___063880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063877_))));
    vlSelf->wasmetal_core__DOT___048742_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001497_)))))))));
    vlSelf->__VdfgTmp_h8fa00ac2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001497_))));
    vlSelf->__VdfgTmp_he798fe47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9ea6e74c__0)));
    vlSelf->wasmetal_core__DOT___055343_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9ea6e74c__0)))));
    vlSelf->wasmetal_core__DOT___054714_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h84d44246__0)))));
    vlSelf->wasmetal_core__DOT___002041_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048820_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048818_)))))))));
    vlSelf->wasmetal_core__DOT___026576_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071957_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071949_))))));
    vlSelf->wasmetal_core__DOT___026571_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071949_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071941_))))));
    vlSelf->wasmetal_core__DOT___026574_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071953_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071945_))))));
    vlSelf->wasmetal_core__DOT___066530_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066323_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066529_)))));
    vlSelf->wasmetal_core__DOT___069097_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x8000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0))))));
    vlSelf->wasmetal_core__DOT___019400_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8926b37c__0))));
    vlSelf->wasmetal_core__DOT___002143_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001730_))))));
    vlSelf->wasmetal_core__DOT___055017_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69142c13__0)))));
    vlSelf->wasmetal_core__DOT___002477_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048733_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048732_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048731_)))))))));
    vlSelf->wasmetal_core__DOT___066404_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066266_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066403_)))));
    vlSelf->wasmetal_core__DOT___002106_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001496_))))));
    vlSelf->wasmetal_core__DOT___019268_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0))))));
    vlSelf->wasmetal_core__DOT___054976_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0)))));
    vlSelf->wasmetal_core__DOT___002153_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048826_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048825_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048823_)))))))));
    vlSelf->wasmetal_core__DOT___066324_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066131_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066323_)))));
    vlSelf->wasmetal_core__DOT___002142_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001729_))))));
    vlSelf->wasmetal_core__DOT___019257_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h744f9b35__0))))));
    vlSelf->wasmetal_core__DOT___054934_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h744f9b35__0)))));
    vlSelf->wasmetal_core__DOT___002116_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048813_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048812_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048810_)))))))));
    vlSelf->wasmetal_core__DOT___066267_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066266_)))));
    vlSelf->wasmetal_core__DOT___002105_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001495_))))));
    vlSelf->wasmetal_core__DOT___054896_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h413b142d__0)))));
    vlSelf->wasmetal_core__DOT___002079_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048836_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048834_)))))))));
    vlSelf->wasmetal_core__DOT___066132_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065929_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066131_)))));
    vlSelf->__VdfgTmp_h4ea6bbba__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d)))) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3a315b1c__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072034_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0))))))))));
    vlSelf->__VdfgTmp_h982d8c02__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h3a315b1c__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96696996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0)) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hab155f14__0))))))));
    vlSelf->wasmetal_core__DOT___002382_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001726_))))));
    vlSelf->wasmetal_core__DOT___019245_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h64194573__0))))));
    vlSelf->wasmetal_core__DOT___054873_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h64194573__0)))));
    vlSelf->wasmetal_core__DOT___002356_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048775_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048773_)))))))));
    vlSelf->wasmetal_core__DOT___066075_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065905_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066074_)))));
    vlSelf->wasmetal_core__DOT___002460_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001342_))))));
    vlSelf->wasmetal_core__DOT___054830_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h67f18e55__0)))));
    vlSelf->wasmetal_core__DOT___002434_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048783_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048782_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048780_)))))))));
    vlSelf->wasmetal_core__DOT___053511_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052677_))));
    vlSelf->wasmetal_core__DOT___052836_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044526_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052677_))));
    vlSelf->wasmetal_core__DOT___052678_ = (1U & (IData)(
                                                         (0x7fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052677_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052676_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052675_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052021_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052020_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052019_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b87__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b86__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b80__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052013_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052012_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052011_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b55__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b48__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052005_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052004_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b119__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b118__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b112__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___053512_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044526_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052677_))))));
    vlSelf->wasmetal_core__DOT___026569_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071945_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071937_))))));
    vlSelf->wasmetal_core__DOT___026565_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071937_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071929_))))));
    vlSelf->wasmetal_core__DOT___026567_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071941_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071933_))))));
    vlSelf->wasmetal_core__DOT___026563_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071933_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071925_))))));
    vlSelf->wasmetal_core__DOT___065930_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065929_)))));
    vlSelf->wasmetal_core__DOT___065810_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065619_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065809_)))));
    vlSelf->wasmetal_core__DOT___002225_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001725_))))));
    vlSelf->wasmetal_core__DOT___054757_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h83053a2d__0)))));
    vlSelf->wasmetal_core__DOT___002396_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048768_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048767_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048765_)))))))));
    vlSelf->wasmetal_core__DOT___061762_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaaaaccccf0f0ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061759_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061758_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h422a580d__0)))))))))));
    vlSelf->wasmetal_core__DOT___061767_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061759_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061758_)))));
    vlSelf->wasmetal_core__DOT___026568_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071943_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071935_))))));
    vlSelf->wasmetal_core__DOT___026564_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071927_))))));
    vlSelf->wasmetal_core__DOT___026566_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071939_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071931_))))));
    vlSelf->wasmetal_core__DOT___065906_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065707_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065905_)))));
    vlSelf->wasmetal_core__DOT___063894_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063891_))));
    vlSelf->wasmetal_core__DOT___001770_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001341_))))));
    vlSelf->wasmetal_core__DOT___002519_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048740_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048739_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048737_)))))))));
    vlSelf->wasmetal_core__DOT___001728_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001726_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001724_))))));
    vlSelf->wasmetal_core__DOT___002199_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048753_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048752_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048750_)))))))));
    vlSelf->wasmetal_core__DOT___065708_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065424_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065707_)))));
    vlSelf->wasmetal_core__DOT___001859_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001340_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x33550f0fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hf4328824__0)))))))))));
    vlSelf->wasmetal_core__DOT___001344_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001342_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001340_))))));
    vlSelf->wasmetal_core__DOT___001744_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048893_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048892_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048890_)))))))));
    vlSelf->wasmetal_core__DOT___065620_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065307_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065619_)))));
    vlSelf->wasmetal_core__DOT___065308_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065307_)))));
    vlSelf->wasmetal_core__DOT___042178_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063948_))));
    vlSelf->wasmetal_core__DOT___042097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063948_))));
    vlSelf->wasmetal_core__DOT___001727_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001725_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001723_))))));
    vlSelf->wasmetal_core__DOT___063745_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063739_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063738_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063737_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((6U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h63306680__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)))))))))));
    vlSelf->wasmetal_core__DOT___011103_ = (1U & (0xff4f4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aecec62__0)))));
    vlSelf->wasmetal_core__DOT___010084_ = (1U & (0xff4f4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aecec62__0)))));
    vlSelf->wasmetal_core__DOT___001679_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048885_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048883_)))))))));
    vlSelf->wasmetal_core__DOT___003130_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbbe1bed2__0)))));
    vlSelf->wasmetal_core__DOT___065425_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065199_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065424_)))));
    vlSelf->wasmetal_core__DOT___001343_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001341_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001339_))))));
    vlSelf->wasmetal_core__DOT___010085_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->wasmetal_core__DOT___001254_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048877_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048875_)))))))));
    vlSelf->wasmetal_core__DOT___052835_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044492_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052833_))));
    vlSelf->wasmetal_core__DOT___053250_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044492_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052833_)))))));
    vlSelf->wasmetal_core__DOT___045805_ = ((IData)(vlSelf->wasmetal_core__DOT___045828_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045837_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045836_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045835_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045834_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045833_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045832_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045831_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045830_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045829_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045827_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045815_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045817_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045818_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045819_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045820_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045821_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045822_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045823_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045824_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045825_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045816_));
    vlSelf->wasmetal_core__DOT___049164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049163_))));
    vlSelf->wasmetal_core__DOT___049316_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049163_))));
    vlSelf->__VdfgTmp_hfa759b39__0 = (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010722_));
    vlSelf->wasmetal_core__DOT___010396_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_)))));
    vlSelf->wasmetal_core__DOT___061905_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061899_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061898_)))));
    vlSelf->__VdfgTmp_hfd1fc688__0 = (((IData)(vlSelf->wasmetal_core__DOT___010349_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010348_));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026465_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d));
    vlSelf->wasmetal_core__DOT___026593_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071931_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071923_))))));
    vlSelf->wasmetal_core__DOT___026589_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071923_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071915_))))));
    vlSelf->wasmetal_core__DOT___026591_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071927_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071919_))))));
    vlSelf->wasmetal_core__DOT___026587_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071919_)))));
    vlSelf->wasmetal_core__DOT___050394_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044280_))));
    vlSelf->wasmetal_core__DOT___049156_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049155_))));
    vlSelf->wasmetal_core__DOT___049311_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049155_))));
    vlSelf->wasmetal_core__DOT___065200_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064901_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065199_)))));
    vlSelf->wasmetal_core__DOT___010395_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001874_)))));
    vlSelf->wasmetal_core__DOT___054831_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hef814ba9__0)))));
    vlSelf->wasmetal_core__DOT___044396_ = ((IData)(vlSelf->wasmetal_core__DOT___044442_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044441_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044439_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044438_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044437_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044436_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044435_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044434_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044433_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044432_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044431_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044430_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044450_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044449_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044448_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044447_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044446_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044445_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044444_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044443_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044440_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044429_) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___044405_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044416_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044419_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044420_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044421_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044422_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044423_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044424_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044425_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044426_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044406_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044407_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044408_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044409_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044410_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044411_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044412_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044413_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044414_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044415_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044417_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044418_));
    vlSelf->__VdfgTmp_ha1796962__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___061460_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061459_))) 
                                             << 1U)) 
                                      | (1U & (8U >> (IData)(vlSelf->__VdfgTmp_h4dc07bf4__0))));
    vlSelf->wasmetal_core__DOT___061837_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061831_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061830_)))));
    vlSelf->__VdfgTmp_hbd418077__0 = (((IData)(vlSelf->wasmetal_core__DOT___002289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002288_));
    vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031043_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->__VdfgTmp_h1f90c42a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010288_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010287_));
    vlSelf->wasmetal_core__DOT___054825_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf131a410__0)))));
    vlSelf->wasmetal_core__DOT___049027_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049026_))));
    vlSelf->wasmetal_core__DOT___049075_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049026_))));
    vlSelf->__VdfgTmp_h41c2ec0e__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___007778_)
                                               : (0xc0aU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7b8e4425__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                         & (IData)(
                                                   (0xf0f0aaaaff00ccccULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h05980b33__0)))))))));
    vlSelf->__VdfgTmp_h805d75e1__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1fbedb27__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c85186d__0))))));
    vlSelf->wasmetal_core__DOT___054811_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c85186d__0)))));
    vlSelf->wasmetal_core__DOT___010881_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66742b2d__0))))))));
    if (vlSelf->wasmetal_core__DOT___007235_) {
        if (vlSelf->wasmetal_core__DOT___007234_) {
            vlSelf->wasmetal_core__DOT___010982_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h66742b2d__0)));
            vlSelf->wasmetal_core__DOT___054806_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007588_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007587_))));
            vlSelf->wasmetal_core__DOT___010988_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h0761bbb4__0)));
            vlSelf->wasmetal_core__DOT___010957_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0)));
            vlSelf->wasmetal_core__DOT___010193_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h939caa69__0)));
            vlSelf->wasmetal_core__DOT___009784_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h29ef1e90__0))));
            vlSelf->wasmetal_core__DOT___009796_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7619e45d__0))));
            vlSelf->wasmetal_core__DOT___010231_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hd4d40399__0)));
            vlSelf->wasmetal_core__DOT___054855_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf2283ef8__0)));
            vlSelf->wasmetal_core__DOT___010977_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7e54e6f3__0))));
        } else {
            vlSelf->wasmetal_core__DOT___010982_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007545_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007544_))));
            vlSelf->wasmetal_core__DOT___054806_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007586_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007585_))));
            vlSelf->wasmetal_core__DOT___010988_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007566_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007565_))));
            vlSelf->wasmetal_core__DOT___010957_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___007628_));
            vlSelf->wasmetal_core__DOT___010193_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007525_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007524_))));
            vlSelf->wasmetal_core__DOT___009784_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h2aa6a52e__0))));
            vlSelf->wasmetal_core__DOT___009796_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h009b2026__0))));
            vlSelf->wasmetal_core__DOT___010231_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hae0eb281__0)));
            vlSelf->wasmetal_core__DOT___054855_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007641_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007640_))));
            vlSelf->wasmetal_core__DOT___010977_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h0fc2ac4f__0))));
        }
        vlSelf->wasmetal_core__DOT___010164_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h13d2f137__0)))
                                                    : 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he182d032__0)))));
        vlSelf->wasmetal_core__DOT___011003_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb4fb5a01__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___010982_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007548_)))));
        vlSelf->wasmetal_core__DOT___054806_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007589_)))));
        vlSelf->wasmetal_core__DOT___010988_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007569_)))));
        vlSelf->wasmetal_core__DOT___010164_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                   | (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007729_)))));
        vlSelf->wasmetal_core__DOT___010957_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007623_)))));
        vlSelf->wasmetal_core__DOT___010193_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007528_)))));
        vlSelf->wasmetal_core__DOT___009784_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007740_)))));
        vlSelf->wasmetal_core__DOT___009796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007703_)))));
        vlSelf->wasmetal_core__DOT___011003_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007664_))));
        vlSelf->wasmetal_core__DOT___010231_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007505_)))));
        vlSelf->wasmetal_core__DOT___054855_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007644_)))));
        vlSelf->wasmetal_core__DOT___010977_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007755_)))));
    }
    vlSelf->wasmetal_core__DOT___010374_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010371_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010370_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010369_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010368_)))))));
    vlSelf->wasmetal_core__DOT___010045_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010369_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010368_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010370_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010371_)))))));
    vlSelf->wasmetal_core__DOT___060881_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had16ce46__0)))));
    vlSelf->__VdfgTmp_h35b20f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010278_));
    vlSelf->__VdfgTmp_h8e4b209e__0 = ((2U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010269_));
    vlSelf->wasmetal_core__DOT___061062_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha17fb340__0)))));
    vlSelf->wasmetal_core__DOT___054904_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha17fb340__0)))));
    vlSelf->wasmetal_core__DOT___051548_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051547_))));
    vlSelf->__VdfgTmp_hce73595f__0 = (((IData)(vlSelf->wasmetal_core__DOT___048606_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048605_));
    vlSelf->__VdfgTmp_hd7e7c41d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010250_));
    vlSelf->__VdfgTmp_h36154466__0 = (((IData)(vlSelf->wasmetal_core__DOT___051547_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051579_));
    vlSelf->__VdfgTmp_h1dedb610__0 = (((IData)(vlSelf->wasmetal_core__DOT___048605_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048660_));
    vlSelf->wasmetal_core__DOT___051612_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051611_))));
    vlSelf->__VdfgTmp_ha9985ff6__0 = (((IData)(vlSelf->wasmetal_core__DOT___048660_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048659_));
    vlSelf->__VdfgTmp_hcb315704__0 = (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb53fd6c1__0)));
    vlSelf->wasmetal_core__DOT___051629_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051628_))));
    vlSelf->__VdfgTmp_h309182ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___048659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048670_));
    vlSelf->__VdfgTmp_h4965d650__0 = (((IData)(vlSelf->wasmetal_core__DOT___010240_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010239_));
    vlSelf->__VdfgTmp_hb5f0d294__0 = (((IData)(vlSelf->wasmetal_core__DOT___010239_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010240_));
    vlSelf->wasmetal_core__DOT___054870_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hca7cb6a3__0)))));
    vlSelf->wasmetal_core__DOT___055005_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h223b6529__0)))));
    vlSelf->wasmetal_core__DOT___049030_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049029_))));
    vlSelf->wasmetal_core__DOT___049079_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049029_))));
    vlSelf->__VdfgTmp_h4ec1ed59__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007308_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007287_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007782_))));
    vlSelf->__VdfgTmp_h25286e3d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h37472320__0)))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007782_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007717_)));
    vlSelf->__VdfgTmp_h85e16522__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h15fa30e3__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h08beb063__0))))));
    vlSelf->wasmetal_core__DOT___054856_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h08beb063__0)))));
    vlSelf->__VdfgTmp_h3d308cc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007585_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007586_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___053918_))))));
    vlSelf->__VdfgTmp_h3226e594__0 = (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007473_));
    vlSelf->wasmetal_core__DOT___027481_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007340_)))))))));
    vlSelf->__VdfgTmp_h161030dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007473_));
    vlSelf->__VdfgTmp_h51b5ea87__0 = (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054901_));
    vlSelf->wasmetal_core__DOT___062025_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))));
    vlSelf->wasmetal_core__DOT___010321_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hba71a165__0))));
    vlSelf->__VdfgTmp_hb1a6f4d3__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5cfad588__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8993186__0))))));
    vlSelf->wasmetal_core__DOT___054952_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8993186__0)))));
    vlSelf->wasmetal_core__DOT___049009_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049008_))));
    vlSelf->wasmetal_core__DOT___049123_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049008_))));
    vlSelf->__VdfgTmp_hf6bbf4d1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007390_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007789_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007754_)));
    vlSelf->wasmetal_core__DOT___062084_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))));
    vlSelf->__VdfgTmp_hcf41fd11__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9c4c7506__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h61af7368__0))))));
    vlSelf->wasmetal_core__DOT___054991_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h61af7368__0)))));
    vlSelf->wasmetal_core__DOT___055971_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055794_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055795_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055796_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055797_)))))))));
    vlSelf->wasmetal_core__DOT___055805_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055794_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055793_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055792_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055791_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055795_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008069_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055797_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055796_)))))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007590_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007587_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007588_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007585_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007586_)))))))))))))));
    vlSelf->wasmetal_core__DOT___061045_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb33d3cb7__0)))));
    vlSelf->wasmetal_core__DOT___054905_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb33d3cb7__0)))));
    vlSelf->wasmetal_core__DOT___010715_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf37b3ae8__0))))))));
    vlSelf->__VdfgTmp_ha8fd39d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d));
    vlSelf->wasmetal_core__DOT___010887_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0761bbb4__0))))))));
    vlSelf->__VdfgTmp_h6df87d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010350_)));
    vlSelf->wasmetal_core__DOT___060957_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h891cd943__0)))));
    vlSelf->wasmetal_core__DOT___010361_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3856dbf8__0))))))));
    vlSelf->wasmetal_core__DOT___010151_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3856dbf8__0))))));
    vlSelf->wasmetal_core__DOT___061975_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))));
    vlSelf->__VdfgTmp_h544074d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he9d168d9__0)));
    vlSelf->wasmetal_core__DOT___010272_ = (1U & (IData)(
                                                         (0xaa00f000ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he9d168d9__0)))))));
    vlSelf->wasmetal_core__DOT___061046_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbc236300__0)))));
    vlSelf->__VdfgTmp_h4481aac1__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbc236300__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf21032c8__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h82899d97__0)))))));
    vlSelf->wasmetal_core__DOT___009808_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xa0c0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb53fd6c1__0))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h973345c0__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007604_))))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h973345c0__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054852_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054851_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054850_)))))));
    vlSelf->wasmetal_core__DOT___010141_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37a4ed19__0))))));
    vlSelf->wasmetal_core__DOT___010322_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h37a4ed19__0))))))));
    vlSelf->wasmetal_core__DOT___010131_ = (1U & (0xff550f33U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5551ada__0)))));
    vlSelf->wasmetal_core__DOT___010253_ = (1U & (IData)(
                                                         (0xaa00f000ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd5551ada__0)))))));
    vlSelf->wasmetal_core__DOT___061127_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0d308a29__0)))));
    vlSelf->__VdfgTmp_hb52e5b74__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h0d308a29__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd27b8df6__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5cfad588__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                 & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                     ? (IData)((0xff0fff0fff55ff33ULL 
                                >> (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                     << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___007824_) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((IData)(
                                                                 (0xf0f555500ff3333ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h447558a7__0))))))) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007628_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0))))))))))
                     : (2U >> (IData)(vlSelf->wasmetal_core__DOT___007824_)))));
    vlSelf->wasmetal_core__DOT___010869_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0))))))));
    vlSelf->wasmetal_core__DOT___010336_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010333_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010330_)))))));
    vlSelf->wasmetal_core__DOT___033416_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010332_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010333_)))))));
    vlSelf->wasmetal_core__DOT___061209_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e5b7cf0__0)))));
    vlSelf->wasmetal_core__DOT___049087_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048973_))));
    vlSelf->wasmetal_core__DOT___048974_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048973_))));
    vlSelf->__VdfgTmp_h831e3e64__0 = (((IData)(vlSelf->wasmetal_core__DOT___009792_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009791_));
    vlSelf->__VdfgTmp_h910334c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009791_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009792_)));
    vlSelf->wasmetal_core__DOT___055430_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h949b8002__0))));
    vlSelf->__VdfgTmp_hd544aedd__0 = (((IData)(vlSelf->wasmetal_core__DOT___010589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010588_));
    vlSelf->__VdfgTmp_h20b0bc38__0 = (((IData)(vlSelf->wasmetal_core__DOT___010588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010589_));
    vlSelf->__VdfgTmp_h00532677__0 = (((IData)(vlSelf->wasmetal_core__DOT___010290_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010289_));
    vlSelf->__VdfgTmp_h0549af28__0 = (((IData)(vlSelf->wasmetal_core__DOT___010290_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010289_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010287_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010288_))));
    vlSelf->wasmetal_core__DOT___061842_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))));
    vlSelf->__VdfgTmp_h0f4209a4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc5dd9afa__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf131a410__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb63b65e7__0)))))));
    vlSelf->__VdfgTmp_hafe0013c__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_had16ce46__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb63b65e7__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1fbedb27__0)))))));
    vlSelf->__VdfgTmp_h58306e5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___048617_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048606_));
    vlSelf->wasmetal_core__DOT___051519_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051518_))));
    vlSelf->__VdfgTmp_h5ce4c910__0 = (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054775_));
    vlSelf->wasmetal_core__DOT___055759_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055751_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055750_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055749_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055753_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008040_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055755_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055754_)))))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007529_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hca913760__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007526_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007527_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007524_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007525_)))))))))))))));
    vlSelf->__VdfgTmp_h16ee9b67__0 = (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007232_));
    vlSelf->wasmetal_core__DOT___027493_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007253_)))))))));
    vlSelf->wasmetal_core__DOT___007776_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007230_))))));
    vlSelf->__VdfgTmp_hbb919cd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007232_))));
    vlSelf->__VdfgTmp_h7b1353df__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007230_))))));
    vlSelf->wasmetal_core__DOT___054278_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007233_)))))))));
    vlSelf->__VdfgTmp_hab146f1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054770_));
    vlSelf->wasmetal_core__DOT___056182_ = (1U & (IData)(
                                                         (0xf00001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h939caa69__0))))))));
    vlSelf->wasmetal_core__DOT___010893_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h939caa69__0))))))));
    vlSelf->wasmetal_core__DOT___056187_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010319_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010320_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                              & (IData)(
                                                                        (0xf0f555500ff3333ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hba71a165__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                                   ? 
                                                                  (0x305U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___007731_)))))
                                                                   : 
                                                                  (0x305U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb9c84dcf__0))))))))));
    vlSelf->__VdfgTmp_h249314f5__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0ccccff00aaaaULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007366_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb9c84dcf__0))
                                                     : 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he182d032__0)))))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012124_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010559_)));
        vlSelf->wasmetal_core__DOT___012027_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d)));
        vlSelf->wasmetal_core__DOT___012123_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010568_)));
    } else {
        vlSelf->wasmetal_core__DOT___012124_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                    ? 
                                                   (0xfaf3U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h79c46d44__0))))
                                                    : 
                                                   (0xefU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010558_))))));
        vlSelf->wasmetal_core__DOT___012027_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcab0eaad__0))))));
        vlSelf->wasmetal_core__DOT___012123_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010569_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hce8e9d12__0))))));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d 
        = (1U & (IData)((0x5500cc000f0000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010558_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h79c46d44__0))))))));
    vlSelf->__VdfgTmp_h627ddd53__0 = (((IData)(vlSelf->wasmetal_core__DOT___007740_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h29ef1e90__0));
    vlSelf->wasmetal_core__DOT___062094_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))));
    vlSelf->__VdfgTmp_h0fd3f1c4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h597612ae__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h223b6529__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h997e3a26__0)))))));
    vlSelf->__VdfgTmp_hc6adb13e__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6e5b7cf0__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h997e3a26__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9c4c7506__0)))))));
    vlSelf->__VdfgTmp_h9bd5098e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009795_));
    vlSelf->wasmetal_core__DOT___019243_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055782_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055781_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055780_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055779_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055783_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008056_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055785_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055784_)))))))))))));
    vlSelf->wasmetal_core__DOT___009832_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010582_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007834_)))))))));
    vlSelf->__VdfgTmp_hc5fe5af8__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___007834_)) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010582_));
    vlSelf->__VdfgTmp_h9e2ff648__0 = (((IData)(vlSelf->wasmetal_core__DOT___007703_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7619e45d__0));
    vlSelf->wasmetal_core__DOT___061912_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))));
    vlSelf->__VdfgTmp_hc0fd2d13__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he6aadab7__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hca7cb6a3__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6b627b07__0)))))));
    vlSelf->__VdfgTmp_h9a768dd6__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h891cd943__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6b627b07__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h15fa30e3__0)))))));
    vlSelf->wasmetal_core__DOT___049096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049095_))));
    vlSelf->wasmetal_core__DOT___049260_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049095_))));
    vlSelf->wasmetal_core__DOT___061488_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061485_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061484_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054702_)))))))));
    vlSelf->wasmetal_core__DOT___061111_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054908_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054900_))))))))))))));
    vlSelf->__VdfgTmp_hac54b2bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007473_))));
    vlSelf->wasmetal_core__DOT___027488_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007341_)))))))));
    vlSelf->wasmetal_core__DOT___010271_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007470_)))))))));
    vlSelf->__VdfgTmp_h988afe01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054900_));
    vlSelf->wasmetal_core__DOT___049064_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049063_))));
    vlSelf->wasmetal_core__DOT___049271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049063_))));
    vlSelf->wasmetal_core__DOT___055978_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055810_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055811_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055812_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055813_)))))))));
    vlSelf->wasmetal_core__DOT___019255_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055807_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055811_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008077_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055813_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055812_)))))))))))));
    vlSelf->__VdfgTmp_h047929cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009815_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009814_));
    vlSelf->wasmetal_core__DOT___049061_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049060_))));
    vlSelf->wasmetal_core__DOT___049270_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049060_))));
    vlSelf->__VdfgTmp_h0b52da3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009780_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009781_));
    vlSelf->__VdfgTmp_hab0a7d16__0 = (((IData)(vlSelf->wasmetal_core__DOT___009830_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_hcdc85607__0 = (((IData)(vlSelf->wasmetal_core__DOT___010214_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010213_));
    vlSelf->__VdfgTmp_h15c467ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___010215_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010213_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010214_)));
    vlSelf->__VdfgTmp_h63abc8ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___011712_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055135_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055136_) 
                                                                       << 2U) 
                                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                           & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a84499c__0)))))) 
                                                                          << 1U) 
                                                                         | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                            & (IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc18298c4__0))))))))))))));
    vlSelf->wasmetal_core__DOT___010102_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055136_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055135_))))));
    vlSelf->wasmetal_core__DOT___060863_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054775_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054779_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054767_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054769_))))))))))))));
    vlSelf->__VdfgTmp_h6995c07d__0 = (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054782_))));
    vlSelf->wasmetal_core__DOT___027485_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007254_)))))))));
    vlSelf->__VdfgTmp_h028c74de__0 = (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054779_));
    vlSelf->__VdfgTmp_h4f58838a__0 = (((IData)(vlSelf->wasmetal_core__DOT___048618_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048617_));
    vlSelf->wasmetal_core__DOT___051365_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051364_))));
    vlSelf->wasmetal_core__DOT___055105_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055089_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha89e6386__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h284fdec6__0)))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf5533ffU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xc0aU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0)))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((0xc0aU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebcfe313__0)))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xc0aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___010172_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd4d40399__0))))));
    vlSelf->wasmetal_core__DOT___054743_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd4d40399__0))))))));
    vlSelf->wasmetal_core__DOT___055276_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053789_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha85bab6c__0))))));
    vlSelf->wasmetal_core__DOT___061668_ = (1U & (IData)(
                                                         (0xff00fff0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061666_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h73a9d128__0)))))));
    vlSelf->__VdfgTmp_h479e0c47__0 = (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcab0eaad__0))))));
    vlSelf->__VdfgTmp_hd25df3ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___011622_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2966a39c__0))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he26aa999__0)))))));
    vlSelf->__VdfgTmp_h4e8951c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___054157_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he26aa999__0))) 
                                                     << 2U)) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(
                                                                (0xf0f0aaaaff00ccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___007430_))))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h2966a39c__0)))))));
    vlSelf->wasmetal_core__DOT___061908_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061649_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007301_)))))))));
    vlSelf->wasmetal_core__DOT___061503_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061500_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054675_)))))))));
    vlSelf->__VdfgTmp_he6780703__0 = (((IData)(vlSelf->wasmetal_core__DOT___009650_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009649_));
    vlSelf->wasmetal_core__DOT___053074_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045623_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044026_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->type_matches)))));
    vlSelf->wasmetal_core__DOT___053070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044045_))));
    vlSelf->wasmetal_core__DOT___061496_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061493_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061492_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054692_)))))))));
    vlSelf->wasmetal_core__DOT___055051_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h49097fbe__0)))));
    vlSelf->wasmetal_core__DOT___049012_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049011_))));
    vlSelf->wasmetal_core__DOT___049126_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049011_))));
    vlSelf->wasmetal_core__DOT___061489_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054699_)))))))));
    vlSelf->__VdfgTmp_hf96aac0e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007420_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007399_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007792_))));
    vlSelf->__VdfgTmp_h5ffe6cff__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007417_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007792_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007769_)));
    vlSelf->wasmetal_core__DOT___062150_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))));
    vlSelf->wasmetal_core__DOT___055037_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5d8e5746__0)))));
    vlSelf->wasmetal_core__DOT___010310_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h22d02546__0))));
    vlSelf->wasmetal_core__DOT___061490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061482_))));
    vlSelf->__VdfgTmp_hc9e45bda__0 = (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->__VdfgTmp_h9c14d25f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010529_));
    vlSelf->wasmetal_core__DOT___010875_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf2283ef8__0))))))));
    vlSelf->wasmetal_core__DOT___011520_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010308_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010309_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                              & (IData)(
                                                                        (0xf0f555500ff3333ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h22d02546__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf00001111ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2283ef8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061497_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061495_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061494_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054778_)))))))));
    vlSelf->__VdfgTmp_h415259f4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_haef34542__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5d8e5746__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb53c364f__0)))))));
    vlSelf->wasmetal_core__DOT___070026_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053071_))));
    vlSelf->__VdfgTmp_h5d9fd2de__0 = (((IData)(vlSelf->wasmetal_core__DOT___048629_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048618_));
    vlSelf->wasmetal_core__DOT___051345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051344_))));
    vlSelf->wasmetal_core__DOT___055683_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055682_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055681_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055680_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055679_)))))))));
    vlSelf->wasmetal_core__DOT___055863_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055862_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055861_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055860_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055859_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010569_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce8e9d12__0))))));
    vlSelf->__VdfgTmp_he68aaf0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007755_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7e54e6f3__0));
    vlSelf->wasmetal_core__DOT___061502_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061499_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061498_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054683_)))))))));
    vlSelf->wasmetal_core__DOT___055062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027491_))));
    vlSelf->wasmetal_core__DOT___062139_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))));
    vlSelf->__VdfgTmp_h88cf509b__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h72b22246__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd9dc27af__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h49097fbe__0)))))));
    vlSelf->__VdfgTmp_h84a7ba42__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb53c364f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd9dc27af__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haef34542__0)))))));
    vlSelf->wasmetal_core__DOT___069246_ = (1U & (IData)(
                                                         (0xcc00f0000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h703a7a56__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000169_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048922_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048923_)))))))));
    vlSelf->wasmetal_core__DOT___055026_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055020_))));
    vlSelf->wasmetal_core__DOT___053694_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->__VdfgTmp_hb6137419__0 = (((IData)(vlSelf->wasmetal_core__DOT___051628_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051648_));
    vlSelf->__VdfgTmp_h3f02e9b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___048670_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048669_));
    vlSelf->wasmetal_core__DOT___064770_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064538_))));
    vlSelf->wasmetal_core__DOT___064541_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hab155f14__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x4fff00ff00000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063867_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h101b2914__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h75b63843__0))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h61f75715__0 = (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h75b63843__0))));
    vlSelf->wasmetal_core__DOT___042153_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65785f77__0))));
    vlSelf->wasmetal_core__DOT___042208_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070500_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65785f77__0))));
    vlSelf->wasmetal_core__DOT___042387_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67b52d18__0))));
    vlSelf->wasmetal_core__DOT___042354_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070500_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67b52d18__0))));
    vlSelf->wasmetal_core__DOT___022491_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he55adf41__0))));
    vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005903_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_ha0b2e14a__0 = (((IData)(vlSelf->wasmetal_core__DOT___047928_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047927_));
    vlSelf->wasmetal_core__DOT___050691_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049883_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050690_))));
    vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013778_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h77ed0e73__0 = (((IData)(vlSelf->wasmetal_core__DOT___047945_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047928_));
    vlSelf->wasmetal_core__DOT___049884_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049794_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049883_))));
    vlSelf->__VdfgTmp_h3d1308f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___047946_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047945_));
    vlSelf->wasmetal_core__DOT___049795_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049794_))));
    vlSelf->wasmetal_core__DOT___063909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063902_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063901_))));
    vlSelf->__VdfgTmp_hf5f2577b__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h1811a1bb__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9cfb7302__0)))));
    vlSelf->wasmetal_core__DOT___061474_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061471_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007341_)))))))));
    vlSelf->wasmetal_core__DOT___054723_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1b99479d__0)))));
    vlSelf->wasmetal_core__DOT___047871_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047870_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049697_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047870_))));
    vlSelf->__VdfgTmp_hc3924088__0 = (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014037_));
    vlSelf->__VdfgTmp_h7ffc48a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h42c557be__0)));
    vlSelf->__VdfgTmp_he957a5af__0 = (((IData)(vlSelf->wasmetal_core__DOT___047851_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047872_));
    vlSelf->__VdfgTmp_hfbafed17__0 = (((IData)(vlSelf->wasmetal_core__DOT___049497_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049613_));
    vlSelf->__VdfgTmp_h6d3ebca4__0 = (((IData)(vlSelf->wasmetal_core__DOT___047852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047851_));
    vlSelf->wasmetal_core__DOT___049498_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049115_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049497_))));
    vlSelf->wasmetal_core__DOT___048930_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d))))));
    vlSelf->__VdfgTmp_hfac3f09e__0 = (((IData)(vlSelf->wasmetal_core__DOT___047909_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047852_));
    vlSelf->wasmetal_core__DOT___049116_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049115_))));
    vlSelf->wasmetal_core__DOT___055958_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf0f555500ff3333ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055418_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055423_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055422_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055425_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055764_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055761_)))))));
    vlSelf->wasmetal_core__DOT___055777_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055764_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055418_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055423_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf5f3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008048_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055761_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055422_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055425_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055424_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055427_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x330fff55U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055426_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h949b8002__0))))))))))))));
    vlSelf->__VdfgTmp_hc36aba22__0 = (((IData)(vlSelf->wasmetal_core__DOT___047910_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047909_));
    vlSelf->wasmetal_core__DOT___048581_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048577_))));
    vlSelf->__VdfgTmp_h868ae0cf__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h4a43881d__0))) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4e2d279b__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  ((8U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4a43881d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0))))))))));
    vlSelf->__VdfgTmp_hd6896023__0 = (((IData)(vlSelf->wasmetal_core__DOT___047891_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047910_));
    vlSelf->wasmetal_core__DOT___049117_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048578_))));
    vlSelf->__VdfgTmp_h87becbe1__0 = (((IData)(vlSelf->wasmetal_core__DOT___047892_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047891_));
    vlSelf->wasmetal_core__DOT___048582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048579_))));
    vlSelf->wasmetal_core__DOT___063923_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063915_))));
    vlSelf->wasmetal_core__DOT___061476_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061468_))));
    vlSelf->__VdfgTmp_ha333b59f__0 = (((IData)(vlSelf->wasmetal_core__DOT___047831_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047892_));
    vlSelf->__VdfgTmp_hf502c6b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___048583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048580_));
    vlSelf->wasmetal_core__DOT___063967_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___042169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063964_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042167_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___042176_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042172_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___042171_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___042170_))))))))))));
    vlSelf->__VdfgTmp_ha952ad99__0 = (((IData)(vlSelf->wasmetal_core__DOT___002069_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002068_));
    vlSelf->__VdfgTmp_h96c76ab3__0 = (((IData)(vlSelf->wasmetal_core__DOT___047832_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047831_));
    vlSelf->wasmetal_core__DOT___048587_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048583_))));
    vlSelf->__VdfgTmp_h2956b7c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___047813_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047832_));
    vlSelf->wasmetal_core__DOT___049119_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048585_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048584_))));
    vlSelf->__VdfgTmp_h211aef5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___047814_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047813_));
    vlSelf->wasmetal_core__DOT___048588_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048585_))));
    vlSelf->__VdfgTmp_h07a6aef0__0 = (((IData)(vlSelf->wasmetal_core__DOT___002272_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002271_));
    vlSelf->__VdfgTmp_h343b1824__0 = (((IData)(vlSelf->wasmetal_core__DOT___000168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000167_));
    vlSelf->wasmetal_core__DOT___002931_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4408f503__0)))))));
    vlSelf->wasmetal_core__DOT___002688_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4408f503__0)))))));
    vlSelf->__VdfgTmp_ha4843895__0 = (((IData)(vlSelf->wasmetal_core__DOT___047814_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048689_));
    vlSelf->wasmetal_core__DOT___049142_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049141_))));
    vlSelf->__VdfgTmp_h09589e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___049365_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048689_));
    vlSelf->wasmetal_core__DOT___049503_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049139_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049141_))));
    vlSelf->wasmetal_core__DOT___006972_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048702_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048701_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___005903_))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x8000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006226_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))))))))))));
    vlSelf->__VdfgTmp_h2b3afffd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049365_));
    vlSelf->__VdfgTmp_h0a02dc0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049140_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049139_));
    vlSelf->__VdfgTmp_hc4ac601e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049366_));
    vlSelf->wasmetal_core__DOT___049501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049140_))));
    vlSelf->wasmetal_core__DOT___063924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063921_))));
    vlSelf->__VdfgTmp_h00f9b844__0 = (((IData)(vlSelf->wasmetal_core__DOT___063872_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2e505808__0))));
    vlSelf->wasmetal_core__DOT___042295_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h607fca11__0))));
    vlSelf->wasmetal_core__DOT___042317_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h607fca11__0))));
    vlSelf->wasmetal_core__DOT___042083_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff973d2d__0))));
    vlSelf->wasmetal_core__DOT___042116_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff973d2d__0))));
    vlSelf->wasmetal_core__DOT___011719_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___049158_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003221_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h534a5d27__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001902_)))))))));
    vlSelf->wasmetal_core__DOT___065075_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064734_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065074_)))));
    vlSelf->wasmetal_core__DOT___064735_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064734_)))));
    vlSelf->wasmetal_core__DOT___053993_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054040_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054044_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054048_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028663_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028630_)
            : (IData)(vlSelf->wasmetal_core__DOT___004522_));
    vlSelf->wasmetal_core__DOT___029079_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___029076_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___029065_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029054_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028975_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028942_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d));
    vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001443_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001443_)
            : (IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128103___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028766_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028763_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028752_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028741_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028734_ = ((IData)(vlSelf->wasmetal_core__DOT___028766_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT____Vcellout___127876___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026696_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026685_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026674_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026663_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127876___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026631_ = ((IData)(vlSelf->wasmetal_core__DOT___026696_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT____Vcellout___127927___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027166_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027155_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027144_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027133_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027101_ = ((IData)(vlSelf->wasmetal_core__DOT___027166_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026573_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003269_));
    vlSelf->wasmetal_core__DOT____Vcellout___127910___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026966_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026955_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026944_) 
                                   << 1U) | (1U & (~ 
                                                   (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc01d1a00__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026901_ = ((IData)(vlSelf->wasmetal_core__DOT___026966_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT____Vcellout___127893___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)) 
                   << 3U)) | (IData)(vlSelf->__VdfgTmp_h0d1a9c72__0)) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127893___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026766_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT____Vcellout___134219___O 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___001437_))) 
           ^ (4U | (((IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__) 
                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034541_))));
    vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001443_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___064503_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064502_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064501_)))));
    vlSelf->wasmetal_core__DOT___063988_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063985_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063984_)))));
    vlSelf->wasmetal_core__DOT___064928_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064501_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064506_)))));
    vlSelf->wasmetal_core__DOT___064756_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063990_)))));
    vlSelf->wasmetal_core__DOT___064510_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064505_)))));
    vlSelf->wasmetal_core__DOT___063994_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063990_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063989_)))));
    vlSelf->wasmetal_core__DOT___064926_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064505_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064508_)))));
    vlSelf->wasmetal_core__DOT___064758_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063992_)))));
    vlSelf->wasmetal_core__DOT___064509_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064507_)))));
    vlSelf->wasmetal_core__DOT___063993_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063992_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063991_)))));
    vlSelf->wasmetal_core__DOT___064925_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064507_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064493_)))));
    vlSelf->wasmetal_core__DOT___064757_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063977_)))));
    vlSelf->wasmetal_core__DOT___064497_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064493_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064492_)))));
    vlSelf->wasmetal_core__DOT___063981_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063977_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063976_)))));
    vlSelf->wasmetal_core__DOT___064922_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064495_)))));
    vlSelf->wasmetal_core__DOT___064753_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063976_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063979_)))));
    vlSelf->wasmetal_core__DOT___064496_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064494_)))));
    vlSelf->wasmetal_core__DOT___063980_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063978_)))));
    vlSelf->wasmetal_core__DOT___064921_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064494_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064489_)))));
    vlSelf->wasmetal_core__DOT___064752_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063978_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063973_)))));
    vlSelf->wasmetal_core__DOT___064490_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064489_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064488_)))));
    vlSelf->wasmetal_core__DOT___063974_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063973_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063972_)))));
    vlSelf->wasmetal_core__DOT___064750_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063972_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063970_)))));
    vlSelf->wasmetal_core__DOT___064919_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064488_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064486_)))));
    vlSelf->wasmetal_core__DOT___064751_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063971_))));
    vlSelf->wasmetal_core__DOT___063975_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063971_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063970_)))));
    vlSelf->wasmetal_core__DOT___064920_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064487_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___064491_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064486_)))));
    vlSelf->wasmetal_core__DOT___030118_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc07dc041__0)))));
    vlSelf->wasmetal_core__DOT___030254_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc07dc041__0)))));
    vlSelf->wasmetal_core__DOT___030115_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d93b5b__0)))));
    vlSelf->wasmetal_core__DOT___030243_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d93b5b__0)))));
    vlSelf->wasmetal_core__DOT___030104_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817566b__0))));
    vlSelf->wasmetal_core__DOT___030232_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817566b__0))));
    vlSelf->wasmetal_core__DOT___030093_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30dbdcaa__0))));
    vlSelf->wasmetal_core__DOT___030221_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30dbdcaa__0))));
    vlSelf->wasmetal_core__DOT___069034_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068961_)))));
    vlSelf->wasmetal_core__DOT___068962_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068961_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068935_)))));
    vlSelf->wasmetal_core__DOT___068892_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068844_)))));
    vlSelf->wasmetal_core__DOT___068790_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068789_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068745_)))));
    vlSelf->wasmetal_core__DOT___068936_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068935_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068891_)))));
    vlSelf->wasmetal_core__DOT___068697_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068696_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068648_)))));
    vlSelf->wasmetal_core__DOT___068845_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068789_)))));
    vlSelf->wasmetal_core__DOT___068599_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068598_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068546_)))));
    vlSelf->wasmetal_core__DOT___068746_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068745_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068696_)))));
    vlSelf->wasmetal_core__DOT___068649_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068598_)))));
    vlSelf->wasmetal_core__DOT___068473_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068472_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068419_)))));
    vlSelf->wasmetal_core__DOT___068547_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068546_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068472_)))));
    vlSelf->wasmetal_core__DOT___068396_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068395_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068340_)))));
    vlSelf->wasmetal_core__DOT___068287_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068286_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068233_)))));
    vlSelf->wasmetal_core__DOT___068420_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068395_)))));
    vlSelf->wasmetal_core__DOT___068149_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068097_)))));
    vlSelf->wasmetal_core__DOT___068341_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068286_)))));
    vlSelf->wasmetal_core__DOT___068073_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068024_)))));
    vlSelf->wasmetal_core__DOT___068234_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068148_)))));
    vlSelf->wasmetal_core__DOT___067968_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067901_)))));
    vlSelf->wasmetal_core__DOT___068098_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068097_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068072_)))));
    vlSelf->wasmetal_core__DOT___068025_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068024_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067967_)))));
    vlSelf->wasmetal_core__DOT___067815_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067814_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067753_)))));
    vlSelf->wasmetal_core__DOT___067902_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067901_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067814_)))));
    vlSelf->wasmetal_core__DOT___067754_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067729_)))));
    vlSelf->wasmetal_core__DOT___067592_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___067447_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2bd8c9ed__0))));
    vlSelf->wasmetal_core__DOT___067496_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0))));
    vlSelf->wasmetal_core__DOT___067300_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_had26118d__0))));
    vlSelf->wasmetal_core__DOT___067145_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4e6deac__0))));
    vlSelf->wasmetal_core__DOT___066962_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4438b1a5__0))));
    vlSelf->wasmetal_core__DOT___066843_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a3dbf89__0))));
    vlSelf->wasmetal_core__DOT___066638_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h898e287a__0))));
    vlSelf->wasmetal_core__DOT___066516_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e6b526c__0))));
    vlSelf->wasmetal_core__DOT___067330_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h717e9861__0))));
    vlSelf->wasmetal_core__DOT___066304_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h238b010e__0))));
    vlSelf->wasmetal_core__DOT___067186_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdba97a87__0))));
    vlSelf->wasmetal_core__DOT___066116_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9040377d__0))));
    vlSelf->wasmetal_core__DOT___067067_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))));
    vlSelf->wasmetal_core__DOT___066884_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))));
    vlSelf->wasmetal_core__DOT___065925_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd9104ee__0))));
    vlSelf->wasmetal_core__DOT___066760_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b010904__0))));
    vlSelf->wasmetal_core__DOT___066593_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))));
    vlSelf->wasmetal_core__DOT___065793_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h06dc5af9__0))));
    vlSelf->wasmetal_core__DOT___066390_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he924c244__0))));
    vlSelf->wasmetal_core__DOT___065595_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))));
    vlSelf->wasmetal_core__DOT___066260_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7dd7d539__0))));
    vlSelf->wasmetal_core__DOT___066070_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))));
    vlSelf->wasmetal_core__DOT___065291_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbfd77ec1__0))));
    vlSelf->wasmetal_core__DOT___065070_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))));
    vlSelf->wasmetal_core__DOT___065889_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9d768121__0))));
    vlSelf->wasmetal_core__DOT___065691_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa154e86__0))));
    vlSelf->wasmetal_core__DOT___065404_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h03893f91__0))));
    vlSelf->wasmetal_core__DOT___065175_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h776ad714__0))));
    vlSelf->wasmetal_core__DOT___064723_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___064890_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4328824__0))));
    vlSelf->wasmetal_core__DOT___064482_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))));
    vlSelf->wasmetal_core__DOT___063827_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063826_))));
    vlSelf->wasmetal_core__DOT___069154_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8025ed93__0))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028296_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028231_));
    vlSelf->wasmetal_core__DOT___049151_ = (1U & (IData)(
                                                         (0xf000f0ff00ffddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003135_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001811_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___003133_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003134_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000157_)))))))));
    vlSelf->wasmetal_core__DOT___064470_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064469_))));
    vlSelf->wasmetal_core__DOT___064902_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064469_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064901_)))));
    vlSelf->wasmetal_core__DOT___063834_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063833_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___064015_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048341_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063728_))));
    vlSelf->wasmetal_core__DOT___064524_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064522_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2e505808__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___064768_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))))));
    vlSelf->wasmetal_core__DOT___064523_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063867_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h0791be06__0 = (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))));
    vlSelf->__VdfgTmp_h563f0a85__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___072046_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072045_))))));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027344_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127427___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h76ba8332__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                          << 1U)))));
}
