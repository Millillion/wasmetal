#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__21(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__21\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___048021_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc5249891__0))))));
    vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5249891__0))))));
    vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
        = (((QData)((IData)((0xfffU & ((IData)((vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                >> 0x23U)) 
                                       + ((IData)((vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                   >> 0x24U)) 
                                          + (1U & (
                                                   ((0xfffU 
                                                     & (IData)(
                                                               (vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                                >> 0x17U))) 
                                                    + 
                                                    ((0xfffU 
                                                      & (IData)(
                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                                 >> 0x18U))) 
                                                     + 
                                                     VL_SHIFTR_III(13,13,32, (IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_h4c2f98f1__0), 0xcU))) 
                                                   >> 0xcU))))))) 
            << 0x24U) | (((QData)((IData)((0xfffU & 
                                           ((IData)(
                                                    (vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                     >> 0x17U)) 
                                            + ((IData)(
                                                       (vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                        >> 0x18U)) 
                                               + (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_h4c2f98f1__0) 
                                                     >> 0xcU))))))) 
                          << 0x18U) | (QData)((IData)(
                                                      ((0xfff000U 
                                                        & (((IData)(
                                                                    (vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                                     >> 0xbU)) 
                                                            + 
                                                            ((IData)(
                                                                     (vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                                      >> 0xcU)) 
                                                             + 
                                                             (1U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_ha5045b21__0) 
                                                                 >> 0xcU)))) 
                                                           << 0xcU)) 
                                                       | (0xfffU 
                                                          & ((0xffeU 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz) 
                                                                 << 1U)) 
                                                             + (IData)(vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed))))))));
    vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029149_));
    vlSelf->wasmetal_core__DOT___053360_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053349_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053348_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053347_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccf0fc3fc00cfff7ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053343_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053345_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053344_)))))))));
    vlSelf->wasmetal_core__DOT___053481_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053477_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052994_)))))));
    vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031068_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031035_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___005659_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8dbe6334__0))));
    vlSelf->wasmetal_core__DOT___070044_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063450_))));
    vlSelf->wasmetal_core__DOT___056745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d))));
    vlSelf->__VdfgTmp_h6d3f2850__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004801_));
    vlSelf->__VdfgTmp_hf2656e40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h79a44c81__0)));
    vlSelf->wasmetal_core__DOT___056778_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d))));
    vlSelf->wasmetal_core__DOT___048860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h4f39dfcd__0 = (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d));
    vlSelf->__VdfgTmp_h3b966d55__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004943_));
    vlSelf->__VdfgTmp_hff1fe4fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h79b790c2__0)));
    vlSelf->wasmetal_core__DOT___057077_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d))));
    vlSelf->wasmetal_core__DOT___048685_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h957273a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d));
    vlSelf->__VdfgTmp_h8541949a__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005011_));
    vlSelf->__VdfgTmp_h815644ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5f30aa50__0)));
    vlSelf->wasmetal_core__DOT___057094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d))));
    vlSelf->wasmetal_core__DOT___048852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___054901_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004875_))))));
    vlSelf->__VdfgTmp_hbaaa25aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc83e3035__0));
    vlSelf->wasmetal_core__DOT___057243_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d))));
    vlSelf->wasmetal_core__DOT___048850_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___054951_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005283_))))));
    vlSelf->__VdfgTmp_hde99fb2e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4e776e09__0)));
    vlSelf->wasmetal_core__DOT___057442_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d))));
    vlSelf->wasmetal_core__DOT___048870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h39dd035b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d));
    vlSelf->__VdfgTmp_h46681fd6__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005215_));
    vlSelf->__VdfgTmp_hc08ecb6b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h77d6a635__0)));
    vlSelf->wasmetal_core__DOT___070033_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070029_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070028_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b97__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___005651_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09328eec__0))));
    vlSelf->wasmetal_core__DOT___011458_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))));
    vlSelf->wasmetal_core__DOT___054775_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003095_))))));
    vlSelf->__VdfgTmp_h898c2bb0__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5702c3be__0));
    vlSelf->wasmetal_core__DOT___005553_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha59547bb__0))));
    vlSelf->wasmetal_core__DOT___044039_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))));
    vlSelf->__VdfgTmp_h3a53928b__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d));
    vlSelf->wasmetal_core__DOT___054692_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hffad8cfa__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d))))));
    vlSelf->__VdfgTmp_hc1ba948d__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hffad8cfa__0));
    vlSelf->wasmetal_core__DOT___054691_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003091_))))));
    vlSelf->wasmetal_core__DOT___057539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d))));
    vlSelf->wasmetal_core__DOT___048923_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h67e9fb36__0 = (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d));
    vlSelf->wasmetal_core__DOT___055036_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005599_))))));
    vlSelf->__VdfgTmp_hd79df6c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h66a2df13__0)));
    vlSelf->wasmetal_core__DOT___052826_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052822_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004875_)))))))));
    vlSelf->wasmetal_core__DOT___048849_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_hb73e868c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d));
    vlSelf->__VdfgTmp_h5f6c8a95__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005265_));
    vlSelf->__VdfgTmp_h1ad74d3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h778ea1a1__0)));
    vlSelf->wasmetal_core__DOT___056777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d))));
    vlSelf->wasmetal_core__DOT___048859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h4403b5cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d));
    vlSelf->__VdfgTmp_ha84b0b95__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004925_));
    vlSelf->__VdfgTmp_hd9f044bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9c9d0618__0)));
    vlSelf->wasmetal_core__DOT___048684_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h2d637bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d));
    vlSelf->__VdfgTmp_h136edfac__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004993_));
    vlSelf->__VdfgTmp_hc530df9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h928bb96c__0)));
    vlSelf->wasmetal_core__DOT___057095_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d))));
    vlSelf->wasmetal_core__DOT___048851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h1bd58642__0 = (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d));
    vlSelf->wasmetal_core__DOT___054909_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004857_))))));
    vlSelf->__VdfgTmp_h0e7ef094__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf0d36e17__0)));
    vlSelf->wasmetal_core__DOT___056599_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d))));
    vlSelf->wasmetal_core__DOT___048841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h339d407e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d));
    vlSelf->__VdfgTmp_h10697dc9__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005333_));
    vlSelf->__VdfgTmp_h782800f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb476a254__0)));
    vlSelf->__VdfgTmp_hfd72e8ff__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003381_));
    vlSelf->__VdfgTmp_h707c99af__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha36008d9__0)));
    vlSelf->wasmetal_core__DOT___057449_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d))));
    vlSelf->wasmetal_core__DOT___054998_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003313_))))));
    vlSelf->__VdfgTmp_hef8f7e11__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hab2bfea3__0)));
    vlSelf->wasmetal_core__DOT___056336_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d))));
    vlSelf->wasmetal_core__DOT___048861_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_h8aa65d09__0 = (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d));
    vlSelf->wasmetal_core__DOT___054675_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h24206284__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d))))));
    vlSelf->__VdfgTmp_hf6ccaf8c__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h24206284__0));
    vlSelf->wasmetal_core__DOT___054674_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005061_))))));
    vlSelf->__VdfgTmp_hc2efa860__0 = (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d));
    vlSelf->__VdfgTmp_h5c8699d0__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005129_));
    vlSelf->__VdfgTmp_hdfae4d94__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb797e152__0)));
    vlSelf->wasmetal_core__DOT___005508_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcde84ebb__0))));
    vlSelf->wasmetal_core__DOT___056983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d))));
    vlSelf->wasmetal_core__DOT___054861_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003107_))))));
    vlSelf->__VdfgTmp_h79bfec12__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h1dfe6e3d__0)));
    vlSelf->wasmetal_core__DOT___005504_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h52266111__0))));
    vlSelf->wasmetal_core__DOT___056730_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d))));
    vlSelf->__VdfgTmp_h585a3ceb__0 = (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d));
    vlSelf->__VdfgTmp_h633a8051__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003105_));
    vlSelf->__VdfgTmp_h4f29d017__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h45475158__0)));
    vlSelf->wasmetal_core__DOT___005647_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7d4fca25__0))));
    vlSelf->wasmetal_core__DOT___056967_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d))));
    vlSelf->__VdfgTmp_h18ff28cf__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004727_));
    vlSelf->__VdfgTmp_hbf3b567a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h103d8e23__0)));
    vlSelf->wasmetal_core__DOT___005557_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d77f97__0))));
    vlSelf->wasmetal_core__DOT___057127_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d))));
    vlSelf->__VdfgTmp_h7cf17ecc__0 = (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d));
    vlSelf->__VdfgTmp_h51fc7bb2__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003097_));
    vlSelf->__VdfgTmp_h68d11ed0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hbbacc71f__0)));
    vlSelf->wasmetal_core__DOT___005541_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0176237__0))));
    vlSelf->wasmetal_core__DOT___057288_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))));
    vlSelf->wasmetal_core__DOT___054956_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003099_))))));
    vlSelf->__VdfgTmp_hb18976f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6b621180__0)));
    vlSelf->wasmetal_core__DOT___005549_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbacded4f__0))));
    vlSelf->wasmetal_core__DOT___057390_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d))));
    vlSelf->wasmetal_core__DOT___054995_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003101_))))));
    vlSelf->__VdfgTmp_hab3c597f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h880089dc__0)));
    vlSelf->wasmetal_core__DOT___005529_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff8a2099__0))));
    vlSelf->wasmetal_core__DOT___056623_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))));
    vlSelf->wasmetal_core__DOT___054778_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))))));
    vlSelf->__VdfgTmp_h5c5b87f4__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0));
    vlSelf->wasmetal_core__DOT___054777_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003111_))))));
    vlSelf->wasmetal_core__DOT___005533_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h601dd350__0))));
    vlSelf->wasmetal_core__DOT___070137_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052847_))));
    vlSelf->__VdfgTmp_he0c10a9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d));
    vlSelf->wasmetal_core__DOT___054689_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h350dca3c__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d))))));
    vlSelf->__VdfgTmp_he6e69fea__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h350dca3c__0));
    vlSelf->__VdfgTmp_h23f02d0a__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003109_));
    vlSelf->wasmetal_core__DOT___005565_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb7a72eea__0))));
    vlSelf->wasmetal_core__DOT___050407_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))))));
    vlSelf->wasmetal_core__DOT___057571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d))));
    vlSelf->wasmetal_core__DOT___055041_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003103_))))));
    vlSelf->__VdfgTmp_hde24342a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h903282ee__0)));
    vlSelf->wasmetal_core__DOT___056600_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d))));
    vlSelf->wasmetal_core__DOT___048842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_hb12ee9bf__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005351_));
    vlSelf->__VdfgTmp_heeb73844__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8511382f__0));
    vlSelf->wasmetal_core__DOT___056769_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d))));
    vlSelf->__VdfgTmp_ha2b26e01__0 = (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d));
    vlSelf->wasmetal_core__DOT___054809_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004043_))))));
    vlSelf->__VdfgTmp_hbb6385ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2e498b5e__0)));
    vlSelf->wasmetal_core__DOT___069736_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069732_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069731_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b83__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x11U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___057044_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d))));
    vlSelf->wasmetal_core__DOT___051498_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003827_))))));
    vlSelf->__VdfgTmp_h4f418a9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc135e20a__0)));
    vlSelf->wasmetal_core__DOT___057092_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d))));
    vlSelf->__VdfgTmp_h63a6348e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d));
    vlSelf->wasmetal_core__DOT___054900_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003919_))))));
    vlSelf->__VdfgTmp_h6277318a__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h74dbdf51__0));
    vlSelf->wasmetal_core__DOT___057247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d))));
    vlSelf->__VdfgTmp_h8ae31ec8__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d));
    vlSelf->__VdfgTmp_h9eae91ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d));
    vlSelf->__VdfgTmp_h52bd55da__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003399_));
    vlSelf->__VdfgTmp_ha4d9f57f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha6dc66a3__0)));
    vlSelf->wasmetal_core__DOT___057450_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d))));
    vlSelf->__VdfgTmp_h76527ded__0 = (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d));
    vlSelf->__VdfgTmp_h979ce723__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003331_));
    vlSelf->__VdfgTmp_haf65e04e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0f5e432a__0)));
    vlSelf->wasmetal_core__DOT___056598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d))));
    vlSelf->wasmetal_core__DOT___048757_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))));
    vlSelf->wasmetal_core__DOT___054769_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004265_))))));
    vlSelf->__VdfgTmp_h9fcdfa16__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he315da1d__0)));
    vlSelf->wasmetal_core__DOT___056335_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))));
    vlSelf->wasmetal_core__DOT___048862_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___054699_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h3ac48b87__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))))));
    vlSelf->__VdfgTmp_hd68176c7__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3ac48b87__0));
    vlSelf->wasmetal_core__DOT___054698_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005079_))))));
    vlSelf->wasmetal_core__DOT___069823_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b87__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x15U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___057536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d))));
    vlSelf->__VdfgTmp_h5fb0de62__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d));
    vlSelf->wasmetal_core__DOT___055035_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005147_))))));
    vlSelf->__VdfgTmp_h6ce01618__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h26cb2e9d__0)));
    vlSelf->wasmetal_core__DOT___052670_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052665_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052664_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005284_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005266_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___004892_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003416_)))))))));
    vlSelf->wasmetal_core__DOT___063766_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d)))))))));
    vlSelf->wasmetal_core__DOT___044035_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))))))));
    vlSelf->wasmetal_core__DOT___057205_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d))));
    vlSelf->wasmetal_core__DOT___054908_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003901_))))));
    vlSelf->__VdfgTmp_h2e164c3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h063ae0f2__0)));
    vlSelf->wasmetal_core__DOT___005517_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0adea875__0))));
    vlSelf->wasmetal_core__DOT___057129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d))));
    vlSelf->wasmetal_core__DOT___054907_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003117_))))));
    vlSelf->__VdfgTmp_h692f01d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc85d0f69__0)));
    vlSelf->wasmetal_core__DOT___005561_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79860539__0))));
    vlSelf->wasmetal_core__DOT___044033_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))))))));
    vlSelf->wasmetal_core__DOT___057289_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d))));
    vlSelf->__VdfgTmp_h98d262dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d));
    vlSelf->wasmetal_core__DOT___054957_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003119_))))));
    vlSelf->__VdfgTmp_hc03ee7e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9d0797f2__0)));
    vlSelf->wasmetal_core__DOT___005521_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5978f26f__0))));
    vlSelf->wasmetal_core__DOT___057384_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))));
    vlSelf->wasmetal_core__DOT___054996_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003121_))))));
    vlSelf->__VdfgTmp_h437f0271__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he9b54a3e__0)));
    vlSelf->wasmetal_core__DOT___005545_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31225405__0))));
    vlSelf->wasmetal_core__DOT___056768_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d))));
    vlSelf->__VdfgTmp_h22b2afd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d));
    vlSelf->__VdfgTmp_h1eef7f72__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004061_));
    vlSelf->__VdfgTmp_h13d4f79e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0fc0fcd7__0)));
    vlSelf->__VdfgTmp_ha720ddd6__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d));
    vlSelf->__VdfgTmp_hdb184deb__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003845_));
    vlSelf->__VdfgTmp_hb918ea35__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hbe45befc__0)));
    vlSelf->wasmetal_core__DOT___005537_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h177129ae__0))));
    vlSelf->wasmetal_core__DOT___056597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d))));
    vlSelf->wasmetal_core__DOT___054779_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003115_))))));
    vlSelf->__VdfgTmp_hd5b1a253__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbd0c1b7__0));
    vlSelf->wasmetal_core__DOT___005655_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h71a6f88b__0))));
    vlSelf->wasmetal_core__DOT___050416_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d))))));
    vlSelf->wasmetal_core__DOT___056501_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))));
    vlSelf->wasmetal_core__DOT___054683_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h154ca593__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))))));
    vlSelf->__VdfgTmp_h63aeb1f3__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h154ca593__0));
    vlSelf->__VdfgTmp_h73150903__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003113_));
    vlSelf->wasmetal_core__DOT___005525_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha13bce2f__0))));
    vlSelf->wasmetal_core__DOT___050408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))));
    vlSelf->wasmetal_core__DOT___057574_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d))));
    vlSelf->wasmetal_core__DOT___048729_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___047862_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d))))));
    vlSelf->wasmetal_core__DOT___055042_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003689_))))));
    vlSelf->__VdfgTmp_hb69256f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4b62075b__0)));
    vlSelf->wasmetal_core__DOT___052830_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004635_)))))))));
    vlSelf->wasmetal_core__DOT___052817_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052813_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003827_)))))))));
    vlSelf->wasmetal_core__DOT___056331_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))));
    vlSelf->wasmetal_core__DOT___048818_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))));
    vlSelf->wasmetal_core__DOT___054702_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf3cb0d91__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))))));
    vlSelf->__VdfgTmp_h88a0444f__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf3cb0d91__0));
    vlSelf->__VdfgTmp_h691e257b__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003969_));
    vlSelf->wasmetal_core__DOT___056731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d))));
    vlSelf->wasmetal_core__DOT___048780_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))));
    vlSelf->wasmetal_core__DOT___054808_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003449_))))));
    vlSelf->__VdfgTmp_hbb98e230__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfd746550__0)));
    vlSelf->wasmetal_core__DOT___056984_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d))));
    vlSelf->wasmetal_core__DOT___048773_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))));
    vlSelf->wasmetal_core__DOT___051491_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003523_))))));
    vlSelf->__VdfgTmp_h86c1a93d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h1b5c1c30__0)));
    vlSelf->wasmetal_core__DOT___057130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d))));
    vlSelf->__VdfgTmp_hb14b0648__0 = (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d));
    vlSelf->__VdfgTmp_ha853ba7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004117_));
    vlSelf->__VdfgTmp_h5d9bd5b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc2378e95__0)));
    vlSelf->wasmetal_core__DOT___057290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d))));
    vlSelf->__VdfgTmp_h491e13b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d));
    vlSelf->wasmetal_core__DOT___054949_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004191_))))));
    vlSelf->__VdfgTmp_hdc49a285__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3e014765__0)));
    vlSelf->wasmetal_core__DOT___057385_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d))));
    vlSelf->wasmetal_core__DOT___048823_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))));
    vlSelf->__VdfgTmp_hf41e7ecd__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004635_));
    vlSelf->__VdfgTmp_h84d68e3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb797ade1__0)));
    vlSelf->wasmetal_core__DOT___056622_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d))));
    vlSelf->wasmetal_core__DOT___048765_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))));
    vlSelf->wasmetal_core__DOT___054768_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003597_))))));
    vlSelf->__VdfgTmp_h7751d301__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc0be46f7__0)));
    vlSelf->wasmetal_core__DOT___056371_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))));
    vlSelf->__VdfgTmp_h3fcac4a1__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d));
    vlSelf->__VdfgTmp_h2112a96a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d));
    vlSelf->wasmetal_core__DOT___054706_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h477043a8__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))))));
    vlSelf->__VdfgTmp_h7c46a142__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h477043a8__0));
    vlSelf->__VdfgTmp_hf440d852__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003745_));
    vlSelf->wasmetal_core__DOT___057573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d))));
    vlSelf->wasmetal_core__DOT___048730_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___048731_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))));
    vlSelf->wasmetal_core__DOT___055034_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003671_))))));
    vlSelf->__VdfgTmp_hb4659c85__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5f949c7c__0)));
    vlSelf->wasmetal_core__DOT___052671_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003151_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004744_)))))))));
    vlSelf->wasmetal_core__DOT___052810_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003901_)))))))));
    vlSelf->wasmetal_core__DOT___050354_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050349_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050348_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___004358_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004340_)))))));
    vlSelf->wasmetal_core__DOT___057572_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))));
    vlSelf->wasmetal_core__DOT___048750_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d)))));
    vlSelf->__VdfgTmp_hc9d89c9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004561_));
    vlSelf->__VdfgTmp_h7a210d44__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hce00e764__0)));
    vlSelf->wasmetal_core__DOT___056746_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d))));
    vlSelf->__VdfgTmp_h51befd44__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004783_));
    vlSelf->__VdfgTmp_h8916279c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5877aba2__0)));
    vlSelf->wasmetal_core__DOT___056968_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d))));
    vlSelf->wasmetal_core__DOT___051493_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004709_))))));
    vlSelf->__VdfgTmp_hce0059e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hdb8b9d9d__0)));
    vlSelf->wasmetal_core__DOT___057128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))));
    vlSelf->__VdfgTmp_had719570__0 = (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d));
    vlSelf->__VdfgTmp_heb8a147e__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004487_));
    vlSelf->__VdfgTmp_h3d3eaa9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9699bb18__0)));
    vlSelf->wasmetal_core__DOT___057286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d))));
    vlSelf->__VdfgTmp_h3ce0f075__0 = (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d));
    vlSelf->wasmetal_core__DOT___054948_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004339_))))));
    vlSelf->__VdfgTmp_h5f14afc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h1d34c5b9__0)));
    vlSelf->wasmetal_core__DOT___057391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d))));
    vlSelf->wasmetal_core__DOT___048890_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))));
    vlSelf->wasmetal_core__DOT___054987_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004413_))))));
    vlSelf->__VdfgTmp_h9ebbc558__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h92dd6962__0)));
    vlSelf->wasmetal_core__DOT___011459_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d))));
    vlSelf->wasmetal_core__DOT___048805_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))));
    vlSelf->wasmetal_core__DOT___054767_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003233_))))));
    vlSelf->__VdfgTmp_h890db370__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5b4e7e80__0)));
    vlSelf->wasmetal_core__DOT___003134_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048022_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048023_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha59547bb__0))))))));
    vlSelf->type_actual = (((0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                   << 1U) 
                                                  | (vlSelf->function_type 
                                                     >> 0x1fU)))) 
                            << 0x1fU) | ((0x40000000U 
                                          & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (vlSelf->function_type 
                                                           >> 0x1eU))))) 
                                             << 0x1eU)) 
                                         | ((0x20000000U 
                                             & ((0xacU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (vlSelf->function_type 
                                                           >> 0x1dU))))) 
                                                << 0x1dU)) 
                                            | ((0x10000000U 
                                                & ((0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (vlSelf->function_type 
                                                              >> 0x1cU))))) 
                                                   << 0x1cU)) 
                                               | ((0x8000000U 
                                                   & ((0xacU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (vlSelf->function_type 
                                                                 >> 0x1bU))))) 
                                                      << 0x1bU)) 
                                                  | ((0x4000000U 
                                                      & ((0xacU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->function_type 
                                                                    >> 0x1aU))))) 
                                                         << 0x1aU)) 
                                                     | ((0x2000000U 
                                                         & ((0xacU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & (vlSelf->function_type 
                                                                       >> 0x19U))))) 
                                                            << 0x19U)) 
                                                        | ((0x1000000U 
                                                            & ((0xacU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (vlSelf->function_type 
                                                                          >> 0x18U))))) 
                                                               << 0x18U)) 
                                                           | ((0x800000U 
                                                               & ((0xacU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->function_type 
                                                                             >> 0x17U))))) 
                                                                  << 0x17U)) 
                                                              | ((0x400000U 
                                                                  & ((0xacU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (vlSelf->function_type 
                                                                                >> 0x16U))))) 
                                                                     << 0x16U)) 
                                                                 | ((0x200000U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x15U))))) 
                                                                        << 0x15U)) 
                                                                    | ((0x100000U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x14U))))) 
                                                                           << 0x14U)) 
                                                                       | ((0x80000U 
                                                                           & ((0xacU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x13U))))) 
                                                                              << 0x13U)) 
                                                                          | ((0x40000U 
                                                                              & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x12U))))) 
                                                                                << 0x12U)) 
                                                                             | ((0x20000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x11U))))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x10U))))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xfU))))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xeU))))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xdU))))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xcU))))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xbU))))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xaU))))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 9U))))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 8U))))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 7U))))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 6U))))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 5U))))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 4U))))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 3U))))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 2U))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & vlSelf->function_type))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050409_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))));
    vlSelf->wasmetal_core__DOT___056382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))));
    vlSelf->__VdfgTmp_h33bf650d__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d));
    vlSelf->__VdfgTmp_h2a4ee2b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d));
    vlSelf->wasmetal_core__DOT___054709_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd0bdda62__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))))));
    vlSelf->__VdfgTmp_h1ccba379__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd0bdda62__0));
    vlSelf->wasmetal_core__DOT___054708_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003150_))))));
    vlSelf->wasmetal_core__DOT___052266_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052193_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052192_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052191_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052190_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h14b4bf2b__0))))))));
    vlSelf->wasmetal_core__DOT___034507_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->wasmetal_core__DOT___026722_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005636_))));
    vlSelf->wasmetal_core__DOT___027192_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026992_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054247_))));
    vlSelf->wasmetal_core__DOT___010568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->__VdfgTmp_hdb4c449f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001330_));
    vlSelf->wasmetal_core__DOT___007419_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h965c3061__0))))))));
    vlSelf->__VdfgTmp_h8696f73b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d));
    vlSelf->wasmetal_core__DOT___051954_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051953_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051952_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051951_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003332_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003314_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004062_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004044_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005028_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005380_)))))))));
    vlSelf->wasmetal_core__DOT___057443_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d))));
    vlSelf->wasmetal_core__DOT___048869_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_hb1867682__0 = (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d));
    vlSelf->__VdfgTmp_hf9b00456__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005197_));
    vlSelf->__VdfgTmp_h83a675b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha95ffc90__0)));
    vlSelf->__VdfgTmp_he9d835d5__0 = ((2U & ((0xe0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047990_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047989_)))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb85239a7__0)))));
    vlSelf->wasmetal_core__DOT___044036_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___048922_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___055046_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005581_))))));
    vlSelf->__VdfgTmp_h0919a607__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hbd4ae96e__0)));
    vlSelf->__VdfgTmp_hd81cbf50__0 = (((IData)(vlSelf->wasmetal_core__DOT___005455_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005454_));
    vlSelf->wasmetal_core__DOT___034506_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001168_))));
    vlSelf->wasmetal_core__DOT___026721_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001168_))));
    vlSelf->wasmetal_core__DOT___026856_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001168_))));
    vlSelf->wasmetal_core__DOT___027191_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026991_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054245_))));
    vlSelf->wasmetal_core__DOT___010559_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001168_))));
    vlSelf->wasmetal_core__DOT___007392_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf266c674__0))))))));
    vlSelf->__VdfgTmp_h46733dea__0 = (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001169_));
    vlSelf->__VdfgTmp_h65f01eca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005418_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005417_));
    vlSelf->wasmetal_core__DOT___069144_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007031_)))));
    vlSelf->wasmetal_core__DOT___044330_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haaf717df__0))))))));
    vlSelf->wasmetal_core__DOT___034505_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001146_))));
    vlSelf->wasmetal_core__DOT___026720_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001146_))));
    vlSelf->wasmetal_core__DOT___026855_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001146_))));
    vlSelf->wasmetal_core__DOT___027190_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026990_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054243_))));
    vlSelf->wasmetal_core__DOT___010552_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001146_))));
    vlSelf->wasmetal_core__DOT___007366_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h26fdb0d9__0))))))));
    vlSelf->__VdfgTmp_h3493c9ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001147_));
    vlSelf->__VdfgTmp_hb5adad38__0 = (((IData)(vlSelf->wasmetal_core__DOT___005408_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005407_));
    vlSelf->wasmetal_core__DOT___069095_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007031_)))));
    vlSelf->wasmetal_core__DOT___034504_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001124_))));
    vlSelf->wasmetal_core__DOT___026719_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001124_))));
    vlSelf->wasmetal_core__DOT___026854_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001124_))));
    vlSelf->wasmetal_core__DOT___027189_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026989_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054241_))));
    vlSelf->wasmetal_core__DOT___010546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001124_))));
    vlSelf->__VdfgTmp_hd0975535__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc23ff14f__0)));
    vlSelf->__VdfgTmp_hd25ddcc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001125_));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___048208_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b59__05d)));
        vlSelf->wasmetal_core__DOT___005428_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b57__05d)));
        vlSelf->wasmetal_core__DOT___005427_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b56__05d)));
        vlSelf->wasmetal_core__DOT___048148_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b55__05d)));
    } else if (vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) {
        vlSelf->wasmetal_core__DOT___048208_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005400_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005399_)))));
        vlSelf->wasmetal_core__DOT___005428_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005447_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005446_)))));
        vlSelf->wasmetal_core__DOT___005427_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005437_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005436_)))));
        vlSelf->wasmetal_core__DOT___048148_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005497_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005496_)))));
    } else {
        vlSelf->wasmetal_core__DOT___048208_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9462500e__0))));
        vlSelf->wasmetal_core__DOT___005428_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcea60642__0))));
        vlSelf->wasmetal_core__DOT___005427_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc3acb233__0))));
        vlSelf->wasmetal_core__DOT___048148_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he5858a3c__0))));
    }
    vlSelf->__VdfgTmp_h7b89d77c__0 = (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001102_));
    vlSelf->wasmetal_core__DOT___034503_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001102_))));
    vlSelf->wasmetal_core__DOT___050415_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d)))))))));
    vlSelf->wasmetal_core__DOT___026717_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001102_))));
    vlSelf->wasmetal_core__DOT___026852_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001102_))));
    vlSelf->wasmetal_core__DOT___027187_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026987_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054239_))));
    vlSelf->wasmetal_core__DOT___010584_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001102_))));
    vlSelf->wasmetal_core__DOT___007307_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he56eea3a__0))))))));
    vlSelf->__VdfgTmp_ha7b9d4b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001103_));
    vlSelf->__VdfgTmp_h5dfa9ecf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005387_));
    vlSelf->wasmetal_core__DOT___044329_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7fbee1d__0))))))));
    vlSelf->wasmetal_core__DOT___034502_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))));
    vlSelf->wasmetal_core__DOT___026716_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))));
    vlSelf->wasmetal_core__DOT___026851_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))));
    vlSelf->wasmetal_core__DOT___027186_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026986_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054237_))));
    vlSelf->wasmetal_core__DOT___010590_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))));
    vlSelf->wasmetal_core__DOT___007280_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99cf87be__0))))))));
    vlSelf->__VdfgTmp_h56116db4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001081_));
    vlSelf->wasmetal_core__DOT___034501_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))));
    vlSelf->wasmetal_core__DOT___026715_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))));
    vlSelf->wasmetal_core__DOT___026850_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))));
    vlSelf->wasmetal_core__DOT___027185_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026985_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054235_))));
    vlSelf->wasmetal_core__DOT___056327_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))));
    vlSelf->wasmetal_core__DOT___007253_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbd712dd8__0))))))));
    vlSelf->__VdfgTmp_hf21aaa1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001059_));
    vlSelf->wasmetal_core__DOT___068911_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068890_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x200f3ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068883_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068882_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064358_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->__VdfgTmp_h59235eaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001036_));
    vlSelf->wasmetal_core__DOT___034500_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))));
    vlSelf->wasmetal_core__DOT___026714_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))));
    vlSelf->wasmetal_core__DOT___026849_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))));
    vlSelf->wasmetal_core__DOT___027184_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026984_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054233_))));
    vlSelf->wasmetal_core__DOT___056326_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))));
    vlSelf->__VdfgTmp_hce5bccc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd5ee5b41__0)));
    vlSelf->__VdfgTmp_h139d3776__0 = (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001037_));
    vlSelf->wasmetal_core__DOT___068864_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068843_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068842_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068834_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000fcffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065478_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h14cfefd1__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___044327_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc7c7ad9a__0))))))));
    vlSelf->wasmetal_core__DOT___052780_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x4000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005617_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052768_)))))))));
    vlSelf->wasmetal_core__DOT___034499_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))));
    vlSelf->wasmetal_core__DOT___026713_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))));
    vlSelf->wasmetal_core__DOT___026848_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))));
    vlSelf->wasmetal_core__DOT___027183_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026983_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054231_))));
    vlSelf->wasmetal_core__DOT___010529_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))));
    vlSelf->wasmetal_core__DOT___007420_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha04b46b6__0))))))));
    vlSelf->__VdfgTmp_h3378cabf__0 = (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001015_));
    vlSelf->__VdfgTmp_hd852066e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005484_));
    vlSelf->wasmetal_core__DOT___034498_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000992_))));
    vlSelf->wasmetal_core__DOT___026712_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003360_))));
    vlSelf->wasmetal_core__DOT___027182_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026982_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054229_))));
    vlSelf->wasmetal_core__DOT___010528_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000992_))));
    vlSelf->__VdfgTmp_ha541df85__0 = (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000993_));
    vlSelf->wasmetal_core__DOT___007393_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h59798d13__0))))))));
    vlSelf->__VdfgTmp_h8df5578a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000992_));
    vlSelf->wasmetal_core__DOT___068762_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068734_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80b000fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066746_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065216_)))))))))))))));
    vlSelf->__VdfgTmp_h5779821b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005475_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005474_));
    vlSelf->__VdfgTmp_h388edf60__0 = (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000992_));
    vlSelf->wasmetal_core__DOT___034497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000980_))));
    vlSelf->wasmetal_core__DOT___050419_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))))));
    vlSelf->wasmetal_core__DOT___026711_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003428_))));
    vlSelf->wasmetal_core__DOT___027181_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026981_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054227_))));
    vlSelf->wasmetal_core__DOT___056324_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000980_))));
    vlSelf->__VdfgTmp_heb331328__0 = (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000981_));
    vlSelf->wasmetal_core__DOT___007367_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4b249985__0))))))));
    vlSelf->__VdfgTmp_h87d91e6a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000980_));
    vlSelf->__VdfgTmp_h63c99640__0 = (((IData)(vlSelf->wasmetal_core__DOT___005465_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005464_));
    vlSelf->wasmetal_core__DOT___044326_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h351f56c5__0))))))));
    vlSelf->wasmetal_core__DOT___034496_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001327_))));
    vlSelf->wasmetal_core__DOT___026710_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003948_))));
    vlSelf->wasmetal_core__DOT___027180_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026980_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054225_))));
    vlSelf->wasmetal_core__DOT___010533_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001327_))));
    vlSelf->__VdfgTmp_hc67fdbf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000926_));
    vlSelf->__VdfgTmp_h2cdc7e5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5d0edfe8__0)));
    vlSelf->__VdfgTmp_h94ceffb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001327_));
    vlSelf->wasmetal_core__DOT___068646_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068642_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054223_)))))));
    vlSelf->__VdfgTmp_hde5a6edf__0 = ((2U & ((0xe0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h70d2167a__0))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h64e10f56__0)))));
    vlSelf->wasmetal_core__DOT___034495_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))));
    vlSelf->wasmetal_core__DOT___050429_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))))));
    vlSelf->wasmetal_core__DOT___026709_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003876_))));
    vlSelf->wasmetal_core__DOT___027179_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026979_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054223_))));
    vlSelf->wasmetal_core__DOT___010538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))));
    vlSelf->wasmetal_core__DOT___048902_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))))));
    vlSelf->__VdfgTmp_hbf523586__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000927_));
    vlSelf->wasmetal_core__DOT___007308_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf825dcba__0))))))));
    vlSelf->__VdfgTmp_hf33edb7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT___048903_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___068616_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068595_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054221_)))))))));
    vlSelf->wasmetal_core__DOT___005546_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf93df92c__0))));
    vlSelf->wasmetal_core__DOT___034494_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))));
    vlSelf->wasmetal_core__DOT___026708_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004092_))));
    vlSelf->wasmetal_core__DOT___027178_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026978_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054221_))));
    vlSelf->wasmetal_core__DOT___010537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))));
    vlSelf->wasmetal_core__DOT___048919_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))))));
    vlSelf->__VdfgTmp_h379ad787__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000897_));
    vlSelf->wasmetal_core__DOT___007281_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd7f74d59__0))))))));
    vlSelf->__VdfgTmp_hb40a316f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___048920_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___068567_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068545_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068544_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))))));
    vlSelf->wasmetal_core__DOT___005538_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a9c07e1__0))));
    vlSelf->wasmetal_core__DOT___044325_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed1a6099__0))))))));
    vlSelf->wasmetal_core__DOT___034493_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___026706_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004314_))));
    vlSelf->wasmetal_core__DOT___027176_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026976_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054219_))));
    if (vlSelf->wasmetal_core__DOT___000418_) {
        vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d 
            = vlSelf->wasmetal_core__DOT___001169_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d 
            = vlSelf->wasmetal_core__DOT___001147_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d 
            = vlSelf->wasmetal_core__DOT___001125_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d 
            = vlSelf->wasmetal_core__DOT___001103_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d 
            = vlSelf->wasmetal_core__DOT___001081_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d 
            = vlSelf->wasmetal_core__DOT___001059_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d 
            = vlSelf->wasmetal_core__DOT___001037_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d 
            = vlSelf->wasmetal_core__DOT___001015_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d 
            = vlSelf->wasmetal_core__DOT___000993_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d 
            = vlSelf->wasmetal_core__DOT___000981_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d 
            = vlSelf->wasmetal_core__DOT___000926_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d 
            = vlSelf->wasmetal_core__DOT___000658_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d 
            = vlSelf->wasmetal_core__DOT___000636_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d 
            = vlSelf->wasmetal_core__DOT___000614_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d 
            = vlSelf->wasmetal_core__DOT___000592_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d 
            = vlSelf->wasmetal_core__DOT___000565_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d 
            = vlSelf->wasmetal_core__DOT___000543_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d 
            = vlSelf->wasmetal_core__DOT___000521_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d 
            = vlSelf->wasmetal_core__DOT___000499_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d 
            = vlSelf->wasmetal_core__DOT___000477_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d 
            = vlSelf->wasmetal_core__DOT___000465_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d 
            = vlSelf->wasmetal_core__DOT___000433_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d 
            = vlSelf->wasmetal_core__DOT___000420_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d 
            = vlSelf->wasmetal_core__DOT___001647_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d 
            = vlSelf->wasmetal_core__DOT___001625_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d 
            = vlSelf->wasmetal_core__DOT___001613_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d 
            = vlSelf->wasmetal_core__DOT___001581_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d 
            = vlSelf->wasmetal_core__DOT___001569_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d 
            = vlSelf->wasmetal_core__DOT___001537_;
    } else {
        vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d 
            = vlSelf->wasmetal_core__DOT___001168_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d 
            = vlSelf->wasmetal_core__DOT___001146_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d 
            = vlSelf->wasmetal_core__DOT___001124_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d 
            = vlSelf->wasmetal_core__DOT___001102_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d 
            = vlSelf->wasmetal_core__DOT___001080_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d 
            = vlSelf->wasmetal_core__DOT___001058_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d 
            = vlSelf->wasmetal_core__DOT___001036_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d 
            = vlSelf->wasmetal_core__DOT___001014_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d 
            = vlSelf->wasmetal_core__DOT___000992_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d 
            = vlSelf->wasmetal_core__DOT___000980_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d 
            = vlSelf->wasmetal_core__DOT___001327_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d 
            = vlSelf->wasmetal_core__DOT___000657_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d 
            = vlSelf->wasmetal_core__DOT___000635_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d 
            = vlSelf->wasmetal_core__DOT___000613_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d 
            = vlSelf->wasmetal_core__DOT___000591_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d 
            = vlSelf->wasmetal_core__DOT___000564_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d 
            = vlSelf->wasmetal_core__DOT___000542_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d 
            = vlSelf->wasmetal_core__DOT___000520_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d 
            = vlSelf->wasmetal_core__DOT___000498_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d 
            = vlSelf->wasmetal_core__DOT___000476_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d 
            = vlSelf->wasmetal_core__DOT___000464_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d 
            = vlSelf->wasmetal_core__DOT___000432_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d 
            = vlSelf->wasmetal_core__DOT___000419_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d 
            = vlSelf->wasmetal_core__DOT___001646_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d 
            = vlSelf->wasmetal_core__DOT___001624_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d 
            = vlSelf->wasmetal_core__DOT___001612_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d 
            = vlSelf->wasmetal_core__DOT___001580_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d 
            = vlSelf->wasmetal_core__DOT___001568_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d 
            = vlSelf->wasmetal_core__DOT___001536_;
    }
    vlSelf->wasmetal_core__DOT___010540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___048921_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))))));
    vlSelf->__VdfgTmp_h375e931a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000896_));
    vlSelf->wasmetal_core__DOT___007254_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hef5b3f20__0))))))));
    vlSelf->__VdfgTmp_h461c5ceb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT___068513_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054217_)))))));
    vlSelf->wasmetal_core__DOT___005656_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9ea03dd__0))));
    vlSelf->wasmetal_core__DOT___034492_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))));
    vlSelf->wasmetal_core__DOT___026705_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004018_))));
    vlSelf->wasmetal_core__DOT___027175_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026975_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054217_))));
    vlSelf->wasmetal_core__DOT___056325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))));
    vlSelf->wasmetal_core__DOT___048918_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))))));
    vlSelf->__VdfgTmp_hd06fbc0c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000873_));
    vlSelf->__VdfgTmp_h38ad22b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfec86816__0)));
    vlSelf->__VdfgTmp_h38e0bed2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    vlSelf->wasmetal_core__DOT___068471_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068467_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068466_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054215_)))))))));
    vlSelf->wasmetal_core__DOT___005526_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33498483__0))));
    vlSelf->wasmetal_core__DOT___034491_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))));
    vlSelf->wasmetal_core__DOT___050412_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))))))));
    vlSelf->wasmetal_core__DOT___026704_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003720_))));
    vlSelf->wasmetal_core__DOT___027174_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026974_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054215_))));
    vlSelf->wasmetal_core__DOT___010749_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))));
    vlSelf->wasmetal_core__DOT___048898_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))))));
    vlSelf->__VdfgTmp_h2b7d2fec__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000872_));
    vlSelf->wasmetal_core__DOT___007417_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h97b1be8c__0))))))));
    vlSelf->__VdfgTmp_hac359f24__0 = (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    vlSelf->wasmetal_core__DOT___068394_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068391_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))));
    vlSelf->wasmetal_core__DOT___005522_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd8e6335__0))));
    vlSelf->wasmetal_core__DOT___044324_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h79eb8028__0))))))));
    vlSelf->wasmetal_core__DOT___034490_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___026703_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004684_))));
    vlSelf->wasmetal_core__DOT___027173_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026973_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054213_))));
    vlSelf->wasmetal_core__DOT___010755_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___048901_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))))));
    vlSelf->__VdfgTmp_hb948b455__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000849_));
    vlSelf->wasmetal_core__DOT___007390_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2cbbdbef__0))))))));
    vlSelf->__VdfgTmp_h132c3402__0 = (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    vlSelf->wasmetal_core__DOT___068335_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068333_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___005562_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0dacca2__0))));
    vlSelf->wasmetal_core__DOT___034489_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___026702_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004240_))));
    vlSelf->wasmetal_core__DOT___027172_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026972_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054211_))));
    vlSelf->wasmetal_core__DOT___010741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___048904_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))))));
    vlSelf->__VdfgTmp_h5dede88d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000848_));
    vlSelf->wasmetal_core__DOT___007364_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1fd76cb3__0))))))));
    vlSelf->__VdfgTmp_h82148a8f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT___068283_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068281_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068280_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___005518_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2566b586__0))));
    vlSelf->wasmetal_core__DOT___034488_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___026701_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004166_))));
    vlSelf->wasmetal_core__DOT___027171_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026971_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054209_))));
    vlSelf->wasmetal_core__DOT___010735_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___048899_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))))));
    vlSelf->__VdfgTmp_h8c7509c5__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000824_));
    vlSelf->__VdfgTmp_h7678d7b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h598b279f__0)));
    vlSelf->__VdfgTmp_h33528dbb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->wasmetal_core__DOT___048900_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___068232_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068228_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))))));
    vlSelf->wasmetal_core__DOT___005509_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5a2b04d__0))));
    vlSelf->wasmetal_core__DOT___044323_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179c0c32__0))))))));
    vlSelf->wasmetal_core__DOT___034487_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___026700_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003572_))));
    vlSelf->wasmetal_core__DOT___027170_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026970_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054207_))));
    vlSelf->wasmetal_core__DOT___010767_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___048894_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))))));
    vlSelf->__VdfgTmp_hc65b9dd7__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000825_));
    vlSelf->wasmetal_core__DOT___007305_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d1b60d2__0))))))));
    vlSelf->__VdfgTmp_h9319fdaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT___068198_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068195_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054205_)))))));
    vlSelf->wasmetal_core__DOT___005505_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7f6ab5bd__0))));
    vlSelf->wasmetal_core__DOT___034486_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___026699_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003498_))));
    vlSelf->wasmetal_core__DOT___027169_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026969_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054205_))));
    vlSelf->wasmetal_core__DOT___010761_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___048897_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)))))));
    vlSelf->__VdfgTmp_h483290db__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000796_));
    vlSelf->wasmetal_core__DOT___007278_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h38fb75d8__0))))))));
    vlSelf->__VdfgTmp_h17bd1a59__0 = (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    vlSelf->wasmetal_core__DOT___068147_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068142_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068141_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054203_)))))))));
    vlSelf->wasmetal_core__DOT___005530_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2712d491__0))));
    vlSelf->wasmetal_core__DOT___034485_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___026698_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003646_))));
    vlSelf->wasmetal_core__DOT___027168_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026968_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054203_))));
    vlSelf->wasmetal_core__DOT___010773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___048895_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))))));
    vlSelf->__VdfgTmp_h268e4ef9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000795_));
    vlSelf->wasmetal_core__DOT___007251_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe166c9c__0))))))));
    vlSelf->__VdfgTmp_h9963adf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    vlSelf->wasmetal_core__DOT___005534_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f983ac6__0))));
    vlSelf->wasmetal_core__DOT___044322_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df568d0__0))))))));
    vlSelf->wasmetal_core__DOT___034484_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))));
    vlSelf->wasmetal_core__DOT___026697_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003794_))));
    vlSelf->wasmetal_core__DOT___027167_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026967_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054201_))));
    vlSelf->wasmetal_core__DOT___056367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))));
    vlSelf->wasmetal_core__DOT___048896_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))))));
    vlSelf->__VdfgTmp_he040c9e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000772_));
    vlSelf->__VdfgTmp_h81bae7c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0ee6a0be__0)));
    vlSelf->__VdfgTmp_hc231438f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___068017_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068013_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068012_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054199_)))))))));
    vlSelf->wasmetal_core__DOT___005566_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h158a449d__0))));
    vlSelf->wasmetal_core__DOT___050414_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___034483_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))));
    vlSelf->wasmetal_core__DOT___026695_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004610_))));
    vlSelf->wasmetal_core__DOT___027165_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026965_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054199_))));
    vlSelf->wasmetal_core__DOT___010874_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))));
    vlSelf->wasmetal_core__DOT___048905_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))))));
    vlSelf->__VdfgTmp_h877e6c65__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000771_));
    vlSelf->wasmetal_core__DOT___007418_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94bf9d34__0))))))));
    vlSelf->__VdfgTmp_h0e28c49d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___067959_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067952_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054197_)))))));
    vlSelf->wasmetal_core__DOT___005550_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2937d10d__0))));
    vlSelf->wasmetal_core__DOT___050428_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))))))));
    vlSelf->wasmetal_core__DOT___034482_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))));
    vlSelf->wasmetal_core__DOT___026694_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004462_))));
    vlSelf->wasmetal_core__DOT___027164_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026964_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054197_))));
    vlSelf->wasmetal_core__DOT___010868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))));
    vlSelf->wasmetal_core__DOT___048912_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))))));
    vlSelf->__VdfgTmp_h218f194f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000747_));
    vlSelf->wasmetal_core__DOT___007391_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h58f52bdc__0))))))));
    vlSelf->__VdfgTmp_hde05f3fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___067894_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067890_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067889_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))))));
    vlSelf->wasmetal_core__DOT___005542_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7dc0a46__0))));
    vlSelf->wasmetal_core__DOT___044321_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e211f59__0))))))));
    vlSelf->wasmetal_core__DOT___050420_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT___034481_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___026693_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004388_))));
    vlSelf->wasmetal_core__DOT___027163_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026963_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054195_))));
    vlSelf->wasmetal_core__DOT___010860_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___048907_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))))));
    vlSelf->__VdfgTmp_hd87e5f33__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000748_));
    vlSelf->wasmetal_core__DOT___007365_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcf95a844__0))))))));
    vlSelf->__VdfgTmp_h866cdbfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT___067860_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054193_)))))))));
    vlSelf->wasmetal_core__DOT___005558_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e7f092f__0))));
    vlSelf->wasmetal_core__DOT___034480_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))));
    vlSelf->wasmetal_core__DOT___026692_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004536_))));
    vlSelf->wasmetal_core__DOT___027162_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026962_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054193_))));
    vlSelf->wasmetal_core__DOT___010854_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))));
    vlSelf->wasmetal_core__DOT___048906_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))))));
    vlSelf->__VdfgTmp_h45ac64ad__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000723_));
    vlSelf->wasmetal_core__DOT___007339_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h20a4ea67__0))))))));
    vlSelf->__VdfgTmp_hcfe971ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___067806_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054191_)))))))));
    vlSelf->wasmetal_core__DOT___005648_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd1b03413__0))));
    vlSelf->wasmetal_core__DOT___034479_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))));
    vlSelf->wasmetal_core__DOT___026691_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004758_))));
    vlSelf->wasmetal_core__DOT___027161_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026961_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054191_))));
    vlSelf->wasmetal_core__DOT___010886_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))));
    vlSelf->wasmetal_core__DOT___048913_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)))))));
    vlSelf->__VdfgTmp_hb0eafd09__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000724_));
    vlSelf->wasmetal_core__DOT___007306_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf98ad324__0))))))));
    vlSelf->__VdfgTmp_hf8cdee79__0 = (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___048914_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___005660_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h59e987ab__0))));
    vlSelf->wasmetal_core__DOT___044320_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c632a11__0))))))));
    vlSelf->wasmetal_core__DOT___034478_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))));
    vlSelf->wasmetal_core__DOT___026690_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004832_))));
    vlSelf->wasmetal_core__DOT___027160_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026960_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054189_))));
    vlSelf->wasmetal_core__DOT___010880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))));
    vlSelf->wasmetal_core__DOT___048916_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))))));
    vlSelf->__VdfgTmp_h9dd568d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000694_));
    vlSelf->wasmetal_core__DOT___007279_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84433958__0))))))));
    vlSelf->__VdfgTmp_he7d3ff65__0 = (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    vlSelf->wasmetal_core__DOT___048917_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___067656_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067652_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067651_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___005652_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf92587e4__0))));
    vlSelf->wasmetal_core__DOT___034477_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))));
    vlSelf->wasmetal_core__DOT___026689_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003288_))));
    vlSelf->wasmetal_core__DOT___027159_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026959_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054186_))));
    vlSelf->wasmetal_core__DOT___010892_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))));
    vlSelf->__VdfgTmp_h4bc445dd__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000693_));
    vlSelf->wasmetal_core__DOT___007252_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2ae5a25__0))))))));
    vlSelf->__VdfgTmp_hd40e4c18__0 = (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    vlSelf->wasmetal_core__DOT___052574_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052452_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052451_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052450_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h23d702b8__0))))))));
    vlSelf->wasmetal_core__DOT___067590_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067586_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054182_)))))));
    vlSelf->wasmetal_core__DOT___005554_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8427a44__0))));
    vlSelf->wasmetal_core__DOT___063789_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[0U] 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___034476_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))));
    vlSelf->wasmetal_core__DOT___026688_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003208_))));
    vlSelf->wasmetal_core__DOT___027158_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026958_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054182_))));
    vlSelf->wasmetal_core__DOT___056381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))));
    vlSelf->__VdfgTmp_h80fb591c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000665_));
    vlSelf->wasmetal_core__DOT___007432_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4bbfe337__0))))))));
    vlSelf->__VdfgTmp_h9a79492f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d));
    vlSelf->wasmetal_core__DOT___067538_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067537_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___005572_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048003_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048007_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048006_)))))))));
    vlSelf->__VdfgTmp_h92d236ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047989_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047990_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048004_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048003_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048007_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048006_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb85239a7__0))))))))));
    vlSelf->wasmetal_core__DOT___054541_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))));
    vlSelf->wasmetal_core__DOT___044319_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h561bfeb8__0))))))));
    vlSelf->__VdfgTmp_h946ed16f__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x1eU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT___028765_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052235_))));
    vlSelf->wasmetal_core__DOT___053923_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                       << 1U) 
                                                      | (vlSelf->insn_y 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___026687_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->wasmetal_core__DOT___027157_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d))));
    vlSelf->wasmetal_core__DOT___026957_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054178_))));
    vlSelf->wasmetal_core__DOT___010976_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->wasmetal_core__DOT___003056_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d))))));
    vlSelf->__VdfgTmp_hd6a330ca__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005617_));
    vlSelf->wasmetal_core__DOT___007414_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3edf8090__0))))))));
    vlSelf->__VdfgTmp_h0118c8b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT___005185_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048169_)))))))));
    vlSelf->wasmetal_core__DOT___067481_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000657_)))));
    vlSelf->wasmetal_core__DOT___028764_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052234_))));
    vlSelf->__VdfgTmp_had9a86ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT___053954_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT___026686_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->__VdfgTmp_h0f13542d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___027156_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d))));
    vlSelf->wasmetal_core__DOT___026956_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054174_))));
    vlSelf->wasmetal_core__DOT___010969_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->wasmetal_core__DOT___002885_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d))))));
    vlSelf->wasmetal_core__DOT___007387_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c9b01b4__0))))))));
    vlSelf->__VdfgTmp_hec1752e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000658_));
    vlSelf->wasmetal_core__DOT___067400_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067397_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054170_)))))));
    vlSelf->wasmetal_core__DOT___005253_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048239_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048238_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048241_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048240_)))))))));
    vlSelf->wasmetal_core__DOT___044515_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___028762_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052233_))));
    vlSelf->wasmetal_core__DOT___053953_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1dU))))));
    vlSelf->__VdfgTmp_h3b20cbca__0 = (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___026684_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___026819_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___027154_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d))));
    vlSelf->wasmetal_core__DOT___026954_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054170_))));
    vlSelf->wasmetal_core__DOT___056436_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___002761_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d))))));
    vlSelf->wasmetal_core__DOT___048848_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d)))))))));
    vlSelf->wasmetal_core__DOT___007361_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc454ae75__0))))))));
    vlSelf->__VdfgTmp_h9206c0aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000636_));
    vlSelf->wasmetal_core__DOT___052267_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052258_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052255_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052254_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052253_)))))))));
    vlSelf->wasmetal_core__DOT___067299_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067296_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))));
    vlSelf->wasmetal_core__DOT___004845_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048184_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048183_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048181_)))))))));
    vlSelf->wasmetal_core__DOT___044318_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3a468d3__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128441___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000657_)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000635_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___000613_))))));
    vlSelf->wasmetal_core__DOT___028761_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052232_))));
    vlSelf->wasmetal_core__DOT___071973_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___053952_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___026683_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000613_))));
    vlSelf->wasmetal_core__DOT___026818_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000613_))));
    vlSelf->wasmetal_core__DOT___027153_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026953_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054166_))));
    vlSelf->wasmetal_core__DOT___010961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000613_))));
    vlSelf->wasmetal_core__DOT___002721_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d))))));
    vlSelf->wasmetal_core__DOT___048855_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d)))))))));
    vlSelf->wasmetal_core__DOT___007335_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb30bed30__0))))))));
    vlSelf->__VdfgTmp_hbf5b2f76__0 = (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000614_));
    vlSelf->wasmetal_core__DOT___067260_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067253_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054162_)))))));
    vlSelf->wasmetal_core__DOT___004981_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048259_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048258_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048256_)))))))));
    vlSelf->__VdfgTmp_h6305c07b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005399_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005400_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048259_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048258_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048257_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048256_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h9462500e__0))))))))));
    vlSelf->__VdfgTmp_hb6080b41__0 = (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT___028760_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052567_))));
    vlSelf->wasmetal_core__DOT___053951_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___026682_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000591_))));
    vlSelf->__VdfgTmp_h2be29f89__0 = (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT___071968_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000613_)))));
    vlSelf->wasmetal_core__DOT___027152_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d))));
    vlSelf->wasmetal_core__DOT___026952_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054162_))));
    vlSelf->wasmetal_core__DOT___011017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000591_))));
    vlSelf->wasmetal_core__DOT___002843_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d))))));
    vlSelf->wasmetal_core__DOT___007302_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc7b7ff9d__0))))))));
    vlSelf->__VdfgTmp_hbaf6c8a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000592_));
    vlSelf->wasmetal_core__DOT___004913_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048178_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048177_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048180_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048179_)))))))));
    vlSelf->wasmetal_core__DOT___044524_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000564_)))))))));
    vlSelf->__VdfgTmp_h17df9f02__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x19U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000564_));
    vlSelf->wasmetal_core__DOT___028759_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052566_))));
    vlSelf->wasmetal_core__DOT___053950_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___026681_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->wasmetal_core__DOT___026816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->__VdfgTmp_h879a663d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT___027151_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026951_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054158_))));
    vlSelf->wasmetal_core__DOT___011014_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->wasmetal_core__DOT___002801_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d))))));
    vlSelf->wasmetal_core__DOT___007275_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2c2ac443__0))))))));
    vlSelf->__VdfgTmp_h6e881f1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000565_));
    vlSelf->wasmetal_core__DOT___067102_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067099_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))));
    vlSelf->wasmetal_core__DOT___005321_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048245_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048244_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048242_)))))))));
    vlSelf->__VdfgTmp_hea3adbd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005446_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005447_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048245_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048244_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048243_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048242_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hcea60642__0))))))))));
    vlSelf->wasmetal_core__DOT___044338_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6e6c7922__0))))))));
    vlSelf->wasmetal_core__DOT___028758_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___053949_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___026680_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___026815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___071964_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000564_)))));
    vlSelf->wasmetal_core__DOT___027150_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026950_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054135_))));
    vlSelf->wasmetal_core__DOT___011011_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___002682_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d))))));
    vlSelf->wasmetal_core__DOT___048845_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d)))))))));
    vlSelf->wasmetal_core__DOT___007248_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h27758395__0))))))));
    vlSelf->__VdfgTmp_h975aebd1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000543_));
    vlSelf->wasmetal_core__DOT___067028_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067025_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054131_)))))));
    vlSelf->wasmetal_core__DOT___044526_ = ((IData)(vlSelf->wasmetal_core__DOT___044549_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044558_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044557_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044556_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044555_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044554_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044553_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044552_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044551_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044550_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044548_) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044536_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044538_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044539_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044540_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044541_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044542_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044543_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044544_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044545_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044546_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044537_));
    vlSelf->wasmetal_core__DOT___005049_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048176_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048175_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048173_)))))))));
    vlSelf->__VdfgTmp_h04914456__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005436_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005437_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048176_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048175_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048174_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048173_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hc3acb233__0))))))))));
    vlSelf->__VdfgTmp_h00038af9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000520_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128440___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000591_)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000564_)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000542_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___000520_))))));
    vlSelf->wasmetal_core__DOT___028757_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___053948_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___026679_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___026814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___071962_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000542_)))));
    vlSelf->wasmetal_core__DOT___027149_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d))));
    vlSelf->wasmetal_core__DOT___026949_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054131_))));
    vlSelf->wasmetal_core__DOT___011004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___002643_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))))));
    vlSelf->wasmetal_core__DOT___048865_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d)))))))));
    vlSelf->wasmetal_core__DOT___007433_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h09cdcbfb__0))))))));
    vlSelf->__VdfgTmp_h8670d2e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000521_));
    vlSelf->wasmetal_core__DOT___066960_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054127_)))))));
    vlSelf->wasmetal_core__DOT___005117_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048071_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048069_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048068_)))))))));
    vlSelf->__VdfgTmp_hc2abfe6d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005496_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005497_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048071_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048070_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048069_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048068_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_he5858a3c__0))))))))));
    vlSelf->wasmetal_core__DOT___044523_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000498_)))))))));
    vlSelf->__VdfgTmp_h81203724__0 = (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->__VdfgTmp_hf5ee6f21__0 = (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->__VdfgTmp_hd5d86514__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x16U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->wasmetal_core__DOT___028756_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052527_))));
    vlSelf->wasmetal_core__DOT___053947_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___026678_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___026813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___071960_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000520_)))));
    vlSelf->wasmetal_core__DOT___027148_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d))));
    vlSelf->wasmetal_core__DOT___026948_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054127_))));
    vlSelf->wasmetal_core__DOT___011867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___002925_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d))))));
    vlSelf->wasmetal_core__DOT___048840_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))))))));
    vlSelf->wasmetal_core__DOT___007415_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heec1cc96__0))))))));
    vlSelf->__VdfgTmp_h3e1a5258__0 = (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000499_));
    vlSelf->wasmetal_core__DOT___066883_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066875_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))));
    vlSelf->wasmetal_core__DOT___003301_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048047_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048046_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048045_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048044_)))))))));
    vlSelf->wasmetal_core__DOT___044337_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h42ef1750__0))))))));
    vlSelf->wasmetal_core__DOT___028755_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052528_))));
    vlSelf->wasmetal_core__DOT___053946_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x16U))))));
    vlSelf->wasmetal_core__DOT___026677_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___071958_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000498_)))));
    vlSelf->wasmetal_core__DOT___027147_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d))));
    vlSelf->wasmetal_core__DOT___026947_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054123_))));
    vlSelf->wasmetal_core__DOT___010958_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___002556_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d))))));
    vlSelf->__VdfgTmp_hf0334e7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000477_));
    vlSelf->wasmetal_core__DOT___007388_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h898dd08d__0))))))));
    vlSelf->__VdfgTmp_h434b0db3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___066802_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066793_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054119_)))))));
    vlSelf->wasmetal_core__DOT___003369_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048060_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048059_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048058_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048057_)))))))));
    vlSelf->wasmetal_core__DOT___028754_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___053945_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x15U))))));
    vlSelf->wasmetal_core__DOT___026676_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->__VdfgTmp_h745b6e5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000476_));
    vlSelf->wasmetal_core__DOT___027146_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d))));
    vlSelf->wasmetal_core__DOT___026946_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054119_))));
    vlSelf->wasmetal_core__DOT___011125_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___002595_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d))))));
    vlSelf->__VdfgTmp_h9cad1664__0 = (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000465_));
    vlSelf->wasmetal_core__DOT___007362_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5d92aff2__0))))))));
    vlSelf->__VdfgTmp_hf1e329c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000464_));
    vlSelf->wasmetal_core__DOT___066720_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066710_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054115_)))))));
    vlSelf->wasmetal_core__DOT___003889_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048043_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048042_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048041_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048040_)))))))));
    vlSelf->wasmetal_core__DOT___044522_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000432_)))))))));
    vlSelf->__VdfgTmp_h2c65ce9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->__VdfgTmp_hd7080d55__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x13U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128439___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000498_)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000476_)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000464_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___000432_))))));
    vlSelf->wasmetal_core__DOT___028753_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___053944_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___026675_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___071954_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000464_)))));
    vlSelf->wasmetal_core__DOT___027145_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d))));
    vlSelf->wasmetal_core__DOT___026945_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054115_))));
    vlSelf->wasmetal_core__DOT___011124_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___002318_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d))))));
    vlSelf->__VdfgTmp_hd86a0826__0 = (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000433_));
    vlSelf->wasmetal_core__DOT___007336_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4a3667e8__0))))))));
    vlSelf->__VdfgTmp_h8476215a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->wasmetal_core__DOT___066636_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066624_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))));
    vlSelf->wasmetal_core__DOT___003815_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048139_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048140_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048142_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048141_)))))))));
    vlSelf->__VdfgTmp_he16d2f4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048140_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048139_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h70d2167a__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048142_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048141_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h64e10f56__0))))))))));
    vlSelf->wasmetal_core__DOT___044336_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5eac1f1__0))))))));
    vlSelf->__VdfgTmp_hfe93be6e__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x12U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___028751_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052555_))));
    vlSelf->wasmetal_core__DOT___053943_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___026673_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    vlSelf->wasmetal_core__DOT___071952_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000432_)))));
    vlSelf->wasmetal_core__DOT___027143_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d))));
    vlSelf->wasmetal_core__DOT___026943_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054111_))));
    vlSelf->wasmetal_core__DOT___010989_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    vlSelf->wasmetal_core__DOT___000155_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d))))));
    vlSelf->wasmetal_core__DOT___048881_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))))))));
    vlSelf->__VdfgTmp_h3e3e53ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000420_));
    vlSelf->wasmetal_core__DOT___007303_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb2653381__0))))))));
    vlSelf->__VdfgTmp_h4d6951f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___000145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___066553_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066548_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054107_)))))));
    vlSelf->wasmetal_core__DOT___004031_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048016_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048017_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048019_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048018_)))))))));
    vlSelf->__VdfgTmp_h5d95a729__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048017_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048016_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h31225405__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048019_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048018_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf93df92c__0))))))))));
    vlSelf->wasmetal_core__DOT___028750_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    vlSelf->wasmetal_core__DOT___053942_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___026672_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    vlSelf->__VdfgTmp_h877be1c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->wasmetal_core__DOT___027142_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d))));
    vlSelf->wasmetal_core__DOT___026942_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054107_))));
    vlSelf->wasmetal_core__DOT___010983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    vlSelf->wasmetal_core__DOT___002280_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d))))));
    vlSelf->__VdfgTmp_h0cc9f882__0 = (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001647_));
    vlSelf->wasmetal_core__DOT___007276_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h68543eec__0))))))));
    vlSelf->__VdfgTmp_h95830544__0 = (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___002192_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___066473_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066467_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054103_)))))));
    vlSelf->wasmetal_core__DOT___052757_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052751_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbaa2fe71__0))))));
    vlSelf->wasmetal_core__DOT___004253_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048075_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048074_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048073_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048072_)))))))));
    vlSelf->__VdfgTmp_h1fced7c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048074_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048075_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h177129ae__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048073_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048072_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h4a9c07e1__0))))))))));
    vlSelf->wasmetal_core__DOT___044521_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000419_)))))))));
    vlSelf->wasmetal_core__DOT___028749_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    vlSelf->wasmetal_core__DOT___053941_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___026671_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    vlSelf->__VdfgTmp_hf05757ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___027141_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d))));
    vlSelf->wasmetal_core__DOT___026941_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054103_))));
    vlSelf->wasmetal_core__DOT___010999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    vlSelf->wasmetal_core__DOT___002243_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d))))));
    vlSelf->__VdfgTmp_h63306680__0 = (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001625_));
    vlSelf->wasmetal_core__DOT___007249_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h57521c49__0))))))));
    vlSelf->__VdfgTmp_ha8cefda7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___002191_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___066388_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066385_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054099_)))))));
    vlSelf->wasmetal_core__DOT___003957_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048011_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048010_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048009_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048008_)))))))));
    vlSelf->__VdfgTmp_h2852ec0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048010_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048011_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h71a6f88b__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048009_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048008_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb9ea03dd__0))))))))));
    vlSelf->wasmetal_core__DOT___044335_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfa74de2f__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128438___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000419_)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001646_)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___001624_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___001612_))))));
    vlSelf->wasmetal_core__DOT___028748_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___053940_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___026670_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___071946_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001624_)))));
    vlSelf->wasmetal_core__DOT___027140_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d))));
    vlSelf->wasmetal_core__DOT___026940_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054099_))));
    vlSelf->wasmetal_core__DOT___010992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___002040_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))))));
    vlSelf->__VdfgTmp_h560b7672__0 = (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001613_));
    vlSelf->wasmetal_core__DOT___007430_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0b995397__0))))))));
    vlSelf->__VdfgTmp_h652edcf1__0 = (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___002031_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___003659_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048696_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048695_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048694_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048693_)))))))));
    vlSelf->__VdfgTmp_had67ef57__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048695_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048696_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha13bce2f__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048694_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048693_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h33498483__0))))))))));
    vlSelf->wasmetal_core__DOT___028747_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052400_))));
    vlSelf->wasmetal_core__DOT___053939_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___026669_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->__VdfgTmp_hb150d0ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___027139_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d))));
    vlSelf->wasmetal_core__DOT___026939_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054095_))));
    vlSelf->wasmetal_core__DOT___011527_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->wasmetal_core__DOT___002479_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d))))));
    vlSelf->__VdfgTmp_hb96516e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001581_));
    vlSelf->wasmetal_core__DOT___007412_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed5e83f9__0))))))));
    vlSelf->__VdfgTmp_h5e46481a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___055867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054752_))));
    vlSelf->wasmetal_core__DOT___002469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___004623_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048190_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048189_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048192_)))))))));
    vlSelf->__VdfgTmp_hcbae1cfc__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048190_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048189_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5978f26f__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048192_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048191_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hbd8e6335__0))))))))));
    vlSelf->wasmetal_core__DOT___044520_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001568_)))))))));
    vlSelf->__VdfgTmp_ha7a1e5c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->__VdfgTmp_h8243d19d__0 = ((2U & (vlSelf->insn_y 
                                             >> 0xdU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___028746_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052401_))));
    vlSelf->wasmetal_core__DOT___053938_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___026668_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___071942_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001580_)))));
    vlSelf->wasmetal_core__DOT___027138_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d))));
    vlSelf->wasmetal_core__DOT___026938_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054091_))));
    vlSelf->wasmetal_core__DOT___010925_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___002152_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d))))));
    vlSelf->__VdfgTmp_he974eeb2__0 = (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001569_));
    vlSelf->wasmetal_core__DOT___007385_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h11733417__0))))))));
    vlSelf->__VdfgTmp_h88a0d3a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___002034_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___066115_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066069_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 0xdU))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065586_)))))))));
    vlSelf->wasmetal_core__DOT___004179_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048235_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048237_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048236_)))))))));
    vlSelf->__VdfgTmp_h1f7a3fb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048235_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048234_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h79860539__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048237_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048236_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf0dacca2__0))))))))));
    vlSelf->wasmetal_core__DOT___044334_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc1441d8__0))))))));
    vlSelf->wasmetal_core__DOT___028745_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052257_))));
    vlSelf->wasmetal_core__DOT___053937_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___026667_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___071940_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001568_)))));
    vlSelf->wasmetal_core__DOT___027137_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d))));
    vlSelf->wasmetal_core__DOT___026937_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054087_))));
    vlSelf->wasmetal_core__DOT___010918_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___002115_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d))))));
    vlSelf->__VdfgTmp_h5a182b30__0 = (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001537_));
    vlSelf->wasmetal_core__DOT___007359_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h20a47ce2__0))))))));
    vlSelf->__VdfgTmp_h5bc17448__0 = (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___002033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
}
