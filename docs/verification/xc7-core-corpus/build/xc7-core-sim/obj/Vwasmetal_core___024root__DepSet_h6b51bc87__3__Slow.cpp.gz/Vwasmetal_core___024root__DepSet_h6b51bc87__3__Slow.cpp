#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__22(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__22\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___066012_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066007_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 0xcU))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065586_)))))))));
    vlSelf->wasmetal_core__DOT___004105_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048185_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048186_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048188_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048187_)))))))));
    vlSelf->__VdfgTmp_h1f83dfd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048186_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048185_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h0adea875__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048188_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048187_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2566b586__0))))))))));
    vlSelf->__VdfgTmp_h48afdd44__0 = (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128437___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001580_)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001568_)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___001536_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___001524_))))));
    vlSelf->wasmetal_core__DOT___028744_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052255_))));
    vlSelf->wasmetal_core__DOT___053936_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___026666_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    vlSelf->wasmetal_core__DOT___071938_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001536_)))));
    vlSelf->wasmetal_core__DOT___027136_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d))));
    vlSelf->wasmetal_core__DOT___026936_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054083_))));
    vlSelf->wasmetal_core__DOT___010911_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    vlSelf->wasmetal_core__DOT___002078_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d))))));
    if (vlSelf->wasmetal_core__DOT___000418_) {
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d 
            = vlSelf->wasmetal_core__DOT___001525_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d 
            = vlSelf->wasmetal_core__DOT___001426_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d 
            = vlSelf->wasmetal_core__DOT___001414_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d 
            = vlSelf->wasmetal_core__DOT___001382_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d 
            = vlSelf->wasmetal_core__DOT___001370_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d 
            = vlSelf->wasmetal_core__DOT___001488_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d 
            = vlSelf->wasmetal_core__DOT___001476_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d 
            = vlSelf->wasmetal_core__DOT___001444_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d 
            = vlSelf->wasmetal_core__DOT___001438_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d 
            = vlSelf->wasmetal_core__DOT___001887_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d 
            = vlSelf->wasmetal_core__DOT___001875_;
    } else {
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d 
            = vlSelf->wasmetal_core__DOT___001524_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d 
            = vlSelf->wasmetal_core__DOT___001425_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d 
            = vlSelf->wasmetal_core__DOT___001413_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d 
            = vlSelf->wasmetal_core__DOT___001381_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d 
            = vlSelf->wasmetal_core__DOT___001369_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d 
            = vlSelf->wasmetal_core__DOT___001487_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d 
            = vlSelf->wasmetal_core__DOT___001475_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d 
            = vlSelf->wasmetal_core__DOT___001443_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d 
            = vlSelf->wasmetal_core__DOT___001437_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d 
            = vlSelf->wasmetal_core__DOT___001886_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d 
            = vlSelf->wasmetal_core__DOT___001874_;
    }
    vlSelf->__VdfgTmp_h3daf64ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001525_));
    vlSelf->wasmetal_core__DOT___007333_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h71467b4f__0))))))));
    vlSelf->__VdfgTmp_h840c74b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___002032_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___003511_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048263_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048261_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048260_)))))))));
    vlSelf->__VdfgTmp_h07f42939__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048262_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048263_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hcde84ebb__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048261_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048260_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd5a2b04d__0))))))))));
    vlSelf->wasmetal_core__DOT___044519_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001425_)))))))));
    vlSelf->__VdfgTmp_h4143e379__0 = (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->__VdfgTmp_he8f67c93__0 = ((2U & (vlSelf->insn_y 
                                             >> 0xaU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___028743_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052477_))));
    vlSelf->wasmetal_core__DOT___053935_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___026665_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___071936_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001524_)))));
    vlSelf->wasmetal_core__DOT___027135_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d))));
    vlSelf->wasmetal_core__DOT___026935_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054079_))));
    vlSelf->wasmetal_core__DOT___010939_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___002355_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d))))));
    vlSelf->__VdfgTmp_hce5538fe__0 = (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001426_));
    vlSelf->wasmetal_core__DOT___007300_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h51a5c0e8__0))))))));
    vlSelf->__VdfgTmp_h0585c3f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___048790_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___065833_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065792_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065791_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 0xaU))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065586_)))))))));
    vlSelf->wasmetal_core__DOT___050342_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050341_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050340_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003764_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003746_)))))));
    vlSelf->wasmetal_core__DOT___003437_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048198_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048200_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048199_)))))))));
    vlSelf->__VdfgTmp_h5d126061__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048198_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048197_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h52266111__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048200_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048199_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h7f6ab5bd__0))))))))));
    vlSelf->wasmetal_core__DOT___044333_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33545cb0__0))))))));
    vlSelf->__VdfgTmp_haf096c00__0 = ((2U & (vlSelf->insn_y 
                                             >> 9U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___028742_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052476_))));
    vlSelf->wasmetal_core__DOT___053934_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xaU))))));
    vlSelf->wasmetal_core__DOT___026664_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___027134_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d))));
    vlSelf->wasmetal_core__DOT___071934_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001425_)))));
    vlSelf->wasmetal_core__DOT___026934_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054075_))));
    vlSelf->wasmetal_core__DOT___010932_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___002433_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d))))));
    vlSelf->__VdfgTmp_h32ee57a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001414_));
    vlSelf->wasmetal_core__DOT___007273_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h11929a69__0))))))));
    vlSelf->__VdfgTmp_h4172973d__0 = (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___048792_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___003585_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048230_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048231_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048233_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048232_)))))))));
    vlSelf->__VdfgTmp_h74bfec90__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048231_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048230_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hff8a2099__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048233_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048232_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2712d491__0))))))))));
    vlSelf->wasmetal_core__DOT___028772_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052398_))));
    vlSelf->wasmetal_core__DOT___053933_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___026726_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___027196_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d))));
    vlSelf->__VdfgTmp_h8f3a812b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___026996_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054071_))));
    vlSelf->wasmetal_core__DOT___011537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___002395_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d))))));
    vlSelf->__VdfgTmp_h5011624a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001382_));
    vlSelf->wasmetal_core__DOT___007246_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h25819d29__0))))))));
    vlSelf->__VdfgTmp_hcc9d97e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___048791_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___065637_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054067_)))))))));
    vlSelf->wasmetal_core__DOT___003733_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048196_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048195_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048194_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048193_)))))))));
    vlSelf->__VdfgTmp_hbe250e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048195_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048196_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h601dd350__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048194_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048193_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2f983ac6__0))))))))));
    vlSelf->wasmetal_core__DOT___044518_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))))));
    vlSelf->wasmetal_core__DOT___050427_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001568_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128436___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001425_)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001413_)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___001381_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___001369_))))));
    vlSelf->wasmetal_core__DOT___028771_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052399_))));
    vlSelf->wasmetal_core__DOT___053932_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___026725_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___027195_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d))));
    vlSelf->__VdfgTmp_h6be648c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___026995_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054067_))));
    vlSelf->wasmetal_core__DOT___011519_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___002518_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))))));
    vlSelf->__VdfgTmp_h30cac7a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001370_));
    vlSelf->wasmetal_core__DOT___007431_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3c8de641__0))))))));
    vlSelf->__VdfgTmp_h6a7f974d__0 = (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___002470_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___004549_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048067_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048066_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048065_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048064_)))))))));
    vlSelf->__VdfgTmp_hb5c2181f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048066_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048067_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb7a72eea__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048065_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048064_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h158a449d__0))))))))));
    vlSelf->wasmetal_core__DOT___044332_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb28d3ef__0))))))));
    vlSelf->wasmetal_core__DOT___028770_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052557_))));
    vlSelf->wasmetal_core__DOT___053931_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 7U))))));
    vlSelf->wasmetal_core__DOT___026724_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___027194_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d))));
    vlSelf->wasmetal_core__DOT___071928_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001369_)))));
    vlSelf->wasmetal_core__DOT___026994_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054063_))));
    vlSelf->wasmetal_core__DOT___011518_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___002198_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))))));
    vlSelf->__VdfgTmp_h5fd7d7a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001488_));
    vlSelf->wasmetal_core__DOT___007413_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h01ed509a__0))))))));
    vlSelf->__VdfgTmp_h1ea91d16__0 = (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___002190_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___004401_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048012_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048013_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048015_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048014_)))))))));
    vlSelf->__VdfgTmp_h3bba44d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048013_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048012_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hbacded4f__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048015_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048014_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2937d10d__0))))))))));
    vlSelf->__VdfgTmp_hcbda1b46__0 = (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___028769_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052556_))));
    vlSelf->wasmetal_core__DOT___053930_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___026723_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___027193_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d))));
    vlSelf->wasmetal_core__DOT___071926_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001487_)))));
    vlSelf->wasmetal_core__DOT___026993_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054059_))));
    vlSelf->wasmetal_core__DOT___011522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___001743_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d))))));
    vlSelf->__VdfgTmp_h47fa9bfe__0 = (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001476_));
    vlSelf->wasmetal_core__DOT___007386_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ad4d6dd__0))))))));
    vlSelf->__VdfgTmp_h1048f6d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___000148_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___004327_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048156_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048155_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048154_)))))))));
    vlSelf->__VdfgTmp_h4ff79496__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048156_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048157_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf0176237__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048155_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048154_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha7dc0a46__0))))))))));
    vlSelf->wasmetal_core__DOT___044517_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001443_)))))))));
    vlSelf->__VdfgTmp_hfcd21fa2__0 = ((2U & (vlSelf->insn_y 
                                             >> 4U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___028768_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052474_))));
    vlSelf->wasmetal_core__DOT___053929_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___026718_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___027188_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071924_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001475_)))));
    vlSelf->wasmetal_core__DOT___026988_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054055_))));
    vlSelf->wasmetal_core__DOT___056425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___001678_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d))))));
    vlSelf->wasmetal_core__DOT___000170_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)))));
    vlSelf->__VdfgTmp_h2b4ef23a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001444_));
    vlSelf->wasmetal_core__DOT___007360_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc6273ca__0))))))));
    vlSelf->__VdfgTmp_h1656da2e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___000147_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___065173_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065160_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065159_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x5550fff0fff0cccULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              << 3U)) 
                                                                          | ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065153_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065134_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064429_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064436_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065132_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065141_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065148_))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___004475_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048031_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048030_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048029_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048028_)))))))));
    vlSelf->__VdfgTmp_h627c070d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048030_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048031_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h82d77f97__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048029_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048028_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h6e7f092f__0))))))))));
    vlSelf->wasmetal_core__DOT___064477_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064476_))));
    vlSelf->wasmetal_core__DOT___044331_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6661b389__0))))))));
    vlSelf->wasmetal_core__DOT___061584_ = (1U & (0xffefefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048434_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048448_)))))));
    vlSelf->wasmetal_core__DOT___028767_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052475_))));
    vlSelf->wasmetal_core__DOT___053928_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___026707_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___027177_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071922_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001443_)))));
    vlSelf->wasmetal_core__DOT___026977_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054051_))));
    vlSelf->wasmetal_core__DOT___011508_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___001253_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))))));
    vlSelf->wasmetal_core__DOT___000169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->__VdfgTmp_h77a25d8c__0 = (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001438_));
    vlSelf->wasmetal_core__DOT___007334_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h04643804__0))))))));
    vlSelf->wasmetal_core__DOT____VdfgTmp_h5ad60c71__0 
        = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001443_)) 
                  << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->__VdfgTmp_h8b5bebff__0 = (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___000146_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___065050_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065047_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065046_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x30f0200030f030fULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065040_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00f0f01111ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065024_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065023_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f00003355ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065020_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064689_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064690_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___065019_)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065031_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065037_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___004697_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048153_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048152_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048151_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048150_)))))))));
    vlSelf->__VdfgTmp_hfcbc0180__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048152_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048153_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h7d4fca25__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048151_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048150_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd1b03413__0))))))))));
    vlSelf->__VdfgTmp_h4104a354__0 = ((2U & (vlSelf->insn_y 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->__VdfgTmp_h84f9890b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___061553_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___028766_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052253_))));
    vlSelf->wasmetal_core__DOT___053927_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___026696_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___027166_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d))));
    vlSelf->wasmetal_core__DOT___071920_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->wasmetal_core__DOT___026966_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054047_))));
    vlSelf->wasmetal_core__DOT___011513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___001995_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d))))));
    vlSelf->wasmetal_core__DOT___048803_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))))))));
    vlSelf->wasmetal_core__DOT___000180_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->__VdfgTmp_hd3bfd495__0 = (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001887_));
    vlSelf->wasmetal_core__DOT___007301_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf58c538__0))))))));
    vlSelf->__VdfgTmp_hf0092dd5__0 = (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___001803_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___004771_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048038_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048039_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048035_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048034_)))))))));
    vlSelf->__VdfgTmp_hd09f2908__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048039_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048038_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h8dbe6334__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048035_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048034_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h59e987ab__0))))))))));
    vlSelf->wasmetal_core__DOT___044516_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001886_)))))))));
    vlSelf->wasmetal_core__DOT___061536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___028763_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052254_))));
    vlSelf->wasmetal_core__DOT___053926_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___026685_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___027155_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d))));
    vlSelf->__VdfgTmp_h87854ac5__0 = (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___026955_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054043_))));
    vlSelf->wasmetal_core__DOT___011503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___001950_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d))))));
    vlSelf->wasmetal_core__DOT___048800_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d)))))))));
    vlSelf->wasmetal_core__DOT___000181_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->__VdfgTmp_h78b443e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001875_));
    vlSelf->wasmetal_core__DOT___007274_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff7a62d4__0))))))));
    vlSelf->__VdfgTmp_h989e4977__0 = (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT___055469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054752_))));
    vlSelf->wasmetal_core__DOT___001802_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___045129_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___045175_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045174_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045172_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045171_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045170_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045169_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045168_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045167_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045166_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045165_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045164_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045163_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045183_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045182_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045181_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045180_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045179_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045178_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___045177_)
                                                                     ? 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___045176_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___045173_)
                                                                       ? 
                                                                      ((~ 
                                                                        (9U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4ae0787e__0))) 
                                                                       & (4U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h4ae0787e__0)))
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___045149_))
                                                                      : (IData)(vlSelf->wasmetal_core__DOT___045152_))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___045153_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045154_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045155_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045156_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045157_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045158_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045159_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045139_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045140_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045141_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045142_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045143_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045144_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045145_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045146_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045147_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045148_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045150_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045151_)));
    vlSelf->wasmetal_core__DOT___064722_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064716_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___003221_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048135_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048136_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048138_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048137_)))))))));
    vlSelf->__VdfgTmp_h534a5d27__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048136_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048135_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h09328eec__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048138_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048137_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf92587e4__0))))))))));
    vlSelf->wasmetal_core__DOT___044328_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66f1f037__0))))))));
    vlSelf->wasmetal_core__DOT___052759_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000542_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000635_))))))))))));
    vlSelf->wasmetal_core__DOT___050424_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_)))));
    vlSelf->wasmetal_core__DOT___061527_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___028752_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052256_))));
    vlSelf->wasmetal_core__DOT___053925_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_y 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___026674_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___027144_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d))));
    vlSelf->wasmetal_core__DOT___071916_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001874_)))));
    vlSelf->wasmetal_core__DOT___026944_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054039_))));
    vlSelf->wasmetal_core__DOT___056427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___001901_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d))))));
    vlSelf->wasmetal_core__DOT___000182_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->__VdfgTmp_hc8dfb864__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003269_));
    vlSelf->wasmetal_core__DOT___007247_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h365733f0__0))))))));
    vlSelf->__VdfgTmp_h47317805__0 = (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___001801_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128640___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001887_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001875_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___003269_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___003189_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003189_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___034380_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001887_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028472_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003270_));
    vlSelf->wasmetal_core__DOT___045423_ = ((IData)(vlSelf->wasmetal_core__DOT___045446_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045455_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045454_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045453_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045452_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045451_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045450_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045449_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045448_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045447_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045445_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045433_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045435_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045436_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045437_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045438_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045439_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045440_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045441_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045442_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045443_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045434_));
    vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028637_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___003190_));
    vlSelf->wasmetal_core__DOT___052575_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052571_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052570_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052569_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he4fb154e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052566_)))))))));
    vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028949_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d));
    vlSelf->wasmetal_core__DOT___064456_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064451_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064450_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053990_)))))))));
    vlSelf->wasmetal_core__DOT___003133_ = (1U & (IData)(
                                                         (0xeeee0000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048021_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048020_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha8427a44__0))))))));
    vlSelf->wasmetal_core__DOT___003135_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048023_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048022_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048021_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048020_)))))))));
    vlSelf->wasmetal_core__DOT___044502_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___044514_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___050422_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000419_)))))))));
    vlSelf->__VdfgTmp_h521b28ea__0 = ((2U & (vlSelf->insn_y 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___061522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___028741_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052558_))));
    vlSelf->wasmetal_core__DOT___053924_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053922_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlSelf->insn_y)))));
    vlSelf->wasmetal_core__DOT___026663_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___027133_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d))));
    vlSelf->__VdfgTmp_h644f4591__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___071913_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071910_))));
    vlSelf->__VdfgTmp_hc01d1a00__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053990_));
    vlSelf->wasmetal_core__DOT___056428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___001810_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))))));
    vlSelf->__VdfgTmp_h93039dba__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003189_));
    vlSelf->wasmetal_core__DOT___007881_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3cb924f__0))))))));
    vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->__VdfgTmp_hb2eda61f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___001800_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___048492_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & ((IData)(
                                                                       (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                        >> 6U)) 
                                                               << 2U)) 
                                                           | (3U 
                                                              & (IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                         >> 5U)))))));
    vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031069_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___054815_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6d3f2850__0)))));
    vlSelf->__VdfgTmp_h7690c014__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hf2656e40__0));
    vlSelf->wasmetal_core__DOT___007546_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf2656e40__0))))));
    vlSelf->wasmetal_core__DOT___048858_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4f39dfcd__0))))))));
    vlSelf->wasmetal_core__DOT___054810_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b966d55__0)))));
    vlSelf->__VdfgTmp_h01d6394a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0));
    vlSelf->wasmetal_core__DOT___007688_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0))))));
    vlSelf->wasmetal_core__DOT___048868_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h957273a9__0))))))));
    vlSelf->wasmetal_core__DOT___063779_ = (1U & (0xb00bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8541949a__0)))));
    vlSelf->wasmetal_core__DOT___051496_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8541949a__0)))));
    vlSelf->__VdfgTmp_h878f9978__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h815644ec__0));
    vlSelf->wasmetal_core__DOT___055514_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054901_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h6eb17b7a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hbaaa25aa__0));
    vlSelf->wasmetal_core__DOT___057244_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057243_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___055590_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h624c4f06__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hde99fb2e__0));
    vlSelf->wasmetal_core__DOT___012964_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057442_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___048873_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h39dd035b__0))))))));
    vlSelf->wasmetal_core__DOT___063740_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46681fd6__0))))))));
    vlSelf->wasmetal_core__DOT___054990_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46681fd6__0)))));
    vlSelf->__VdfgTmp_h40471efb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0));
    vlSelf->wasmetal_core__DOT___055372_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054775_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h3f534570__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h898c2bb0__0));
    vlSelf->wasmetal_core__DOT___007519_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc1ba948d__0)))))));
    vlSelf->__VdfgTmp_h7780ec55__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hc1ba948d__0));
    vlSelf->__VdfgTmp_h284fdec6__0 = (((IData)(vlSelf->wasmetal_core__DOT___054692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054691_));
    if (vlSelf->wasmetal_core__DOT___000666_) {
        if (vlSelf->wasmetal_core__DOT___000418_) {
            vlSelf->wasmetal_core__DOT___001663_ = 
                (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_ha7f22436__0)))));
            vlSelf->wasmetal_core__DOT___000575_ = 
                (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005617_))))));
        } else {
            vlSelf->wasmetal_core__DOT___001663_ = 
                (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
            vlSelf->wasmetal_core__DOT___000575_ = 
                (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
        }
        vlSelf->wasmetal_core__DOT___001787_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___001169_)))))))));
        vlSelf->wasmetal_core__DOT___001285_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000723_)))))))));
        vlSelf->wasmetal_core__DOT___001302_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000897_)))))))));
        vlSelf->wasmetal_core__DOT___001661_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000658_)))))))));
        vlSelf->wasmetal_core__DOT___001662_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000694_)))))))));
        vlSelf->wasmetal_core__DOT___001287_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000772_)))))))));
        vlSelf->wasmetal_core__DOT___000574_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000693_)))))))));
        vlSelf->wasmetal_core__DOT___000719_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000771_)))))))));
        vlSelf->wasmetal_core__DOT___000720_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000795_)))))))));
        vlSelf->wasmetal_core__DOT___000820_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000848_)))))))));
        vlSelf->wasmetal_core__DOT___000821_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000872_)))))))));
        vlSelf->wasmetal_core__DOT___000822_ = (1U 
                                                & (IData)(
                                                          (0xf0f5555333300ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___000896_)))))))));
        vlSelf->wasmetal_core__DOT___000920_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))));
        vlSelf->wasmetal_core__DOT___001301_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))));
        vlSelf->wasmetal_core__DOT___001300_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hac359f24__0))))))));
        vlSelf->wasmetal_core__DOT___001299_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))));
        vlSelf->wasmetal_core__DOT___000819_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))));
        vlSelf->wasmetal_core__DOT___001288_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))));
        vlSelf->wasmetal_core__DOT___001286_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))));
        vlSelf->wasmetal_core__DOT___000718_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))));
        vlSelf->wasmetal_core__DOT___000717_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___001663_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)));
        vlSelf->wasmetal_core__DOT___000575_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)));
        vlSelf->wasmetal_core__DOT___001787_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___001168_)));
        vlSelf->wasmetal_core__DOT___001285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)));
        vlSelf->wasmetal_core__DOT___001302_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)));
        vlSelf->wasmetal_core__DOT___001661_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000657_)));
        vlSelf->wasmetal_core__DOT___001662_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)));
        vlSelf->wasmetal_core__DOT___001287_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)));
        vlSelf->wasmetal_core__DOT___000574_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)));
        vlSelf->wasmetal_core__DOT___000719_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)));
        vlSelf->wasmetal_core__DOT___000720_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)));
        vlSelf->wasmetal_core__DOT___000820_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)));
        vlSelf->wasmetal_core__DOT___000821_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)));
        vlSelf->wasmetal_core__DOT___000822_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)));
        vlSelf->wasmetal_core__DOT___000920_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)));
        vlSelf->wasmetal_core__DOT___001301_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)));
        vlSelf->wasmetal_core__DOT___001300_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)));
        vlSelf->wasmetal_core__DOT___001299_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)));
        vlSelf->wasmetal_core__DOT___000819_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)));
        vlSelf->wasmetal_core__DOT___001288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)));
        vlSelf->wasmetal_core__DOT___001286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)));
        vlSelf->wasmetal_core__DOT___000718_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)));
        vlSelf->wasmetal_core__DOT___000717_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)));
    }
    vlSelf->wasmetal_core__DOT___055331_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___048926_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h67e9fb36__0))))))));
    vlSelf->wasmetal_core__DOT___055673_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h69484b9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0));
    vlSelf->wasmetal_core__DOT___048651_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb73e868c__0))))))));
    vlSelf->wasmetal_core__DOT___054959_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f6c8a95__0)))));
    vlSelf->__VdfgTmp_h2e0ea116__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h1ad74d3e__0));
    vlSelf->wasmetal_core__DOT___048597_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4403b5cc__0))))))));
    vlSelf->wasmetal_core__DOT___054820_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha84b0b95__0)))));
    vlSelf->__VdfgTmp_h6ee5998b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0));
    vlSelf->wasmetal_core__DOT___007692_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0))))));
    vlSelf->wasmetal_core__DOT___048602_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2d637bc4__0))))))));
    vlSelf->wasmetal_core__DOT___054865_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h136edfac__0)))));
    vlSelf->__VdfgTmp_h5ba532b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc530df9f__0));
    vlSelf->wasmetal_core__DOT___007703_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc530df9f__0))))));
    vlSelf->wasmetal_core__DOT___048656_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1bd58642__0))))))));
    vlSelf->wasmetal_core__DOT___055518_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054909_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h127745a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h0e7ef094__0));
    vlSelf->wasmetal_core__DOT___048614_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h339d407e__0))))))));
    vlSelf->wasmetal_core__DOT___054781_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h10697dc9__0)))));
    vlSelf->__VdfgTmp_h88de5544__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h782800f0__0));
    vlSelf->wasmetal_core__DOT___007679_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h782800f0__0))))));
    vlSelf->wasmetal_core__DOT___063773_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd72e8ff__0)))));
    vlSelf->wasmetal_core__DOT___054958_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd72e8ff__0)))));
    vlSelf->wasmetal_core__DOT___007730_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h707c99af__0))))));
    vlSelf->wasmetal_core__DOT___007603_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h707c99af__0))))));
    vlSelf->wasmetal_core__DOT___055651_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h7146d025__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0));
    vlSelf->wasmetal_core__DOT___007623_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0))))));
    vlSelf->wasmetal_core__DOT___048609_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8aa65d09__0))))))));
    vlSelf->__VdfgTmp_ha292c154__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hf6ccaf8c__0));
    vlSelf->wasmetal_core__DOT___007505_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(
                                                      (0x33ff55ff0fff0fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf6ccaf8c__0)))))));
    vlSelf->__VdfgTmp_h6ad9b652__0 = (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054674_));
    vlSelf->wasmetal_core__DOT___055332_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054674_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___063774_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc2efa860__0)))));
    vlSelf->wasmetal_core__DOT___048626_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc2efa860__0))))))));
    vlSelf->wasmetal_core__DOT___063772_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c8699d0__0))))))));
    vlSelf->wasmetal_core__DOT___055044_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5c8699d0__0)))));
    vlSelf->__VdfgTmp_h6127a0a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0));
    vlSelf->wasmetal_core__DOT___007644_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0))))));
    vlSelf->wasmetal_core__DOT___055496_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h8f363e22__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h79bfec12__0));
    vlSelf->wasmetal_core__DOT___007707_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h79bfec12__0))))));
    vlSelf->wasmetal_core__DOT___054816_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h633a8051__0)))));
    vlSelf->__VdfgTmp_hd1dc222f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h4f29d017__0));
    vlSelf->wasmetal_core__DOT___007691_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4f29d017__0))))));
    vlSelf->wasmetal_core__DOT___061924_ = (1U & (IData)(
                                                         (0x5533fffff0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056967_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056983_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___012262_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056967_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___054860_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h18ff28cf__0)))));
    vlSelf->__VdfgTmp_h41aaabca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0));
    vlSelf->wasmetal_core__DOT___007567_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0))))));
    vlSelf->wasmetal_core__DOT___012395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___063778_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7cf17ecc__0)))));
    vlSelf->wasmetal_core__DOT___054906_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51fc7bb2__0)))));
    vlSelf->wasmetal_core__DOT___007472_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0))))));
    vlSelf->wasmetal_core__DOT___007587_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0))))));
    vlSelf->wasmetal_core__DOT___055593_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054956_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007484_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb18976f4__0))))));
    vlSelf->wasmetal_core__DOT___007601_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb18976f4__0))))));
    vlSelf->wasmetal_core__DOT___055649_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hbda9acd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hab3c597f__0));
    vlSelf->wasmetal_core__DOT___007621_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hab3c597f__0))))));
    vlSelf->wasmetal_core__DOT___011749_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hc86399cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h5c5b87f4__0));
    vlSelf->wasmetal_core__DOT___007677_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                                  & (IData)(
                                                            (0x33ff55ff0fff0fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c5b87f4__0))))))));
    vlSelf->__VdfgTmp_hff6b6a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054777_));
    vlSelf->wasmetal_core__DOT___055371_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___056542_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054675_)))));
    vlSelf->wasmetal_core__DOT___007518_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he6e69fea__0)))))));
    vlSelf->__VdfgTmp_h52f4f13a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_he6e69fea__0));
    vlSelf->wasmetal_core__DOT___063742_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h23f02d0a__0))))))));
    vlSelf->wasmetal_core__DOT___054688_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h23f02d0a__0)))));
    vlSelf->wasmetal_core__DOT___050411_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050407_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d))));
    vlSelf->wasmetal_core__DOT___055676_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h62d1863a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hde24342a__0));
    vlSelf->wasmetal_core__DOT___007642_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hde24342a__0))))));
    vlSelf->wasmetal_core__DOT___054770_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb12ee9bf__0)))));
    vlSelf->__VdfgTmp_h5a84499c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_heeb73844__0));
    vlSelf->__VdfgTmp_hd5802a9c__0 = ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                              & (IData)(
                                                        (0x33ff55ff0fff0fffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_heeb73844__0))))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                         & (IData)(
                                                   (0x33ff55ff0fff0fffULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h898c2bb0__0))))))));
    vlSelf->wasmetal_core__DOT___063744_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2b26e01__0))))))));
    vlSelf->wasmetal_core__DOT___048763_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2b26e01__0))))))));
    vlSelf->wasmetal_core__DOT___055425_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007260_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0))))));
    vlSelf->wasmetal_core__DOT___007544_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0))))));
    vlSelf->wasmetal_core__DOT___055495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007287_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0))))));
    vlSelf->wasmetal_core__DOT___007565_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0))))));
    vlSelf->wasmetal_core__DOT___048748_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h63a6348e__0))))))));
    vlSelf->wasmetal_core__DOT___055515_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054900_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hd6444f5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h6277318a__0));
    vlSelf->wasmetal_core__DOT___063748_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9eae91ba__0))))))));
    vlSelf->wasmetal_core__DOT___048745_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9eae91ba__0))))))));
    vlSelf->wasmetal_core__DOT___063758_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h52bd55da__0))))))));
    vlSelf->wasmetal_core__DOT___054950_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h52bd55da__0)))));
    vlSelf->wasmetal_core__DOT___007347_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0))))));
    vlSelf->wasmetal_core__DOT___007599_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0))))));
    vlSelf->wasmetal_core__DOT___048534_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76527ded__0))))))));
    vlSelf->wasmetal_core__DOT___063763_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h979ce723__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4f39dfcd__0)))))))))));
    vlSelf->wasmetal_core__DOT___054989_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h979ce723__0)))));
    vlSelf->wasmetal_core__DOT___007373_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf65e04e__0))))));
    vlSelf->wasmetal_core__DOT___055370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054769_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007233_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0))))));
    vlSelf->wasmetal_core__DOT___007524_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0))))));
    vlSelf->wasmetal_core__DOT___007520_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd68176c7__0)))))));
    vlSelf->__VdfgTmp_h42498a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hd68176c7__0));
    vlSelf->__VdfgTmp_ha89e6386__0 = (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054698_));
    vlSelf->wasmetal_core__DOT___055328_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055674_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007399_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ce01618__0))))));
    vlSelf->wasmetal_core__DOT___007640_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ce01618__0))))));
    vlSelf->wasmetal_core__DOT___055519_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054908_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007719_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0))))));
    vlSelf->wasmetal_core__DOT___007589_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0))))));
    vlSelf->wasmetal_core__DOT___061999_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057205_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057127_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057129_)))))))));
    vlSelf->wasmetal_core__DOT___012412_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057129_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___055516_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054907_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hffa75465__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h692f01d1__0));
    vlSelf->wasmetal_core__DOT___012581_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___063767_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h98d262dd__0))))))));
    vlSelf->wasmetal_core__DOT___055592_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054957_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h40b73a73__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc03ee7e3__0));
    vlSelf->wasmetal_core__DOT___055648_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hc57757c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h437f0271__0));
    vlSelf->wasmetal_core__DOT___007744_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h437f0271__0))))));
    vlSelf->wasmetal_core__DOT___061861_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056730_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056745_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056768_)))))))));
    vlSelf->wasmetal_core__DOT___063799_ = (1U & (0x90U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xb0bb00000000b0bbULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h22b2afd4__0))))))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5f6c8a95__0))));
    vlSelf->wasmetal_core__DOT___054818_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1eef7f72__0)))));
    vlSelf->__VdfgTmp_h15014ab6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0));
    vlSelf->wasmetal_core__DOT___007548_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0))))));
    vlSelf->wasmetal_core__DOT___054863_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdb184deb__0)))));
    vlSelf->__VdfgTmp_h4fcd3c01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb918ea35__0));
    vlSelf->wasmetal_core__DOT___007569_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb918ea35__0))))));
    vlSelf->wasmetal_core__DOT___061771_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056597_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056599_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011458_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056623_)))))))));
    vlSelf->wasmetal_core__DOT___055374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h43b9ff93__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hd5b1a253__0));
    vlSelf->wasmetal_core__DOT___007678_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(
                                                      (0x33ff55ff0fff0fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd5b1a253__0)))))));
    vlSelf->wasmetal_core__DOT___061659_ = (1U & (IData)(
                                                         (0xf0f0f0f03355ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056501_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056336_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d)))))))));
    vlSelf->__VdfgTmp_h73cf3648__0 = (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054692_))));
    vlSelf->wasmetal_core__DOT___007517_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h63aeb1f3__0)))))));
    vlSelf->__VdfgTmp_hd1bccf33__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h63aeb1f3__0));
    vlSelf->wasmetal_core__DOT___063768_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h73150903__0))))))));
    vlSelf->wasmetal_core__DOT___054682_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h73150903__0)))));
    vlSelf->wasmetal_core__DOT___044034_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050408_))));
    vlSelf->wasmetal_core__DOT___050410_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050408_))));
    vlSelf->wasmetal_core__DOT___062169_ = (1U & (IData)(
                                                         (0x3355fffff0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057571_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___057574_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))))))));
    vlSelf->wasmetal_core__DOT___055675_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h4a43ab44__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb69256f0__0));
    vlSelf->wasmetal_core__DOT___007759_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb69256f0__0))))));
    vlSelf->wasmetal_core__DOT___007521_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h88a0444f__0)))))));
    vlSelf->__VdfgTmp_h3caf5d97__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h88a0444f__0));
    vlSelf->wasmetal_core__DOT___054701_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h691e257b__0)))));
    vlSelf->wasmetal_core__DOT___055422_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007257_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb98e230__0))))));
    vlSelf->wasmetal_core__DOT___055492_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007284_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h86c1a93d__0))))));
    vlSelf->wasmetal_core__DOT___012411_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___063762_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb14b0648__0)))));
    vlSelf->wasmetal_core__DOT___048834_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb14b0648__0))));
    vlSelf->wasmetal_core__DOT___054898_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha853ba7f__0)))));
    vlSelf->__VdfgTmp_he34a288c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0));
    vlSelf->wasmetal_core__DOT___055073_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0))))));
    vlSelf->wasmetal_core__DOT___012580_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057290_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___048810_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h491e13b5__0))));
    vlSelf->wasmetal_core__DOT___055588_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007344_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdc49a285__0))))));
    vlSelf->wasmetal_core__DOT___063757_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h691e257b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf41e7ecd__0)))))))))));
    vlSelf->wasmetal_core__DOT___054988_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf41e7ecd__0)))));
    vlSelf->wasmetal_core__DOT___007370_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h84d68e3f__0))))));
    vlSelf->wasmetal_core__DOT___011748_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___055367_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054768_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007230_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7751d301__0))))));
    vlSelf->wasmetal_core__DOT___063734_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2112a96a__0))))))));
    vlSelf->wasmetal_core__DOT___048737_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2112a96a__0))));
    vlSelf->wasmetal_core__DOT___007522_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7c46a142__0)))))));
    vlSelf->__VdfgTmp_h2814f082__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h7c46a142__0));
    vlSelf->wasmetal_core__DOT___054705_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf440d852__0)))));
    vlSelf->wasmetal_core__DOT___055671_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007396_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb4659c85__0))))));
    vlSelf->wasmetal_core__DOT___052816_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052811_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003150_)))))))));
    vlSelf->wasmetal_core__DOT___055033_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc9d89c9c__0)))));
    vlSelf->wasmetal_core__DOT___007397_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a210d44__0))))));
    vlSelf->wasmetal_core__DOT___054807_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51befd44__0)))));
    vlSelf->wasmetal_core__DOT___007258_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8916279c__0))))));
    vlSelf->wasmetal_core__DOT___007285_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce0059e1__0))))));
    vlSelf->wasmetal_core__DOT___012394_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057128_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___063809_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had719570__0)))));
    vlSelf->wasmetal_core__DOT___048875_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_had719570__0))));
    vlSelf->wasmetal_core__DOT___054899_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb8a147e__0)))));
    vlSelf->__VdfgTmp_hc3b7ffa9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0));
    vlSelf->wasmetal_core__DOT___053919_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0))))));
    vlSelf->wasmetal_core__DOT___063811_ = (1U & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc9d89c9c__0)) 
                                                  & (IData)(
                                                            (0x1001000000001001ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h3ce0f075__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf440d852__0))))))))))));
    vlSelf->wasmetal_core__DOT___048883_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3ce0f075__0))));
    vlSelf->wasmetal_core__DOT___007345_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5f14afc9__0))))));
    vlSelf->wasmetal_core__DOT___055645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054987_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007371_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9ebbc558__0))))));
    vlSelf->wasmetal_core__DOT___007231_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890db370__0))))));
    vlSelf->wasmetal_core__DOT___063785_ = (1U & (0xb00bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2a4ee2b9__0)))));
    vlSelf->wasmetal_core__DOT___048794_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a4ee2b9__0))));
    vlSelf->wasmetal_core__DOT___061606_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054706_)))))))));
    vlSelf->__VdfgTmp_h52d73039__0 = (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054709_))));
    vlSelf->wasmetal_core__DOT___007523_ = (1U & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1ccba379__0)))))));
    vlSelf->__VdfgTmp_h8893fd49__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h1ccba379__0));
    vlSelf->__VdfgTmp_hffdded68__0 = (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054708_));
    vlSelf->wasmetal_core__DOT___055327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054708_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hb5b904ce__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hdb4c449f__0));
    vlSelf->wasmetal_core__DOT___008469_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)))));
    vlSelf->wasmetal_core__DOT___061649_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007419_))));
    vlSelf->wasmetal_core__DOT___057602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007419_))));
    vlSelf->wasmetal_core__DOT___063353_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))));
    vlSelf->wasmetal_core__DOT___048661_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))));
    vlSelf->wasmetal_core__DOT___001712_ = (1U & (IData)(
                                                         (0xc0a000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b63__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8696f73b__0)))));
    vlSelf->wasmetal_core__DOT___048002_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8696f73b__0)))));
    vlSelf->wasmetal_core__DOT___062112_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057390_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057384_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057443_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057449_)))))))));
    vlSelf->wasmetal_core__DOT___012965_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___048666_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1867682__0))))))));
    vlSelf->wasmetal_core__DOT___063795_ = (1U & (IData)(
                                                         (0xb00000b00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf9b00456__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha84b0b95__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h136edfac__0))))))));
    vlSelf->wasmetal_core__DOT___055000_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf9b00456__0)))));
    vlSelf->__VdfgTmp_h855fc881__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h83a675b5__0));
    vlSelf->wasmetal_core__DOT___007740_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h83a675b5__0))))));
    vlSelf->wasmetal_core__DOT___050421_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050416_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044035_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044036_)))));
    vlSelf->wasmetal_core__DOT___055677_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055046_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h1fccf85f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h0919a607__0));
    vlSelf->wasmetal_core__DOT___007755_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0919a607__0))))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___005429_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b62__05d)));
        vlSelf->wasmetal_core__DOT___048205_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b61__05d)));
        vlSelf->wasmetal_core__DOT___048166_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b60__05d)));
        vlSelf->wasmetal_core__DOT___048164_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b58__05d)));
        vlSelf->wasmetal_core__DOT___048049_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b54__05d)));
        vlSelf->wasmetal_core__DOT___048062_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b53__05d)));
        vlSelf->wasmetal_core__DOT___048051_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b52__05d)));
    } else if (vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) {
        vlSelf->wasmetal_core__DOT___005429_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005457_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005456_)))));
        vlSelf->wasmetal_core__DOT___048205_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005420_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005419_)))));
        vlSelf->wasmetal_core__DOT___048166_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005410_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005409_)))));
        vlSelf->wasmetal_core__DOT___048164_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005390_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005389_)))));
        vlSelf->wasmetal_core__DOT___048049_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005487_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005486_)))));
        vlSelf->wasmetal_core__DOT___048062_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005477_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005476_)))));
        vlSelf->wasmetal_core__DOT___048051_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005467_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005466_)))));
    } else {
        vlSelf->wasmetal_core__DOT___005429_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd81cbf50__0))));
        vlSelf->wasmetal_core__DOT___048205_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h65f01eca__0))));
        vlSelf->wasmetal_core__DOT___048166_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb5adad38__0))));
        vlSelf->wasmetal_core__DOT___048164_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5dfa9ecf__0))));
        vlSelf->wasmetal_core__DOT___048049_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd852066e__0))));
        vlSelf->wasmetal_core__DOT___048062_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5779821b__0))));
        vlSelf->wasmetal_core__DOT___048051_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h63c99640__0))));
    }
    vlSelf->__VdfgTmp_h6b2c9c37__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005456_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005457_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048172_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048171_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048170_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048169_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd81cbf50__0))))))))));
    vlSelf->wasmetal_core__DOT___069163_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010523_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008462_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___057531_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___063351_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46733dea__0))));
    vlSelf->wasmetal_core__DOT___052778_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h46733dea__0)))))))))));
    vlSelf->wasmetal_core__DOT___001317_ = ((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                               & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))))))));
    vlSelf->wasmetal_core__DOT___008461_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b62__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT___005430_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->__VdfgTmp_h9b25c217__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005419_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005420_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048239_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048238_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048241_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048240_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h65f01eca__0))))))))));
    vlSelf->wasmetal_core__DOT___044354_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026990_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026992_)))));
    vlSelf->wasmetal_core__DOT___010518_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4f90e104__0 = (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d)));
    vlSelf->wasmetal_core__DOT___069133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008454_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063349_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0))));
    vlSelf->wasmetal_core__DOT___008453_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b61__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT___048206_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->__VdfgTmp_h651d6523__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005409_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005410_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048184_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048183_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048182_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048181_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb5adad38__0))))))))));
    vlSelf->__VdfgTmp_ha80d5d1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___034505_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034504_));
    vlSelf->wasmetal_core__DOT___010513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h8f6175c0__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d));
    vlSelf->wasmetal_core__DOT___069084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->__VdfgTmp_h504ea901__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd0975535__0));
    vlSelf->wasmetal_core__DOT___054339_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd0975535__0))))));
    vlSelf->wasmetal_core__DOT___063347_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0))));
    vlSelf->wasmetal_core__DOT___008445_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b60__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT___048167_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT___069045_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010500_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hd5d1004a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d));
    vlSelf->wasmetal_core__DOT___069033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008433_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0))));
    vlSelf->wasmetal_core__DOT___008432_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b59__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT___048209_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->__VdfgTmp_h9b410c9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005389_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005390_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048178_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048177_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048180_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048179_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h5dfa9ecf__0))))))))));
    vlSelf->wasmetal_core__DOT___044353_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026986_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026987_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026989_)))));
    vlSelf->wasmetal_core__DOT___068973_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042353_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7b89d77c__0))))))));
    vlSelf->wasmetal_core__DOT___042152_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7b89d77c__0))))))));
    vlSelf->wasmetal_core__DOT___042176_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001080_)))))))));
    vlSelf->wasmetal_core__DOT___010495_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hfe7af35a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d));
    vlSelf->wasmetal_core__DOT___068961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___061472_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007280_))));
    vlSelf->wasmetal_core__DOT___063343_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56116db4__0))));
    vlSelf->wasmetal_core__DOT___008424_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b58__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT___048165_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT___063806_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026851_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026850_)))));
    vlSelf->wasmetal_core__DOT___010572_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068947_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h131eee20__0 = (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d)));
    vlSelf->wasmetal_core__DOT___068935_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008417_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063341_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0))));
    vlSelf->wasmetal_core__DOT___008416_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b57__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT___005431_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT___010597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068903_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h60f9d0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d));
    vlSelf->wasmetal_core__DOT___068891_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008409_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->__VdfgTmp_h528a2190__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hce5bccc4__0));
    vlSelf->wasmetal_core__DOT___054150_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hce5bccc4__0))))));
    vlSelf->wasmetal_core__DOT___063339_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h139d3776__0))));
    vlSelf->wasmetal_core__DOT___008408_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b56__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT___005432_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT___044351_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026983_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026985_)))));
    vlSelf->wasmetal_core__DOT___068856_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042351_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h59235eaf__0))))))));
    vlSelf->wasmetal_core__DOT___042150_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h59235eaf__0))))))));
    vlSelf->wasmetal_core__DOT___042174_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001014_)))))))));
    vlSelf->__VdfgTmp_h1811a1bb__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d)));
    vlSelf->wasmetal_core__DOT___010472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4fe6474e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d));
    vlSelf->wasmetal_core__DOT___068844_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->__VdfgTmp_h2df8dd7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007419_));
    vlSelf->wasmetal_core__DOT___063337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3378cabf__0))));
    vlSelf->wasmetal_core__DOT___008394_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b55__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT___048149_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->__VdfgTmp_hd44758f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005486_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005487_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048047_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048046_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048045_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048044_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd852066e__0))))))))));
    vlSelf->__VdfgTmp_h2f9ca2ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___010529_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010528_));
    vlSelf->wasmetal_core__DOT___068801_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h74f7a068__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d)));
    vlSelf->wasmetal_core__DOT___010467_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h67451104__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d));
    vlSelf->wasmetal_core__DOT___068789_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008387_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008386_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha541df85__0)))));
    vlSelf->__VdfgTmp_h447558a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007392_));
    vlSelf->wasmetal_core__DOT___063335_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))));
    vlSelf->wasmetal_core__DOT___048621_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b54__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8df5578a__0)))));
    vlSelf->wasmetal_core__DOT___048050_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8df5578a__0)))));
    vlSelf->__VdfgTmp_hadae1421__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005476_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005477_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048060_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048059_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048058_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048057_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h5779821b__0))))))))));
    vlSelf->wasmetal_core__DOT___010534_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068757_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010462_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4575751b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d)));
    vlSelf->wasmetal_core__DOT___068745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008379_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063807_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___026854_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___026852_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___026849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___026848_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha541df85__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_heb331328__0)))))))))));
    vlSelf->wasmetal_core__DOT___008378_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb331328__0)))));
    vlSelf->__VdfgTmp_h372c3d93__0 = (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007366_));
    vlSelf->wasmetal_core__DOT___063333_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))));
    vlSelf->wasmetal_core__DOT___048638_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b53__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0)))));
    vlSelf->wasmetal_core__DOT___048063_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0)))));
    vlSelf->__VdfgTmp_he4dfb545__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005466_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005467_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048043_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048042_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048041_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048040_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h63c99640__0))))))))));
    vlSelf->wasmetal_core__DOT___044350_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026980_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026982_)))));
    vlSelf->wasmetal_core__DOT___068708_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042350_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h388edf60__0))))))));
    vlSelf->wasmetal_core__DOT___042149_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h388edf60__0))))))));
    vlSelf->wasmetal_core__DOT___042173_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001327_)))))))));
    vlSelf->wasmetal_core__DOT___010457_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h1a9e6a0c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___068696_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008371_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008370_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)))));
    vlSelf->__VdfgTmp_h3c09d3eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h2cdc7e5b__0));
    vlSelf->wasmetal_core__DOT___063331_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))));
    vlSelf->wasmetal_core__DOT___048633_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b52__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0)))));
    vlSelf->wasmetal_core__DOT___048052_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0)))));
    vlSelf->wasmetal_core__DOT___068665_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068645_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068638_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068637_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80b000fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066579_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065009_)))))))))))))));
    vlSelf->__VdfgTmp_he2e0905c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010538_));
    vlSelf->wasmetal_core__DOT___063812_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbf523586__0))))));
    vlSelf->wasmetal_core__DOT___008357_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf523586__0)))));
    vlSelf->__VdfgTmp_hb4c136ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007307_));
    vlSelf->wasmetal_core__DOT___063329_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))));
    vlSelf->wasmetal_core__DOT___047924_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b51__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0)))));
    vlSelf->wasmetal_core__DOT___005514_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0)))));
    vlSelf->__VdfgTmp_hf37b3ae8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010538_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010537_));
    vlSelf->wasmetal_core__DOT___008349_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h379ad787__0)))));
    vlSelf->wasmetal_core__DOT___061470_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007281_))));
    vlSelf->__VdfgTmp_h797b2590__0 = (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007280_));
    vlSelf->wasmetal_core__DOT___063327_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))));
    vlSelf->wasmetal_core__DOT___047917_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b50__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hb40a316f__0)))));
    vlSelf->wasmetal_core__DOT___005816_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b50__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005546_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005545_))))))))));
    vlSelf->wasmetal_core__DOT___044349_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026976_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026978_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026979_)))));
    vlSelf->__VdfgTmp_h3c2b613a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010540_));
    vlSelf->wasmetal_core__DOT___008341_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h375e931a__0)))));
    vlSelf->__VdfgTmp_hca913760__0 = (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007253_));
    vlSelf->wasmetal_core__DOT___063325_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))));
    vlSelf->wasmetal_core__DOT___047933_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b49__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0)))));
    vlSelf->wasmetal_core__DOT___005903_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b49__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005538_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005537_))))))))));
    vlSelf->wasmetal_core__DOT___068516_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068513_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068512_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xef00efefULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068506_) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068505_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064360_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___010541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008333_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)))));
    vlSelf->__VdfgTmp_hc859778d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h38ad22b9__0));
    vlSelf->wasmetal_core__DOT___063323_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))));
    vlSelf->wasmetal_core__DOT___047941_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b48__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0)))));
    vlSelf->wasmetal_core__DOT___005823_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b48__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005656_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005655_))))))))));
    vlSelf->wasmetal_core__DOT___050413_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050412_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))))))));
    vlSelf->wasmetal_core__DOT___008318_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)))));
    vlSelf->wasmetal_core__DOT___007422_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007417_))))));
    vlSelf->wasmetal_core__DOT___063321_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT___047861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b47__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hac359f24__0)))));
    vlSelf->wasmetal_core__DOT___006274_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hac359f24__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b47__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005526_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005525_))))))))));
    vlSelf->wasmetal_core__DOT___044348_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026973_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026974_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026975_)))));
    vlSelf->wasmetal_core__DOT___008310_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb948b455__0)))));
    vlSelf->wasmetal_core__DOT___007395_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007390_))))));
    vlSelf->wasmetal_core__DOT___057497_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___063319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h132c3402__0))));
    vlSelf->wasmetal_core__DOT___047857_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h132c3402__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b46__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h132c3402__0)))));
    vlSelf->wasmetal_core__DOT___006226_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b46__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005522_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005521_))))))))));
    vlSelf->wasmetal_core__DOT___068339_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068335_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054211_)))))));
    vlSelf->wasmetal_core__DOT___008302_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))));
    vlSelf->wasmetal_core__DOT___007369_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007364_))))));
    vlSelf->wasmetal_core__DOT___063317_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))));
    vlSelf->wasmetal_core__DOT___047839_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b45__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h82148a8f__0)))));
    vlSelf->wasmetal_core__DOT___006151_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b45__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005562_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005561_))))))))));
    vlSelf->wasmetal_core__DOT___008294_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))));
    vlSelf->wasmetal_core__DOT___007338_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7678d7b9__0))))));
    vlSelf->wasmetal_core__DOT___063315_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))));
    vlSelf->wasmetal_core__DOT___047847_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b44__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h33528dbb__0)))));
    vlSelf->wasmetal_core__DOT___006178_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b44__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005518_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005517_))))))))));
    vlSelf->wasmetal_core__DOT___044347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026970_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026971_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026972_)))));
    vlSelf->wasmetal_core__DOT___008281_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)))));
    vlSelf->__VdfgTmp_hfcd73105__0 = (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007307_));
    vlSelf->wasmetal_core__DOT___007310_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007305_))))));
    vlSelf->wasmetal_core__DOT___063313_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))));
    vlSelf->wasmetal_core__DOT___047897_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b43__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0)))));
    vlSelf->wasmetal_core__DOT___006058_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b43__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005509_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005508_))))))))));
    vlSelf->wasmetal_core__DOT___008273_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h483290db__0)))));
    vlSelf->wasmetal_core__DOT___061466_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007278_))));
    vlSelf->__VdfgTmp_h05777dd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007280_));
    vlSelf->wasmetal_core__DOT___007283_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007278_))))));
    vlSelf->wasmetal_core__DOT___063311_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))));
    vlSelf->wasmetal_core__DOT___047905_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b42__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0)))));
    vlSelf->wasmetal_core__DOT___006044_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b42__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005505_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005504_))))))))));
    vlSelf->wasmetal_core__DOT___008265_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)))));
    vlSelf->__VdfgTmp_hf1275c5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007253_));
    vlSelf->__VdfgTmp_hf8957689__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007251_))));
    vlSelf->wasmetal_core__DOT___063309_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))));
    vlSelf->wasmetal_core__DOT___047887_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b41__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9963adf9__0)))));
    vlSelf->wasmetal_core__DOT___006029_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b41__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005530_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005529_))))))))));
    vlSelf->wasmetal_core__DOT___044346_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026967_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026969_)))));
    vlSelf->wasmetal_core__DOT___010781_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008257_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))));
    vlSelf->wasmetal_core__DOT___007770_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81bae7c4__0))))));
    vlSelf->wasmetal_core__DOT___063307_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc231438f__0))));
    vlSelf->wasmetal_core__DOT___047879_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc231438f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b40__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc231438f__0)))));
    vlSelf->wasmetal_core__DOT___006051_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b40__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005534_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005533_))))))))));
    vlSelf->wasmetal_core__DOT___068039_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068017_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068016_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068010_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068009_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x7033U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065484_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065493_)))))))))))))));
    vlSelf->wasmetal_core__DOT___008243_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h877e6c65__0)))));
    vlSelf->wasmetal_core__DOT___063305_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))));
    vlSelf->wasmetal_core__DOT___047819_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b39__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0)))));
    vlSelf->wasmetal_core__DOT___005948_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b39__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005566_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005565_))))))))));
    vlSelf->wasmetal_core__DOT___050434_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050428_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___008235_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h218f194f__0)))));
    vlSelf->wasmetal_core__DOT___063303_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))));
    vlSelf->wasmetal_core__DOT___047827_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b38__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0)))));
    vlSelf->wasmetal_core__DOT___005809_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b38__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005550_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005549_))))))))));
    vlSelf->wasmetal_core__DOT___044345_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026963_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026965_)))));
    vlSelf->wasmetal_core__DOT___008227_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))));
    vlSelf->wasmetal_core__DOT___010140_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007364_)))))))));
    vlSelf->wasmetal_core__DOT___063301_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))));
    vlSelf->wasmetal_core__DOT___047809_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b37__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0)))));
    vlSelf->wasmetal_core__DOT___005882_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b37__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005542_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005541_))))))))));
    vlSelf->wasmetal_core__DOT___052801_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___034487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___034486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___034481_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___034502_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___034480_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___034503_)))))))));
    vlSelf->wasmetal_core__DOT___008219_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))));
    vlSelf->wasmetal_core__DOT___063299_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))));
    vlSelf->wasmetal_core__DOT___047800_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b36__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0)))));
    vlSelf->wasmetal_core__DOT___005802_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b36__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005558_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005557_))))))))));
    vlSelf->wasmetal_core__DOT___063792_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb0eafd09__0))))));
    vlSelf->wasmetal_core__DOT___008206_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)))));
    vlSelf->__VdfgTmp_h37472320__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007305_));
    vlSelf->wasmetal_core__DOT___063297_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))));
    vlSelf->wasmetal_core__DOT___048686_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b35__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0)))));
    vlSelf->wasmetal_core__DOT___005955_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b35__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005648_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005647_))))))))));
    vlSelf->wasmetal_core__DOT___044344_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026960_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026961_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026962_)))));
    vlSelf->wasmetal_core__DOT___008198_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)))));
    vlSelf->wasmetal_core__DOT___061464_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007279_))));
    vlSelf->__VdfgTmp_h05980b33__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007278_));
    vlSelf->wasmetal_core__DOT___063295_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))));
    vlSelf->wasmetal_core__DOT___048915_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b34__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0)))));
    vlSelf->wasmetal_core__DOT___005788_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b34__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005660_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005659_))))))))));
    vlSelf->__VdfgTmp_h312c1c6b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005651_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005652_));
    vlSelf->wasmetal_core__DOT___063791_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4bc445dd__0))))));
    vlSelf->wasmetal_core__DOT___008190_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)))));
    vlSelf->__VdfgTmp_h860ce20a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007251_));
    vlSelf->__VdfgTmp_h3a577ede__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007252_))));
    vlSelf->wasmetal_core__DOT___063293_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))));
    vlSelf->wasmetal_core__DOT___048910_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))))))));
    vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b33__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0)))));
    vlSelf->wasmetal_core__DOT___005653_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0)))));
    vlSelf->wasmetal_core__DOT___067614_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067590_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067589_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbf00bfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067582_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064447_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019407_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___011605_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008182_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h80fb591c__0)))));
    vlSelf->wasmetal_core__DOT___061465_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007252_))));
    vlSelf->wasmetal_core__DOT___063287_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))));
    vlSelf->wasmetal_core__DOT___048908_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))))));
    vlSelf->wasmetal_core__DOT___001774_ = ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                               & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9a79492f__0)))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b32__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9a79492f__0)))));
    vlSelf->wasmetal_core__DOT___005795_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b32__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005554_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005553_))))))))));
    vlSelf->wasmetal_core__DOT___067543_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))));
    vlSelf->wasmetal_core__DOT___045828_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x19U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h946ed16f__0))))))));
    vlSelf->wasmetal_core__DOT___069234_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053923_))));
    vlSelf->wasmetal_core__DOT___026478_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053923_))));
    vlSelf->wasmetal_core__DOT___044343_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026957_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026958_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026959_)))));
    vlSelf->wasmetal_core__DOT___063805_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h80fb591c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6a330ca__0))))));
    vlSelf->wasmetal_core__DOT___008168_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd6a330ca__0)))));
    vlSelf->wasmetal_core__DOT___061650_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007414_)))));
    vlSelf->wasmetal_core__DOT___057671_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007414_))));
    vlSelf->wasmetal_core__DOT___028244_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT___063281_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT___001735_ = ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                               & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0)))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b31__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT___005711_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))))) 
                                                  & (IData)(
                                                            (0xff00ff00ff1fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005572_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005571_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h92d236ac__0))))))));
    vlSelf->wasmetal_core__DOT___044503_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_had9a86ff__0))))))));
    vlSelf->wasmetal_core__DOT___045816_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x18U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x1bU)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had9a86ff__0)))))));
    vlSelf->wasmetal_core__DOT___069160_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053954_))));
    vlSelf->wasmetal_core__DOT___026477_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053954_))));
    vlSelf->wasmetal_core__DOT___063938_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->wasmetal_core__DOT___010159_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008161_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___057461_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007387_))));
    vlSelf->wasmetal_core__DOT___009780_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007391_)))))))));
    vlSelf->wasmetal_core__DOT___028243_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___063275_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___008160_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hec1752e3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b30__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___069141_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053953_))));
    vlSelf->wasmetal_core__DOT___026475_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053953_))));
    vlSelf->wasmetal_core__DOT___071971_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b20cbca__0))));
    vlSelf->wasmetal_core__DOT___010964_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056436_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___002760_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048848_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb73e868c__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0))))))))))))))));
}
