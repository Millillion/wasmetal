#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__15(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__15\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___049890_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049887_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049886_))));
    vlSelf->wasmetal_core__DOT___051522_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051521_))));
    vlSelf->wasmetal_core__DOT___051290_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049619_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051289_))));
    vlSelf->wasmetal_core__DOT___051632_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051631_))));
    vlSelf->wasmetal_core__DOT___049801_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049798_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049797_))));
    vlSelf->wasmetal_core__DOT___051368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049797_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051367_))));
    vlSelf->wasmetal_core__DOT___051115_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051114_))));
    vlSelf->wasmetal_core__DOT___051615_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051614_))));
    vlSelf->wasmetal_core__DOT___049709_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049702_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049701_))));
    vlSelf->wasmetal_core__DOT___051328_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051327_))));
    vlSelf->wasmetal_core__DOT___051551_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050693_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051550_))));
    vlSelf->wasmetal_core__DOT___050697_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050693_))));
    vlSelf->wasmetal_core__DOT___051647_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___050977_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> 
                                                                 (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_habccd4be__0))))))))))));
    vlSelf->wasmetal_core__DOT___049714_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___049630_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))));
    vlSelf->wasmetal_core__DOT___049684_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049465_))));
    vlSelf->wasmetal_core__DOT___049545_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd698a5e2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))));
    vlSelf->wasmetal_core__DOT___066143_ = (1U & (IData)(
                                                         (0xf0fcf0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066135_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066140_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065315_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065313_)))))))))))));
    vlSelf->wasmetal_core__DOT___054052_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054056_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054060_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054064_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028667_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028634_)
            : (IData)(vlSelf->wasmetal_core__DOT___003780_));
    vlSelf->wasmetal_core__DOT____Vcellout___128130___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029079_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029076_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029065_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029054_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029047_ = ((IData)(vlSelf->wasmetal_core__DOT___029079_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___029083_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___029082_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___029081_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___029080_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028979_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028946_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d));
    vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001381_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001381_)
            : (IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128104___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028769_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028768_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028767_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028734_)))));
    vlSelf->wasmetal_core__DOT___028738_ = ((IData)(vlSelf->wasmetal_core__DOT___028770_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT____Vcellout___127884___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026724_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026723_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026718_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026707_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026631_)))));
    vlSelf->wasmetal_core__DOT___026660_ = ((IData)(vlSelf->wasmetal_core__DOT___026724_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT____Vcellout___127935___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027194_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027177_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027101_)))));
    vlSelf->wasmetal_core__DOT___027130_ = ((IData)(vlSelf->wasmetal_core__DOT___027194_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026589_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001444_));
    vlSelf->wasmetal_core__DOT____Vcellout___127918___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026994_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026993_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026988_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026977_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026901_)))));
    vlSelf->wasmetal_core__DOT___026930_ = ((IData)(vlSelf->wasmetal_core__DOT___026994_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT____Vcellout___127901___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026766_)))));
    vlSelf->wasmetal_core__DOT___026795_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001381_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___030122_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heaadd324__0)))));
    vlSelf->wasmetal_core__DOT___030282_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heaadd324__0)))));
    vlSelf->wasmetal_core__DOT___030121_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6f4f7aa5__0)))));
    vlSelf->wasmetal_core__DOT___030281_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6f4f7aa5__0)))));
    vlSelf->wasmetal_core__DOT___030120_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4482002c__0)))));
    vlSelf->wasmetal_core__DOT___030276_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4482002c__0)))));
    vlSelf->wasmetal_core__DOT___030119_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5cbe3a9__0)))));
    vlSelf->wasmetal_core__DOT___030265_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5cbe3a9__0)))));
    vlSelf->wasmetal_core__DOT___067596_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063836_))));
    vlSelf->wasmetal_core__DOT___063838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063836_))));
    vlSelf->wasmetal_core__DOT___067320_ = (1U & (IData)(
                                                         (0xf0f00000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065932_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066653_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066980_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067161_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067306_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067350_ = (1U & (IData)(
                                                         (0xf0f00000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067338_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066077_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066775_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067084_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067202_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067336_)))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128231___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030118_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030115_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030104_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030093_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030086_ = ((IData)(vlSelf->wasmetal_core__DOT___030118_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128239___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030254_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030243_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030221_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030190_ = ((IData)(vlSelf->wasmetal_core__DOT___030254_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT___068795_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067971_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068398_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068792_)))))))));
    vlSelf->wasmetal_core__DOT___068702_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067818_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068289_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068699_)))))))));
    vlSelf->wasmetal_core__DOT___068604_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067733_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068151_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068601_)))))))));
    vlSelf->wasmetal_core__DOT___068850_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068028_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068422_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068847_)))))))));
    vlSelf->wasmetal_core__DOT___068751_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067905_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068343_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068748_)))))))));
    vlSelf->wasmetal_core__DOT___068654_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067757_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068236_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068651_)))))))));
    vlSelf->wasmetal_core__DOT___068552_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067667_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068100_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068549_)))))))));
    vlSelf->wasmetal_core__DOT___067821_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066641_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067818_))))));
    vlSelf->wasmetal_core__DOT___067735_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066519_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067733_))))));
    vlSelf->wasmetal_core__DOT___068031_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066887_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___068028_))))));
    vlSelf->wasmetal_core__DOT___067759_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066596_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067757_))))));
    vlSelf->wasmetal_core__DOT___067669_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066393_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067667_))))));
    vlSelf->wasmetal_core__DOT___066888_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065407_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066887_)))));
    vlSelf->wasmetal_core__DOT___065427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065407_))));
    vlSelf->wasmetal_core__DOT___067500_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067499_)))));
    vlSelf->wasmetal_core__DOT___066288_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066263_))));
    vlSelf->wasmetal_core__DOT___066597_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064893_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066596_)))));
    vlSelf->wasmetal_core__DOT___064913_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064893_))));
    vlSelf->wasmetal_core__DOT___065909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065892_))));
    vlSelf->wasmetal_core__DOT___067190_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067189_)))));
    vlSelf->wasmetal_core__DOT___066764_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065178_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066763_)))));
    vlSelf->wasmetal_core__DOT___066088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066073_))));
    vlSelf->wasmetal_core__DOT___067335_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067333_)))));
    vlSelf->wasmetal_core__DOT___066394_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064485_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066393_)))));
    vlSelf->wasmetal_core__DOT___064515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064485_))));
    vlSelf->wasmetal_core__DOT___067071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065694_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067070_)))));
    vlSelf->wasmetal_core__DOT___065711_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065694_))));
    vlSelf->wasmetal_core__DOT___066847_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066846_)))));
    vlSelf->wasmetal_core__DOT___066141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066119_))));
    vlSelf->wasmetal_core__DOT___067468_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066119_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067450_)))));
    vlSelf->wasmetal_core__DOT___065813_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065796_))));
    vlSelf->wasmetal_core__DOT___067149_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065796_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067148_)))));
    vlSelf->wasmetal_core__DOT___066520_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064726_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066519_)))));
    vlSelf->wasmetal_core__DOT___064747_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064726_))));
    vlSelf->wasmetal_core__DOT___066642_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066641_)))));
    vlSelf->wasmetal_core__DOT___065083_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065073_))));
    vlSelf->wasmetal_core__DOT___065943_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065928_))));
    vlSelf->wasmetal_core__DOT___067305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065928_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067303_)))));
    vlSelf->wasmetal_core__DOT___066966_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065598_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066965_)))));
    vlSelf->wasmetal_core__DOT___065623_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065598_))));
    vlSelf->wasmetal_core__DOT___066308_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066307_)))));
    vlSelf->wasmetal_core__DOT___063099_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063095_)))))));
    vlSelf->wasmetal_core__DOT___063105_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063101_)))))));
    vlSelf->wasmetal_core__DOT___063111_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063108_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063107_)))))));
    vlSelf->wasmetal_core__DOT___063117_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063113_)))))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028312_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028247_));
    vlSelf->wasmetal_core__DOT___064933_ = (1U & (0x4fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064918_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0791be06__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x4fff00ff00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063924_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063923_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063909_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h61f75715__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027469_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027388_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127434___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he7a338fa__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022537_)))));
    vlSelf->wasmetal_core__DOT___022565_ = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___013668_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001802_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001798_))));
    vlSelf->wasmetal_core__DOT___013656_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002192_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002189_))));
    vlSelf->__VdfgTmp_h0ed8cd5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002634_));
    vlSelf->wasmetal_core__DOT___058013_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___000144_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001743_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001742_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001741_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001740_))))))));
        vlSelf->wasmetal_core__DOT___002030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002152_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002151_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3fe5e3ea__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___000144_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001744_))));
        vlSelf->wasmetal_core__DOT___002030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002153_))));
    }
    vlSelf->__VdfgTmp_h80016717__0 = (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002636_));
    vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___002473_));
    vlSelf->wasmetal_core__DOT___017283_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013690_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048787_))));
    vlSelf->wasmetal_core__DOT___013694_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001799_))));
    vlSelf->wasmetal_core__DOT___013687_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000141_))));
    vlSelf->wasmetal_core__DOT___061662_ = (1U & (IData)(
                                                         (0xc0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061518_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061517_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048458_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf56802d2__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061510_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha1796962__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048414_)))))))));
    vlSelf->__VdfgTmp_h6c83109e__0 = (((IData)(vlSelf->wasmetal_core__DOT___012176_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012175_));
    vlSelf->wasmetal_core__DOT___071993_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xfff4f4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010574_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha620249b__0)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf0faaccU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h88f91f2d__0)))))));
    vlSelf->wasmetal_core__DOT___011403_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88f91f2d__0)))));
    vlSelf->wasmetal_core__DOT___011184_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h00eaf9c7__0))))));
    vlSelf->wasmetal_core__DOT___056921_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h00eaf9c7__0))))));
    vlSelf->wasmetal_core__DOT___057549_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057048_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057047_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057065_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057066_)))))));
    vlSelf->__VdfgTmp_h31fa1bee__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056281_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056280_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_had4ae229__0)))));
    vlSelf->wasmetal_core__DOT___013167_ = (1U & (IData)(
                                                         (0x30303030000ffaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056925_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056923_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056920_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))))));
    vlSelf->wasmetal_core__DOT___056340_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))))))));
    vlSelf->wasmetal_core__DOT___056174_ = ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                                               & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT___000137_ = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                            & (IData)(
                                                      (1ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002192_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002189_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002188_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___002187_)))))))));
    vlSelf->wasmetal_core__DOT___013658_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002187_))));
    vlSelf->wasmetal_core__DOT___053551_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051763_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050255_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050255_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051305_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051305_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051307_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051307_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050269_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050269_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050272_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050272_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051311_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051311_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051304_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051304_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050273_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050273_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050262_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050262_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051312_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051312_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051530_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051530_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051278_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051278_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050266_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050266_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050140_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050140_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051306_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051306_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051280_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051280_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050276_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050276_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050166_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050166_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051308_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051308_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051283_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051283_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050278_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050278_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050155_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050155_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051310_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051310_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051300_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051300_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051285_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051285_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050274_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050274_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050268_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050268_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051299_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051299_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051282_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051282_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050144_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050144_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051380_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051380_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017815_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013805_))));
    vlSelf->wasmetal_core__DOT___017355_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017273_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))));
    vlSelf->wasmetal_core__DOT___053545_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051751_))));
    vlSelf->wasmetal_core__DOT___013722_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000142_))));
    vlSelf->wasmetal_core__DOT___017383_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013712_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002028_))));
    vlSelf->wasmetal_core__DOT___000135_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001803_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___001802_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___001801_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001800_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001799_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001798_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001797_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___001796_)))))))))));
    vlSelf->wasmetal_core__DOT___013672_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001796_))));
    vlSelf->wasmetal_core__DOT___013635_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002027_))));
    vlSelf->wasmetal_core__DOT___002635_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002885_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002883_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002882_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002884_))))));
    vlSelf->wasmetal_core__DOT___013666_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002471_))));
    vlSelf->wasmetal_core__DOT___000139_ = ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                            & (IData)(
                                                      (0xe00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002471_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))));
    vlSelf->wasmetal_core__DOT___000138_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048789_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048788_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048787_)))))))));
    vlSelf->wasmetal_core__DOT___013654_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048792_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048789_))));
    vlSelf->wasmetal_core__DOT___049722_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049721_))));
    vlSelf->wasmetal_core__DOT___052633_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051691_))));
    vlSelf->wasmetal_core__DOT___053518_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051720_))));
    vlSelf->wasmetal_core__DOT___051889_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051652_))));
    vlSelf->wasmetal_core__DOT___053534_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051741_))));
    vlSelf->wasmetal_core__DOT___052718_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051707_))));
    vlSelf->wasmetal_core__DOT___011915_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf508d85__0))))))));
    vlSelf->__VdfgTmp_h619b0a2b__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_haf508d85__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011912_));
    vlSelf->wasmetal_core__DOT___057134_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056291_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010395_)))));
    vlSelf->wasmetal_core__DOT___012506_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056291_)))))));
    vlSelf->__VdfgTmp_h234e76cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___012383_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056291_));
    vlSelf->wasmetal_core__DOT___056573_ = ((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                               & (IData)(
                                                         (0xfffcff00aaaa0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011207_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011206_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011205_))))))))));
    vlSelf->__VdfgTmp_h77b6db08__0 = ((4U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010395_)));
    vlSelf->wasmetal_core__DOT___057551_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h98e4ab16__0))))))));
    vlSelf->wasmetal_core__DOT___056431_ = (1U & (0xf0f00077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011899_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xccccaaaaf0f000ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011518_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011522_)))))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2790f0bb__0))))));
    vlSelf->wasmetal_core__DOT___017437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013692_))));
    vlSelf->wasmetal_core__DOT___014394_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013648_))));
    vlSelf->wasmetal_core__DOT___051276_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050459_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050458_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050457_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->reset)))))));
    vlSelf->wasmetal_core__DOT___050463_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050459_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050458_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050457_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->reset)))))));
    vlSelf->wasmetal_core__DOT___053571_ = (1U & (IData)(
                                                         (0x1f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053570_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053249_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053569_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053568_)))))))));
    vlSelf->wasmetal_core__DOT___059112_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006204_))));
    vlSelf->wasmetal_core__DOT___059106_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___059153_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___059156_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006215_))))));
    vlSelf->wasmetal_core__DOT___059113_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006085_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049918_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049918_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050492_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050492_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049913_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049913_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051269_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051269_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049945_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049945_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051270_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051270_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050486_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050486_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049925_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049925_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051274_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051274_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051272_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051272_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050494_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050494_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT___014425_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013701_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128648___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001426_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001414_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001382_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001370_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034408_)))));
    vlSelf->wasmetal_core__DOT___034349_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001426_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028872_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028839_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028492_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003632_));
    vlSelf->wasmetal_core__DOT___057941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013670_))));
    vlSelf->wasmetal_core__DOT___051424_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___051919_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___049111_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049100_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049099_))));
    vlSelf->wasmetal_core__DOT___051413_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048980_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050525_))));
    vlSelf->wasmetal_core__DOT___049268_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h32efca0f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049266_))));
    vlSelf->wasmetal_core__DOT___049858_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h40926396__0))))));
    vlSelf->wasmetal_core__DOT___049704_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049485_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0))))));
    vlSelf->wasmetal_core__DOT___049845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049836_))));
    vlSelf->wasmetal_core__DOT___049589_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049459_))));
    vlSelf->wasmetal_core__DOT___053212_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0))))));
    vlSelf->wasmetal_core__DOT___049576_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0))))));
    vlSelf->wasmetal_core__DOT___049622_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049109_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049100_))));
    vlSelf->wasmetal_core__DOT___049000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048981_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048980_))));
    vlSelf->wasmetal_core__DOT___049656_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049258_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h32efca0f__0))))));
    vlSelf->wasmetal_core__DOT___050688_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0))))));
    vlSelf->wasmetal_core__DOT___049488_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049485_))));
    vlSelf->wasmetal_core__DOT___050609_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050602_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049837_))));
    vlSelf->wasmetal_core__DOT___049461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049457_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049456_))));
    vlSelf->wasmetal_core__DOT___051317_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0))))));
    vlSelf->wasmetal_core__DOT___049112_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf7ec4412__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049109_))));
    vlSelf->wasmetal_core__DOT___051414_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048981_))));
    vlSelf->wasmetal_core__DOT___049269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049259_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049258_))));
    vlSelf->wasmetal_core__DOT___053386_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xf0f5533U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052600_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h40926396__0)))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0))))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048680_))))));
    vlSelf->wasmetal_core__DOT___050623_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0))))));
    vlSelf->wasmetal_core__DOT___049711_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97f76463__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0))))));
    vlSelf->wasmetal_core__DOT___051483_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050607_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050602_))));
    vlSelf->wasmetal_core__DOT___049600_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049457_))));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036897_)) 
                 & (0x96U >> (IData)(vlSelf->__VdfgTmp_h79b76beb__0))));
    vlSelf->wasmetal_core__DOT___049577_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2cac88ff__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0))))));
    vlSelf->wasmetal_core__DOT___049631_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049204_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7ec4412__0))))));
    vlSelf->wasmetal_core__DOT___049001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048998_))));
    vlSelf->wasmetal_core__DOT___049662_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049259_))));
    vlSelf->wasmetal_core__DOT___050689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050626_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0))))));
    vlSelf->wasmetal_core__DOT___049519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h97f76463__0))))));
    vlSelf->wasmetal_core__DOT___050610_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050608_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050607_))));
    vlSelf->wasmetal_core__DOT___049473_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049469_))));
    vlSelf->wasmetal_core__DOT___051318_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049562_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2cac88ff__0))))));
    vlSelf->wasmetal_core__DOT___049206_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049204_))));
    vlSelf->wasmetal_core__DOT___051415_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050508_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048999_))));
    vlSelf->wasmetal_core__DOT___049309_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049307_))));
    vlSelf->wasmetal_core__DOT___050628_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050627_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050626_))));
    vlSelf->wasmetal_core__DOT___049712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049516_))));
    vlSelf->wasmetal_core__DOT___051484_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050619_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050608_))));
    vlSelf->wasmetal_core__DOT___049601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049470_))));
    vlSelf->wasmetal_core__DOT___049578_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049562_))));
    vlSelf->wasmetal_core__DOT___049632_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0))))));
    vlSelf->wasmetal_core__DOT___050516_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050509_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050508_))));
    vlSelf->wasmetal_core__DOT___049663_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf18161ea__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049308_))));
    vlSelf->wasmetal_core__DOT___050730_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050627_))));
    vlSelf->wasmetal_core__DOT___049520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049517_))));
    vlSelf->wasmetal_core__DOT___050634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050620_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050619_))));
    vlSelf->wasmetal_core__DOT___049474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049471_))));
    vlSelf->wasmetal_core__DOT___051425_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049575_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049563_))));
    vlSelf->wasmetal_core__DOT___049207_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0))))));
    vlSelf->wasmetal_core__DOT___051416_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050515_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050509_))));
    vlSelf->wasmetal_core__DOT___049310_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049300_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf18161ea__0))))));
    vlSelf->wasmetal_core__DOT___018279_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058550_))));
    vlSelf->wasmetal_core__DOT___058551_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051509_)))));
    vlSelf->wasmetal_core__DOT___050629_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050625_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050624_))));
    vlSelf->wasmetal_core__DOT___051646_ = (1U & (0x5cU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049518_))));
    vlSelf->wasmetal_core__DOT___049513_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___049713_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049518_))));
    vlSelf->wasmetal_core__DOT___051833_ = (1U & (IData)(
                                                         (0xaaccf00000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 5U)) 
                                                           | ((4U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   ((2U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((0xacU 
                                                                      >> 
                                                                      ((2U 
                                                                        & ((0xcaU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0))))) 
                                                                     << 1U)) 
                                                                 | (1U 
                                                                    & (0xacU 
                                                                       >> 
                                                                       ((2U 
                                                                         & ((0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (0xacU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0))))))))))));
    vlSelf->wasmetal_core__DOT___049173_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0))))));
    vlSelf->wasmetal_core__DOT___049629_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0))))));
    vlSelf->wasmetal_core__DOT___051485_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050620_))));
    vlSelf->wasmetal_core__DOT___049683_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049466_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049472_))));
    vlSelf->wasmetal_core__DOT___049467_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049466_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049465_))));
    vlSelf->wasmetal_core__DOT___049661_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049300_))));
    vlSelf->wasmetal_core__DOT___049324_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd698a5e2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049319_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128042___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028116_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028113_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028102_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028091_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028084_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028116_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026482_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128142___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029126_)))));
    vlSelf->wasmetal_core__DOT___029130_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128325___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031048_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031047_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031046_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031045_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031012_)))));
    vlSelf->wasmetal_core__DOT___031016_ = ((IData)(vlSelf->wasmetal_core__DOT___031048_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->__VdfgTmp_h1d3dc22c__0 = ((2U & ((0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h23ac912c__0)))) 
                                             << 1U)) 
                                      | (1U & (0x3500U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011870_)))))));
    vlSelf->wasmetal_core__DOT___057558_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057557_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057067_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057264_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___056728_ = (1U & (0xa030000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056725_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011924_)))))));
    vlSelf->wasmetal_core__DOT___012806_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056720_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056721_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056725_)))))));
    vlSelf->wasmetal_core__DOT___056775_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011923_)))))));
    if (vlSelf->wasmetal_core__DOT___010721_) {
        if (vlSelf->wasmetal_core__DOT___010722_) {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011924_)));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010842_)));
        } else {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011922_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011921_))));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hdeb472fa__0)));
        }
        vlSelf->wasmetal_core__DOT___012828_ = (1U 
                                                & (0xc4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011923_)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010722_) {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011923_)));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010841_)));
        } else {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h4284cb76__0)));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010727_));
        }
        vlSelf->wasmetal_core__DOT___012828_ = (1U 
                                                & (0xf00ee00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h36a8bb37__0))))));
    }
    vlSelf->wasmetal_core__DOT___012801_ = (1U & (IData)(
                                                         (0xff00aa0f0f0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056440_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcef50cee__0))))))));
    vlSelf->__VdfgTmp_h1d16dec4__0 = (((IData)(vlSelf->wasmetal_core__DOT___011868_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcef50cee__0));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___012548_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011701_));
        vlSelf->wasmetal_core__DOT___057009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___012287_)) 
                                                   & (0xfbfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h8b4e795d__0))))));
        vlSelf->wasmetal_core__DOT___056830_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011998_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011997_)))));
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012295_)));
        } else {
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012044_)));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___012295_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012294_))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___012548_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___011697_)) 
                                                   & (0xf0fbU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010199_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hca8ac9e4__0))))));
        vlSelf->wasmetal_core__DOT___057009_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011701_));
        vlSelf->wasmetal_core__DOT___056830_ = (1U 
                                                & (0xf4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2aa20ca5__0))));
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___012045_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012043_))));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012293_)));
        } else {
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012045_)));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h4a9b748c__0)));
        }
    }
    vlSelf->wasmetal_core__DOT___051295_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049659_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->__VdfgTmp_h03a652de__0 = (((IData)(vlSelf->wasmetal_core__DOT___012798_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012797_));
    vlSelf->wasmetal_core__DOT___010949_ = (1U & (0xf0f05533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011887_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011528_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011381_)))))));
    vlSelf->wasmetal_core__DOT___056351_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056346_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___011854_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011939_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))))))));
    vlSelf->__VdfgTmp_h9d4acb63__0 = (((IData)(vlSelf->wasmetal_core__DOT___012184_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x555533330f0f00ffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0)))));
    vlSelf->wasmetal_core__DOT___011593_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056621_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h29c29c56__0)))))));
    vlSelf->wasmetal_core__DOT___011441_ = (1U & (IData)(
                                                         (0xff555533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h29c29c56__0)))))));
    vlSelf->__VdfgTmp_hf6de1ad3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h29c29c56__0))));
    vlSelf->wasmetal_core__DOT___056211_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056206_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056205_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___011992_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_heb18a766__0)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (((~ (IData)(vlSelf->wasmetal_core__DOT___009833_)) 
                                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___009832_)) 
                                                                    & (IData)(
                                                                              (1ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___009831_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009830_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d)))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (1ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056186_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe9a1cba__0))))))))))))));
    vlSelf->wasmetal_core__DOT___012915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff0f0fff001111ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056725_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf19e2482__0)))))))))));
    vlSelf->wasmetal_core__DOT___012934_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011923_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h36a8bb37__0))))));
    vlSelf->__VdfgTmp_hb331ded8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013143_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013142_));
    vlSelf->__VdfgTmp_hcec95e31__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056801_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056800_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf4d8b80a__0)))));
    vlSelf->wasmetal_core__DOT___012866_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056801_))));
    vlSelf->wasmetal_core__DOT___056647_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056642_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc88b842e__0))))))));
    vlSelf->wasmetal_core__DOT___056831_ = (1U & (IData)(
                                                         (0xff0f11111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056277_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056826_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056825_)))))))));
    vlSelf->wasmetal_core__DOT___057438_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056621_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012749_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h375c9c07__0))))))));
    vlSelf->wasmetal_core__DOT___013100_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056621_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012749_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056375_)))))))));
    vlSelf->wasmetal_core__DOT___056349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d)) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)) 
                                                           & (IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb211d2c2__0))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)) 
                                                            & (IData)(
                                                                      (1ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee315f88__0)))))))))))));
    vlSelf->wasmetal_core__DOT___056177_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009808_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___009807_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xfef0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hee315f88__0))))))))));
    vlSelf->__VdfgTmp_h5164472e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->__VdfgTmp_h8262dffe__0 = (((IData)(vlSelf->wasmetal_core__DOT___010389_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010390_));
    vlSelf->__VdfgTmp_he0f8989d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010390_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010389_));
    vlSelf->wasmetal_core__DOT___057010_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3a025ab3__0))))));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010022_) 
           & (IData)(vlSelf->wasmetal_core__DOT___033452_));
    if (vlSelf->wasmetal_core__DOT___010531_) {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011538_)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011858_)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011858_)));
        } else {
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011539_)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_hbc86843d__0)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_hf996b543__0))));
        }
        vlSelf->wasmetal_core__DOT___011586_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011471_))))));
        vlSelf->wasmetal_core__DOT___011631_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011649_));
        vlSelf->wasmetal_core__DOT___013144_ = vlSelf->wasmetal_core__DOT___011636_;
    } else {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011540_)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (2U >> (IData)(vlSelf->__VdfgTmp_h5fdab2da__0)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (0xdU >> (IData)(vlSelf->__VdfgTmp_h5fdab2da__0)));
            vlSelf->wasmetal_core__DOT___011631_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
        } else {
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h06746976__0)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011859_)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011859_)));
            vlSelf->wasmetal_core__DOT___011631_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011530_)));
        }
        vlSelf->wasmetal_core__DOT___011586_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011470_))))));
        vlSelf->wasmetal_core__DOT___013144_ = vlSelf->wasmetal_core__DOT___011649_;
    }
    vlSelf->__VdfgTmp_h9edc9904__0 = (((IData)(vlSelf->wasmetal_core__DOT___011771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011772_));
    vlSelf->wasmetal_core__DOT___056901_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012179_))));
    vlSelf->wasmetal_core__DOT___072013_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071983_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))))))));
    vlSelf->wasmetal_core__DOT___013041_ = ((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                            & (IData)(
                                                      (0xff00fff0f0eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013047_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xaaaaccccf0f0ff00ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012175_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012176_)))))))));
    vlSelf->wasmetal_core__DOT___013104_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056897_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056898_))))));
    vlSelf->wasmetal_core__DOT___057096_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15546f37__0))));
    vlSelf->wasmetal_core__DOT___012413_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010722_))))));
    vlSelf->wasmetal_core__DOT___012714_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xffaaccf0U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)))))))));
    vlSelf->wasmetal_core__DOT___012582_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xffaaccf0U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010722_))))));
    vlSelf->wasmetal_core__DOT___056424_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0a5eca32__0)))))));
    vlSelf->wasmetal_core__DOT___013145_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011539_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0a5eca32__0)))))));
    vlSelf->wasmetal_core__DOT___011437_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x55330fU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011405_)))))));
    vlSelf->wasmetal_core__DOT___011576_ = (1U & (0xfcf50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xffaaccf0U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011405_)))))));
    if (vlSelf->wasmetal_core__DOT___010722_) {
        vlSelf->wasmetal_core__DOT___011407_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011405_)));
        vlSelf->wasmetal_core__DOT___012420_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010841_)));
        vlSelf->wasmetal_core__DOT___011135_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hdeb472fa__0))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___010727_)));
    } else {
        vlSelf->wasmetal_core__DOT___011407_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)));
        vlSelf->wasmetal_core__DOT___012420_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9c39d480__0)));
        vlSelf->wasmetal_core__DOT___011135_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010720_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010719_))));
    }
    vlSelf->wasmetal_core__DOT___012393_ = (1U & (IData)(
                                                         (0xf0f0ff001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010841_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdeb472fa__0))))))));
    vlSelf->__VdfgTmp_h62b744ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010841_));
    vlSelf->wasmetal_core__DOT___072179_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072177_))));
    vlSelf->wasmetal_core__DOT___012362_ = (1U & (0xddf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012045_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056277_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010124_)))))));
    vlSelf->wasmetal_core__DOT___056640_ = (1U & (IData)(
                                                         (0xf0f0cccc00ff00aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012295_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012294_)))))))));
    vlSelf->wasmetal_core__DOT___012400_ = (1U & (IData)(
                                                         (0xff00ff0f33335555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011831_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1055e951__0)))))));
    vlSelf->__VdfgTmp_h53b21008__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011831_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011472_))));
    vlSelf->wasmetal_core__DOT___012761_ = ((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                            & (IData)(
                                                      (0xff55ff0033330f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012749_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011471_)))))))));
    vlSelf->wasmetal_core__DOT___012185_ = (1U & (IData)(
                                                         (0xaaaacccc00f000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012729_)))))))));
    vlSelf->wasmetal_core__DOT___012878_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011772_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011771_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011962_)))))));
    vlSelf->wasmetal_core__DOT___011185_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010219_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010261_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h744d21e3__0))))))));
    vlSelf->wasmetal_core__DOT___056928_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h744d21e3__0))));
    vlSelf->__VdfgTmp_h64d6559e__0 = ((8U & ((0xe8U 
                                              >> (IData)(vlSelf->__VdfgTmp_h6af19a3e__0)) 
                                             << 3U)) 
                                      | ((4U & ((0xb2U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___033411_)))) 
                                                << 2U)) 
                                         | ((2U & (
                                                   (0x17U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h028857f6__0)) 
                                                   << 1U)) 
                                            | (1U & 
                                               (0x17U 
                                                >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0))))));
    vlSelf->__VdfgTmp_hf95d62e9__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h028857f6__0)))));
    vlSelf->wasmetal_core__DOT___072011_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072002_)))));
    vlSelf->wasmetal_core__DOT___011444_ = (1U & (IData)(
                                                         (0x3300ff0f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056596_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcd2c6110__0)))))));
    vlSelf->__VdfgTmp_h1632b282__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011831_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9484b551__0)))));
    vlSelf->__VdfgTmp_ha12381c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9484b551__0)));
    vlSelf->__VdfgTmp_he9efeda2__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_hda718c9e__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha4e3e772__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h58c9f225__0)))));
    vlSelf->__VdfgTmp_h74dc1f9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58c9f225__0)))));
    vlSelf->wasmetal_core__DOT___050733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050678_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7f4141b2__0))))));
    vlSelf->wasmetal_core__DOT___065163_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051474_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049043_))))));
    vlSelf->wasmetal_core__DOT___050639_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050600_))));
    vlSelf->wasmetal_core__DOT___050532_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050528_))));
    vlSelf->wasmetal_core__DOT___051418_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051412_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051401_))))));
    vlSelf->wasmetal_core__DOT___050713_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050712_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049688_))))));
    vlSelf->wasmetal_core__DOT___049777_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049776_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049775_))));
    vlSelf->wasmetal_core__DOT___051100_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049462_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051044_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049252_))))));
    vlSelf->wasmetal_core__DOT___049871_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049870_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049869_))));
    vlSelf->wasmetal_core__DOT___012868_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056289_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2aa20ca5__0)))))));
    vlSelf->wasmetal_core__DOT___010394_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056289_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8b4e795d__0)))))))))));
    vlSelf->wasmetal_core__DOT___010950_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e559da9__0)))));
    vlSelf->wasmetal_core__DOT___072001_ = (1U & (IData)(
                                                         (0x33330f0f00ff5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011604_)))))))));
    vlSelf->wasmetal_core__DOT___011358_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefe0e1be__0))))));
    vlSelf->__VdfgTmp_h23c0a543__0 = (((IData)(vlSelf->wasmetal_core__DOT___010850_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010849_));
    vlSelf->wasmetal_core__DOT___056475_ = (1U & (0x5f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010850_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha8f305c7__0))))));
    vlSelf->wasmetal_core__DOT___064527_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048330_)))))));
    vlSelf->wasmetal_core__DOT___011765_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010084_))))));
    if (vlSelf->wasmetal_core__DOT___010396_) {
        vlSelf->wasmetal_core__DOT___011176_ = (1U 
                                                & (0xfef0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfff00000eeeeULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011207_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011206_)))))));
        vlSelf->wasmetal_core__DOT___012867_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011962_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011772_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011771_))))));
    } else {
        vlSelf->wasmetal_core__DOT___011176_ = (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h55e24ebb__0))));
        vlSelf->wasmetal_core__DOT___012867_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xfff00000eeee0000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011770_)))));
    }
    vlSelf->wasmetal_core__DOT___010904_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hef0b5c34__0))))));
    vlSelf->wasmetal_core__DOT___010081_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hef0b5c34__0)))));
    vlSelf->wasmetal_core__DOT___057399_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xfff00000eeee0000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011770_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010395_)))));
    vlSelf->wasmetal_core__DOT___056703_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xfffcff0055550000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (0xfff00000eeeeULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011772_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011771_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011770_)))))))));
    vlSelf->__VdfgTmp_h3b3aaa80__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011770_));
    vlSelf->wasmetal_core__DOT___056970_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056931_))));
    vlSelf->__VdfgTmp_h0b76dd71__0 = (((IData)(vlSelf->wasmetal_core__DOT___056931_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056930_));
    vlSelf->wasmetal_core__DOT___050658_ = (1U & (0x3f203f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049049_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049045_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                   << 1U)))))))));
    vlSelf->wasmetal_core__DOT___053662_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051543_))));
    vlSelf->wasmetal_core__DOT___051321_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049690_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->wasmetal_core__DOT___050069_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050064_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050061_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050060_))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___049531_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___050048_)))))))))));
    vlSelf->wasmetal_core__DOT___053195_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050061_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050048_))));
    vlSelf->wasmetal_core__DOT___049387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049371_))));
    vlSelf->wasmetal_core__DOT___066797_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051432_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha128d41e__0)))))));
    vlSelf->wasmetal_core__DOT___051804_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051354_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051461_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050855_))))))));
    vlSelf->wasmetal_core__DOT___053392_ = (1U & (IData)(
                                                         (0xaaccf000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053388_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he62a830e__0)))))));
    vlSelf->wasmetal_core__DOT___053115_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051586_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053111_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049241_))))))));
    vlSelf->wasmetal_core__DOT___050982_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050899_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had82d15e__0)))));
    vlSelf->wasmetal_core__DOT___066633_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049901_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050543_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050544_))))))));
    vlSelf->wasmetal_core__DOT___049802_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049799_))));
    vlSelf->wasmetal_core__DOT___050861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049799_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049798_))));
    vlSelf->wasmetal_core__DOT___051116_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049495_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049507_))));
    vlSelf->wasmetal_core__DOT___049508_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049507_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049506_))));
    vlSelf->wasmetal_core__DOT___051329_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049707_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049702_))));
    vlSelf->wasmetal_core__DOT___050870_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050694_))));
    vlSelf->wasmetal_core__DOT___050698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050696_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050695_))));
    vlSelf->wasmetal_core__DOT___049148_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049146_))));
    vlSelf->wasmetal_core__DOT___051059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049147_))));
    vlSelf->wasmetal_core__DOT___050801_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049751_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049750_))));
    vlSelf->wasmetal_core__DOT___050820_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049888_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049887_))));
    vlSelf->wasmetal_core__DOT___049891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049889_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049888_))));
    vlSelf->wasmetal_core__DOT___050997_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049625_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049620_))));
    vlSelf->wasmetal_core__DOT___049627_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049620_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049619_))));
    vlSelf->wasmetal_core__DOT___056686_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xf4f40000ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)))))))))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___011304_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)));
        vlSelf->wasmetal_core__DOT___010790_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)));
    } else {
        vlSelf->wasmetal_core__DOT___011304_ = (1U 
                                                & (0xfdfU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0xfef0U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                        << 4U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9b5fb542__0))));
        vlSelf->wasmetal_core__DOT___010790_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
                                                   & (0xfdfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9b5fb542__0)))));
    }
    vlSelf->wasmetal_core__DOT___011564_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010232_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056451_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010194_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056450_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011052_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056449_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010188_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056455_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010189_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056454_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010184_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056453_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010185_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056452_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010180_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056459_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010181_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056458_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010216_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056457_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010199_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056456_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010208_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056460_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010206_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___011306_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010165_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___011305_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010159_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___010417_ = (1U & (IData)(
                                                         (0xff00ff00ff0fffdfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h890ba8da__0)))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___011914_ = (1U 
                                                & (IData)(
                                                          (0xffff0000ffffff40ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha28d971c__0)))));
        vlSelf->wasmetal_core__DOT___012631_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011666_)));
    } else {
        vlSelf->wasmetal_core__DOT___011914_ = 0U;
        vlSelf->wasmetal_core__DOT___012631_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010301_)))
                                                    : (IData)(
                                                              (0xbfULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                 << 5U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha28d971c__0))))));
    }
    vlSelf->wasmetal_core__DOT___011913_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011029_));
    vlSelf->wasmetal_core__DOT___012629_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011029_));
    vlSelf->wasmetal_core__DOT___056445_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011030_));
    vlSelf->wasmetal_core__DOT___012630_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011030_));
    vlSelf->wasmetal_core__DOT___056444_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011031_));
    vlSelf->wasmetal_core__DOT___012628_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011031_));
    vlSelf->wasmetal_core__DOT___011035_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011038_));
    vlSelf->wasmetal_core__DOT___012627_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011038_));
    vlSelf->wasmetal_core__DOT___011034_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011039_));
    vlSelf->wasmetal_core__DOT___011566_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011039_));
    vlSelf->wasmetal_core__DOT___011033_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011040_));
    vlSelf->wasmetal_core__DOT___011565_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011040_));
    vlSelf->wasmetal_core__DOT___055188_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5505cc0cff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055186_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010241_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010242_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5f0d294__0)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___055149_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa0acc0cff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055147_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hffef1e62__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h35b20f8b__0)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___055134_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x1111fff000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0549af28__0))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055130_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054814_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054834_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054832_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054813_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054812_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054811_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054825_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hafe0013c__0)))))))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055104_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___057630_ = (1U & (0xeU 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     & (IData)(
                                                               (0xfff0fff0ffff4444ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011603_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011602_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013095_))))))))) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056910_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010721_)))));
    vlSelf->wasmetal_core__DOT___056828_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h86de1fc0__0)))))));
    vlSelf->__VdfgTmp_hca116eb2__0 = ((2U & ((IData)(
                                                     (0xfff4ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012287_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h86de1fc0__0)))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf4f400ff00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3a025ab3__0)))))));
    vlSelf->wasmetal_core__DOT___072143_ = (1U & (0xb2U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab99f676__0))));
    vlSelf->wasmetal_core__DOT___056497_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055199_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d 
        = (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___055309_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT___012805_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056717_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056723_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056722_)))))));
    vlSelf->__VdfgTmp_hf1343531__0 = (((IData)(vlSelf->wasmetal_core__DOT___011936_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011937_));
    vlSelf->__VdfgTmp_h52908d38__0 = (((IData)(vlSelf->wasmetal_core__DOT___011937_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011936_));
    vlSelf->__VdfgTmp_h7f7a7923__0 = (((IData)(vlSelf->wasmetal_core__DOT___012979_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012978_));
    vlSelf->__VdfgTmp_h00c406e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056634_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056635_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056638_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056639_))))));
    vlSelf->__VdfgTmp_h4e50e0f7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)))));
    vlSelf->wasmetal_core__DOT___012616_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056618_))))));
    vlSelf->__VdfgTmp_h1d24e3fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012845_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012799_));
    vlSelf->wasmetal_core__DOT___056803_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011961_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011960_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011962_)))))));
    vlSelf->__VdfgTmp_h703b59c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011961_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011960_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf4d8b80a__0)))));
    if (vlSelf->wasmetal_core__DOT___010395_) {
        vlSelf->wasmetal_core__DOT___012425_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012384_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)))));
        vlSelf->wasmetal_core__DOT___012441_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010393_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0))));
    } else {
        vlSelf->wasmetal_core__DOT___012425_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012373_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012383_)))));
        vlSelf->wasmetal_core__DOT___012441_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012377_)
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012373_))));
    }
    vlSelf->wasmetal_core__DOT___056293_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012373_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012384_)))));
    vlSelf->wasmetal_core__DOT___056932_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056924_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056923_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___055308_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055307_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055306_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055305_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055304_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055303_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055302_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055301_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055300_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055299_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055298_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055297_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055296_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055295_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055294_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055293_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055292_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055291_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055290_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055289_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055288_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055286_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055285_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055284_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055283_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055282_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055281_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055280_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055279_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055278_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055273_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00fff4ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055271_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055112_)))));
    vlSelf->wasmetal_core__DOT___055270_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009780_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___055241_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054806_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054805_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___055221_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d2a78cf__0)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___055219_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haef445c6__0)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134231___B 
        = ((0x38000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039366_))) 
                        << 0xfU)) | ((0x4000U & ((0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                 << 0xeU)) 
                                     | ((0x2000U & 
                                         ((0xf8U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                          << 0xdU)) 
                                        | ((0x1000U 
                                            & ((0xf8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                               << 0xcU)) 
                                           | ((0x800U 
                                               & ((0xf8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                  << 0xbU)) 
                                              | ((0x400U 
                                                  & ((0xf8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                     << 0xaU)) 
                                                 | ((0x200U 
                                                     & ((0xf8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                        << 9U)) 
                                                    | ((0x100U 
                                                        & ((0xf8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                           << 8U)) 
                                                       | ((0x80U 
                                                           & ((0xf8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                              << 7U)) 
                                                          | ((0x40U 
                                                              & ((0xf8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                 << 6U)) 
                                                             | ((0x20U 
                                                                 & ((0xf8U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                    << 5U)) 
                                                                | ((0x10U 
                                                                    & ((0xf8U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                       << 4U)) 
                                                                   | ((8U 
                                                                       & ((0xf8U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                          << 3U)) 
                                                                      | ((4U 
                                                                          & ((0xf8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((0xf8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                                << 1U)) 
                                                                            | (1U 
                                                                               & (0xf8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134230___B 
        = ((0x10000U & ((0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                        << 0x10U)) | ((0x8000U & ((0xf8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((0xfffff888U 
                                            >> (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001568_)))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((0xfffff888U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___001536_)))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((0xfffff888U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001524_)))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((0xfffff888U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___001425_)))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((0xfffff888U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((0xfffff888U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001381_)))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((0xfffff888U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001369_)))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((0xfffff888U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055712_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___001487_)))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xf888fffff888f888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055660_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055606_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055558_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055510_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055467_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127557___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006178_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8744bfbd__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023480_)))));
    vlSelf->wasmetal_core__DOT___023497_ = ((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127574___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013739_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc3924088__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023601_)))));
    vlSelf->wasmetal_core__DOT___023618_ = ((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___049538_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h454dd727__0))));
    vlSelf->wasmetal_core__DOT___050896_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050895_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))))));
    vlSelf->wasmetal_core__DOT___051843_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051467_))));
    vlSelf->wasmetal_core__DOT___053730_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049721_)))));
    vlSelf->wasmetal_core__DOT___053119_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h444aee6e__0))));
    vlSelf->wasmetal_core__DOT___051857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051583_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___051689_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051752_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051751_)))));
    vlSelf->wasmetal_core__DOT___051809_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051348_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051690_)))))));
    vlSelf->wasmetal_core__DOT___051692_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051691_)))));
    vlSelf->wasmetal_core__DOT___051721_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051720_)))));
    vlSelf->wasmetal_core__DOT___051834_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051522_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051719_)))))));
    vlSelf->wasmetal_core__DOT___051780_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051290_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051779_)))));
    vlSelf->wasmetal_core__DOT___051880_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051632_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051708_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049801_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051707_)))));
    vlSelf->wasmetal_core__DOT___051817_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051368_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051706_)))))));
    vlSelf->wasmetal_core__DOT___051764_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051763_)))));
    vlSelf->wasmetal_core__DOT___051866_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051615_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (1U 
                                                                       & (0x53U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___009538_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049709_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051652_)))));
    vlSelf->wasmetal_core__DOT___051795_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051328_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___051651_)))))));
    vlSelf->wasmetal_core__DOT___051849_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051551_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___051650_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051742_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051741_)))));
    vlSelf->wasmetal_core__DOT___051744_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049714_))))))));
    vlSelf->wasmetal_core__DOT___050500_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049630_))))))));
    vlSelf->wasmetal_core__DOT___065165_ = (1U & (IData)(
                                                         (0x7fff7fff7fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065162_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (1U 
                                                                       & (4U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))));
    vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028668_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003632_));
    vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029080_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029047_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028980_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d));
    vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001413_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001413_)
            : (IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045367_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b35__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb8b9c084__0))))))));
    vlSelf->wasmetal_core__DOT___045379_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b37__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b36__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028771_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028738_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___045013_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h57cd27d4__0)))))))))));
    vlSelf->wasmetal_core__DOT___045037_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h57cd27d4__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))))));
    vlSelf->__VdfgTmp_h8a76b5de__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                             >> 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054059_)))));
    vlSelf->wasmetal_core__DOT___045333_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052508_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052505_)))))))));
    vlSelf->wasmetal_core__DOT___045345_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052508_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052190_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052505_)))))))));
    vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026725_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026660_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___054331_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054333_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054335_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027195_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027130_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026590_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001476_));
    vlSelf->wasmetal_core__DOT___054330_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054332_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054328_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054334_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026995_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026930_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___045919_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052253_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h91f69850__0)))))));
    vlSelf->wasmetal_core__DOT___045931_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052474_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052253_)))))))));
    vlSelf->wasmetal_core__DOT___045401_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc8d209ec__0))))));
    vlSelf->wasmetal_core__DOT___045413_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004388_)))))))));
    vlSelf->wasmetal_core__DOT___045874_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004448_)))))))));
    vlSelf->wasmetal_core__DOT___045898_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004374_)))))))));
    vlSelf->wasmetal_core__DOT___045871_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004744_)))))))));
    vlSelf->wasmetal_core__DOT___045895_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004744_)))))))));
    vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026795_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001413_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___064762_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063838_))));
    vlSelf->__VdfgTmp_hcf6e1765__0 = (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___063824_)));
    vlSelf->wasmetal_core__DOT___064907_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___064473_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___064738_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030119_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030086_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030265_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030190_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->wasmetal_core__DOT___067352_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067335_)))));
    vlSelf->wasmetal_core__DOT___067322_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067305_)))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028313_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028248_));
    vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027470_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027393_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b6__05d));
    vlSelf->__VdfgTmp_h2a29372f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h2bad41f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O)))))));
    vlSelf->__VdfgTmp_hfaf781e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->__VdfgTmp_h38639508__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hc23424b0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_h2a096466__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022565_));
    vlSelf->__VdfgTmp_hf8096cfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013668_));
    vlSelf->__VdfgTmp_h13976eb2__0 = (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013656_));
    vlSelf->wasmetal_core__DOT___017344_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013656_))));
    vlSelf->wasmetal_core__DOT___000134_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000148_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___000147_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000145_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000144_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000143_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000141_)))))))))));
    vlSelf->wasmetal_core__DOT___013719_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000148_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000144_))));
    vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___014408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013690_))));
    vlSelf->__VdfgTmp_h009053fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013694_));
    vlSelf->wasmetal_core__DOT___017404_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013694_))));
    vlSelf->__VdfgTmp_h62ff3be8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013687_));
    vlSelf->wasmetal_core__DOT___017345_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013687_))));
    vlSelf->wasmetal_core__DOT___012180_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6c83109e__0))))));
    vlSelf->wasmetal_core__DOT___072014_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071993_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071992_)))));
    vlSelf->__VdfgTmp_h56d07f21__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___071983_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010721_))) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___010722_))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xaaaaf0f0ff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071993_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071992_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071991_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0)))))))))))));
    vlSelf->__VdfgTmp_h39b11875__0 = (((IData)(vlSelf->wasmetal_core__DOT___011404_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011403_));
    vlSelf->wasmetal_core__DOT___011763_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011184_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011183_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011181_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011182_)))))))));
    vlSelf->wasmetal_core__DOT___011192_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011184_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011183_))));
    vlSelf->__VdfgTmp_haa3334f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056921_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056920_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056919_))))));
    vlSelf->wasmetal_core__DOT___017396_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013658_))));
    vlSelf->wasmetal_core__DOT___058816_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005962_))));
    vlSelf->wasmetal_core__DOT___058832_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___058841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005875_))));
    vlSelf->wasmetal_core__DOT___058854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___058842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___058862_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006226_))))));
    vlSelf->wasmetal_core__DOT___058848_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___058828_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006159_))));
    vlSelf->wasmetal_core__DOT___058853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006171_))));
    vlSelf->__VdfgTmp_hc26f8061__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d));
    vlSelf->wasmetal_core__DOT___058845_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005738_))));
    vlSelf->wasmetal_core__DOT___058817_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___058824_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006058_))))));
    vlSelf->wasmetal_core__DOT___058834_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___058838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___058860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005935_))));
    vlSelf->wasmetal_core__DOT___058822_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006085_))));
    vlSelf->wasmetal_core__DOT___058861_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005816_))))));
    vlSelf->wasmetal_core__DOT___058827_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006051_))));
    vlSelf->wasmetal_core__DOT___058847_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006092_))));
    vlSelf->wasmetal_core__DOT___058855_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006400_))))));
    vlSelf->wasmetal_core__DOT___058851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005795_))));
    vlSelf->wasmetal_core__DOT___058850_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006029_))));
    vlSelf->wasmetal_core__DOT___058823_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005982_))))));
    vlSelf->wasmetal_core__DOT___058833_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005903_))))));
    vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127454___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006400_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003808_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022667_)))));
    vlSelf->wasmetal_core__DOT___022671_ = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017401_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013722_))));
    vlSelf->wasmetal_core__DOT___014415_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013712_))));
    vlSelf->wasmetal_core__DOT___057949_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013672_))));
    vlSelf->__VdfgTmp_h563e3bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))));
    vlSelf->wasmetal_core__DOT___017274_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013635_))));
    vlSelf->__VdfgTmp_h0d220f7a__0 = (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013805_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn 
        = ((IData)(vlSelf->wasmetal_core__DOT___002636_) 
           & ((IData)(vlSelf->wasmetal_core__DOT___002635_) 
              & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd5565504__0)))))))));
    vlSelf->wasmetal_core__DOT___017354_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___000136_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___002034_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___002033_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002030_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002029_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___002027_)))))))))));
    vlSelf->wasmetal_core__DOT___013705_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002034_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002030_))));
    vlSelf->wasmetal_core__DOT___014428_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013666_))));
    vlSelf->__VdfgTmp_h41b1ef3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013690_));
    vlSelf->__VdfgTmp_h7d2fcfb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013654_));
    vlSelf->wasmetal_core__DOT___014401_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013654_))));
    vlSelf->wasmetal_core__DOT___053871_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053534_))));
    vlSelf->wasmetal_core__DOT___057196_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057134_))))));
    vlSelf->wasmetal_core__DOT___012427_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057134_))))));
    vlSelf->wasmetal_core__DOT___012440_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012384_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h234e76cf__0))))))));
    vlSelf->wasmetal_core__DOT___056292_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h234e76cf__0))));
    vlSelf->wasmetal_core__DOT___057334_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xbU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h77b6db08__0)))))))));
    vlSelf->wasmetal_core__DOT___057306_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xbU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h77b6db08__0)))))));
    vlSelf->wasmetal_core__DOT___012687_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77b6db08__0)))));
    vlSelf->wasmetal_core__DOT___056443_ = (1U & (7U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xf0f00003355ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011900_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x5cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6a02124a__0))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056428_)))))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056431_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010721_))))));
    vlSelf->wasmetal_core__DOT___019770_ = (1U & (0xffffff70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051277_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->reset) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051276_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))));
    vlSelf->wasmetal_core__DOT___019771_ = (1U & (IData)(
                                                         (0xffffeaffffffc0c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050463_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050362_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb0023997__0))))))));
    vlSelf->wasmetal_core__DOT___019772_ = (1U & (IData)(
                                                         (0xffffeaffffffc0c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050463_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050447_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050362_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb0023997__0))))))));
    vlSelf->wasmetal_core__DOT___019779_ = (1U & (IData)(
                                                         (0x7770000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053368_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0))))))));
    vlSelf->wasmetal_core__DOT___059109_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___059107_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___059148_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    vlSelf->wasmetal_core__DOT___059116_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003809_))));
    vlSelf->wasmetal_core__DOT___059152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___059110_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___059154_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006092_))))));
    vlSelf->wasmetal_core__DOT___059115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003807_))));
    vlSelf->wasmetal_core__DOT___059147_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___059117_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059113_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059112_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003811_)))))))));
    vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT___054550_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001370_)))));
    vlSelf->wasmetal_core__DOT___054551_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001382_)))));
    vlSelf->wasmetal_core__DOT___054552_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001414_)))));
    vlSelf->wasmetal_core__DOT___054553_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001426_)))));
    vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001525_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034349_));
    vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028873_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028462_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003484_));
    vlSelf->wasmetal_core__DOT___066109_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xf0f5533U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053111_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___051919_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (0xcaU 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h28b05b3d__0))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049243_))))));
    vlSelf->wasmetal_core__DOT___051920_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051919_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051918_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h28b05b3d__0))))));
    vlSelf->wasmetal_core__DOT___053108_ = (1U & (0x5cU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xf0faaccU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___049109_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf7ec4412__0))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049111_))));
    vlSelf->wasmetal_core__DOT___049752_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049086_))));
    vlSelf->wasmetal_core__DOT___051591_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051410_))));
    vlSelf->wasmetal_core__DOT___049732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049268_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049286_))));
    vlSelf->wasmetal_core__DOT___049859_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049858_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049857_))));
    vlSelf->wasmetal_core__DOT___049708_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049704_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049703_))));
    vlSelf->wasmetal_core__DOT___049846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049845_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049844_))));
    vlSelf->wasmetal_core__DOT___049602_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049588_))));
    vlSelf->wasmetal_core__DOT___053215_ = (1U & (IData)(
                                                         (0xf0f0aa3300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050830_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053212_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2cac88ff__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053210_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053209_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052592_))))))));
    vlSelf->wasmetal_core__DOT___049626_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049621_))));
    vlSelf->wasmetal_core__DOT___052624_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050527_))));
}
