#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__7(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__7\n"); );
    // Body
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b126__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b125__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b124__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b123__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b122__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b121__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129185___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129169___Q = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b120__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129192___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129168___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129161___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129183___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129167___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129160___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129190___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129166___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129189___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129159___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129165___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129188___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129153___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129158___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129164___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129163___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129152___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129157___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129162___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129156___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129151___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129155___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129150___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129145___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129154___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129149___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129144___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129148___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129143___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129147___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129142___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129146___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129141___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129137___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129140___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129136___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129139___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129135___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129138___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129134___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129133___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129113___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129129___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129132___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129112___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129128___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129111___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129131___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129110___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129127___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129130___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129109___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129126___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129108___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129125___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129107___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129106___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129124___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129121___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129123___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129120___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129122___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129119___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129118___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129117___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129116___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129115___Q = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129114___Q = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b243__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b242__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b241__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b240__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b231__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b230__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b229__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b228__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b211__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b210__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b209__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b208__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b207__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b206__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b205__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b204__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b203__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b202__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b201__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b200__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b199__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b198__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b197__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b196__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b195__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b194__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b193__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b192__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b179__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b178__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b177__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b176__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b167__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b166__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b165__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b164__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b159__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b158__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b157__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b156__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b155__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b154__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b153__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b152__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b151__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b150__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b149__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b148__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b147__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b146__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b145__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b144__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b139__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b138__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b137__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b136__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019793_) {
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b126__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b70__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b102__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b94__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b78__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b110__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b118__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b69__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b125__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b101__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b93__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b109__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b117__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b85__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b68__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b124__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b100__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b92__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b76__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b108__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b116__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b67__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b123__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b99__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b91__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b75__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b107__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b115__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b66__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b122__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b98__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b90__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b74__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b106__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b114__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b65__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b121__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b97__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b73__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b89__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b105__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b81__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b113__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b64__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b120__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b96__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b72__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b88__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b104__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b80__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b112__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
        }
        if (vlSelf->wasmetal_core__DOT___019787_) {
            vlSelf->wasmetal_core__DOT__exception_reference__05b6__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b5__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b4__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b3__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b2__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b1__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b0__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d)))));
        }
        if (vlSelf->wasmetal_core__DOT___046015_) {
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068516_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068515_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___068514_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056334_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064017_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d 
                = (1U & (0xfff2ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___068471_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___068470_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___068469_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xcfaf00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___068464_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068463_) 
                                                              << 4U) 
                                                             | ((8U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((0xef000f0fU 
                                                                           >> 
                                                                           ((0x10U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___068460_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b47__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffe000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0))))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0xef000f0fU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066224_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b47__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___067588_)))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d 
                = (1U & (0xefU >> ((4U & ((0xdf0f0000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___068394_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___068393_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0x45000000cf00cfcfULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___068387_) 
                                                                       << 5U) 
                                                                      | ((0x10U 
                                                                          & ((8U 
                                                                              >> 
                                                                              (3U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                             << 4U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068386_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___066193_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068385_)))))))) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f010f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___068415_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068414_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___068413_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xf033f0f0ffffff55ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048829_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002893_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002894_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___068416_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0xef000000ffff0000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068339_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068338_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((8U 
                                                                       >> 
                                                                       ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            >> 2U)) 
                                                                        | (1U 
                                                                           & (0xef000f0fU 
                                                                              >> 
                                                                              ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___068329_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066034_))))))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> 
                                                                        ((2U 
                                                                          & ((0xef000f0fU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___066026_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                                                << 1U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                               >> 3U)))))))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___068361_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0xaf8c00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___068359_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068358_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048816_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002769_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002770_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066103_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0xef000000ffff0000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068232_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068231_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((8U 
                                                                       >> 
                                                                       ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            >> 2U)) 
                                                                        | (1U 
                                                                           & (0xef000f0fU 
                                                                              >> 
                                                                              ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___068223_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b43__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))))))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> 
                                                                        ((2U 
                                                                          & ((0xef000f0fU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___065857_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b43__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                               >> 3U)))))))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___068254_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0xaf8c00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___068252_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068251_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2ba16db__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065919_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d 
                = (1U & (0xefU >> ((4U & ((0xdf0f0000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___068198_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___068197_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0x7077000070777077ULL 
                                                                     >> 
                                                                     ((0x20U 
                                                                       & ((8U 
                                                                           >> 
                                                                           (3U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                               >> 2U))) 
                                                                          << 5U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068191_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___065767_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b42__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xba11feffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068189_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))))))))))))))) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f010f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___068167_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068166_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___068165_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xf033f0f0ffffff55ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a517e30__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___068199_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d 
                = (1U & (IData)((0xffffffb0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068147_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068146_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___068145_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x7f333f3f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___068130_) 
                                                                        << 5U) 
                                                                       | ((0x10U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068129_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h712d7252__0))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x3500U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 1U)) 
                                                                   | ((2U 
                                                                       & ((0xef000f0fU 
                                                                           >> 
                                                                           ((0x10U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___068137_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b41__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0)))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0xef000f0fU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065662_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b41__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065654_))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xaf3f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___068070_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068069_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f010f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___068091_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068090_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___068089_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xf033f0f0ffffff55ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfd6c95b6__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d)))))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___068094_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068039_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068038_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff1f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___068033_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068032_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___068031_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065427_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x8fU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013081_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___056034_))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x5300U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013114_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d 
                = (1U & (0x4fU >> ((4U & ((IData)((0xdf0f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___067959_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067958_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067957_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0x7077000070777077ULL 
                                                                             >> 
                                                                             ((0x20U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067948_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065379_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b38__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x7522fdffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))))))))) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))) 
                                          << 2U)) | 
                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                     << 1U) | (1U & (IData)(
                                                            (0xaf8c00000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___067980_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067979_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07469665__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012818_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xef000000ffff0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067894_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067893_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((0x70330000U 
                                                                     >> 
                                                                     ((0x18U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                          << 1U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067887_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b37__05d) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___067886_))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x7033U 
                                                                      >> 
                                                                      ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065222_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065230_)))))))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f010f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___067914_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067913_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___067912_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xf033f0f0ffffff55ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he9d730e6__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d)))))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___067915_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d 
                = (1U & (0xfff2ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___067860_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___067859_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x44f4ffff00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___067853_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___067852_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0x5fcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067850_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b36__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h102f49bb__0))))))))))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xafcf00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___067826_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067825_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057177_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xaf3f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___067723_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067722_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f010f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___067743_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067742_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___067741_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xf033f0f0ffffff55ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5b64371c__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbd418077__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d)))))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___067744_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x45cf454500000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___067656_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067655_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067654_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((0xa3U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___054186_)))) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___067588_)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___067680_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0xafcf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067678_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067677_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064529_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d 
                = (1U & (IData)((0xffffffb0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___067543_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___067542_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___067541_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xbbb0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___067502_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061327_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013159_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048330_)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f00005533ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012559_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha052db73__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x100ffff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067614_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067613_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x5300U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064018_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___012559_))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067608_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067607_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4bbfe337__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x88fff8f8ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067544_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010904_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056001_)))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___067617_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xaf3f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___067446_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067445_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054174_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f7f00000000ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___067472_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xefefef00000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___067470_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012969_)))))))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___011026_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___067473_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d 
                = (1U & (0x4fU >> ((4U & ((IData)((0xfef00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___067299_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067298_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0x45cf454500000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___067292_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067291_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067290_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xb000bb000000ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067287_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067285_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067284_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064978_)))))))) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))) 
                                          << 2U)) | 
                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                     << 1U) | (1U & (IData)(
                                                            (0x35f00000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___067327_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067326_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___057105_))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061099_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0xfef00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067400_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067399_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xef00U 
                                                                    >> 
                                                                    ((8U 
                                                                      & ((IData)(
                                                                                (0xef00efef00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067380_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067379_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x4000cfff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067375_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x200f3ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 3U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064604_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)))))))))))))))))))))) 
                                                                         << 3U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((0x80b000f0U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067390_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067389_)))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xfef0f00ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067382_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064710_))))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___067404_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___067261_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___067260_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x35f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___067213_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067212_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056938_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061010_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xffff0000ef00ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067249_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfef0f00ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067238_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___065033_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064710_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80b000f0U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067245_)))))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___067103_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___067102_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xeU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xef00efef00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___067065_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067064_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x4000cfff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067061_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067060_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80b000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0xbU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3616a991__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064606_)))))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019393_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x35f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___067095_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___067094_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011683_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___067029_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___067028_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x35f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___066991_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066990_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056316_))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060754_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0x8acf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067020_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067019_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b24__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h400b74e1__0)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067016_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064156_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067014_)))))))))))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d 
                = (1U & (0xfff2ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___066883_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___066882_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066881_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0x35f00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___066871_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___066870_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___057504_))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061253_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066961_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066960_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x35f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___066913_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066912_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0xf400U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013184_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057552_))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061323_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xff40U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xff0f4404ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066934_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066933_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xef000f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 3U))))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33bf3f3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066947_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h312e660c__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9bcef377__0)))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xdfc00000U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdda09bd4__0))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066721_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066720_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xe0U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0xefefef00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___066665_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061089_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057114_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___012476_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019385_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((0x4f0000U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___066705_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066704_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0xe0000000f0ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066701_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066700_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x55330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065134_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2f6e42c0__0)))))))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066803_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066802_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xeU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xff4f0000U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___066758_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066757_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xfef0f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066747_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066746_)))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 3U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019393_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xfb00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___066789_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066788_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066787_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057256_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048330_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d 
                = (1U & (IData)((0xffffffb0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066553_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066552_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___066551_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xfafc0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___066544_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___011951_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h5d9b5f2a__0))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___011949_)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xfac0U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056790_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___060919_))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066637_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066636_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xeU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xff4f0000U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___066591_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066590_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xfef0f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066580_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066579_)))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 3U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019393_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x35f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___066620_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066619_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056951_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061000_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066303_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066302_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x7f7f7f00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066259_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & (vlSelf->mem_rdata[0U] 
                                                                                >> 0xdU)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065581_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1f0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___066296_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066295_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066292_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055853_)))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066389_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066388_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (((IData)(
                                                                   (0xefefef00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___066335_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060743_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xc5U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9167c706__0)))))))))) 
                                                           & (IData)(
                                                                     (0xfff0fff0ff00ffeeULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011093_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h3b8e8d7c__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0xd00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066380_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066379_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x200000003fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b16__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h737b874d__0))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x80000000cfffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b16__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha994bb2b__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064097_)))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066115_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066114_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x70U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0xf0fd000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___066099_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___066098_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002114_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002113_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___066100_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064012_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___066100_) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (0xdU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbcde5889__0)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x305U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066103_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___012608_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___012607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010085_))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066210_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066209_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x1f0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___066149_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___066148_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061213_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___066145_)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xaf8caa88aa88aa88ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___066199_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066198_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066197_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0x5f3f0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x773f3f3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066187_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b14__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066188_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066190_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065374_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065376_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066193_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066012_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066011_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x70U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0xf0fd000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___065954_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065953_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002075_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002076_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___057189_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064012_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061051_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___057189_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf00eeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h895eb4d9__0)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xeee00000ffff0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065888_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065887_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (vlSelf->mem_rdata[0U] 
                                                                               >> 0xbU))))) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___065586_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xff00e000ff00ff00ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___065921_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065920_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060962_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___065917_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___065922_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___065833_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___065832_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x70U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0xf0fd00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___065820_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065819_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002432_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002430_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002431_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056706_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064012_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056708_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___056706_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf00eeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065822_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011783_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___011782_)))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___065733_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___065732_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffffff0007070700ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___065586_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065689_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065584_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x35f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___065720_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065719_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056573_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc6176170__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d 
                = (1U & (0xefU >> ((4U & ((0xdf0f0000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___065505_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___065504_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0x30f0200030f030fULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065498_) 
                                                                          << 4U) 
                                                                         | ((8U 
                                                                             & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f335500000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065484_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065483_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065012_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065018_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065017_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065020_))))))))))))) 
                                                                                << 2U)) 
                                                                               | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065490_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065495_)))))))) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f080f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___065435_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065434_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065433_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057617_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___065506_)))));
        }
        if (vlSelf->wasmetal_core__DOT___052916_) {
            vlSelf->wasmetal_core__DOT__load_vector__05b4__05d 
                = vlSelf->wasmetal_core__DOT___001437_;
            vlSelf->wasmetal_core__DOT__load_vector__05b3__05d 
                = vlSelf->wasmetal_core__DOT___001886_;
            vlSelf->wasmetal_core__DOT__load_vector__05b0__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d;
        }
        if (vlSelf->wasmetal_core__DOT___019800_) {
            vlSelf->wasmetal_core__DOT____Vcellout___129185___Q 
                = (1U & (0xf0fff44U >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062367_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b79__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[2U] 
                                                                         >> 0xeU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b79__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129169___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b63__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x1eU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b63__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056133_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129192___Q 
                = (1U & (0xf0fff44U >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062388_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b86__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[2U] 
                                                                         >> 0x15U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b86__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129168___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b62__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x1dU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b62__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061264_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001168_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129161___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b55__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x16U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b55__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061333_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001014_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129183___Q 
                = (1U & (0xf0fff44U >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062362_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b77__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[2U] 
                                                                         >> 0xcU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b77__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129167___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b61__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x1cU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b61__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056124_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001146_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129160___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b54__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x15U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b54__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061265_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000992_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129190___Q 
                = (1U & (0xf0fff44U >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062381_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b84__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[2U] 
                                                                         >> 0x13U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b84__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129166___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b60__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x1bU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b60__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056168_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001124_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129189___Q 
                = (1U & (0xf0fff44U >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062378_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b83__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[2U] 
                                                                         >> 0x12U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b83__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129159___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b53__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x14U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b53__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061182_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000980_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129165___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b59__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x1aU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b59__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056114_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001102_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129188___Q 
                = (1U & (0xf0fff44U >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062375_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b82__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[2U] 
                                                                         >> 0x11U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b82__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129153___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b47__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0xeU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b47__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061304_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129158___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b52__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x13U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b52__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061102_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001327_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129164___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b58__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x19U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b58__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001080_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129163___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b57__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x18U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b57__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060853_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001058_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129152___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b46__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0xdU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b46__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061218_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129157___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b51__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x12U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b51__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061016_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129162___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b56__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x17U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b56__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060766_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001036_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129156___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b50__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x11U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b50__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060930_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129151___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b45__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0xcU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b45__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061152_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129155___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b49__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0x10U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b49__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060849_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129150___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b44__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0xbU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b44__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061071_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129145___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b39__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 6U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b39__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129154___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b48__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0xfU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b48__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060759_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129149___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b43__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 0xaU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b43__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060982_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129144___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b38__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 5U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b38__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056030_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129148___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b42__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 9U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b42__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056048_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129143___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b37__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 4U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b37__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129147___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b41__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 8U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b41__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060804_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129142___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b36__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 3U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b36__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056021_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129146___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b40__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 7U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b40__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129141___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b35__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 2U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b35__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056018_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129137___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b31__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x1eU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b31__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061327_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129140___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b34__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         >> 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b34__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056014_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129136___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b30__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x1dU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b30__05d)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000657_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129139___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b33__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & vlSelf->mem_rdata[1U]) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b33__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056009_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129135___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b29__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x1cU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b29__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019261_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129138___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b32__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[1U] 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b32__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056001_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129134___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b28__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x1bU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b28__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061099_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000613_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129133___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b27__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x1aU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b27__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061010_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000591_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129113___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b7__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 6U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b7__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001487_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129129___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b23__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x16U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b23__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061323_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000498_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129132___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b26__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x19U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b26__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060927_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000564_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129112___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b6__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 5U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b6__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001475_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129128___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b22__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x15U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b22__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061253_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000476_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129111___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b5__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 4U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b5__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001443_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129131___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b25__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x18U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b25__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060846_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000542_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129110___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b4__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 3U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b4__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001437_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129127___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b21__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x14U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b21__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061171_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000464_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129130___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b24__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x17U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b24__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060754_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000520_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129109___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b3__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 2U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b3__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001886_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129126___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b20__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x13U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b20__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000432_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129108___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b2__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b2__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001874_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129125___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b19__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x12U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b19__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061000_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000419_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129107___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b1__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & vlSelf->mem_rdata[0U]) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b1__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055410_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129106___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b0__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b0__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055363_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129124___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b18__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x11U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b18__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060919_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001646_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129121___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b15__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0xeU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b15__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055853_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001580_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129123___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b17__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0x10U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b17__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060834_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001624_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129120___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b14__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0xdU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b14__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061213_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001568_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129122___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b16__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0xfU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b16__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060743_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001612_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129119___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b13__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0xcU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b13__05d)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hbcde5889__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001536_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129118___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b12__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0xbU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b12__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061051_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001524_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129117___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b11__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 0xaU)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b11__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060962_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001425_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129116___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b10__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 9U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b10__05d)))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056708_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129115___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b9__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 8U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b9__05d)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xfef0U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc6176170__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001381_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129114___Q 
                = (1U & (0xf0fccaaU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x53U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b8__05d)))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (vlSelf->mem_rdata[0U] 
                                                                         >> 7U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b8__05d)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x1fU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcb50dc13__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001369_)))))));
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049730_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b243__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049728_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b242__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049729_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b241__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050786_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b240__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051250_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b231__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051251_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b230__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050328_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b229__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050267_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b228__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049605_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b211__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049862_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b210__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049597_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b209__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049920_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b208__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050070_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b207__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050037_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b206__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051275_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b205__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050036_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b204__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051273_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b203__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050473_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b202__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050087_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b201__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050474_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b200__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050472_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b199__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050393_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b198__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050477_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b197__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051123_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b196__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050903_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b195__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050072_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b194__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049592_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b193__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050563_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b192__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050909_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b179__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051255_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b178__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050156_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b177__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050134_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b176__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051249_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b167__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051248_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b166__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050294_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b165__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050296_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b164__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049443_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b159__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049442_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b158__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049441_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b157__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050305_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b156__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050298_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b155__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050297_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b154__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048576_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b153__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048574_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b152__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049058_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b151__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049391_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b150__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049393_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b149__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050306_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b148__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050304_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b147__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050299_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b146__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051247_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b145__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049350_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b144__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051241_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b139__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051242_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b138__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050157_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b137__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050902_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b136__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051540_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b115__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048547_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b114__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048544_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b113__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048538_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b112__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051137_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b103__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049941_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b102__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051136_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b101__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051135_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b100__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050466_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b83__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050465_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b82__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050088_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b81__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050089_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b80__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050439_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b79__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050440_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b78__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050436_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b77__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049582_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b76__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050395_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b75__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050396_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b74__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050391_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b73__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050390_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b72__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050378_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b71__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050377_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b70__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050374_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b69__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050375_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b68__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050370_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b67__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050372_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b66__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049425_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b65__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049426_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b64__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049423_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b63__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050355_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b62__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050356_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b61__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050279_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b60__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050333_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b59__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050330_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b58__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050329_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b57__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049583_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b56__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050326_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b55__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050324_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b54__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050323_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b53__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049594_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b52__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051379_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b51__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049935_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b50__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049922_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b49__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049919_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b48__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049951_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b47__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049950_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b46__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049949_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b45__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051378_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b44__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049916_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b43__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049915_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b42__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050471_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b41__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051246_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b40__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051245_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b39__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051243_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b38__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051244_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b37__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050085_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b36__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050086_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b35__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051233_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b34__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050369_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b33__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051232_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b32__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051234_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b31__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051213_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b30__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051211_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b29__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050734_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b28__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050376_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b27__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051206_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b26__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051193_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b25__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051192_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b24__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050910_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b23__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051190_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b22__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050437_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b21__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051133_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b20__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050373_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b19__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050367_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b18__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050345_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b17__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050083_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b16__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050084_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b15__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051489_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b14__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051490_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b13__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050331_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b12__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050325_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b11__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051377_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b10__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051488_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b9__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051487_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b8__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049612_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b7__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049939_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b6__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049952_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b5__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049937_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b4__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049940_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b3__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050327_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b2__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050470_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b1__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050478_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048300_))))) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b0__05d = 1U;
        }
        if (vlSelf->wasmetal_core__DOT___019797_) {
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d 
                = (1U & (0x3aU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               ((0x777ffffU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                               >> 2U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))) 
                                                << 1U)) 
                                              | (vlSelf->cmd_data[1U] 
                                                 >> 0x1fU)))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x1aU)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054450_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___045777_))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d 
                = (1U & (0x10U >> ((4U & ((IData)(vlSelf->cmd_aux) 
                                          << 2U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b21__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x14U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x15U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b17__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x10U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x11U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 6U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 7U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 5U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 6U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 4U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 5U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 3U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 4U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 2U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 1U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & vlSelf->insn_x) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                << 1U)) 
                                              | (1U 
                                                 & vlSelf->cmd_index)))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b31__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x1eU)) 
                                              | (vlSelf->cmd_index 
                                                 >> 0x1fU)))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b30__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x1dU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x1eU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b29__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x1cU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x1dU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b28__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x1bU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x1cU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b27__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x1aU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x1bU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b26__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x19U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x1aU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b25__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x18U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x19U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b24__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x17U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x18U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b23__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x16U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x17U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b22__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x15U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x16U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b20__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x13U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x14U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b19__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x12U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x13U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b18__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0x11U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x12U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b16__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0xfU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0x10U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b15__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0xeU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0xfU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b14__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0xdU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0xeU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b13__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0xcU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0xdU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b12__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0xbU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0xcU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b11__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 0xaU)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0xbU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b10__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 9U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 0xaU))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b9__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 8U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 9U))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b8__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->insn_x 
                                                >> 7U)) 
                                              | (1U 
                                                 & (vlSelf->cmd_index 
                                                    >> 8U))))));
        }
    }
    vlSelf->wasmetal_core__DOT__memory_bounds__02epending_write 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___046017_));
}
