#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__35(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__35\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___009186_;
    wasmetal_core__DOT___009186_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009238_;
    wasmetal_core__DOT___009238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009239_;
    wasmetal_core__DOT___009239_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009251_;
    wasmetal_core__DOT___009251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009252_;
    wasmetal_core__DOT___009252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009291_;
    wasmetal_core__DOT___009291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009301_;
    wasmetal_core__DOT___009301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009302_;
    wasmetal_core__DOT___009302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009768_;
    wasmetal_core__DOT___009768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009769_;
    wasmetal_core__DOT___009769_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051495_;
    wasmetal_core__DOT___051495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055224_;
    wasmetal_core__DOT___055224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055225_;
    wasmetal_core__DOT___055225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055238_;
    wasmetal_core__DOT___055238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055406_;
    wasmetal_core__DOT___055406_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055449_;
    wasmetal_core__DOT___055449_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055564_;
    wasmetal_core__DOT___055564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055565_;
    wasmetal_core__DOT___055565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055571_;
    wasmetal_core__DOT___055571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055574_;
    wasmetal_core__DOT___055574_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055621_;
    wasmetal_core__DOT___055621_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055622_;
    wasmetal_core__DOT___055622_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055692_;
    wasmetal_core__DOT___055692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055850_;
    wasmetal_core__DOT___055850_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055851_;
    wasmetal_core__DOT___055851_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056008_;
    wasmetal_core__DOT___056008_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056148_;
    wasmetal_core__DOT___056148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058142_;
    wasmetal_core__DOT___058142_ = 0;
    CData/*1:0*/ __VdfgTmp_heeb49de9__0;
    __VdfgTmp_heeb49de9__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb3c8072f__0;
    __VdfgTmp_hb3c8072f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7cc8bc90__0;
    __VdfgTmp_h7cc8bc90__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9513718__0;
    __VdfgTmp_hf9513718__0 = 0;
    CData/*1:0*/ __VdfgTmp_he9adc993__0;
    __VdfgTmp_he9adc993__0 = 0;
    CData/*1:0*/ __VdfgTmp_hba82f58f__0;
    __VdfgTmp_hba82f58f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h66d4b740__0;
    __VdfgTmp_h66d4b740__0 = 0;
    CData/*1:0*/ __VdfgTmp_h78ab269f__0;
    __VdfgTmp_h78ab269f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h984be98a__0;
    __VdfgTmp_h984be98a__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc8a1f90d__0;
    __VdfgTmp_hc8a1f90d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h003583a9__0;
    __VdfgTmp_h003583a9__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha3cbecc2__0;
    __VdfgTmp_ha3cbecc2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8255702a__0;
    __VdfgTmp_h8255702a__0 = 0;
    CData/*2:0*/ __VdfgTmp_h58490cb9__0;
    __VdfgTmp_h58490cb9__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0c69b60f__0;
    __VdfgTmp_h0c69b60f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h74a36385__0;
    __VdfgTmp_h74a36385__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6299ef40__0;
    __VdfgTmp_h6299ef40__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5311778a__0;
    __VdfgTmp_h5311778a__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc1229de7__0;
    __VdfgTmp_hc1229de7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4bc07745__0;
    __VdfgTmp_h4bc07745__0 = 0;
    CData/*1:0*/ __VdfgTmp_h073f9b05__0;
    __VdfgTmp_h073f9b05__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1432c284__0;
    __VdfgTmp_h1432c284__0 = 0;
    CData/*1:0*/ __VdfgTmp_he55661b3__0;
    __VdfgTmp_he55661b3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3043729e__0;
    __VdfgTmp_h3043729e__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcf6d3894__0;
    __VdfgTmp_hcf6d3894__0 = 0;
    CData/*1:0*/ __VdfgTmp_h86440ee1__0;
    __VdfgTmp_h86440ee1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6bf7b02b__0;
    __VdfgTmp_h6bf7b02b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1a11d128__0;
    __VdfgTmp_h1a11d128__0 = 0;
    CData/*1:0*/ __VdfgTmp_h281b8ab1__0;
    __VdfgTmp_h281b8ab1__0 = 0;
    CData/*1:0*/ __VdfgTmp_hae4042e0__0;
    __VdfgTmp_hae4042e0__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0f5bdf9__0;
    __VdfgTmp_he0f5bdf9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6e85e3ea__0;
    __VdfgTmp_h6e85e3ea__0 = 0;
    CData/*1:0*/ __VdfgTmp_h77b03a4f__0;
    __VdfgTmp_h77b03a4f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h038396ba__0;
    __VdfgTmp_h038396ba__0 = 0;
    CData/*1:0*/ __VdfgTmp_h199a7061__0;
    __VdfgTmp_h199a7061__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf34c8dd6__0;
    __VdfgTmp_hf34c8dd6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h524558f7__0;
    __VdfgTmp_h524558f7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1f1491ac__0;
    __VdfgTmp_h1f1491ac__0 = 0;
    CData/*1:0*/ __VdfgTmp_h45767413__0;
    __VdfgTmp_h45767413__0 = 0;
    CData/*1:0*/ __VdfgTmp_h509cc1df__0;
    __VdfgTmp_h509cc1df__0 = 0;
    CData/*1:0*/ __VdfgTmp_h62a41e7a__0;
    __VdfgTmp_h62a41e7a__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb0c1ca1e__0;
    __VdfgTmp_hb0c1ca1e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h36eed793__0;
    __VdfgTmp_h36eed793__0 = 0;
    CData/*1:0*/ __VdfgTmp_h39517120__0;
    __VdfgTmp_h39517120__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9087e671__0;
    __VdfgTmp_h9087e671__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7ae355e5__0;
    __VdfgTmp_h7ae355e5__0 = 0;
    CData/*1:0*/ __VdfgTmp_h029c8a85__0;
    __VdfgTmp_h029c8a85__0 = 0;
    CData/*1:0*/ __VdfgTmp_h004771e7__0;
    __VdfgTmp_h004771e7__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd226433b__0;
    __VdfgTmp_hd226433b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h31ba5af5__0;
    __VdfgTmp_h31ba5af5__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc49bb9d8__0;
    __VdfgTmp_hc49bb9d8__0 = 0;
    CData/*1:0*/ __VdfgTmp_hfb882020__0;
    __VdfgTmp_hfb882020__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4e0b8941__0;
    __VdfgTmp_h4e0b8941__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8b5fdfca__0;
    __VdfgTmp_h8b5fdfca__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6f4dbdf9__0;
    __VdfgTmp_h6f4dbdf9__0 = 0;
    CData/*1:0*/ __VdfgTmp_hea01e0cb__0;
    __VdfgTmp_hea01e0cb__0 = 0;
    CData/*1:0*/ __VdfgTmp_he9911376__0;
    __VdfgTmp_he9911376__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7fe0949a__0;
    __VdfgTmp_h7fe0949a__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha94b79fc__0;
    __VdfgTmp_ha94b79fc__0 = 0;
    CData/*1:0*/ __VdfgTmp_h23e62674__0;
    __VdfgTmp_h23e62674__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf92edf21__0;
    __VdfgTmp_hf92edf21__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6bd09dd8__0;
    __VdfgTmp_h6bd09dd8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8a1e5cea__0;
    __VdfgTmp_h8a1e5cea__0 = 0;
    CData/*1:0*/ __VdfgTmp_h09e28282__0;
    __VdfgTmp_h09e28282__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___135425___DOT__X = 
        (0xffffffffffffULL & VL_EXTENDS_QQ(48,43, vlSelf->wasmetal_core__DOT___135425___DOT__Mr));
    vlSelf->wasmetal_core__DOT___135425___DOT__Z = 
        (0xffffffffffffULL & VL_EXTENDS_QI(48,31, (0x7fffffffU 
                                                   & (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                              >> 0x11U)))));
    if (vlSelf->wasmetal_core__DOT___008018_) {
        vlSelf->wasmetal_core__DOT___007844_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 2U))));
        vlSelf->wasmetal_core__DOT___007847_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 1U))));
        vlSelf->wasmetal_core__DOT___007846_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O))));
        vlSelf->wasmetal_core__DOT___007858_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 3U))));
    } else {
        vlSelf->wasmetal_core__DOT___007844_ = (1U 
                                                & (0x80bfaaaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008495_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 3U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_x)))))))))));
        vlSelf->wasmetal_core__DOT___007847_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008500_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                           >> 2U)))))))));
        vlSelf->wasmetal_core__DOT___007846_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008017_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                           >> 1U)))))))));
        vlSelf->wasmetal_core__DOT___007858_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007208_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum))))))));
    }
    vlSelf->wasmetal_core__DOT___008809_ = (1U & (0x8080ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb0e57990__0))))));
    wasmetal_core__DOT___058142_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 4U)) 
                                                 | (0xfU 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                               >> 8U))))));
    vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
        = (vlSelf->wasmetal_core__DOT___135425___DOT__X 
           & vlSelf->wasmetal_core__DOT___135425___DOT__Z);
    vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
        = (vlSelf->wasmetal_core__DOT___135425___DOT__X 
           ^ vlSelf->wasmetal_core__DOT___135425___DOT__Z);
    vlSelf->__VdfgTmp_h4ad8a46a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007847_)));
    vlSelf->wasmetal_core__DOT___062324_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008809_)))));
    vlSelf->wasmetal_core__DOT___058143_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058142_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                                           >> 0xeU)) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum)))))));
    vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_ha5045b21__0 
        = (0x1fffU & ((0xffeU & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz) 
                                 << 1U)) + (0xfffU 
                                            & (IData)(vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed))));
    vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_h4c2f98f1__0 
        = (0x1fffU & ((0xfffU & (IData)((vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                         >> 0xbU))) 
                      + ((0xfffU & (IData)((vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                            >> 0xcU))) 
                         + VL_SHIFTR_III(13,13,32, (IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_ha5045b21__0), 0xcU))));
    vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
        = (((QData)((IData)((0xfffU & ((IData)((vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                >> 0x23U)) 
                                       + ((IData)((vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                   >> 0x24U)) 
                                          + (1U & (
                                                   ((0xfffU 
                                                     & (IData)(
                                                               (vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                                >> 0x17U))) 
                                                    + 
                                                    ((0xfffU 
                                                      & (IData)(
                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                                 >> 0x18U))) 
                                                     + 
                                                     VL_SHIFTR_III(13,13,32, (IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_h4c2f98f1__0), 0xcU))) 
                                                   >> 0xcU))))))) 
            << 0x24U) | (((QData)((IData)((0xfffU & 
                                           ((IData)(
                                                    (vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                     >> 0x17U)) 
                                            + ((IData)(
                                                       (vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                        >> 0x18U)) 
                                               + (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_h4c2f98f1__0) 
                                                     >> 0xcU))))))) 
                          << 0x18U) | (QData)((IData)(
                                                      ((0xfff000U 
                                                        & (((IData)(
                                                                    (vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                                                     >> 0xbU)) 
                                                            + 
                                                            ((IData)(
                                                                     (vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                                                      >> 0xcU)) 
                                                             + 
                                                             (1U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_ha5045b21__0) 
                                                                 >> 0xcU)))) 
                                                           << 0xcU)) 
                                                       | (0xfffU 
                                                          & ((0xffeU 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz) 
                                                                 << 1U)) 
                                                             + (IData)(vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed))))))));
    vlSelf->wasmetal_core__DOT___048492_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & ((IData)(
                                                                       (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                        >> 6U)) 
                                                               << 2U)) 
                                                           | (3U 
                                                              & (IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                         >> 5U)))))));
    vlSelf->wasmetal_core__DOT___048502_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x1000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___048492_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (7U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 0xeU)))) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((IData)(
                                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                                >> 3U)) 
                                                                           << 3U)) 
                                                                       | ((6U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 0xdU))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (3U 
                                                                        & (IData)(
                                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                                >> 4U)))) 
                                                                      << 5U)) 
                                                                  | ((0x10U 
                                                                      & ((1U 
                                                                          >> 
                                                                          (3U 
                                                                           & (IData)(
                                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                                >> 0xaU)))) 
                                                                         << 4U)) 
                                                                     | (0xfU 
                                                                        & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 9U)))))))))));
    vlSelf->wasmetal_core__DOT___007869_ = (1U & (IData)(
                                                         (0xfefffeff0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048503_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048502_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->wasmetal_core__DOT___135425___DOT__alu_sum 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 7U))))))))));
    vlSelf->wasmetal_core__DOT___009290_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83a675b5__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055000_)))))))));
    wasmetal_core__DOT___009291_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054998_)))))))));
    wasmetal_core__DOT___055621_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84d68e3f__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054988_)))))))));
    vlSelf->wasmetal_core__DOT___008935_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ebbc558__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054987_)))))))));
    vlSelf->wasmetal_core__DOT___055617_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054990_)))))))));
    vlSelf->wasmetal_core__DOT___055618_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf65e04e__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054989_)))))))));
    vlSelf->wasmetal_core__DOT___009292_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h437f0271__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054996_)))))))));
    vlSelf->wasmetal_core__DOT___009293_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab3c597f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054995_)))))))));
    wasmetal_core__DOT___055574_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc49a285__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054949_)))))))));
    vlSelf->wasmetal_core__DOT___008904_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f14afc9__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054948_)))))))));
    vlSelf->wasmetal_core__DOT___055570_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde99fb2e__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054951_)))))))));
    wasmetal_core__DOT___055571_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054950_)))))))));
    wasmetal_core__DOT___055564_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1ad74d3e__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054959_)))))))));
    wasmetal_core__DOT___055565_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h707c99af__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054958_)))))))));
    vlSelf->wasmetal_core__DOT___055566_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc03ee7e3__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054957_)))))))));
    vlSelf->wasmetal_core__DOT___055567_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb18976f4__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054956_)))))))));
    vlSelf->wasmetal_core__DOT___055544_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054900_)))))))));
    vlSelf->wasmetal_core__DOT___055543_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054898_)))))))));
    vlSelf->wasmetal_core__DOT___008860_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054899_)))))))));
    vlSelf->wasmetal_core__DOT___009771_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6eb17b7a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054901_)))))))));
    wasmetal_core__DOT___009769_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h692f01d1__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054907_)))))))));
    vlSelf->wasmetal_core__DOT___009770_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054906_)))))))));
    vlSelf->wasmetal_core__DOT___055534_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0e7ef094__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054909_)))))))));
    wasmetal_core__DOT___009768_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054908_)))))))));
    vlSelf->wasmetal_core__DOT___009189_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h815644ec__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051496_)))))))));
    vlSelf->wasmetal_core__DOT___051500_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051498_)))))))));
    vlSelf->wasmetal_core__DOT___008835_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce0059e1__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051493_)))))))));
    vlSelf->wasmetal_core__DOT___009187_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h79bfec12__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054861_)))))))));
    vlSelf->wasmetal_core__DOT___009188_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054860_)))))))));
    vlSelf->wasmetal_core__DOT___009185_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc530df9f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054865_)))))))));
    wasmetal_core__DOT___009186_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb918ea35__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054863_)))))))));
    wasmetal_core__DOT___051495_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86c1a93d__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___051491_)))))))));
    vlSelf->wasmetal_core__DOT___055448_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb98e230__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054808_)))))))));
    vlSelf->wasmetal_core__DOT___009174_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8916279c__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054807_)))))))));
    vlSelf->wasmetal_core__DOT___055444_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054810_)))))))));
    vlSelf->wasmetal_core__DOT___055445_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054809_)))))))));
    vlSelf->wasmetal_core__DOT___009254_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2656e40__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054815_)))))))));
    vlSelf->wasmetal_core__DOT___009253_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f29d017__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054816_)))))))));
    wasmetal_core__DOT___009251_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054820_)))))))));
    wasmetal_core__DOT___009252_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054818_)))))))));
    wasmetal_core__DOT___055406_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7751d301__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054768_)))))))));
    vlSelf->wasmetal_core__DOT___009163_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h890db370__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054767_)))))))));
    vlSelf->wasmetal_core__DOT___055408_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054769_)))))))));
    vlSelf->wasmetal_core__DOT___055407_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a84499c__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054770_)))))))));
    wasmetal_core__DOT___009238_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782800f0__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054781_)))))))));
    wasmetal_core__DOT___009239_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054779_)))))))));
    vlSelf->wasmetal_core__DOT___009240_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc86399cc__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054777_)))))))));
    vlSelf->wasmetal_core__DOT___009241_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f534570__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054775_)))))))));
    vlSelf->wasmetal_core__DOT___055234_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h42498a1f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054698_)))))))));
    vlSelf->wasmetal_core__DOT___055235_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054701_)))))))));
    vlSelf->wasmetal_core__DOT___055236_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2814f082__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054705_)))))))));
    vlSelf->wasmetal_core__DOT___009146_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8893fd49__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054708_)))))))));
    vlSelf->wasmetal_core__DOT___055228_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054688_)))))))));
    vlSelf->wasmetal_core__DOT___055229_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7780ec55__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054691_)))))))));
    wasmetal_core__DOT___055224_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha292c154__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))));
    wasmetal_core__DOT___055225_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054682_)))))))));
    wasmetal_core__DOT___055692_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb4659c85__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055034_)))))))));
    vlSelf->wasmetal_core__DOT___008962_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7a210d44__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055033_)))))))));
    vlSelf->wasmetal_core__DOT___009303_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb69256f0__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055042_)))))))));
    vlSelf->wasmetal_core__DOT___009304_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde24342a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055041_)))))))));
    vlSelf->wasmetal_core__DOT___055696_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ce01618__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055035_)))))))));
    wasmetal_core__DOT___009301_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0919a607__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))));
    wasmetal_core__DOT___009302_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055044_)))))))));
    vlSelf->wasmetal_core__DOT___055695_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055036_)))))))));
    vlSelf->wasmetal_core__DOT___007880_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007869_)))));
    vlSelf->wasmetal_core__DOT___055983_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009290_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007846_)))));
    vlSelf->wasmetal_core__DOT___009473_ = (1U & (IData)(
                                                         (0xffff8000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009290_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0)))))));
    vlSelf->__VdfgTmp_hbd36bb7c__0 = (((IData)(wasmetal_core__DOT___009291_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009290_));
    vlSelf->__VdfgTmp_h7d874977__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008935_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055621_)));
    vlSelf->__VdfgTmp_ha16fbbbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___055618_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055617_));
    vlSelf->wasmetal_core__DOT___009471_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055621_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055618_)))));
    vlSelf->wasmetal_core__DOT___009472_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009292_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___009291_)))))))));
    vlSelf->__VdfgTmp_hd2b13b0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009292_));
    vlSelf->__VdfgTmp_ha295f108__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008904_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055574_)));
    vlSelf->wasmetal_core__DOT___009745_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055571_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055570_)))));
    vlSelf->__VdfgTmp_hb307080d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___055574_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055571_)));
    vlSelf->wasmetal_core__DOT___009463_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___055564_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_h6e24fc79__0 = (((IData)(wasmetal_core__DOT___055565_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055564_));
    vlSelf->__VdfgTmp_hb785bdc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___055566_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055565_));
    vlSelf->wasmetal_core__DOT___009412_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___055571_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055566_)))))))));
    vlSelf->wasmetal_core__DOT___055822_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055567_)))));
    vlSelf->__VdfgTmp_h8b31618a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055544_));
    vlSelf->wasmetal_core__DOT___009091_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055543_)))));
    vlSelf->__VdfgTmp_h1ccd197a__0 = (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009770_));
    vlSelf->__VdfgTmp_hf7b90195__0 = (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009769_));
    vlSelf->wasmetal_core__DOT___008877_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055534_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->wasmetal_core__DOT___009762_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                ? (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009769_)))))
                                                : (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009768_)))))));
    vlSelf->__VdfgTmp_hd1825153__0 = (((IData)(wasmetal_core__DOT___009769_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009768_));
    vlSelf->__VdfgTmp_h6ca56fa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___009768_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055534_)));
    vlSelf->__VdfgTmp_h23e0654e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009188_));
    vlSelf->__VdfgTmp_hbf11cfc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009187_));
    vlSelf->__VdfgTmp_hd3ee6e40__0 = (((IData)(vlSelf->wasmetal_core__DOT___009185_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0));
    vlSelf->wasmetal_core__DOT___009449_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                ? (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009187_)))))
                                                : (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009186_)))))));
    vlSelf->__VdfgTmp_hd63c68ee__0 = (((IData)(wasmetal_core__DOT___009186_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009185_));
    vlSelf->__VdfgTmp_ha296f98c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___051495_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___051500_)));
    vlSelf->wasmetal_core__DOT___009069_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008835_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___051495_)))));
    vlSelf->wasmetal_core__DOT___009035_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055448_)))));
    vlSelf->__VdfgTmp_he1badc2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___055445_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055444_));
    vlSelf->__VdfgTmp_he6145195__0 = (((IData)(vlSelf->wasmetal_core__DOT___055448_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055445_));
    vlSelf->wasmetal_core__DOT___055768_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009254_)))));
    vlSelf->__VdfgTmp_h52b8127f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009253_));
    vlSelf->wasmetal_core__DOT___055953_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009251_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_h416357e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___009253_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009252_));
    vlSelf->__VdfgTmp_h53c22b41__0 = (((IData)(wasmetal_core__DOT___009252_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009251_));
    vlSelf->__VdfgTmp_hecc250a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055406_)));
    vlSelf->__VdfgTmp_h62e050c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___055406_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055408_)));
    vlSelf->__VdfgTmp_ha9c0231a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055408_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055407_));
    vlSelf->wasmetal_core__DOT___055736_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_h10a22e24__0 = (((IData)(wasmetal_core__DOT___009239_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009238_));
    vlSelf->__VdfgTmp_ha4fdb8c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___009240_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009239_));
    vlSelf->wasmetal_core__DOT___055738_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009241_)))));
    vlSelf->__VdfgTmp_h381f02c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009240_));
    vlSelf->__VdfgTmp_h0eab1d01__0 = (((IData)(vlSelf->wasmetal_core__DOT___055235_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055234_));
    vlSelf->__VdfgTmp_h0b92bce8__0 = (((IData)(vlSelf->wasmetal_core__DOT___055236_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055235_));
    vlSelf->__VdfgTmp_h6b0a05f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055236_)));
    vlSelf->wasmetal_core__DOT___055718_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055229_)))));
    vlSelf->__VdfgTmp_hef4c4e2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055228_));
    vlSelf->wasmetal_core__DOT___055719_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___055224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_haccd68b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___055228_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055225_));
    vlSelf->__VdfgTmp_h0dc57e5a__0 = (((IData)(wasmetal_core__DOT___055225_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055224_));
    vlSelf->__VdfgTmp_h315e9115__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008962_));
    vlSelf->__VdfgTmp_he25b62bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008962_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055692_)));
    vlSelf->__VdfgTmp_hd3eaf9cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009303_));
    vlSelf->__VdfgTmp_h567718cf__0 = (((IData)(wasmetal_core__DOT___055692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055696_));
    vlSelf->wasmetal_core__DOT___009477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009301_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_h74bdf3b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___009303_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009302_));
    vlSelf->__VdfgTmp_h4ba92f5a__0 = (((IData)(wasmetal_core__DOT___009302_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009301_));
    vlSelf->__VdfgTmp_h2fcb0063__0 = (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009304_));
    vlSelf->__VdfgTmp_h3832b0f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___055696_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055695_));
    if (vlSelf->wasmetal_core__DOT___007874_) {
        vlSelf->wasmetal_core__DOT___007864_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007873_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))))));
        vlSelf->wasmetal_core__DOT___007863_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007887_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001874_))))))));
        vlSelf->wasmetal_core__DOT___007862_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007895_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001886_))))))));
        vlSelf->wasmetal_core__DOT___007905_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007908_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001437_))))))));
        vlSelf->wasmetal_core__DOT___007904_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007916_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001443_))))))));
        vlSelf->wasmetal_core__DOT___007903_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007924_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001475_))))))));
        vlSelf->wasmetal_core__DOT___007902_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007932_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001487_))))))));
        vlSelf->wasmetal_core__DOT___007942_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007947_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001369_))))))));
        vlSelf->wasmetal_core__DOT___007941_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007955_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001381_))))))));
        vlSelf->wasmetal_core__DOT___007940_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007963_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001413_))))))));
        vlSelf->wasmetal_core__DOT___007939_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007971_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001425_))))))));
        vlSelf->wasmetal_core__DOT___007981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007984_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001524_))))))));
        vlSelf->wasmetal_core__DOT___007980_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007992_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001536_))))))));
        vlSelf->wasmetal_core__DOT___007979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008000_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001568_))))))));
        vlSelf->wasmetal_core__DOT___007978_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008008_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001580_))))))));
        vlSelf->wasmetal_core__DOT___008028_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008033_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008032_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001612_))))))));
        vlSelf->wasmetal_core__DOT___008027_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008041_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008040_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001624_))))))));
        vlSelf->wasmetal_core__DOT___008026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008049_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008048_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001646_))))))));
        vlSelf->wasmetal_core__DOT___008025_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008057_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008056_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000419_))))))));
        vlSelf->wasmetal_core__DOT___008067_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008070_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008069_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000432_))))))));
        vlSelf->wasmetal_core__DOT___008066_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008078_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008077_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000464_))))))));
        vlSelf->wasmetal_core__DOT___008065_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008086_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008085_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000476_))))))));
        vlSelf->wasmetal_core__DOT___008064_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008094_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008093_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000498_))))))));
        vlSelf->wasmetal_core__DOT___008104_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008108_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000520_))))))));
        vlSelf->wasmetal_core__DOT___008103_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008116_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000542_))))))));
        vlSelf->wasmetal_core__DOT___008102_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008124_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000564_))))))));
        vlSelf->wasmetal_core__DOT___008101_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008132_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000591_))))))));
        vlSelf->wasmetal_core__DOT___008142_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008145_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000613_))))))));
        vlSelf->wasmetal_core__DOT___008141_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008153_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000635_))))))));
        vlSelf->wasmetal_core__DOT___008140_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008161_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000657_))))))));
        vlSelf->wasmetal_core__DOT___008139_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008169_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))))))));
        vlSelf->wasmetal_core__DOT___008179_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008183_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))))));
        vlSelf->wasmetal_core__DOT___008178_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008191_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))))));
        vlSelf->wasmetal_core__DOT___008177_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008199_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))))))));
        vlSelf->wasmetal_core__DOT___008176_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008207_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))))))));
        vlSelf->wasmetal_core__DOT___008217_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008220_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))))))));
        vlSelf->wasmetal_core__DOT___008216_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008228_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))))))));
        vlSelf->wasmetal_core__DOT___008215_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008236_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))))))));
        vlSelf->wasmetal_core__DOT___008214_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008244_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))))))));
        vlSelf->wasmetal_core__DOT___008254_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008258_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))))))));
        vlSelf->wasmetal_core__DOT___008253_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008266_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))))))));
        vlSelf->wasmetal_core__DOT___008252_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008274_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))))))));
        vlSelf->wasmetal_core__DOT___008251_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008282_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))))))));
        vlSelf->wasmetal_core__DOT___008292_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008295_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))))))));
        vlSelf->wasmetal_core__DOT___008291_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008303_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))))))));
        vlSelf->wasmetal_core__DOT___008290_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008311_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))))))));
        vlSelf->wasmetal_core__DOT___008289_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008319_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))))))));
        vlSelf->wasmetal_core__DOT___008329_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008334_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))))))));
        vlSelf->wasmetal_core__DOT___008328_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008342_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008341_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))))))));
        vlSelf->wasmetal_core__DOT___008327_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008350_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))))))));
        vlSelf->wasmetal_core__DOT___008326_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008358_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008357_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))))));
        vlSelf->wasmetal_core__DOT___008368_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008371_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008370_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001327_))))))));
        vlSelf->wasmetal_core__DOT___008367_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008379_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008378_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000980_))))))));
        vlSelf->wasmetal_core__DOT___008366_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008387_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000992_))))))));
        vlSelf->wasmetal_core__DOT___008365_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008395_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001014_))))))));
        vlSelf->wasmetal_core__DOT___008405_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008409_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001036_))))))));
        vlSelf->wasmetal_core__DOT___008404_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008417_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001058_))))))));
        vlSelf->wasmetal_core__DOT___008403_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008425_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001080_))))))));
        vlSelf->wasmetal_core__DOT___008402_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008433_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001102_))))))));
        vlSelf->wasmetal_core__DOT___008443_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008446_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001124_))))))));
        vlSelf->wasmetal_core__DOT___008442_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008454_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001146_))))))));
        vlSelf->wasmetal_core__DOT___008441_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008462_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001168_))))))));
        vlSelf->wasmetal_core__DOT___008440_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008470_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))))));
    } else {
        vlSelf->wasmetal_core__DOT___007864_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007873_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007247_)))));
        vlSelf->wasmetal_core__DOT___007863_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007887_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007274_)))));
        vlSelf->wasmetal_core__DOT___007862_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007895_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007301_)))));
        vlSelf->wasmetal_core__DOT___007905_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007908_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007334_)))));
        vlSelf->wasmetal_core__DOT___007904_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007916_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007360_)))));
        vlSelf->wasmetal_core__DOT___007903_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007924_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007386_)))));
        vlSelf->wasmetal_core__DOT___007902_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007932_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007413_)))));
        vlSelf->wasmetal_core__DOT___007942_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007947_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007431_)))));
        vlSelf->wasmetal_core__DOT___007941_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007955_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007246_)))));
        vlSelf->wasmetal_core__DOT___007940_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007963_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007273_)))));
        vlSelf->wasmetal_core__DOT___007939_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007971_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007300_)))));
        vlSelf->wasmetal_core__DOT___007981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007984_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007333_)))));
        vlSelf->wasmetal_core__DOT___007980_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007992_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007359_)))));
        vlSelf->wasmetal_core__DOT___007979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008000_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007385_)))));
        vlSelf->wasmetal_core__DOT___007978_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008008_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007412_)))));
        vlSelf->wasmetal_core__DOT___008028_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008033_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007430_)))));
        vlSelf->wasmetal_core__DOT___008027_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008041_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007249_)))));
        vlSelf->wasmetal_core__DOT___008026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008049_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007276_)))));
        vlSelf->wasmetal_core__DOT___008025_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008057_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007303_)))));
        vlSelf->wasmetal_core__DOT___008067_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008070_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007336_)))));
        vlSelf->wasmetal_core__DOT___008066_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008078_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007362_)))));
        vlSelf->wasmetal_core__DOT___008065_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008086_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007388_)))));
        vlSelf->wasmetal_core__DOT___008064_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008094_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007415_)))));
        vlSelf->wasmetal_core__DOT___008104_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008108_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007433_)))));
        vlSelf->wasmetal_core__DOT___008103_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008116_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007248_)))));
        vlSelf->wasmetal_core__DOT___008102_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008124_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007275_)))));
        vlSelf->wasmetal_core__DOT___008101_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008132_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007302_)))));
        vlSelf->wasmetal_core__DOT___008142_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008145_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007335_)))));
        vlSelf->wasmetal_core__DOT___008141_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008153_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007361_)))));
        vlSelf->wasmetal_core__DOT___008140_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008161_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007387_)))));
        vlSelf->wasmetal_core__DOT___008139_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008169_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007414_)))));
        vlSelf->wasmetal_core__DOT___008179_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008183_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007432_)))));
        vlSelf->wasmetal_core__DOT___008178_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008191_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007252_)))));
        vlSelf->wasmetal_core__DOT___008177_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008199_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007279_)))));
        vlSelf->wasmetal_core__DOT___008176_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008207_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007306_)))));
        vlSelf->wasmetal_core__DOT___008217_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008220_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007339_)))));
        vlSelf->wasmetal_core__DOT___008216_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008228_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007365_)))));
        vlSelf->wasmetal_core__DOT___008215_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008236_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007391_)))));
        vlSelf->wasmetal_core__DOT___008214_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008244_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007418_)))));
        vlSelf->wasmetal_core__DOT___008254_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008258_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007770_)))));
        vlSelf->wasmetal_core__DOT___008253_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008266_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007251_)))));
        vlSelf->wasmetal_core__DOT___008252_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008274_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007278_)))));
        vlSelf->wasmetal_core__DOT___008251_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008282_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007305_)))));
        vlSelf->wasmetal_core__DOT___008292_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008295_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007338_)))));
        vlSelf->wasmetal_core__DOT___008291_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008303_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007364_)))));
        vlSelf->wasmetal_core__DOT___008290_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008311_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007390_)))));
        vlSelf->wasmetal_core__DOT___008289_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008319_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007417_)))));
        vlSelf->wasmetal_core__DOT___008329_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008334_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007772_)))));
        vlSelf->wasmetal_core__DOT___008328_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008342_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007254_)))));
        vlSelf->wasmetal_core__DOT___008327_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008350_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007281_)))));
        vlSelf->wasmetal_core__DOT___008326_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008358_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007308_)))));
        vlSelf->wasmetal_core__DOT___008368_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008371_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007341_)))));
        vlSelf->wasmetal_core__DOT___008367_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008379_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007367_)))));
        vlSelf->wasmetal_core__DOT___008366_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008387_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007393_)))));
        vlSelf->wasmetal_core__DOT___008365_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008395_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007420_)))));
        vlSelf->wasmetal_core__DOT___008405_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008409_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007771_)))));
        vlSelf->wasmetal_core__DOT___008404_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008417_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007253_)))));
        vlSelf->wasmetal_core__DOT___008403_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008425_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007280_)))));
        vlSelf->wasmetal_core__DOT___008402_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008433_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007307_)))));
        vlSelf->wasmetal_core__DOT___008443_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008446_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007340_)))));
        vlSelf->wasmetal_core__DOT___008442_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008454_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007366_)))));
        vlSelf->wasmetal_core__DOT___008441_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008462_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007392_)))));
        vlSelf->wasmetal_core__DOT___008440_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008470_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007419_)))));
    }
    vlSelf->wasmetal_core__DOT___062488_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055983_))));
    __VdfgTmp_h1432c284__0 = (((IData)(vlSelf->wasmetal_core__DOT___009292_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hbd36bb7c__0));
    vlSelf->__VdfgTmp_h48a07a7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hbd36bb7c__0));
    vlSelf->wasmetal_core__DOT___009945_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha16fbbbf__0))))));
    wasmetal_core__DOT___055622_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha16fbbbf__0))));
    vlSelf->wasmetal_core__DOT___009357_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009471_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009293_)))))));
    vlSelf->wasmetal_core__DOT___055984_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009472_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055983_)))));
    vlSelf->wasmetal_core__DOT___055921_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055618_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2b13b0f__0))))))));
    vlSelf->wasmetal_core__DOT___055614_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2b13b0f__0))));
    vlSelf->wasmetal_core__DOT___009939_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009745_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)))))));
    vlSelf->__VdfgTmp_h282170d2__0 = ((2U & ((0x35U 
                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009745_));
    vlSelf->__VdfgTmp_h7bd92bc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009463_));
    vlSelf->__VdfgTmp_h8ad90c85__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6e24fc79__0)))));
    vlSelf->wasmetal_core__DOT___009275_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055566_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6e24fc79__0))))))));
    vlSelf->wasmetal_core__DOT___009465_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb785bdc8__0))))))));
    __VdfgTmp_h5311778a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb785bdc8__0));
    vlSelf->wasmetal_core__DOT___009346_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb307080d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055822_)))));
    vlSelf->wasmetal_core__DOT___009979_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055822_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb307080d__0)))))));
    vlSelf->wasmetal_core__DOT___009459_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b31618a__0))));
    vlSelf->__VdfgTmp_heeb9424e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009091_));
    vlSelf->wasmetal_core__DOT___009267_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009091_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055544_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009771_)))))));
    vlSelf->wasmetal_core__DOT___008878_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055543_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055544_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1ccd197a__0))))))));
    vlSelf->wasmetal_core__DOT___009405_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055544_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf7b90195__0))))))));
    vlSelf->wasmetal_core__DOT___055538_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7b90195__0))));
    __VdfgTmp_h073f9b05__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008877_));
    vlSelf->wasmetal_core__DOT___009460_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd1825153__0))))))));
    vlSelf->__VdfgTmp_hbd15e417__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd1825153__0));
    vlSelf->wasmetal_core__DOT___056089_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0)))))));
    vlSelf->wasmetal_core__DOT___009400_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbf11cfc1__0))))))));
    vlSelf->wasmetal_core__DOT___055962_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___009185_))))
                                                    : 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009187_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009188_)))
                                                    : 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(wasmetal_core__DOT___009186_))))));
    vlSelf->wasmetal_core__DOT___009181_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    __VdfgTmp_h74a36385__0 = (((IData)(vlSelf->wasmetal_core__DOT___009187_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hd63c68ee__0));
    vlSelf->__VdfgTmp_hb1de0cec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd63c68ee__0));
    vlSelf->wasmetal_core__DOT___009330_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h23e0654e__0))))));
    vlSelf->wasmetal_core__DOT___009258_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051500_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009189_)))))));
    vlSelf->wasmetal_core__DOT___009956_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055448_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he1badc2d__0))))))));
    wasmetal_core__DOT___055449_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_he1badc2d__0))));
    vlSelf->wasmetal_core__DOT___009175_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he6145195__0))));
    vlSelf->wasmetal_core__DOT___009323_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055768_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he6145195__0))))));
    vlSelf->wasmetal_core__DOT___009923_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055445_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h52b8127f__0))))))));
    vlSelf->wasmetal_core__DOT___055451_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h52b8127f__0))));
    __VdfgTmp_h4bc07745__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055953_));
    __VdfgTmp_he55661b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___055953_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h416357e2__0)))));
    vlSelf->wasmetal_core__DOT___009441_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h416357e2__0))))))));
    __VdfgTmp_h0c69b60f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009253_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h53c22b41__0));
    vlSelf->__VdfgTmp_h3f55ca01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h53c22b41__0));
    wasmetal_core__DOT___056008_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha9c0231a__0))));
    vlSelf->wasmetal_core__DOT___009972_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha9c0231a__0))))));
    vlSelf->__VdfgTmp_h3eec0328__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055736_));
    vlSelf->wasmetal_core__DOT___009233_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009240_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a22e24__0))))))));
    vlSelf->__VdfgTmp_hfc35c726__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a22e24__0));
    vlSelf->wasmetal_core__DOT___009434_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha4fdb8c7__0))))))));
    vlSelf->__VdfgTmp_h243a5897__0 = ((2U & ((0x35U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha4fdb8c7__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___055736_));
    vlSelf->wasmetal_core__DOT___009317_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055738_)))));
    vlSelf->wasmetal_core__DOT___056079_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h381f02c3__0))));
    vlSelf->wasmetal_core__DOT___009927_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055408_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h381f02c3__0))))))));
    vlSelf->wasmetal_core__DOT___009224_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055236_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0eab1d01__0))))))));
    vlSelf->wasmetal_core__DOT___009147_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0b92bce8__0))));
    vlSelf->wasmetal_core__DOT___009967_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0eab1d01__0))))));
    vlSelf->wasmetal_core__DOT___009309_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b92bce8__0))))));
    wasmetal_core__DOT___055238_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hef4c4e2a__0))));
    vlSelf->wasmetal_core__DOT___009930_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hef4c4e2a__0))))))));
    vlSelf->__VdfgTmp_hf516e409__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055719_));
    vlSelf->wasmetal_core__DOT___009427_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haccd68b9__0))))))));
    __VdfgTmp_h58490cb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_haccd68b9__0));
    vlSelf->wasmetal_core__DOT___055359_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055228_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0dc57e5a__0))))))));
    __VdfgTmp_hf9513718__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h0dc57e5a__0));
    vlSelf->wasmetal_core__DOT___056147_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd3eaf9cd__0))));
    vlSelf->wasmetal_core__DOT___009422_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055696_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd3eaf9cd__0))))))));
    vlSelf->wasmetal_core__DOT___009478_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h567718cf__0))));
    vlSelf->wasmetal_core__DOT___056170_ = (1U & (0xff80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009477_)))))));
    vlSelf->__VdfgTmp_h7ca1d027__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009477_));
    vlSelf->wasmetal_core__DOT___009479_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h74bdf3b8__0))))))));
    wasmetal_core__DOT___055851_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h74bdf3b8__0))));
    vlSelf->wasmetal_core__DOT___009296_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009303_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4ba92f5a__0))))))));
    vlSelf->wasmetal_core__DOT___055689_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ba92f5a__0))));
    wasmetal_core__DOT___055850_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h2fcb0063__0))));
    wasmetal_core__DOT___056148_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h3832b0f6__0))));
    vlSelf->wasmetal_core__DOT___009295_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3832b0f6__0))))));
    vlSelf->__VdfgTmp_h2567a16a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007864_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007863_))));
    __VdfgTmp_heeb49de9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007863_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007862_));
    __VdfgTmp_h66d4b740__0 = (((IData)(vlSelf->wasmetal_core__DOT___007862_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007905_));
    vlSelf->__VdfgTmp_hb7c4f884__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007905_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007904_))));
    vlSelf->__VdfgTmp_h422b1f0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007903_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007902_));
    __VdfgTmp_h45767413__0 = (((IData)(vlSelf->wasmetal_core__DOT___007902_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007942_));
    __VdfgTmp_h3043729e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007942_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007941_));
    __VdfgTmp_h78ab269f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007940_));
    __VdfgTmp_h984be98a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007939_));
    vlSelf->__VdfgTmp_h4bfa77b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007981_));
    vlSelf->__VdfgTmp_ha9e5b07a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007980_));
    __VdfgTmp_ha94b79fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007980_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007979_));
    __VdfgTmp_hcf6d3894__0 = (((IData)(vlSelf->wasmetal_core__DOT___007979_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007978_));
    __VdfgTmp_h509cc1df__0 = (((IData)(vlSelf->wasmetal_core__DOT___007978_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008028_));
    __VdfgTmp_h86440ee1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008028_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008027_));
    __VdfgTmp_h62a41e7a__0 = (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008026_));
    __VdfgTmp_hc8a1f90d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008025_));
    vlSelf->__VdfgTmp_hc20acf35__0 = (((IData)(vlSelf->wasmetal_core__DOT___008025_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008067_));
    __VdfgTmp_he9adc993__0 = (((IData)(vlSelf->wasmetal_core__DOT___008067_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008066_));
    __VdfgTmp_h23e62674__0 = (((IData)(vlSelf->wasmetal_core__DOT___008066_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008065_));
    __VdfgTmp_h6bf7b02b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008065_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008064_));
    __VdfgTmp_hb0c1ca1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___008064_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008104_));
    __VdfgTmp_hba82f58f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008104_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008103_));
    __VdfgTmp_h36eed793__0 = (((IData)(vlSelf->wasmetal_core__DOT___008103_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008102_));
    __VdfgTmp_h003583a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008102_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008101_));
    __VdfgTmp_h39517120__0 = (((IData)(vlSelf->wasmetal_core__DOT___008101_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008142_));
    __VdfgTmp_h6f4dbdf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008142_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008141_));
    __VdfgTmp_hf92edf21__0 = (((IData)(vlSelf->wasmetal_core__DOT___008141_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008140_));
    __VdfgTmp_h1a11d128__0 = (((IData)(vlSelf->wasmetal_core__DOT___008140_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008139_));
    __VdfgTmp_h9087e671__0 = (((IData)(vlSelf->wasmetal_core__DOT___008139_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008179_));
    __VdfgTmp_h281b8ab1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008179_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008178_));
    __VdfgTmp_h7ae355e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___008178_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008177_));
    __VdfgTmp_hae4042e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008177_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008176_));
    __VdfgTmp_h029c8a85__0 = (((IData)(vlSelf->wasmetal_core__DOT___008176_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008217_));
    __VdfgTmp_hea01e0cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___008217_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008216_));
    __VdfgTmp_h6bd09dd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008216_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008215_));
    __VdfgTmp_he0f5bdf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008215_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008214_));
    __VdfgTmp_h004771e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___008214_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008254_));
    __VdfgTmp_hb3c8072f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008254_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008253_));
    __VdfgTmp_hd226433b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008253_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008252_));
    __VdfgTmp_h6e85e3ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___008252_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008251_));
    __VdfgTmp_ha3cbecc2__0 = (((IData)(vlSelf->wasmetal_core__DOT___008251_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008292_));
    __VdfgTmp_h8255702a__0 = (((IData)(vlSelf->wasmetal_core__DOT___008292_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008291_));
    __VdfgTmp_h8a1e5cea__0 = (((IData)(vlSelf->wasmetal_core__DOT___008291_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008290_));
    __VdfgTmp_h7cc8bc90__0 = (((IData)(vlSelf->wasmetal_core__DOT___008290_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008289_));
    __VdfgTmp_h31ba5af5__0 = (((IData)(vlSelf->wasmetal_core__DOT___008289_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008329_));
    __VdfgTmp_h77b03a4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008329_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008328_));
    __VdfgTmp_hc49bb9d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008328_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008327_));
    __VdfgTmp_h038396ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___008327_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008326_));
    __VdfgTmp_hfb882020__0 = (((IData)(vlSelf->wasmetal_core__DOT___008326_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008368_));
    __VdfgTmp_h7fe0949a__0 = (((IData)(vlSelf->wasmetal_core__DOT___008368_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008367_));
    __VdfgTmp_h09e28282__0 = (((IData)(vlSelf->wasmetal_core__DOT___008367_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008366_));
    __VdfgTmp_h199a7061__0 = (((IData)(vlSelf->wasmetal_core__DOT___008366_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008365_));
    __VdfgTmp_h4e0b8941__0 = (((IData)(vlSelf->wasmetal_core__DOT___008365_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008405_));
    __VdfgTmp_hf34c8dd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008405_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008404_));
    __VdfgTmp_h8b5fdfca__0 = (((IData)(vlSelf->wasmetal_core__DOT___008404_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008403_));
    __VdfgTmp_h524558f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___008403_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008402_));
    vlSelf->__VdfgTmp_h94861db4__0 = (((IData)(vlSelf->wasmetal_core__DOT___008402_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008443_));
    __VdfgTmp_he9911376__0 = (((IData)(vlSelf->wasmetal_core__DOT___008443_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008442_));
    __VdfgTmp_h6299ef40__0 = (((IData)(vlSelf->wasmetal_core__DOT___008442_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008441_));
    vlSelf->wasmetal_core__DOT___008901_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                    ? 
                                                   (0xfdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___008440_))))
                                                    : 
                                                   (0xf5f3U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h6299ef40__0)))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008904_))));
    vlSelf->__VdfgTmp_h1ab3b1fe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008440_))));
    vlSelf->__VdfgTmp_h79214203__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008440_));
    vlSelf->wasmetal_core__DOT___009016_ = (1U & (IData)(
                                                         (0xff330f5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008441_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008440_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008442_)))))))));
    __VdfgTmp_hc1229de7__0 = (((IData)(vlSelf->wasmetal_core__DOT___008440_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007854_))));
    vlSelf->wasmetal_core__DOT___055709_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008440_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007858_)))))));
    __VdfgTmp_h1f1491ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___008441_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008440_));
    vlSelf->wasmetal_core__DOT___009285_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h1432c284__0)))))));
    vlSelf->__VdfgTmp_ha91317d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h1432c284__0)));
    vlSelf->wasmetal_core__DOT___009419_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))));
    vlSelf->wasmetal_core__DOT___009728_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd2b13b0f__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009945_)))))));
    vlSelf->wasmetal_core__DOT___009284_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                          << 1U)) 
                                                      | (IData)(wasmetal_core__DOT___055622_)))));
    vlSelf->wasmetal_core__DOT___009708_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___009110_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055921_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))))))));
    vlSelf->wasmetal_core__DOT___009417_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055622_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055614_)))));
    vlSelf->wasmetal_core__DOT___009276_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h282170d2__0))));
    vlSelf->wasmetal_core__DOT___062485_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0))))));
    vlSelf->__VdfgTmp_h35ac7889__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009412_));
    vlSelf->__VdfgTmp_h9f90b4cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))));
    vlSelf->__VdfgTmp_h5e622f55__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_));
    vlSelf->__VdfgTmp_h16f25fe1__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009465_));
    vlSelf->__VdfgTmp_h9685faf4__0 = ((2U & ((0x35U 
                                              >> (IData)(__VdfgTmp_h5311778a__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009463_));
    vlSelf->wasmetal_core__DOT___055825_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009979_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009463_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(__VdfgTmp_h5311778a__0)))))))))));
    vlSelf->wasmetal_core__DOT___009333_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009459_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1ccd197a__0))))));
    vlSelf->wasmetal_core__DOT___009701_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0)))))))))));
    vlSelf->__VdfgTmp_h7856ed04__0 = (((IData)(vlSelf->wasmetal_core__DOT___009405_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x35U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0)))));
    vlSelf->__VdfgTmp_h45aa792f__0 = (((IData)(vlSelf->wasmetal_core__DOT___055538_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0))));
    vlSelf->__VdfgTmp_h18926335__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(__VdfgTmp_h073f9b05__0))));
    vlSelf->wasmetal_core__DOT___062401_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(__VdfgTmp_h073f9b05__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009460_)))));
    vlSelf->wasmetal_core__DOT___009199_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009460_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h073f9b05__0))))))));
    vlSelf->__VdfgTmp_had646e7f__0 = ((2U & ((0x35U 
                                              >> (IData)(vlSelf->__VdfgTmp_hbd15e417__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___008877_));
    vlSelf->wasmetal_core__DOT___009259_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h74a36385__0)))))));
    vlSelf->wasmetal_core__DOT___009329_ = (1U & (0xf5533ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h74a36385__0)))));
    vlSelf->wasmetal_core__DOT___062378_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009400_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)))))))));
    vlSelf->wasmetal_core__DOT___009402_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)))))));
    vlSelf->wasmetal_core__DOT___009050_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)))))))))));
    vlSelf->__VdfgTmp_h7c9afb82__0 = (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                       << 1U) | (1U 
                                                 & (0x3355f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0x35U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)) 
                                                               << 2U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbf11cfc1__0)))))));
    vlSelf->wasmetal_core__DOT___009245_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009035_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___055449_)))));
    vlSelf->wasmetal_core__DOT___009997_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055768_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009175_)))));
    vlSelf->wasmetal_core__DOT___009396_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055451_)))));
    vlSelf->__VdfgTmp_h52168cf5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(__VdfgTmp_h4bc07745__0))));
    vlSelf->wasmetal_core__DOT___009998_ = (1U & (IData)(
                                                         (0xfafcf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he55661b3__0))))))));
    vlSelf->wasmetal_core__DOT___056221_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he55661b3__0))));
    vlSelf->wasmetal_core__DOT___062396_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(__VdfgTmp_h4bc07745__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009441_)))));
    vlSelf->wasmetal_core__DOT___009170_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009441_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h4bc07745__0))))))));
    vlSelf->wasmetal_core__DOT___009246_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h0c69b60f__0)))))));
    vlSelf->wasmetal_core__DOT___009322_ = (1U & (0xf5533ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h0c69b60f__0)))));
    vlSelf->wasmetal_core__DOT___056162_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h52b8127f__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009956_)))))));
    vlSelf->wasmetal_core__DOT___009397_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))));
    vlSelf->wasmetal_core__DOT___009027_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009923_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))))));
    vlSelf->wasmetal_core__DOT___009232_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)) 
                                                          << 1U)) 
                                                      | (IData)(wasmetal_core__DOT___056008_)))));
    vlSelf->__VdfgTmp_h20f110d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3eec0328__0))));
    vlSelf->wasmetal_core__DOT___009973_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___009388_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0)))))));
    vlSelf->wasmetal_core__DOT___011285_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0)) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h381f02c3__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009972_)))))));
    vlSelf->__VdfgTmp_h3dedcb44__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h3eec0328__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009434_));
    vlSelf->wasmetal_core__DOT___055739_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h243a5897__0))));
    vlSelf->wasmetal_core__DOT___009386_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056008_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056079_)))));
    vlSelf->wasmetal_core__DOT___009988_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009147_)))));
    vlSelf->wasmetal_core__DOT___009375_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___055238_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0eab1d01__0))))));
    vlSelf->__VdfgTmp_heabab031__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf516e409__0))));
    vlSelf->__VdfgTmp_h38f150ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___055719_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> (IData)(__VdfgTmp_h58490cb9__0))));
    vlSelf->__VdfgTmp_h1125b1e9__0 = ((2U & ((0x35U 
                                              >> (IData)(__VdfgTmp_h58490cb9__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___055719_));
    vlSelf->wasmetal_core__DOT___055362_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055359_)))));
    vlSelf->wasmetal_core__DOT___009374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(__VdfgTmp_hf9513718__0))))));
    vlSelf->__VdfgTmp_h6b56eebb__0 = (((IData)(wasmetal_core__DOT___055238_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(__VdfgTmp_hf9513718__0))));
    vlSelf->__VdfgTmp_hb294466b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> (IData)(__VdfgTmp_hf9513718__0))));
    vlSelf->wasmetal_core__DOT___062491_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))))));
    vlSelf->wasmetal_core__DOT___009219_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009479_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))))))));
    vlSelf->__VdfgTmp_h748d3c0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009477_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055851_)));
    vlSelf->wasmetal_core__DOT___009952_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009296_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->__VdfgTmp_h584d0366__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055689_));
    vlSelf->wasmetal_core__DOT___056169_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055851_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___055850_)))));
    vlSelf->wasmetal_core__DOT___009984_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___055850_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h567718cf__0))))));
    vlSelf->wasmetal_core__DOT___009920_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056147_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___056148_)))));
    vlSelf->wasmetal_core__DOT___009951_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056148_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)))))));
    vlSelf->wasmetal_core__DOT___055710_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009295_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x3355f0f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055689_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hd3eaf9cd__0))))))))));
    vlSelf->__VdfgTmp_h4d366d59__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_heeb49de9__0)));
    vlSelf->__VdfgTmp_hd4d63a34__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h66d4b740__0)));
    vlSelf->wasmetal_core__DOT___007906_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007905_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007904_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h422b1f0e__0))))))));
    vlSelf->__VdfgTmp_hae568380__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007904_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007903_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h45767413__0)))));
    vlSelf->__VdfgTmp_h3068c687__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h45767413__0)));
    vlSelf->__VdfgTmp_h3ba3f00e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h3043729e__0)));
    vlSelf->__VdfgTmp_h7737ac68__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007903_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007902_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h3043729e__0)))));
    vlSelf->wasmetal_core__DOT___055481_ = (1U & (0xf0f055ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007902_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007942_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h78ab269f__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                   << 2U) 
                                                                  | (IData)(__VdfgTmp_h66d4b740__0))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xacU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007904_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007903_)))))))))));
    vlSelf->__VdfgTmp_hf33cf413__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h78ab269f__0)));
    vlSelf->wasmetal_core__DOT___008639_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h984be98a__0))))))));
    vlSelf->__VdfgTmp_h935ba97a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h984be98a__0)));
    vlSelf->__VdfgTmp_h21ecfb21__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4bfa77b1__0)));
    vlSelf->__VdfgTmp_h83c5326a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha9e5b07a__0)));
    vlSelf->__VdfgTmp_h8c5bf8f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_ha94b79fc__0)));
    vlSelf->__VdfgTmp_h85f1be24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007981_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_ha94b79fc__0)))));
    vlSelf->__VdfgTmp_haff0ba2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007981_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007980_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hcf6d3894__0)))));
    vlSelf->__VdfgTmp_hae7eba08__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hcf6d3894__0)));
    vlSelf->__VdfgTmp_hc719aa4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007980_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007979_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h509cc1df__0)))));
    vlSelf->__VdfgTmp_hdb0e0153__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h509cc1df__0)));
    vlSelf->__VdfgTmp_h0d1d68d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007979_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007978_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h86440ee1__0)))));
    vlSelf->__VdfgTmp_hf5a39c51__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h86440ee1__0)));
    vlSelf->__VdfgTmp_hee048ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007978_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008028_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h62a41e7a__0)))));
    vlSelf->__VdfgTmp_hc903ec6a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h62a41e7a__0)));
    vlSelf->wasmetal_core__DOT___008642_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hc8a1f90d__0))))))));
    vlSelf->__VdfgTmp_ha30079fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hc8a1f90d__0)));
    vlSelf->__VdfgTmp_hab9b53a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc20acf35__0)));
    vlSelf->__VdfgTmp_hab3491b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008025_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he9adc993__0)))));
    vlSelf->wasmetal_core__DOT___008558_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_he9adc993__0)))));
    vlSelf->__VdfgTmp_h09c5f4e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h23e62674__0)));
    vlSelf->__VdfgTmp_hc229347b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008025_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008067_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h23e62674__0)))));
    vlSelf->__VdfgTmp_h0de86ccc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008067_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008066_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6bf7b02b__0)))));
    vlSelf->__VdfgTmp_hc1f7329f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6bf7b02b__0)));
    vlSelf->__VdfgTmp_hd3e9a659__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008066_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008065_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hb0c1ca1e__0)))));
    vlSelf->__VdfgTmp_hbb21088e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hb0c1ca1e__0)));
    vlSelf->wasmetal_core__DOT___055459_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008065_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008064_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hba82f58f__0))))))));
    vlSelf->__VdfgTmp_hb1634503__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hba82f58f__0)));
    vlSelf->__VdfgTmp_h3429c82f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008064_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008104_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h36eed793__0)))));
    vlSelf->__VdfgTmp_h04ff5b07__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h36eed793__0)));
    vlSelf->wasmetal_core__DOT___055550_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008104_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008103_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h003583a9__0))))))));
    vlSelf->__VdfgTmp_h6bb5c719__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h003583a9__0)));
    vlSelf->__VdfgTmp_hfb017b9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008103_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008102_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h39517120__0)))));
    vlSelf->__VdfgTmp_h3c51f194__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h39517120__0)));
    vlSelf->__VdfgTmp_ha22ec9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008101_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6f4dbdf9__0)))));
    vlSelf->__VdfgTmp_hce5d0ce9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6f4dbdf9__0)));
    vlSelf->__VdfgTmp_h7cb0a391__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf92edf21__0)));
    vlSelf->__VdfgTmp_hb46d48f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008101_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008142_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf92edf21__0)))));
    vlSelf->__VdfgTmp_h7092c9cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008142_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008141_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1a11d128__0)))));
    vlSelf->__VdfgTmp_h1390519c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h1a11d128__0)));
    vlSelf->__VdfgTmp_hefb478a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008141_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008140_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h9087e671__0)))));
    vlSelf->__VdfgTmp_h9b67b4e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h9087e671__0)));
    vlSelf->__VdfgTmp_h855995cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008140_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008139_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h281b8ab1__0)))));
    vlSelf->__VdfgTmp_h158bc821__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h281b8ab1__0)));
    vlSelf->__VdfgTmp_h114e86e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008139_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008179_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h7ae355e5__0)))));
    vlSelf->__VdfgTmp_hf0c32555__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h7ae355e5__0)));
    vlSelf->__VdfgTmp_h91c21bf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008179_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008178_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hae4042e0__0)))));
    vlSelf->__VdfgTmp_h8daf8054__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hae4042e0__0)));
    vlSelf->__VdfgTmp_hed13b60d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008178_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008177_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h029c8a85__0)))));
    vlSelf->__VdfgTmp_h690ec875__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h029c8a85__0)));
    vlSelf->__VdfgTmp_h0c7e8da3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008177_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008176_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hea01e0cb__0)))));
    vlSelf->__VdfgTmp_h43e1a2bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hea01e0cb__0)));
    vlSelf->__VdfgTmp_hc1d26d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6bd09dd8__0)));
    vlSelf->__VdfgTmp_h3418aecb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008176_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008217_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6bd09dd8__0)))));
    vlSelf->__VdfgTmp_h051dc5dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008217_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008216_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he0f5bdf9__0)))));
    vlSelf->__VdfgTmp_h4af50ce9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he0f5bdf9__0)));
    vlSelf->__VdfgTmp_hf618fe17__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008216_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008215_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h004771e7__0)))));
    vlSelf->__VdfgTmp_h6ba7f15b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h004771e7__0)));
    vlSelf->__VdfgTmp_h2ada8d2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008215_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008214_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hb3c8072f__0)))));
    vlSelf->wasmetal_core__DOT___008255_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hb3c8072f__0)))));
    vlSelf->__VdfgTmp_he5945a68__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008214_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008254_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd226433b__0)))));
    vlSelf->__VdfgTmp_h5985862f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hd226433b__0)));
    vlSelf->__VdfgTmp_ha8c0c19d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008254_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008253_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6e85e3ea__0)))));
    vlSelf->__VdfgTmp_hcd65a75a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6e85e3ea__0)));
    vlSelf->wasmetal_core__DOT___055577_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008253_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008252_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_ha3cbecc2__0))))))));
    vlSelf->__VdfgTmp_h89da7eb2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_ha3cbecc2__0)));
    vlSelf->wasmetal_core__DOT___055627_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008252_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008251_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h8255702a__0))))))));
    vlSelf->__VdfgTmp_he955f29a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h8255702a__0)));
    vlSelf->__VdfgTmp_he1802e5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h8a1e5cea__0)));
    vlSelf->__VdfgTmp_hefdefca0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008251_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008292_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h8a1e5cea__0)))));
    vlSelf->wasmetal_core__DOT___051933_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008292_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008291_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h7cc8bc90__0))))))));
    vlSelf->__VdfgTmp_hfeda0e04__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h7cc8bc90__0)));
    vlSelf->__VdfgTmp_h91b07825__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008291_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008290_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h31ba5af5__0)))));
    vlSelf->__VdfgTmp_h042cd865__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h31ba5af5__0)));
    vlSelf->__VdfgTmp_he2ba4454__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008290_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008289_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h77b03a4f__0)))));
    vlSelf->__VdfgTmp_hc63fb8c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h77b03a4f__0)));
    vlSelf->__VdfgTmp_hc2ad9167__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008289_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008329_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hc49bb9d8__0)))));
    vlSelf->__VdfgTmp_hb70b394c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hc49bb9d8__0)));
    vlSelf->__VdfgTmp_h70bc0e9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008329_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008328_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h038396ba__0)))));
    vlSelf->__VdfgTmp_h6a6364aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h038396ba__0)));
    vlSelf->__VdfgTmp_hf74c6a47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008328_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008327_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hfb882020__0)))));
    vlSelf->__VdfgTmp_h7267e294__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hfb882020__0)));
    vlSelf->__VdfgTmp_hf4d4c7d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008327_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008326_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h7fe0949a__0)))));
    vlSelf->__VdfgTmp_hfdc2660a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h7fe0949a__0)));
    if (vlSelf->wasmetal_core__DOT___007866_) {
        vlSelf->wasmetal_core__DOT___007853_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_heeb49de9__0))));
        vlSelf->wasmetal_core__DOT___007856_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0)));
        vlSelf->wasmetal_core__DOT___055545_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0)));
        vlSelf->wasmetal_core__DOT___051315_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0)));
        vlSelf->wasmetal_core__DOT___055744_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0)));
        vlSelf->wasmetal_core__DOT___055458_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008558_));
        vlSelf->wasmetal_core__DOT___055474_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)));
        vlSelf->wasmetal_core__DOT___055549_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0)));
        vlSelf->wasmetal_core__DOT___055818_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0)));
        vlSelf->wasmetal_core__DOT___055630_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055845_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___051313_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055353_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055742_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055395_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055456_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0)));
        vlSelf->wasmetal_core__DOT___055898_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0)));
        vlSelf->wasmetal_core__DOT___055472_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0)));
        vlSelf->wasmetal_core__DOT___055547_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)));
        vlSelf->wasmetal_core__DOT___055925_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055701_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___051934_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055358_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055945_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055391_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055885_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055454_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055470_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055804_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055530_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055576_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___055626_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008255_));
        vlSelf->wasmetal_core__DOT___055844_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055699_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___051932_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___055947_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___055389_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___055887_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___055452_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009878_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0)));
        vlSelf->wasmetal_core__DOT___008856_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009338_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009353_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h042cd865__0)));
        vlSelf->wasmetal_core__DOT___009860_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___008930_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___009368_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0)));
        vlSelf->wasmetal_core__DOT___009381_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0)));
        vlSelf->wasmetal_core__DOT___009392_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___009031_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
    } else {
        vlSelf->wasmetal_core__DOT___007853_ = (1U 
                                                & (0xfeeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007864_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___007874_)
                                                                ? 
                                                               (0x5333U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007883_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))))))
                                                                : 
                                                               (1U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007883_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___007881_)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0x8f00U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb0e57990__0))))))))));
        vlSelf->wasmetal_core__DOT___007856_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3ba3f00e__0)));
        vlSelf->wasmetal_core__DOT___055545_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0)));
        vlSelf->wasmetal_core__DOT___051315_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0)));
        vlSelf->wasmetal_core__DOT___055744_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0)));
        vlSelf->wasmetal_core__DOT___055458_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0)));
        vlSelf->wasmetal_core__DOT___055474_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0)));
        vlSelf->wasmetal_core__DOT___055549_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008558_));
        vlSelf->wasmetal_core__DOT___055818_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)));
        vlSelf->wasmetal_core__DOT___055630_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0)));
        vlSelf->wasmetal_core__DOT___055845_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0)));
        vlSelf->wasmetal_core__DOT___051313_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055353_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055742_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___055395_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___055456_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055898_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055472_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055547_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0)));
        vlSelf->wasmetal_core__DOT___055925_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)));
        vlSelf->wasmetal_core__DOT___055701_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0)));
        vlSelf->wasmetal_core__DOT___051934_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055358_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055945_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___055391_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___055885_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055454_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055470_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055804_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055530_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055576_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055626_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055844_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___055699_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___051932_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008255_));
        vlSelf->wasmetal_core__DOT___055947_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055389_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055887_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___055452_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___009878_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___008856_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009338_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009353_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0)));
        vlSelf->wasmetal_core__DOT___009860_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___008930_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009368_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h042cd865__0)));
        vlSelf->wasmetal_core__DOT___009381_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___009392_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0)));
        vlSelf->wasmetal_core__DOT___009031_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0)));
    }
    vlSelf->__VdfgTmp_h63c4c072__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h09e28282__0)));
    vlSelf->__VdfgTmp_h70291c6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008326_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008368_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h09e28282__0)))));
    vlSelf->__VdfgTmp_h850327e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008368_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008367_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h199a7061__0)))));
    vlSelf->__VdfgTmp_h1c0cf2d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h199a7061__0)));
    vlSelf->__VdfgTmp_h950f0cb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008367_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008366_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h4e0b8941__0)))));
    vlSelf->__VdfgTmp_h2f9bc831__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h4e0b8941__0)));
    vlSelf->__VdfgTmp_hd89c9b51__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008366_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008365_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf34c8dd6__0)))));
    vlSelf->__VdfgTmp_h7a5e1d46__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf34c8dd6__0)));
    vlSelf->__VdfgTmp_hdd777bec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008365_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008405_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h8b5fdfca__0)))));
    vlSelf->__VdfgTmp_he24fa3ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h8b5fdfca__0)));
    vlSelf->__VdfgTmp_h69785613__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008405_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008404_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h524558f7__0)))));
    vlSelf->__VdfgTmp_hd9a5d9eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h524558f7__0)));
    vlSelf->__VdfgTmp_h2c35a4fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008404_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008403_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h94861db4__0)))));
    vlSelf->__VdfgTmp_h6405266c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h94861db4__0));
    vlSelf->__VdfgTmp_hf17c2029__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008403_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008402_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he9911376__0)))));
    vlSelf->__VdfgTmp_h4c1297e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he9911376__0)));
    vlSelf->__VdfgTmp_h0dadf452__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h6299ef40__0))));
    vlSelf->__VdfgTmp_h5629f5f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 2U) | (IData)(__VdfgTmp_h6299ef40__0));
    vlSelf->__VdfgTmp_hee6f9dc2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008402_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008443_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6299ef40__0)))));
    vlSelf->wasmetal_core__DOT___055932_ = (1U & (0xfeffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hc1229de7__0))));
    vlSelf->wasmetal_core__DOT___009480_ = ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            & (IData)(
                                                      (0x1000100ffff0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008962_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_hc1229de7__0))))));
    vlSelf->__VdfgTmp_h08b4abe6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 4U) | (IData)(__VdfgTmp_hc1229de7__0));
    vlSelf->__VdfgTmp_hca6b58ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1f1491ac__0)))));
    vlSelf->__VdfgTmp_h637d46f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h1f1491ac__0))));
    vlSelf->__VdfgTmp_h5618ebf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008443_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008442_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1f1491ac__0)))));
    vlSelf->__VdfgTmp_h9bf7e2f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                       << 2U) | (IData)(__VdfgTmp_h1f1491ac__0));
    vlSelf->wasmetal_core__DOT___009946_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009285_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056219_ = (1U & (0xf3faU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf0aacc00U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0)))))))));
    vlSelf->wasmetal_core__DOT___009358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf0aacc00U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0))))));
    vlSelf->wasmetal_core__DOT___055837_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0)))))));
    vlSelf->__VdfgTmp_h890a41f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___009284_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055614_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0))))))));
    vlSelf->wasmetal_core__DOT___062388_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009417_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))))));
    vlSelf->__VdfgTmp_ha3cb0627__0 = (((IData)(vlSelf->wasmetal_core__DOT___009276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_));
    vlSelf->wasmetal_core__DOT___061165_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h35ac7889__0))));
    vlSelf->wasmetal_core__DOT___009940_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e622f55__0)))));
    vlSelf->wasmetal_core__DOT___062404_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h16f25fe1__0))));
    vlSelf->wasmetal_core__DOT___009710_ = (1U & (0xf5fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h16f25fe1__0))))));
    vlSelf->wasmetal_core__DOT___062362_ = (1U & (IData)(
                                                         (0xf0f33aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009346_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9685faf4__0))))))));
    vlSelf->wasmetal_core__DOT___009348_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9685faf4__0)))));
    vlSelf->wasmetal_core__DOT___062381_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7856ed04__0)))));
    vlSelf->wasmetal_core__DOT___009083_ = (1U & (0xf0044U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7856ed04__0)))));
    vlSelf->wasmetal_core__DOT___009935_ = (1U & (IData)(
                                                         (0xf3faf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h45aa792f__0))))))));
    vlSelf->wasmetal_core__DOT___009757_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h45aa792f__0))));
    vlSelf->wasmetal_core__DOT___061031_ = (1U & (0xf0f0cc55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009333_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_had646e7f__0))))));
    vlSelf->wasmetal_core__DOT___009335_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had646e7f__0)))));
    vlSelf->wasmetal_core__DOT___009962_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___062442_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009329_))));
    vlSelf->__VdfgTmp_h792a3800__0 = (((IData)(vlSelf->wasmetal_core__DOT___009330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009329_));
    vlSelf->wasmetal_core__DOT___062332_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7c9afb82__0))));
    vlSelf->wasmetal_core__DOT___055491_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7c9afb82__0)))));
    vlSelf->wasmetal_core__DOT___055464_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009245_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055451_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))));
    vlSelf->wasmetal_core__DOT___062375_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009396_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))));
    vlSelf->wasmetal_core__DOT___062437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056221_))));
    vlSelf->__VdfgTmp_hb864fb42__0 = (((IData)(vlSelf->wasmetal_core__DOT___056221_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009997_));
    vlSelf->wasmetal_core__DOT___009398_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009397_)))));
    vlSelf->__VdfgTmp_h3b5a0ff3__0 = (((IData)(vlSelf->wasmetal_core__DOT___009232_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056079_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0))))))));
    vlSelf->wasmetal_core__DOT___009389_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009388_)))));
    vlSelf->wasmetal_core__DOT___060840_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3dedcb44__0))));
    vlSelf->wasmetal_core__DOT___056042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055739_))));
    vlSelf->__VdfgTmp_h27200c45__0 = (((IData)(vlSelf->wasmetal_core__DOT___009317_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055739_));
    vlSelf->wasmetal_core__DOT___060828_ = (1U & (0xf0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009386_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0))))))));
    vlSelf->__VdfgTmp_h32990406__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h38f150ef__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009988_));
    vlSelf->wasmetal_core__DOT___060752_ = (1U & (0xf055ccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1125b1e9__0))))));
    vlSelf->wasmetal_core__DOT___009308_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1125b1e9__0))));
    vlSelf->wasmetal_core__DOT___062453_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009374_))));
    vlSelf->__VdfgTmp_h41d1df16__0 = (((IData)(vlSelf->wasmetal_core__DOT___009375_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009374_));
    vlSelf->wasmetal_core__DOT___009225_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6b56eebb__0))));
    vlSelf->wasmetal_core__DOT___008975_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009930_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb294466b__0))))))));
    vlSelf->wasmetal_core__DOT___009363_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h748d3c0c__0))));
    vlSelf->wasmetal_core__DOT___062469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h584d0366__0))))));
    vlSelf->wasmetal_core__DOT___009425_ = (1U & (0x200U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h584d0366__0))))))));
    vlSelf->wasmetal_core__DOT___062410_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7ca1d027__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056169_)))));
    vlSelf->__VdfgTmp_he74af19b__0 = ((2U & ((0xacU 
                                              >> (IData)(vlSelf->__VdfgTmp_h748d3c0c__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009984_));
    vlSelf->wasmetal_core__DOT___061316_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h584d0366__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009920_)))));
    vlSelf->wasmetal_core__DOT___009727_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xa3U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055689_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___056147_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009951_)))))));
    vlSelf->wasmetal_core__DOT___007857_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007906_));
    vlSelf->wasmetal_core__DOT___055636_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_ha9e5b07a__0))))))))))));
    vlSelf->wasmetal_core__DOT___008549_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4d366d59__0)))))));
    vlSelf->wasmetal_core__DOT___055355_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ba3f00e__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0)))))));
    vlSelf->wasmetal_core__DOT___007855_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0))));
    vlSelf->wasmetal_core__DOT___009659_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc719aa4c__0)))))));
    vlSelf->wasmetal_core__DOT___055747_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc719aa4c__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0)))))));
    vlSelf->__VdfgTmp_hc3aac618__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc20acf35__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0)))));
    vlSelf->wasmetal_core__DOT___056157_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0d1d68d2__0)))))));
    vlSelf->wasmetal_core__DOT___008548_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0d1d68d2__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0)))))));
    vlSelf->wasmetal_core__DOT___009870_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hee048ece__0)))))));
    vlSelf->wasmetal_core__DOT___008824_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hee048ece__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0)))))));
    vlSelf->wasmetal_core__DOT___055546_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___008642_));
    vlSelf->wasmetal_core__DOT___009851_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hab3491b0__0)))))));
    vlSelf->wasmetal_core__DOT___008920_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hab3491b0__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0)))))));
    vlSelf->wasmetal_core__DOT___008938_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc229347b__0)))))));
    vlSelf->wasmetal_core__DOT___051316_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0de86ccc__0))));
    vlSelf->__VdfgTmp_ha33784b5__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0de86ccc__0)))));
    vlSelf->wasmetal_core__DOT___055745_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd3e9a659__0))));
    vlSelf->__VdfgTmp_h63940f3b__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd3e9a659__0)))));
    vlSelf->__VdfgTmp_hddf47e90__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3429c82f__0)))));
    vlSelf->wasmetal_core__DOT___055475_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3429c82f__0))));
    vlSelf->wasmetal_core__DOT___055817_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfb017b9d__0))));
    vlSelf->__VdfgTmp_h5e3623a6__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb1634503__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha22ec9f2__0)))));
    vlSelf->wasmetal_core__DOT___055631_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha22ec9f2__0))));
    vlSelf->wasmetal_core__DOT___055846_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb46d48f1__0))));
    vlSelf->wasmetal_core__DOT___055704_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb46d48f1__0))));
    vlSelf->wasmetal_core__DOT___051314_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7092c9cd__0))));
    vlSelf->wasmetal_core__DOT___055354_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7092c9cd__0))));
    vlSelf->wasmetal_core__DOT___055743_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefb478a1__0))));
    vlSelf->wasmetal_core__DOT___055396_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefb478a1__0))));
    vlSelf->__VdfgTmp_h33e7f237__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0x555533330f0f00ffULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_h855995cd__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0x503U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0))
                                                     : 
                                                    (0x503U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)))));
    vlSelf->wasmetal_core__DOT___055457_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h855995cd__0))));
    vlSelf->wasmetal_core__DOT___055897_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h114e86e1__0))));
    vlSelf->wasmetal_core__DOT___055473_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h114e86e1__0))));
    vlSelf->__VdfgTmp_hb6e33d53__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h1390519c__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h91c21bf0__0)))));
    vlSelf->wasmetal_core__DOT___055548_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h91c21bf0__0))));
    vlSelf->__VdfgTmp_h1eb86efd__0 = ((2U & ((1U >> 
                                              ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                 & (IData)(
                                                           (0xaaaaccccf0f0ff00ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hfb017b9d__0)))) 
                                                << 1U) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                      ? 
                                                     (0xa0cU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0))
                                                      : 
                                                     (0xa0cU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  & (IData)(
                                                            (0xaaaaccccf0f0ff00ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hed13b60d__0)))) 
                                                 << 1U) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                       ? 
                                                      (0xa0cU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))
                                                       : 
                                                      (0xa0cU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0))))))));
    vlSelf->__VdfgTmp_h16df2209__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hed13b60d__0)))));
    vlSelf->wasmetal_core__DOT___055924_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0c7e8da3__0))));
    vlSelf->__VdfgTmp_hfa157860__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0c7e8da3__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h158bc821__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)))));
    vlSelf->__VdfgTmp_h7e1fafed__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3418aecb__0)))));
    vlSelf->wasmetal_core__DOT___055702_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3418aecb__0))));
    vlSelf->wasmetal_core__DOT___051935_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h051dc5dd__0))));
    vlSelf->wasmetal_core__DOT___055357_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h051dc5dd__0))));
    vlSelf->wasmetal_core__DOT___055392_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf618fe17__0))));
    vlSelf->wasmetal_core__DOT___055884_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2ada8d2f__0))));
    vlSelf->wasmetal_core__DOT___055455_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2ada8d2f__0))));
    vlSelf->wasmetal_core__DOT___055899_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he5945a68__0))));
    vlSelf->wasmetal_core__DOT___055471_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he5945a68__0))));
    vlSelf->wasmetal_core__DOT___055803_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha8c0c19d__0))));
    vlSelf->wasmetal_core__DOT___055531_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha8c0c19d__0))));
    vlSelf->wasmetal_core__DOT___055843_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefdefca0__0))));
    vlSelf->wasmetal_core__DOT___055700_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefdefca0__0))));
    vlSelf->wasmetal_core__DOT___055390_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h91b07825__0))));
    vlSelf->wasmetal_core__DOT___055886_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he2ba4454__0))));
    vlSelf->wasmetal_core__DOT___055453_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he2ba4454__0))));
    vlSelf->wasmetal_core__DOT___009877_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc2ad9167__0))));
    vlSelf->__VdfgTmp_hb6a6380e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2ad9167__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)))));
    vlSelf->wasmetal_core__DOT___008857_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70bc0e9e__0))));
    vlSelf->wasmetal_core__DOT___009339_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70bc0e9e__0))));
    vlSelf->wasmetal_core__DOT___009354_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf74c6a47__0))));
    vlSelf->__VdfgTmp_h900f682d__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h042cd865__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf74c6a47__0)))));
    vlSelf->wasmetal_core__DOT___009861_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4d4c7d0__0))));
    vlSelf->wasmetal_core__DOT___008931_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4d4c7d0__0))));
}
