#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__21(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__21\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___069123_;
    wasmetal_core__DOT___069123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069897_;
    wasmetal_core__DOT___069897_ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___069522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069521_))));
    vlSelf->wasmetal_core__DOT___069875_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069874_))));
    vlSelf->wasmetal_core__DOT___066442_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066441_))));
    vlSelf->wasmetal_core__DOT___066921_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff01ffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))));
    vlSelf->wasmetal_core__DOT___065851_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))));
    vlSelf->wasmetal_core__DOT___065495_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfe00000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___067246_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff00ff1fffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___067534_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))));
    vlSelf->wasmetal_core__DOT___066233_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfffe000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))));
    vlSelf->wasmetal_core__DOT___068687_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))));
    vlSelf->wasmetal_core__DOT___067003_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___065964_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064438_)))))));
    vlSelf->wasmetal_core__DOT___064871_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064868_))));
    vlSelf->wasmetal_core__DOT___066445_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066440_)))));
    vlSelf->wasmetal_core__DOT___064712_ = (1U & (IData)(
                                                         (0x70777700ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064709_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064707_)))))))));
    vlSelf->wasmetal_core__DOT___067005_ = (1U & (0xf400U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))))));
    vlSelf->wasmetal_core__DOT___065514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064710_))));
    vlSelf->wasmetal_core__DOT___067794_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065036_))));
    vlSelf->wasmetal_core__DOT___067946_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065388_))));
    vlSelf->wasmetal_core__DOT___067648_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064707_))));
    vlSelf->wasmetal_core__DOT___067715_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064875_)))));
    vlSelf->wasmetal_core__DOT___068276_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065962_)))));
    vlSelf->wasmetal_core__DOT___069028_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff00ff1fffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___068009_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfe00000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___068637_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066586_))));
    vlSelf->wasmetal_core__DOT___068834_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff01ffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))));
    vlSelf->wasmetal_core__DOT___069222_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))));
    vlSelf->wasmetal_core__DOT___068523_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066441_))));
    vlSelf->wasmetal_core__DOT___067054_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067049_)))));
    vlSelf->wasmetal_core__DOT___065498_ = (1U & (0x3a00U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065493_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064438_))))));
    vlSelf->wasmetal_core__DOT___066924_ = (1U & (0x11f00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h14cfefd1__0))))));
    vlSelf->wasmetal_core__DOT___070431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069958_))));
    vlSelf->wasmetal_core__DOT___065040_ = (1U & (0x3a00U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065034_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064438_))))));
    vlSelf->wasmetal_core__DOT___070406_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069915_))));
    vlSelf->wasmetal_core__DOT___070353_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069834_))));
    vlSelf->wasmetal_core__DOT___070303_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069749_))));
    vlSelf->wasmetal_core__DOT___070238_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069637_))));
    vlSelf->wasmetal_core__DOT___070150_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069500_))));
    vlSelf->wasmetal_core__DOT___070177_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069546_))));
    vlSelf->wasmetal_core__DOT___070075_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069371_))));
    vlSelf->wasmetal_core__DOT___070206_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069588_))));
    vlSelf->wasmetal_core__DOT___070221_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069611_))));
    vlSelf->wasmetal_core__DOT___070128_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069480_))));
    vlSelf->wasmetal_core__DOT___070186_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069571_))));
    vlSelf->wasmetal_core__DOT___064713_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064697_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064696_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf050f030f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                                                << 5U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 3U)) 
                                                                                | ((2U 
                                                                                & vlSelf->mem_rdata[0U]) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064690_))))))))))))))));
    vlSelf->wasmetal_core__DOT___067650_ = (1U & (IData)(
                                                         (0xfbfff3f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064697_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064709_)))))))));
    vlSelf->wasmetal_core__DOT___070043_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069323_))));
    vlSelf->wasmetal_core__DOT___064829_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x8fU 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064241_)))));
    vlSelf->wasmetal_core__DOT___065352_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                         << 1U)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064237_))));
    vlSelf->wasmetal_core__DOT___064251_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xa0aac0cc00ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((0xff003535U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064228_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                                << 1U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064226_))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha92622e4__0)))))))))))));
    vlSelf->__VdfgTmp_h729278ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___064582_) 
                                       << 1U) | (1U 
                                                 & (0x4fU 
                                                    >> 
                                                    ((0x10U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0x8fU 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                                 << 2U)) 
                                                               << 2U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                              << 1U)))))));
    vlSelf->wasmetal_core__DOT___065263_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065260_)))));
    vlSelf->__VdfgTmp_hb2a5d28a__0 = (((IData)(vlSelf->wasmetal_core__DOT___065260_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                              << 5U) 
                                                             | ((0x10U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                    << 4U)) 
                                                                | (0xfU 
                                                                   & (~ 
                                                                      (7U 
                                                                       | (8U 
                                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                             << 3U)))))))))));
    vlSelf->__VdfgTmp_h7592c2bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4bfb58f6__0))));
    vlSelf->wasmetal_core__DOT___065458_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065457_)))));
    vlSelf->__VdfgTmp_h2ca328d2__0 = ((2U & ((IData)(
                                                     (0xe000000000000000ULL 
                                                      >> 
                                                      ((0x20U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           << 5U)) 
                                                       | ((0x18U 
                                                           & ((~ 
                                                               (1U 
                                                                | (2U 
                                                                   & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                      << 1U)))) 
                                                              << 3U)) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                             << 2U))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1f00000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd652459e__0)))));
    vlSelf->__VdfgTmp_h285454e8__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xffe01fffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd652459e__0)))));
    vlSelf->__VdfgTmp_he391eb62__0 = (((IData)(vlSelf->wasmetal_core__DOT___065457_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x100000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h56ef19dd__0)))));
    vlSelf->__VdfgTmp_h9bcef377__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xfffe01ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h56ef19dd__0)))));
    vlSelf->__VdfgTmp_h5ef74162__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h1427a567__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___067106_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1427a567__0))))));
    vlSelf->wasmetal_core__DOT___066165_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0))))));
    vlSelf->wasmetal_core__DOT___068363_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0))))));
    vlSelf->__VdfgTmp_h460c2b6b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___067037_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0))))));
    vlSelf->__VdfgTmp_h06351ce7__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___065645_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0))))));
    vlSelf->wasmetal_core__DOT___067362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha690191b__0))))));
    vlSelf->wasmetal_core__DOT___068309_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha690191b__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066018_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha690191b__0))))));
    vlSelf->__VdfgTmp_h0ae37f35__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_ha690191b__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->__VdfgTmp_h99c00636__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0)))))));
    vlSelf->__VdfgTmp_hca367735__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___065840_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0))))));
    vlSelf->__VdfgTmp_h1c76f20b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0)))))));
    vlSelf->wasmetal_core__DOT___069203_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066216_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0))))));
    vlSelf->__VdfgTmp_h8ba6f27a__0 = (((IData)(vlSelf->wasmetal_core__DOT___064585_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066421_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___065353_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b6__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                    << 1U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065350_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))))))))))));
    vlSelf->__VdfgTmp_h5f663eeb__0 = (((IData)(vlSelf->wasmetal_core__DOT___065350_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066806_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___069064_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000fffcffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b60__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4192dd5__0))))))))))))));
    vlSelf->__VdfgTmp_h07b43cae__0 = (((IData)(vlSelf->wasmetal_core__DOT___064957_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066554_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___064996_ = (1U & (0x4500cfcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064977_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xc1dU 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(
                                                                              (0xaa330f00000000ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064578_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd333e317__0))))) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xc01fdf1fe0ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064956_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                                << 4U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                                << 3U))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___064957_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f335500000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h11c2cb19__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064969_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064615_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064614_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064617_))))))))))))))))))));
    vlSelf->__VdfgTmp_h8b2cdea2__0 = (((IData)(vlSelf->wasmetal_core__DOT___065125_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066667_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___066166_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0))))));
    vlSelf->wasmetal_core__DOT___068364_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0))))));
    vlSelf->wasmetal_core__DOT___069174_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067038_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0))))));
    vlSelf->wasmetal_core__DOT___068914_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h7fac6026__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->wasmetal_core__DOT___065646_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0))))));
    vlSelf->wasmetal_core__DOT___067363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0))))));
    vlSelf->wasmetal_core__DOT___068310_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066019_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0))))));
    vlSelf->wasmetal_core__DOT___069107_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067219_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0))))));
    vlSelf->wasmetal_core__DOT___069012_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h759c5442__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->wasmetal_core__DOT___065841_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0))))));
    vlSelf->wasmetal_core__DOT___068981_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067107_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0))))));
    vlSelf->__VdfgTmp_hfabdc4bc__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1427a567__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->__VdfgTmp_h8c3c8979__0 = ((2U & ((8U >> 
                                              ((2U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0))))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                | (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1427a567__0)))))));
    vlSelf->__VdfgTmp_h007a378e__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->wasmetal_core__DOT___067507_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0))))));
    vlSelf->wasmetal_core__DOT___069204_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0))))));
    vlSelf->wasmetal_core__DOT___070357_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000fff3ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b120__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h400b6e72__0)))))))));
    vlSelf->wasmetal_core__DOT___068873_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000fff3ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((8U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h400b6e72__0)))))))));
    vlSelf->wasmetal_core__DOT___070131_ = (1U & (IData)(
                                                         (0x2000000f3ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b104__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h29064caf__0)))))));
    vlSelf->wasmetal_core__DOT___068538_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbfa812aa__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h82d7bb11__0)))))))));
    vlSelf->wasmetal_core__DOT___068498_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068495_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068494_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xeU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2b9b4b9__0)))))))))))))));
    vlSelf->__VdfgTmp_h26de3b10__0 = (((IData)(vlSelf->wasmetal_core__DOT___065264_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066722_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->__VdfgTmp_hdcdbebf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___065351_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066804_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___069999_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x2000000f3ffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf68b7cf3__0))))))))));
    vlSelf->wasmetal_core__DOT___067572_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x2000000f3ffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf68b7cf3__0))))))))));
    vlSelf->wasmetal_core__DOT___069263_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x2000000f3ffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b64__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                         << 1U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 1U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf68b7cf3__0))))))))));
    vlSelf->wasmetal_core__DOT___069318_ = (1U & (0xac00000U 
                                                  >> 
                                                  ((0x1cU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0696502e__0))));
    vlSelf->__VdfgTmp_hb47a572e__0 = ((4U & ((0xf53fU 
                                              >> ((0xcU 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      << 2U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hdfea75fb__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h0696502e__0));
    vlSelf->__VdfgTmp_h7e9d016d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065459_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066941_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___068775_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b54__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha4f5f30b__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h97331d2b__0)))))))));
    vlSelf->wasmetal_core__DOT___068578_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b50__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h02ac2502__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h23f4485c__0)))))))));
    vlSelf->wasmetal_core__DOT___052580_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->result_index 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___051018_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->result_index 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___070381_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b122__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068997_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069874_))))));
    vlSelf->wasmetal_core__DOT___068998_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068997_))));
    vlSelf->wasmetal_core__DOT___067390_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067388_))));
    wasmetal_core__DOT___069123_ = (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___067388_))));
    vlSelf->__VdfgTmp_hd4f38404__0 = ((0xcU & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                               << 1U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066034_)));
    vlSelf->wasmetal_core__DOT___070279_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b114__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068587_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x7f0000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_heceac102__0))))))));
    vlSelf->wasmetal_core__DOT___068588_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068587_))));
    vlSelf->wasmetal_core__DOT___068930_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf0f0f77U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0))))));
    vlSelf->wasmetal_core__DOT___067051_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (0xf0f0f77U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0))))));
    vlSelf->wasmetal_core__DOT___065656_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (0xf0880000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0))))));
    vlSelf->wasmetal_core__DOT___067886_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065232_))));
    vlSelf->wasmetal_core__DOT___066755_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066753_))));
    vlSelf->wasmetal_core__DOT___068734_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066753_))));
    vlSelf->wasmetal_core__DOT___068189_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065770_))));
    vlSelf->wasmetal_core__DOT___065771_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065770_))));
    vlSelf->wasmetal_core__DOT___069302_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064711_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067646_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069290_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xa27fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       << 1U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064707_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___069295_)))))))))));
    vlSelf->wasmetal_core__DOT___067649_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064711_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067646_)))));
    vlSelf->wasmetal_core__DOT___064840_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064836_))))))))));
    vlSelf->wasmetal_core__DOT___065145_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064836_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065144_))));
    vlSelf->wasmetal_core__DOT___065383_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064836_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065382_))));
    vlSelf->wasmetal_core__DOT___065765_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064836_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065764_))));
    vlSelf->wasmetal_core__DOT___066505_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064836_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066504_)))));
    vlSelf->wasmetal_core__DOT___065031_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065028_))))))));
    vlSelf->wasmetal_core__DOT___065488_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065487_))));
    vlSelf->wasmetal_core__DOT___065848_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065028_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065847_))));
    vlSelf->wasmetal_core__DOT___066587_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065028_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066585_)))));
    vlSelf->wasmetal_core__DOT___065228_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065226_))))));
    vlSelf->wasmetal_core__DOT___066031_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066030_))));
    vlSelf->wasmetal_core__DOT___066754_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065226_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066752_)))));
    vlSelf->wasmetal_core__DOT___067048_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067047_)))));
    vlSelf->wasmetal_core__DOT___065657_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065653_))));
    vlSelf->wasmetal_core__DOT___069685_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066439_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068522_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069682_))))));
    vlSelf->wasmetal_core__DOT___068524_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066439_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068522_)))));
    vlSelf->wasmetal_core__DOT___070305_ = (1U & (IData)(
                                                         (0xaf3f00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068674_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b116__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b5a3019__0))))))));
    vlSelf->wasmetal_core__DOT___066158_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066157_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066156_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066155_)))))))));
    vlSelf->wasmetal_core__DOT___064636_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x3fff20003fff3fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b1__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064556_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064554_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064553_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f335500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                      << 5U) 
                                                                     | ((4U 
                                                                         & ((0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2cdbdda9__0)) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064566_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0x55550f0f00ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064070_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064069_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064074_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064060_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___065275_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf7f000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h25573523__0)))))));
    vlSelf->wasmetal_core__DOT___065469_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ff000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h25573523__0)))))));
    vlSelf->wasmetal_core__DOT___064995_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064986_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064985_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064984_)))))))));
    vlSelf->wasmetal_core__DOT___065129_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x3fff20003fff3fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065098_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065097_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065096_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x330f5500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064056_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064055_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___064077_)))))))))));
    vlSelf->wasmetal_core__DOT___065545_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064082_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065541_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb5acd9d8__0)))))));
    vlSelf->wasmetal_core__DOT___064250_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xcc0f550fU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___064082_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064081_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (0xf0f3355U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064077_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064076_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x47U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064074_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & vlSelf->mem_rdata[0U])))))))))))))))));
    vlSelf->wasmetal_core__DOT___064833_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((0x20003fffU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064788_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064787_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064786_)))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0aaccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064789_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064076_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064066_)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x5cU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h23108600__0))))))))));
    vlSelf->__VdfgTmp_h67fa8c87__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha458d092__0))));
    vlSelf->wasmetal_core__DOT___067126_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h5ea85090__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha458d092__0)))))))));
    vlSelf->__VdfgTmp_h4223b487__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h88dfb892__0))));
    vlSelf->wasmetal_core__DOT___067429_ = (1U & (IData)(
                                                         (0x33bf3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067425_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9bb3dbab__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h88dfb892__0)))))))))));
    vlSelf->wasmetal_core__DOT___069789_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b86__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h72f36192__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6b577092__0)))))))));
    vlSelf->wasmetal_core__DOT___068776_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b54__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h72f36192__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6b577092__0)))))))));
    vlSelf->wasmetal_core__DOT___069703_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b82__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he200cacd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf114f092__0)))))))));
    vlSelf->wasmetal_core__DOT___068579_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b50__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he200cacd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf114f092__0)))))))));
    vlSelf->__VdfgTmp_h42ebc2c2__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hea3a75f9__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h1dd3182a__0))));
    vlSelf->__VdfgTmp_h2428cf91__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he6eb1d70__0))));
    vlSelf->__VdfgTmp_h91af3af4__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9b0680c9__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_he6eb1d70__0))));
    vlSelf->__VdfgTmp_h25e3345e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he6a138a7__0))));
    vlSelf->wasmetal_core__DOT___067235_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h729a2b0d__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he6a138a7__0))))))));
    vlSelf->__VdfgTmp_hc8a29b47__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0160c9d2__0))));
    vlSelf->__VdfgTmp_hdda09bd4__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_had85000c__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h0160c9d2__0))));
    vlSelf->__VdfgTmp_hc3e51450__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h085758ad__0))));
    vlSelf->wasmetal_core__DOT___067379_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h085758ad__0))))))));
    vlSelf->wasmetal_core__DOT___069935_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b93__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h085758ad__0)))))))));
    vlSelf->__VdfgTmp_hdf86f0af__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hec74e4aa__0))));
    vlSelf->wasmetal_core__DOT___066577_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hded1dcfc__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hec74e4aa__0))))))));
    vlSelf->wasmetal_core__DOT___069725_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b83__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hded1dcfc__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hec74e4aa__0)))))))));
    vlSelf->__VdfgTmp_h744d834f__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h96fdd1ca__0))));
    vlSelf->wasmetal_core__DOT___066744_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h96fdd1ca__0))))))));
    vlSelf->wasmetal_core__DOT___069768_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b85__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h96fdd1ca__0)))))))));
    vlSelf->wasmetal_core__DOT___069214_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b63__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8c50959a__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h009830e9__0)))))))));
    vlSelf->wasmetal_core__DOT___067523_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8c50959a__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b31__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h009830e9__0))))))));
    vlSelf->wasmetal_core__DOT___067629_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha5948160__0))));
    vlSelf->wasmetal_core__DOT___067685_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4147928__0))));
    vlSelf->wasmetal_core__DOT___067778_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4606e0f__0))));
    vlSelf->wasmetal_core__DOT___067832_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h720d5baf__0))));
    vlSelf->wasmetal_core__DOT___067925_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ce087b0__0))));
    vlSelf->wasmetal_core__DOT___067870_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb19dabb4__0))));
    vlSelf->wasmetal_core__DOT___069830_ = (1U & (IData)(
                                                         (0xdfff500000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b88__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6d71fd2__0))))))));
    vlSelf->wasmetal_core__DOT___069448_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b71__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc97edddd__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h55dc4d97__0)))))))));
    vlSelf->__VdfgTmp_h1fe62345__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hc97edddd__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h55dc4d97__0));
    vlSelf->__VdfgTmp_h13c22a42__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hf103d5a5__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h07d01a7e__0));
    vlSelf->wasmetal_core__DOT___068367_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7e1e4a5__0))));
    vlSelf->__VdfgTmp_hcf04e80b__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hab510120__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h0afb0546__0));
    vlSelf->wasmetal_core__DOT___068172_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95565af9__0))));
    vlSelf->wasmetal_core__DOT___069631_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b79__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdd57f0a__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he90c68e8__0)))))))));
    vlSelf->wasmetal_core__DOT___068444_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he90c68e8__0))));
    vlSelf->wasmetal_core__DOT___069494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b73__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18a1d918__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51979f8d__0)))))))));
    vlSelf->wasmetal_core__DOT___068121_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h51979f8d__0))));
    vlSelf->wasmetal_core__DOT___069540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b75__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4573e872__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9e5b6509__0)))))))));
    vlSelf->wasmetal_core__DOT___068206_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e5b6509__0))));
    vlSelf->wasmetal_core__DOT___069568_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b76__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3daad387__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h134a2a5b__0)))))))));
    vlSelf->wasmetal_core__DOT___068258_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h134a2a5b__0))));
    vlSelf->wasmetal_core__DOT___128179___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128508___O 
        = ((3U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)) 
                         << 3U)) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                                          << 2U)))) 
           ^ (7U | (8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                          << 3U))));
    vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___067798_ = (1U & (0x7033U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065024_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065034_)))))));
    vlSelf->wasmetal_core__DOT___067799_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37cccaef__0))))));
    vlSelf->wasmetal_core__DOT___068690_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068680_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068679_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdfc00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b52__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he75eceef__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd785ede8__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaf3f00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068674_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b52__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b5a3019__0))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064247_)))))))));
    vlSelf->wasmetal_core__DOT___066198_ = (1U & (IData)(
                                                         (0x153f151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066179_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066177_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xcU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064978_)))))))));
    vlSelf->wasmetal_core__DOT___065577_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x200000003fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___066373_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066371_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066369_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___066368_))))));
    vlSelf->wasmetal_core__DOT___069262_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067558_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067555_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___066371_))))));
    vlSelf->wasmetal_core__DOT___068387_ = (1U & (0x3700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b46__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U)))))))));
    vlSelf->wasmetal_core__DOT___068506_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___069193_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069191_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))));
    wasmetal_core__DOT___069897_ = (1U & (1U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___067246_))));
    vlSelf->wasmetal_core__DOT___068882_ = (1U & (0x3b00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067003_))))));
    vlSelf->wasmetal_core__DOT___064872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064871_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___066343_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065514_))));
    vlSelf->wasmetal_core__DOT___065518_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065514_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___070057_ = (1U & (0x48ccc8ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067794_))))));
    vlSelf->wasmetal_core__DOT___070101_ = (1U & (0x48ccc8ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067946_))))));
    vlSelf->wasmetal_core__DOT___070019_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b97__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067648_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069295_))))));
    vlSelf->wasmetal_core__DOT___070393_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b123__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069028_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069896_))))));
    vlSelf->wasmetal_core__DOT___069029_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069028_))));
    vlSelf->wasmetal_core__DOT___070116_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b103__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068009_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069454_))))));
    vlSelf->wasmetal_core__DOT___070291_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b115__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068637_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069728_))))));
    vlSelf->wasmetal_core__DOT___070341_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b119__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068834_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069815_))))));
    vlSelf->wasmetal_core__DOT___070443_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b127__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069980_))))));
    vlSelf->wasmetal_core__DOT___069223_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069222_))));
    vlSelf->wasmetal_core__DOT___070267_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b113__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068523_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069683_))))));
    vlSelf->wasmetal_core__DOT___064834_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x200000003fffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___064829_) 
                                                                     << 5U) 
                                                                    | ((0x18U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064828_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064827_))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x55330f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064228_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha92622e4__0))))))))));
    vlSelf->wasmetal_core__DOT___065265_ = (1U & (IData)(
                                                         (0xf0ffe000f0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065263_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x5cU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd333e317__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                             << 1U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                              << 1U)))))))))));
    vlSelf->wasmetal_core__DOT___068722_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068719_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hfef6b839__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7592c2bc__0))))))));
    vlSelf->wasmetal_core__DOT___065460_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065458_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                       << 1U)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064235_) 
                                                                          << 1U)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                           << 1U))))))))));
    vlSelf->__VdfgTmp_h90ebf68e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h285454e8__0))));
    vlSelf->__VdfgTmp_h056e943f__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9bcef377__0))));
    vlSelf->wasmetal_core__DOT___067621_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8ba6f27a__0))));
    vlSelf->wasmetal_core__DOT___065365_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065352_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065351_)))))))));
    vlSelf->wasmetal_core__DOT___069068_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069064_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h940ea061__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b60__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h18d94502__0))))))));
    vlSelf->__VdfgTmp_hba46d6b9__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h2ca328d2__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h07b43cae__0));
    vlSelf->wasmetal_core__DOT___069367_ = (1U & (0xf53fU 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b2cdea2__0))));
    vlSelf->__VdfgTmp_h82ca3c22__0 = ((4U & ((0xfe7fffffU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                   << 4U) 
                                                  | ((0xcU 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         << 2U)) 
                                                     | (3U 
                                                        & (~ 
                                                           (1U 
                                                            | (2U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                  << 1U)))))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h8b2cdea2__0));
    vlSelf->wasmetal_core__DOT___068377_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b46__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068363_)))))));
    vlSelf->wasmetal_core__DOT___069178_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069175_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069174_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h460c2b6b__0))))))));
    vlSelf->wasmetal_core__DOT___067041_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067038_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067037_)))))));
    vlSelf->wasmetal_core__DOT___068918_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068915_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068914_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h06351ce7__0))))))));
    vlSelf->wasmetal_core__DOT___068123_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b41__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7fac6026__0))))));
    vlSelf->wasmetal_core__DOT___070146_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b105__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7fac6026__0))))));
    vlSelf->wasmetal_core__DOT___065648_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065646_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065645_)))))));
    vlSelf->wasmetal_core__DOT___068315_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b45__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068310_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068309_)))))));
    vlSelf->wasmetal_core__DOT___066021_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b13__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066019_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066018_)))))));
    vlSelf->wasmetal_core__DOT___069111_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069108_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b61__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ae37f35__0))))))));
    vlSelf->wasmetal_core__DOT___069016_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069013_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069012_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca367735__0))))))));
    vlSelf->wasmetal_core__DOT___068208_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b43__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h759c5442__0))))));
    vlSelf->wasmetal_core__DOT___070173_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b107__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h759c5442__0))))));
    vlSelf->wasmetal_core__DOT___065843_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065841_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065840_)))))));
    vlSelf->wasmetal_core__DOT___068985_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068982_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068981_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5ef74162__0))))))));
    vlSelf->wasmetal_core__DOT___068181_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b42__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfabdc4bc__0))))));
    vlSelf->wasmetal_core__DOT___070160_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b106__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfabdc4bc__0))))));
    vlSelf->wasmetal_core__DOT___069516_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b74__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8c3c8979__0))))));
    vlSelf->wasmetal_core__DOT___065785_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065756_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdfc00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8c3c8979__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0xaU))))))))));
    vlSelf->wasmetal_core__DOT___068446_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b47__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h007a378e__0))))));
    vlSelf->wasmetal_core__DOT___070234_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b111__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h007a378e__0))))));
    vlSelf->wasmetal_core__DOT___069213_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b63__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069204_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069203_)))))));
    vlSelf->wasmetal_core__DOT___066219_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b15__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066216_)))))));
    vlSelf->wasmetal_core__DOT___068889_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068873_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068872_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfdff050000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6d71fd2__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT___068512_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068498_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068497_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x20000000fcffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h54c4945a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067863_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h26de3b10__0))));
    vlSelf->wasmetal_core__DOT___067920_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdcdbebf8__0))));
    vlSelf->wasmetal_core__DOT___067589_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067573_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067572_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7fff500000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h62827519__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & vlSelf->mem_rdata[1U])))))))));
    vlSelf->wasmetal_core__DOT___070039_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((4U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b98__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb47a572e__0))))))));
    vlSelf->wasmetal_core__DOT___067707_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b34__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb47a572e__0))))))));
    vlSelf->wasmetal_core__DOT___069447_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b71__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he391eb62__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h7e9d016d__0)))))))));
    vlSelf->__VdfgTmp_hf139c1ac__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_he391eb62__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h7e9d016d__0));
    vlSelf->wasmetal_core__DOT___066455_ = (1U & (0xf888faffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066453_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064622_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___066451_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> 
                                                                  (3U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                      >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___052581_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052580_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))));
    vlSelf->wasmetal_core__DOT___051019_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))));
    vlSelf->wasmetal_core__DOT___069000_ = (1U & (0x33207f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068998_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064851_)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067134_)))))));
    vlSelf->wasmetal_core__DOT___070418_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b125__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___069123_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069939_))))));
    vlSelf->wasmetal_core__DOT___069124_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___069123_))));
    vlSelf->wasmetal_core__DOT___070369_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b121__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068930_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069857_))))));
    vlSelf->wasmetal_core__DOT___070090_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b101__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067886_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf8ff00ff00ff00ffULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))))));
    vlSelf->wasmetal_core__DOT___070317_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b117__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068734_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf7f00000000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))))));
    vlSelf->wasmetal_core__DOT___070163_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b106__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069521_))))));
    vlSelf->wasmetal_core__DOT___067654_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067650_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067649_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067648_)))))))));
    vlSelf->wasmetal_core__DOT___067716_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064840_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067714_)))));
    vlSelf->wasmetal_core__DOT___069326_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064840_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067714_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069323_))))));
    vlSelf->wasmetal_core__DOT___065148_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065145_))))))));
    vlSelf->wasmetal_core__DOT___065512_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065511_))));
    vlSelf->wasmetal_core__DOT___065960_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065145_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065959_))));
    vlSelf->wasmetal_core__DOT___066700_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065145_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066699_)))));
    vlSelf->wasmetal_core__DOT___065385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065383_))))));
    vlSelf->wasmetal_core__DOT___066184_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066183_))));
    vlSelf->wasmetal_core__DOT___066835_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065383_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066834_)))));
    vlSelf->wasmetal_core__DOT___067133_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065765_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067132_)))));
    vlSelf->wasmetal_core__DOT___065766_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065765_))));
    vlSelf->wasmetal_core__DOT___066511_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066505_))));
    vlSelf->wasmetal_core__DOT___068589_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066505_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068586_)))));
    vlSelf->wasmetal_core__DOT___067795_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067793_)))));
    vlSelf->wasmetal_core__DOT___069353_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065031_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067793_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069346_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xd7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065037_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___065490_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065488_))))));
    vlSelf->wasmetal_core__DOT___066229_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066228_))));
    vlSelf->wasmetal_core__DOT___066919_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065488_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066918_)))));
    vlSelf->wasmetal_core__DOT___067245_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065848_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067243_)))));
    vlSelf->wasmetal_core__DOT___065852_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065848_))));
    vlSelf->wasmetal_core__DOT___066590_ = (1U & (0x80b000f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066588_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066587_)))))));
    vlSelf->wasmetal_core__DOT___069730_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066587_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068636_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069727_))))));
    vlSelf->wasmetal_core__DOT___068638_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066587_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068636_)))));
    vlSelf->wasmetal_core__DOT___067887_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065228_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067885_)))));
    vlSelf->wasmetal_core__DOT___069403_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065228_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067885_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069395_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xa23fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       << 1U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065232_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf8ff00ff00ff00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62686ece__0))))))))))))));
    vlSelf->wasmetal_core__DOT___067389_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067387_)))));
    vlSelf->wasmetal_core__DOT___066032_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066031_))));
    vlSelf->wasmetal_core__DOT___066757_ = (1U & (0x80b000f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066755_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066754_)))))));
    vlSelf->wasmetal_core__DOT___069773_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066754_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068733_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069770_))))));
    vlSelf->wasmetal_core__DOT___068735_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068733_)))));
    vlSelf->wasmetal_core__DOT___068931_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067048_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068929_)))));
    vlSelf->wasmetal_core__DOT___069859_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067048_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068929_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069855_)))))));
    vlSelf->wasmetal_core__DOT___067064_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067054_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065659_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61c930cb__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___067048_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067051_)))))))));
    vlSelf->wasmetal_core__DOT___068137_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068136_)))));
    vlSelf->wasmetal_core__DOT___069502_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068136_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069500_))))));
    vlSelf->wasmetal_core__DOT___065687_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((0x33207f7fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065658_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065656_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064681_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064694_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065662_)))))))));
    vlSelf->wasmetal_core__DOT___068531_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x80b000fU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      >> 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066440_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___064666_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x70330000U 
                                                            >> 
                                                            ((0x18U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                 << 1U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068524_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___068523_))))))))));
    vlSelf->wasmetal_core__DOT___066167_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066158_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064053_)) 
                                                             << 2U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                            << 1U))))));
    vlSelf->wasmetal_core__DOT___065046_ = (1U & (IData)(
                                                         (0x153f151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064995_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064994_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064993_)))))))));
    vlSelf->wasmetal_core__DOT___065159_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065128_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x7f00U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(
                                                                                (0xffcf0080ffcfffcfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064956_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha92622e4__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064224_))))))) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065125_))))))))))))));
    vlSelf->wasmetal_core__DOT___064455_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064251_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064250_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x330faa0fU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064203_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x3aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcce0135b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064197_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064196_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf030f050f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064111_) 
                                                                                << 5U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                                << 3U)) 
                                                                                | (3U 
                                                                                & vlSelf->mem_rdata[0U]))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064193_)))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___068788_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068776_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068775_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbf300000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b54__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068772_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068771_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x16U))))))))));
    vlSelf->wasmetal_core__DOT___068591_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068580_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068579_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068578_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbf300000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b50__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068575_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068574_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x12U))))))))));
    vlSelf->wasmetal_core__DOT___066461_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b17__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42ebc2c2__0))))));
    vlSelf->wasmetal_core__DOT___069680_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b81__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42ebc2c2__0))))));
    vlSelf->wasmetal_core__DOT___069853_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b89__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91af3af4__0))))));
    vlSelf->wasmetal_core__DOT___069812_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b87__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdda09bd4__0))))));
    vlSelf->wasmetal_core__DOT___070017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xafcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067629_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b97__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h4121b81d__0)))))))))));
    vlSelf->wasmetal_core__DOT___070038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcfaf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067685_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b98__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc656bac6__0)))))))))));
    vlSelf->wasmetal_core__DOT___067706_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcfaf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067685_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b34__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc656bac6__0)))))))))));
    vlSelf->wasmetal_core__DOT___067938_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcfaf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067925_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b38__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h78f256d8__0)))))))))));
    vlSelf->wasmetal_core__DOT___068053_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b40__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h13c22a42__0))))))));
    vlSelf->wasmetal_core__DOT___069635_ = (1U & (IData)(
                                                         (0x33bf3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069631_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066217_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b79__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066216_)))))))));
    vlSelf->wasmetal_core__DOT___069498_ = (1U & (IData)(
                                                         (0x33bf3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069494_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b73__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065645_)))))))));
    vlSelf->wasmetal_core__DOT___069544_ = (1U & (IData)(
                                                         (0x33bf3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069540_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065841_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b75__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065840_)))))))));
    vlSelf->wasmetal_core__DOT___068267_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xafcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___068258_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b44__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h3daad387__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128179___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                        << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
                & (IData)(vlSelf->wasmetal_core__DOT___128179___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128179___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                    << 1U))));
    vlSelf->__VdfgTmp_h0fa5f18f__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                             << 3U)) 
                                      | (4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                               << 1U)));
    vlSelf->__VdfgTmp_hf35ae7d9__0 = ((2U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                >> 2U))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_hab6fcc6c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                   >> 2U)))));
    vlSelf->wasmetal_core__DOT___009522_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128615___O 
        = ((1U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)) 
                         << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)) 
                                           << 2U)) 
                                    | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                                             << 1U))))) 
           ^ (3U | (((IData)(vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0) 
                     << 3U) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                                     << 2U)))));
    vlSelf->wasmetal_core__DOT___033042_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___067364_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___067220_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x1bU)))))));
    vlSelf->wasmetal_core__DOT___067508_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (vlSelf->mem_rdata[0U] 
                                                            >> 0x1fU))))));
    vlSelf->__VdfgTmp_hdc8ebfb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066373_));
    vlSelf->wasmetal_core__DOT___067020_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x4000cfffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b24__05d) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066994_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066993_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067271_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x10000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4e6b48d__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___067127_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xdfc00000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((8U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                              >> 2U))) 
                                                                         << 2U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067107_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___067106_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___069681_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069676_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069675_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 9U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___069912_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x19U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1aU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___069584_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069607_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069746_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069726_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069721_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069720_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 8U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x11U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___069769_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069765_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069764_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[2U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))))));
    vlSelf->wasmetal_core__DOT___069813_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069808_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069807_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 0xcU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x15U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___069854_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x16U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x17U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___069936_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1aU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1bU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___070202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069790_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069786_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x15U)) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x16U))))))))));
    vlSelf->wasmetal_core__DOT___069704_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069699_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069698_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0xaU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___069891_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x18U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x19U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___070300_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070299_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x12U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___069871_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x17U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x18U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___069974_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1cU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1dU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[2U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___069953_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067428_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1bU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1cU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT___070314_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x13U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___069319_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[2U]) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067560_)))))));
    vlSelf->wasmetal_core__DOT___070366_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070365_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x19U))))))));
    vlSelf->wasmetal_core__DOT___070378_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070377_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___070390_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070389_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x1bU))))))));
    vlSelf->wasmetal_core__DOT___070264_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070263_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0xfU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070276_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x10U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070326_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070325_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x14U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070440_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070439_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (vlSelf->mem_rdata[3U] 
                                                               >> 0x1fU)))))));
    vlSelf->wasmetal_core__DOT___070414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->__VdfgTmp_h3313b173__0 = (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069262_));
    vlSelf->wasmetal_core__DOT___070195_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070191_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070190_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xaU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x10000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b108__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hadcb4246__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___070403_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070402_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000fffcffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b124__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4192dd5__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069478_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069473_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x200000003fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b72__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069303_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069285_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069284_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h729278ac__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8ba6f27a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069354_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069342_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ca328d2__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07b43cae__0))))))))))))));
    vlSelf->wasmetal_core__DOT___070252_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070249_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070248_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xeU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b112__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2b9b4b9__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069661_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069656_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))));
    vlSelf->wasmetal_core__DOT___070136_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070131_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))));
    vlSelf->wasmetal_core__DOT___069839_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069831_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b88__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h400b74e1__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069404_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069392_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069391_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb2a5d28a__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h26de3b10__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069429_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069417_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b70__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f663eeb__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdcdbebf8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069272_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069264_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x20000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b64__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 1U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h53aa4fbe__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069574_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069569_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069568_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069567_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x40000000cfffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b76__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90496874__0))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___069899_ = (1U & (0xf040f0f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(wasmetal_core__DOT___069897_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b91__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069896_)))))));
    vlSelf->wasmetal_core__DOT___064873_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064872_))));
    vlSelf->wasmetal_core__DOT___069031_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069029_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065007_)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))))));
    vlSelf->wasmetal_core__DOT___064885_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064834_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->mem_rdata[0U]) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064807_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064805_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha9e0ea4b__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064817_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064188_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064187_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064193_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___065280_ = (1U & (IData)(
                                                         (0x7f000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065266_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065265_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065264_)))))))));
    vlSelf->wasmetal_core__DOT___068727_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068722_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h744d834f__0))))))));
    vlSelf->wasmetal_core__DOT___065472_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065460_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065459_)))))));
    vlSelf->wasmetal_core__DOT___068625_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068622_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8a2bba7d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h90ebf68e__0))))))));
    vlSelf->wasmetal_core__DOT___068822_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068819_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h312e660c__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h056e943f__0))))))));
    vlSelf->wasmetal_core__DOT___070016_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xafcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067621_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b97__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h729278ac__0)))))))))));
    vlSelf->wasmetal_core__DOT___067640_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x2a3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067626_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067625_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              << 1U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067621_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h729278ac__0))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xafcf00000f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067629_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h4121b81d__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064993_)))));
    vlSelf->wasmetal_core__DOT___065398_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065365_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xc1dU 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(
                                                                                (0xaa330f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h23108600__0))))) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b6__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7f7f7f7f7fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065359_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065361_))))))))))))));
    vlSelf->wasmetal_core__DOT___069078_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069068_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069067_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b60__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb731668a__0))))))));
    vlSelf->wasmetal_core__DOT___067800_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067774_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hba46d6b9__0)))))))))))));
    vlSelf->wasmetal_core__DOT___070061_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070056_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hba46d6b9__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067835_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b36__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h82ca3c22__0))))))));
    vlSelf->wasmetal_core__DOT___070073_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070070_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070069_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b100__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h82ca3c22__0)))))))))))));
    vlSelf->wasmetal_core__DOT___068393_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068377_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbf300000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b46__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hda165e4b__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xcfaf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068367_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b46__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf270fd27__0))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064097_)))))))));
    vlSelf->wasmetal_core__DOT___069183_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9bb3dbab__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4223b487__0))))))));
    vlSelf->wasmetal_core__DOT___067065_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067041_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdfc00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h91af3af4__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068923_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068918_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9b0680c9__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2428cf91__0))))))));
    vlSelf->wasmetal_core__DOT___068130_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 7U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068121_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18a1d918__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___070148_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070147_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070146_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 7U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068121_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b105__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18a1d918__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___065688_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065648_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 9U))))))));
    vlSelf->wasmetal_core__DOT___068322_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068316_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068315_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xbU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b45__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcf04e80b__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066052_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066021_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xdU))))))));
    vlSelf->wasmetal_core__DOT___069116_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069111_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b61__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3e51450__0))))))));
    vlSelf->wasmetal_core__DOT___069021_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069016_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h729a2b0d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h25e3345e__0))))))));
    vlSelf->wasmetal_core__DOT___068216_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068209_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068208_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 9U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068206_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b43__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4573e872__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___070175_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070174_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070173_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 9U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068206_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b107__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4573e872__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___065871_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065843_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xbU))))))));
    vlSelf->wasmetal_core__DOT___068990_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068985_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5ea85090__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h67fa8c87__0))))))));
    vlSelf->wasmetal_core__DOT___068197_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068181_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068180_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbf300000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b42__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068177_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068176_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068172_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b42__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ad13fe7__0))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064097_)))))))));
    vlSelf->wasmetal_core__DOT___070162_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070161_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070160_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 8U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068172_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b106__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ad13fe7__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___069527_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069517_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069516_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 8U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b74__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ad13fe7__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h95565af9__0))))))))))))));
    vlSelf->wasmetal_core__DOT___068464_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068447_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068446_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068444_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b47__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdd57f0a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___070236_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070235_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068444_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b111__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdd57f0a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___069226_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069215_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069214_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069213_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbf300000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b63__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069210_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069209_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (vlSelf->mem_rdata[1U] 
                                                                          >> 0x1fU)))))))));
    vlSelf->wasmetal_core__DOT___066248_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066219_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xfU))))))));
    vlSelf->wasmetal_core__DOT___067879_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x2a3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067867_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067866_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067863_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b37__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb2a5d28a__0))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xafcf00000f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067870_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b37__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9616de3d__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064993_)))));
    vlSelf->wasmetal_core__DOT___070089_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x2a3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070086_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[3U] 
                                                                              >> 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067863_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b101__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb2a5d28a__0))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xafcf00000f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067870_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b101__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9616de3d__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064993_)))));
    vlSelf->wasmetal_core__DOT___070105_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070100_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070099_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067920_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b102__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f663eeb__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___067937_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xafcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067920_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b38__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h5f663eeb__0)))))))))));
    vlSelf->wasmetal_core__DOT___069461_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069449_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069448_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069447_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b71__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9e38c4fc__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h066a303e__0)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 7U))))))))));
    vlSelf->wasmetal_core__DOT___070120_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070115_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070114_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b103__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf139c1ac__0)))))))))))));
    vlSelf->wasmetal_core__DOT___068002_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x2a3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067989_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067988_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x1f100ffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf139c1ac__0)))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x1f100ffU 
                                                           >> 
                                                           ((0x10U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     >> 2U))) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h1fe62345__0)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064993_)))));
    vlSelf->wasmetal_core__DOT___066460_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066455_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066454_)))))));
    vlSelf->wasmetal_core__DOT___069329_ = (1U & (IData)(
                                                         (0x5fcf00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069326_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b66__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064876_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xc5U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((0x8000ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heceac102__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))))));
    vlSelf->wasmetal_core__DOT___069378_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b68__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065148_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067842_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069371_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7fff800000000000ULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h5851eae3__0))))))))));
    vlSelf->wasmetal_core__DOT___067843_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067842_)))));
    vlSelf->wasmetal_core__DOT___065517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065512_))))));
    vlSelf->wasmetal_core__DOT___066340_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066339_))));
    vlSelf->wasmetal_core__DOT___067004_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065512_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067002_)))));
    vlSelf->wasmetal_core__DOT___067284_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065960_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067282_)))));
    vlSelf->wasmetal_core__DOT___065963_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065960_))));
    vlSelf->wasmetal_core__DOT___068688_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066700_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068686_)))));
    vlSelf->wasmetal_core__DOT___067948_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065385_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067945_)))));
    vlSelf->wasmetal_core__DOT___069428_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b70__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065385_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067945_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069421_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xd7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065389_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___066188_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066184_))));
    vlSelf->wasmetal_core__DOT___067435_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066184_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067434_)))));
    vlSelf->wasmetal_core__DOT___069795_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066835_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068783_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069791_))))));
    vlSelf->wasmetal_core__DOT___068786_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066835_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068783_)))));
    vlSelf->wasmetal_core__DOT___066840_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066835_))));
    vlSelf->wasmetal_core__DOT___068999_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067133_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068996_)))));
    vlSelf->wasmetal_core__DOT___069876_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067133_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069873_))))));
    vlSelf->wasmetal_core__DOT___067138_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067133_))));
    vlSelf->wasmetal_core__DOT___068191_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065766_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068188_)))));
    vlSelf->wasmetal_core__DOT___069523_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065766_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069519_))))));
    vlSelf->wasmetal_core__DOT___065773_ = (1U & (IData)(
                                                         (0x70707777ff00ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065768_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065767_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065766_)))))))));
    vlSelf->wasmetal_core__DOT___069457_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065490_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068008_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069452_))))));
    vlSelf->wasmetal_core__DOT___068010_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068008_)))));
}
