#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__29(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__29\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___029496_;
    wasmetal_core__DOT___029496_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029602_;
    wasmetal_core__DOT___029602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031954_;
    wasmetal_core__DOT___031954_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032016_;
    wasmetal_core__DOT___032016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032020_;
    wasmetal_core__DOT___032020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063490_;
    wasmetal_core__DOT___063490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063498_;
    wasmetal_core__DOT___063498_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063506_;
    wasmetal_core__DOT___063506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063514_;
    wasmetal_core__DOT___063514_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063522_;
    wasmetal_core__DOT___063522_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063530_;
    wasmetal_core__DOT___063530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063538_;
    wasmetal_core__DOT___063538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063546_;
    wasmetal_core__DOT___063546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063586_;
    wasmetal_core__DOT___063586_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063594_;
    wasmetal_core__DOT___063594_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063602_;
    wasmetal_core__DOT___063602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063610_;
    wasmetal_core__DOT___063610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063618_;
    wasmetal_core__DOT___063618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063626_;
    wasmetal_core__DOT___063626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063634_;
    wasmetal_core__DOT___063634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063642_;
    wasmetal_core__DOT___063642_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063650_;
    wasmetal_core__DOT___063650_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063658_;
    wasmetal_core__DOT___063658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063666_;
    wasmetal_core__DOT___063666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063674_;
    wasmetal_core__DOT___063674_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128289___O;
    wasmetal_core__DOT____Vcellout___128289___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128412___O;
    wasmetal_core__DOT____Vcellout___128412___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128413___O;
    wasmetal_core__DOT____Vcellout___128413___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128415___O;
    wasmetal_core__DOT____Vcellout___128415___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128416___O;
    wasmetal_core__DOT____Vcellout___128416___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128417___O;
    wasmetal_core__DOT____Vcellout___128417___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029479_));
    wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036765_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfd696a08__0))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b16__05d) {
        vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030695_;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031941_;
    }
    wasmetal_core__DOT___063490_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063498_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063506_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063514_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032030_));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031338_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134155___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036766_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036765_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036764_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036763_)))) 
           ^ (((IData)(wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036730_)))));
    vlSelf->wasmetal_core__DOT___036734_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036766_)
                                                   ? (IData)(wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9473bd37__0))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b17__05d) {
        vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___063491_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063490_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063489_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063499_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063497_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063507_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063506_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063505_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063515_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063514_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063513_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031339_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036768_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036734_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h1872cc15__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128183___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029585_)))));
    vlSelf->wasmetal_core__DOT___029589_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128286___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030660_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b18__05d) {
        wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
    } else {
        wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128350___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031340_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031339_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031338_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031337_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031304_)))));
    vlSelf->wasmetal_core__DOT___031308_ = ((IData)(vlSelf->wasmetal_core__DOT___031340_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128174___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
           ^ (((IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029479_)))));
    vlSelf->wasmetal_core__DOT___029483_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128294___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030695_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128406___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031941_)))));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036769_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hed077be7__0))));
    vlSelf->wasmetal_core__DOT___063588_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___063596_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___063604_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___063612_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029589_));
    if (vlSelf->wasmetal_core__DOT__sp__05b19__05d) {
        vlSelf->wasmetal_core__DOT___030664_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        vlSelf->wasmetal_core__DOT___030699_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        vlSelf->wasmetal_core__DOT___031945_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030664_ = vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030699_ = wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031945_ = vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT____Vcellout___128412___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032030_)))));
    vlSelf->wasmetal_core__DOT___032003_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031342_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031308_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029483_));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036770_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h17547017__0))));
    vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b20__05d) {
        vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030664_;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030699_;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031945_;
    }
    wasmetal_core__DOT___063522_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063530_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128412___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063538_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063546_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032003_));
    vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031343_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___036739_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036771_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2b80e318__0))));
    wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b21__05d) {
        vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___063523_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063522_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063521_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063531_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063529_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063539_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063538_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063537_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063547_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063546_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063545_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031344_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036772_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036739_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hf6334cf8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128184___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
           ^ (((IData)(wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029589_)))));
    vlSelf->wasmetal_core__DOT___029593_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128287___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030664_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b22__05d) {
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128351___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031345_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031344_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031343_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031342_)))) 
           ^ (((IData)(wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031308_)))));
    vlSelf->wasmetal_core__DOT___031313_ = ((IData)(vlSelf->wasmetal_core__DOT___031345_)
                                             ? (IData)(wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128175___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029483_)))));
    vlSelf->wasmetal_core__DOT___029487_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128295___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030699_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128407___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031945_)))));
    wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036773_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h4835143f__0))));
    vlSelf->wasmetal_core__DOT___063620_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___063628_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___063636_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___063644_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029593_));
    if (vlSelf->wasmetal_core__DOT__sp__05b23__05d) {
        vlSelf->wasmetal_core__DOT___030669_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___030704_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___031950_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030669_ = wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030704_ = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031950_ = wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT____Vcellout___128413___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032003_)))));
    vlSelf->wasmetal_core__DOT___032007_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)
                                             : (IData)(wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032007_));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___032011_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032011_));
    vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___032016_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b24__05d) {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030669_;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030704_;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031950_;
        wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032016_;
    }
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031346_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031313_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029487_));
    wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036774_)
                  ? (IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h93f91ca8__0))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b25__05d) {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___063554_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128413___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031347_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134157___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036775_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036774_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036773_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036772_)))) 
           ^ (((IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036739_)))));
    vlSelf->wasmetal_core__DOT___036743_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036775_)
                                                   ? (IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd2526c88__0))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b26__05d) {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___063555_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063554_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063553_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063563_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063562_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063561_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063571_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063570_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063569_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063579_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063578_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063577_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031348_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036776_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036743_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h364ba349__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128185___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029593_)))));
    vlSelf->wasmetal_core__DOT___029598_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128288___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030669_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b27__05d) {
        vlSelf->wasmetal_core__DOT___030673_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___030708_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        wasmetal_core__DOT___031954_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        wasmetal_core__DOT___032020_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030673_ = vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030708_ = wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___031954_ = vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___032020_ = wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128352___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031349_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031348_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031347_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031346_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031313_)))));
    vlSelf->wasmetal_core__DOT___031317_ = ((IData)(vlSelf->wasmetal_core__DOT___031349_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128176___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
           ^ (((IData)(wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029487_)))));
    vlSelf->wasmetal_core__DOT___029492_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128296___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030704_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128408___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031950_)))));
    vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036777_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h586b57d5__0))));
    vlSelf->wasmetal_core__DOT___063652_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___063660_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___063668_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___063676_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029598_));
    if (vlSelf->wasmetal_core__DOT__sp__05b28__05d) {
        vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030673_;
        wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030708_;
        wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___031954_;
        wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032020_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128414___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032007_)))));
    vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031350_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031317_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029492_));
    vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b29__05d) {
        vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
        wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
        wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
        wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___063586_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063594_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063602_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063610_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031351_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128289___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       : (IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___030673_)))));
    vlSelf->wasmetal_core__DOT___063587_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063586_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063585_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063595_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063593_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063603_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063602_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063601_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063611_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063609_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128353___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031354_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031353_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031351_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031350_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___031353_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031317_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128297___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030708_)))));
    wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128409___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031954_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128186___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
           ^ (((IData)(wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029598_)))));
    wasmetal_core__DOT___029602_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063684_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___063692_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___063700_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___063708_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128177___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
           ^ (((IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029492_)))));
    wasmetal_core__DOT___029496_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
           & (IData)(wasmetal_core__DOT___029602_));
    wasmetal_core__DOT____Vcellout___128415___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032011_)))));
    wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
           & (IData)(wasmetal_core__DOT___029496_));
    wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__ 
        = (((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___063618_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128415___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063626_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128415___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063634_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128415___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063642_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128415___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128187___O 
        = ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
           ^ ((0xfffffff8U & (((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                               << 1U) & ((IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__) 
                                         << 3U))) | 
              (((IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__) 
                << 2U) | (((IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__) 
                           << 1U) | (IData)(wasmetal_core__DOT___029602_)))));
    vlSelf->wasmetal_core__DOT___063619_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063617_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063627_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063626_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063625_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063635_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063634_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063633_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063643_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063641_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128178___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
           ^ ((0xfffffff8U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                               << 1U) & ((IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__) 
                                         << 3U))) | 
              (((IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__) 
                << 2U) | (((IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__) 
                           << 1U) | (IData)(wasmetal_core__DOT___029496_)))));
    wasmetal_core__DOT____Vcellout___128416___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___032016_)))));
    wasmetal_core__DOT___063650_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128416___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063658_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128416___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063666_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128416___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063674_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128416___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063651_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063650_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063649_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063659_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063658_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063667_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063665_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063675_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063673_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    wasmetal_core__DOT____Vcellout___128417___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       : (IData)(wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___032020_)))));
    vlSelf->wasmetal_core__DOT___063682_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128417___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063690_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128417___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128417___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063706_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128417___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063683_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063681_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063691_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063690_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063689_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063699_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063698_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063697_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063707_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063706_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063705_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__2(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__2\n"); );
    // Body
    vlSelf->__VdfgTmp_h39926e96__0 = (((IData)(vlSelf->wasmetal_core__DOT___004321_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5a6445ef__0))));
    vlSelf->wasmetal_core__DOT___004323_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a6445ef__0))));
    vlSelf->wasmetal_core__DOT___000977_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000971_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000970_)));
    vlSelf->__VdfgTmp_h58c7b8aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___004025_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hcba3b702__0))));
    vlSelf->wasmetal_core__DOT___004027_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcba3b702__0))));
    vlSelf->wasmetal_core__DOT___001324_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000949_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000948_)));
    vlSelf->__VdfgTmp_h9b219d07__0 = (((IData)(vlSelf->wasmetal_core__DOT___003727_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5e9c07be__0))));
    vlSelf->wasmetal_core__DOT___003729_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5e9c07be__0))));
    vlSelf->__VdfgTmp_h21caabb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004691_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h60070975__0))));
    vlSelf->wasmetal_core__DOT___004693_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60070975__0))));
    vlSelf->__VdfgTmp_hd35a9dc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004247_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h74f399ec__0))));
    vlSelf->wasmetal_core__DOT___004249_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h74f399ec__0))));
    vlSelf->__VdfgTmp_h31a231e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___004173_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9cca9eb0__0))));
    vlSelf->wasmetal_core__DOT___004175_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9cca9eb0__0))));
    vlSelf->__VdfgTmp_hc1c0d33f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003579_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h67445948__0))));
    vlSelf->wasmetal_core__DOT___003581_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67445948__0))));
    vlSelf->__VdfgTmp_h01d0ee79__0 = (((IData)(vlSelf->wasmetal_core__DOT___003505_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h252badb1__0))));
    vlSelf->wasmetal_core__DOT___003507_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h252badb1__0))));
    vlSelf->__VdfgTmp_he23a6b26__0 = (((IData)(vlSelf->wasmetal_core__DOT___003653_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h34a57f42__0))));
    vlSelf->wasmetal_core__DOT___003655_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h34a57f42__0))));
    vlSelf->__VdfgTmp_h07a3b670__0 = (((IData)(vlSelf->wasmetal_core__DOT___003801_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4e280dfe__0))));
    vlSelf->wasmetal_core__DOT___003803_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4e280dfe__0))));
    vlSelf->__VdfgTmp_he0dafd81__0 = (((IData)(vlSelf->wasmetal_core__DOT___004617_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h054c8d5f__0))));
    vlSelf->wasmetal_core__DOT___004619_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h054c8d5f__0))));
    vlSelf->__VdfgTmp_h2b977022__0 = (((IData)(vlSelf->wasmetal_core__DOT___004469_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc00537e7__0))));
    vlSelf->wasmetal_core__DOT___004471_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc00537e7__0))));
    vlSelf->__VdfgTmp_hd438e6c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___004395_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4f517b43__0))));
    vlSelf->wasmetal_core__DOT___004397_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4f517b43__0))));
    vlSelf->__VdfgTmp_h50f5670e__0 = (((IData)(vlSelf->wasmetal_core__DOT___004543_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_haf89032c__0))));
    vlSelf->wasmetal_core__DOT___004545_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf89032c__0))));
    vlSelf->__VdfgTmp_he2ad86dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004765_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5500fae9__0))));
    vlSelf->wasmetal_core__DOT___004767_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5500fae9__0))));
    vlSelf->__VdfgTmp_h4cb51258__0 = (((IData)(vlSelf->wasmetal_core__DOT___004839_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3c930b99__0))));
    vlSelf->wasmetal_core__DOT___004841_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c930b99__0))));
    vlSelf->__VdfgTmp_h319b52f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003295_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h95280768__0))));
    vlSelf->wasmetal_core__DOT___003297_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95280768__0))));
    vlSelf->__VdfgTmp_h0683198f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003215_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf410ea07__0))));
    vlSelf->wasmetal_core__DOT___003217_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf410ea07__0))));
    vlSelf->__VdfgTmp_h7752095d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005625_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2a120d0d__0))));
    vlSelf->wasmetal_core__DOT___005627_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a120d0d__0))));
    vlSelf->wasmetal_core__DOT___000654_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000648_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000647_)));
    vlSelf->wasmetal_core__DOT___000632_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000626_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000625_)));
    vlSelf->wasmetal_core__DOT___000610_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000604_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000603_)));
    vlSelf->wasmetal_core__DOT___000588_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000582_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000581_)));
    vlSelf->wasmetal_core__DOT___000561_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000555_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000554_)));
    vlSelf->wasmetal_core__DOT___000539_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000533_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000532_)));
    vlSelf->wasmetal_core__DOT___000517_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000511_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000510_)));
    vlSelf->wasmetal_core__DOT___000495_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000489_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000488_)));
    vlSelf->wasmetal_core__DOT___000473_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000445_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000444_)));
    vlSelf->wasmetal_core__DOT___000461_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000455_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000454_)));
    vlSelf->__VdfgTmp_he7820a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___003277_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc744024d__0))));
    vlSelf->wasmetal_core__DOT___003279_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc744024d__0))));
    vlSelf->wasmetal_core__DOT___000429_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000407_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000406_)));
    vlSelf->__VdfgTmp_he9245313__0 = (((IData)(vlSelf->wasmetal_core__DOT___003197_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h856b720a__0))));
    vlSelf->wasmetal_core__DOT___003199_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h856b720a__0))));
    vlSelf->wasmetal_core__DOT___000413_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000397_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000396_)));
    vlSelf->wasmetal_core__DOT___001643_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001637_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001636_)));
    vlSelf->wasmetal_core__DOT___001621_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001603_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001602_)));
    vlSelf->wasmetal_core__DOT___001609_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001593_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001592_)));
    vlSelf->wasmetal_core__DOT___001577_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001559_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001558_)));
    vlSelf->wasmetal_core__DOT___001565_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001549_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001548_)));
    vlSelf->wasmetal_core__DOT___001533_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001515_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001514_)));
    vlSelf->wasmetal_core__DOT___001521_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001505_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001504_)));
    vlSelf->wasmetal_core__DOT___001422_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001404_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001403_)));
    vlSelf->wasmetal_core__DOT___001410_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001394_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001393_)));
    vlSelf->wasmetal_core__DOT___001378_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001350_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001349_)));
    vlSelf->wasmetal_core__DOT___001366_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001360_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001359_)));
    vlSelf->wasmetal_core__DOT___001484_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001466_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001465_)));
    vlSelf->wasmetal_core__DOT___001472_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001456_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001455_)));
    vlSelf->wasmetal_core__DOT___001440_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001191_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001190_)));
    vlSelf->wasmetal_core__DOT___001434_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001201_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001200_)));
    vlSelf->wasmetal_core__DOT___001883_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000193_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000192_)));
    vlSelf->wasmetal_core__DOT___001871_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000387_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000386_)));
    vlSelf->wasmetal_core__DOT___052236_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1ddac1d__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc070dcf__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b25__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb1ddac1d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hdc070dcf__0))))));
    vlSelf->wasmetal_core__DOT___052237_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27610e5d__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h329ed040__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b24__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h27610e5d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h329ed040__0))))));
    vlSelf->wasmetal_core__DOT___052403_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hda033d4f__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6effbe38__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b21__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hda033d4f__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h6effbe38__0))))));
    vlSelf->wasmetal_core__DOT___052402_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbabec73__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1dec8a5e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b20__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfbabec73__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h1dec8a5e__0))))));
    vlSelf->wasmetal_core__DOT___052560_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9975f0a8__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4c7ff695__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b18__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9975f0a8__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h4c7ff695__0))))));
    vlSelf->wasmetal_core__DOT___052559_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h40e72268__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h152b96e8__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b17__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h40e72268__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h152b96e8__0))))));
    vlSelf->wasmetal_core__DOT___052529_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7409986d__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd259e3cd__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b16__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7409986d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hd259e3cd__0))))));
    vlSelf->wasmetal_core__DOT___052294_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9340bbb8__0)))));
    vlSelf->wasmetal_core__DOT___052354_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbc270d96__0)))));
    vlSelf->wasmetal_core__DOT___052101_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hacecf0f9__0)))));
    vlSelf->wasmetal_core__DOT___052281_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4e57fd92__0)))));
    vlSelf->wasmetal_core__DOT___052282_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6f7c691c__0)))));
    vlSelf->wasmetal_core__DOT___052353_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h04a005a2__0)))));
    vlSelf->wasmetal_core__DOT___052107_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h27483593__0)))));
    vlSelf->wasmetal_core__DOT___052099_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6823128b__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff555503f303f3ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                   << 5U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2d07d754__0))))))));
    vlSelf->wasmetal_core__DOT___052108_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc644e6af__0)))));
    vlSelf->wasmetal_core__DOT___052080_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9efd96c7__0)))));
    vlSelf->wasmetal_core__DOT___052276_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7c824381__0)))));
    vlSelf->wasmetal_core__DOT___052345_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbd2119cc__0)))));
    vlSelf->wasmetal_core__DOT___052275_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2098039d__0)))));
    vlSelf->wasmetal_core__DOT___052280_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0b18d540__0)))));
    vlSelf->wasmetal_core__DOT___052061_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4c3dd507__0)))));
    vlSelf->wasmetal_core__DOT___052060_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8b19f5ab__0)))));
    vlSelf->wasmetal_core__DOT___052083_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h96657cd6__0)))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff555503f303f3ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                     << 5U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h04cce861__0)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff555503f303f3ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                        << 5U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h7e6d032b__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff555503f303f3ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h187cbe57__0))))))))));
    vlSelf->wasmetal_core__DOT___052277_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5f1be76b__0)))));
    vlSelf->wasmetal_core__DOT___052069_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9a831d1c__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff555503f303f3ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                   << 5U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h3e0c1557__0))))))));
    vlSelf->wasmetal_core__DOT___052079_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb156040c__0)))));
    vlSelf->wasmetal_core__DOT___052344_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h93ad939a__0)))));
    vlSelf->wasmetal_core__DOT___004784_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001981_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001980_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h71ee5e5b__0)))))))));
    vlSelf->wasmetal_core__DOT___004783_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h71ee5e5b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001981_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001980_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b66__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052068_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004791_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h5f8f87da__0)))))))))));
    vlSelf->wasmetal_core__DOT___004926_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002839_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002838_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcf9144f2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha0134e57__0)))))))));
    vlSelf->wasmetal_core__DOT___004925_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcf9144f2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha0134e57__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002839_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002838_)))))));
    vlSelf->wasmetal_core__DOT___004802_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001991_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001990_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h978f5c03__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfd858dc9__0)))))))));
    vlSelf->wasmetal_core__DOT___004801_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h978f5c03__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfd858dc9__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001991_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001990_)))))));
    vlSelf->wasmetal_core__DOT___004944_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002829_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002828_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h567f5b99__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h346b1359__0)))))))));
    vlSelf->wasmetal_core__DOT___004943_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h567f5b99__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h346b1359__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002829_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002828_)))))));
    vlSelf->wasmetal_core__DOT___003450_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002448_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002447_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hde496412__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h97f578c1__0)))))))));
    vlSelf->wasmetal_core__DOT___003449_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hde496412__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h97f578c1__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002448_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002447_)))))));
    vlSelf->wasmetal_core__DOT___003468_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002458_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002457_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b9c68be__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha79a258b__0)))))))));
    vlSelf->wasmetal_core__DOT___003105_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7b9c68be__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha79a258b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002458_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002457_)))))));
    vlSelf->wasmetal_core__DOT___004710_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002016_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002015_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdb1fbe21__0)))))))));
    vlSelf->wasmetal_core__DOT___004709_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdb1fbe21__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002016_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002015_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b67__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052067_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004717_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6be40165__0)))))))))));
    vlSelf->wasmetal_core__DOT___004488_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001268_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001267_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h04880fd7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8fe0413e__0)))))))));
    vlSelf->wasmetal_core__DOT___004487_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h04880fd7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8fe0413e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001268_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001267_)))))));
    vlSelf->wasmetal_core__DOT___004994_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002881_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002880_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0589a813__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1c139036__0)))))))));
    vlSelf->wasmetal_core__DOT___004993_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0589a813__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1c139036__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002881_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002880_)))))));
    vlSelf->wasmetal_core__DOT___004858_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002757_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002756_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h27cfb5f3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd97a8939__0)))))))));
    vlSelf->wasmetal_core__DOT___004857_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h27cfb5f3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd97a8939__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002757_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002756_)))))));
    vlSelf->wasmetal_core__DOT___005266_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002797_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002796_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he1a2a265__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha991aa19__0)))))))));
    vlSelf->wasmetal_core__DOT___005265_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he1a2a265__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha991aa19__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002797_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002796_)))))));
    vlSelf->wasmetal_core__DOT___004340_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001693_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001692_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc20a91e7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h772b8f1d__0)))))))));
    vlSelf->wasmetal_core__DOT___004339_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc20a91e7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h772b8f1d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001693_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001692_)))))));
    vlSelf->wasmetal_core__DOT___005198_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002921_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002920_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5a3a45b7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h21ed485e__0)))))))));
    vlSelf->wasmetal_core__DOT___005197_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5a3a45b7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h21ed485e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002921_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002920_)))))));
    vlSelf->wasmetal_core__DOT___004414_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001758_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001757_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h97006b3e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7211f94c__0)))))))));
    vlSelf->wasmetal_core__DOT___004413_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h97006b3e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7211f94c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001758_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001757_)))))));
    vlSelf->wasmetal_core__DOT___004728_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002026_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002025_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3348ca28__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h30008db5__0)))))))));
    vlSelf->wasmetal_core__DOT___004727_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3348ca28__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h30008db5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002026_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002025_)))))));
    vlSelf->wasmetal_core__DOT___004506_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001278_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001277_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h924e7878__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h37ae4b02__0)))))))));
    vlSelf->wasmetal_core__DOT___003097_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h924e7878__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h37ae4b02__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001278_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001277_)))))));
    vlSelf->wasmetal_core__DOT___004358_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001703_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001702_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha95b5bdf__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h491d2757__0)))))))));
    vlSelf->wasmetal_core__DOT___003099_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha95b5bdf__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h491d2757__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001703_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001702_)))))));
    vlSelf->wasmetal_core__DOT___004432_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001768_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001767_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14eebae7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4db00d9__0)))))))));
    vlSelf->wasmetal_core__DOT___003101_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h14eebae7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc4db00d9__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001768_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001767_)))))));
    vlSelf->wasmetal_core__DOT___005012_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002871_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002870_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcb2b4d33__0)))))))));
    vlSelf->wasmetal_core__DOT___005011_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcb2b4d33__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002871_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002870_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b91__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052089_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005019_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he20a0bf9__0)))))))))));
    vlSelf->wasmetal_core__DOT___004876_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002747_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002746_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ab68aeb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefb6db46__0)))))))));
    vlSelf->wasmetal_core__DOT___004875_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6ab68aeb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hefb6db46__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002747_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002746_)))))));
    vlSelf->wasmetal_core__DOT___005284_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002787_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002786_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3ecae377__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hba4202f8__0)))))))));
    vlSelf->wasmetal_core__DOT___005283_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3ecae377__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hba4202f8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002787_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002786_)))))));
    vlSelf->wasmetal_core__DOT___003524_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002370_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002369_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd368a607__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h05ad6ae6__0)))))))));
    vlSelf->wasmetal_core__DOT___003523_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd368a607__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h05ad6ae6__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002370_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002369_)))))));
    vlSelf->wasmetal_core__DOT___005216_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002911_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002910_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc521e256__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9c9a7e74__0)))))))));
    vlSelf->wasmetal_core__DOT___005215_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc521e256__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9c9a7e74__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002911_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002910_)))))));
    vlSelf->wasmetal_core__DOT___004118_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002093_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002092_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfbf79e7b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb7be35e7__0)))))))));
    vlSelf->wasmetal_core__DOT___004117_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfbf79e7b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb7be35e7__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002093_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002092_)))))));
    vlSelf->wasmetal_core__DOT___004192_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002130_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002129_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0d5eea6__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h98cd7462__0)))))))));
    vlSelf->wasmetal_core__DOT___004191_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he0d5eea6__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h98cd7462__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002130_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002129_)))))));
    vlSelf->wasmetal_core__DOT___003542_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002380_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002379_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbd2d90ad__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81ca9b0b__0)))))))));
    vlSelf->wasmetal_core__DOT___003107_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbd2d90ad__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h81ca9b0b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002380_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002379_)))))));
    vlSelf->wasmetal_core__DOT___004636_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002167_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002166_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb62a6dc2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfdc5949f__0)))))))));
    vlSelf->wasmetal_core__DOT___004635_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb62a6dc2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfdc5949f__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002167_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002166_)))))));
    vlSelf->wasmetal_core__DOT___004136_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002103_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002102_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc2399f9e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h27f51ffd__0)))))))));
    vlSelf->wasmetal_core__DOT___003117_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc2399f9e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h27f51ffd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002103_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002102_)))))));
    vlSelf->wasmetal_core__DOT___004210_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002140_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002139_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3ed820c7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hade513e3__0)))))))));
    vlSelf->wasmetal_core__DOT___003119_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3ed820c7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hade513e3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002140_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002139_)))))));
    vlSelf->wasmetal_core__DOT___004654_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002177_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002176_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_haa9d6aae__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3bb332b8__0)))))))));
    vlSelf->wasmetal_core__DOT___003121_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_haa9d6aae__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3bb332b8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002177_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002176_)))))));
    vlSelf->wasmetal_core__DOT___003234_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001916_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001915_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h336c7598__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbdb7c255__0)))))))));
    vlSelf->wasmetal_core__DOT___003233_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h336c7598__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbdb7c255__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001916_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001915_)))))));
    vlSelf->wasmetal_core__DOT___005334_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002717_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002716_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4c59d32e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd1570df5__0)))))))));
    vlSelf->wasmetal_core__DOT___005333_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4c59d32e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd1570df5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002717_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002716_)))))));
    vlSelf->wasmetal_core__DOT___003252_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001926_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001925_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hed1e62e4__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha418026d__0)))))))));
    vlSelf->wasmetal_core__DOT___003095_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hed1e62e4__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha418026d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001926_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001925_)))))));
    vlSelf->wasmetal_core__DOT___005352_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002707_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002706_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0352b565__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8396fa72__0)))))))));
    vlSelf->wasmetal_core__DOT___005351_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0352b565__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8396fa72__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002707_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002706_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b89__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052091_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0352b565__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005359_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0)))))))))));
    vlSelf->wasmetal_core__DOT___003598_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002410_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002409_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha5352532__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h75b3f6cb__0)))))))));
    vlSelf->wasmetal_core__DOT___003597_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha5352532__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h75b3f6cb__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002410_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002409_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b73__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052077_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha5352532__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003605_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h24f58f01__0)))))))))));
    vlSelf->wasmetal_core__DOT___003616_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002420_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002419_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha8e2ab84__0)))))))));
    vlSelf->wasmetal_core__DOT___003111_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha8e2ab84__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002420_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002419_)))))));
    vlSelf->wasmetal_core__DOT___004044_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002304_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002303_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e17785c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h57f74169__0)))))))));
    vlSelf->wasmetal_core__DOT___004043_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1e17785c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h57f74169__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002304_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002303_)))))));
    vlSelf->wasmetal_core__DOT___004062_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002314_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002313_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70b5eab4__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h59732ad2__0)))))))));
    vlSelf->wasmetal_core__DOT___004061_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h70b5eab4__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h59732ad2__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002314_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002313_)))))));
    vlSelf->wasmetal_core__DOT___003902_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002341_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002340_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3971fc45__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1553b034__0)))))))));
    vlSelf->wasmetal_core__DOT___003901_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3971fc45__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1553b034__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002341_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002340_)))))));
    vlSelf->wasmetal_core__DOT___003382_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002618_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002617_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8de0b505__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf66f4835__0)))))))));
    vlSelf->wasmetal_core__DOT___003381_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8de0b505__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf66f4835__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002618_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002617_)))))));
    vlSelf->wasmetal_core__DOT___003314_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002581_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002580_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he4198019__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h57a954cd__0)))))))));
    vlSelf->wasmetal_core__DOT___003313_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he4198019__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h57a954cd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002581_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002580_)))))));
    vlSelf->wasmetal_core__DOT___003828_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001215_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001214_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h587b33f1__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42aab1a0__0)))))))));
    vlSelf->wasmetal_core__DOT___003827_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h587b33f1__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h42aab1a0__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001215_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001214_)))))));
    vlSelf->wasmetal_core__DOT___003846_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001225_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001224_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h94eb455b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf50294ef__0)))))))));
    vlSelf->wasmetal_core__DOT___003845_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h94eb455b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf50294ef__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001225_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001224_)))))));
    vlSelf->wasmetal_core__DOT___003920_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002351_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002350_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5fa501f3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9047b303__0)))))))));
    vlSelf->wasmetal_core__DOT___003919_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5fa501f3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9047b303__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002351_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002350_)))))));
    vlSelf->wasmetal_core__DOT___003400_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002628_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002627_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcced7fa9__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4fd522f6__0)))))))));
    vlSelf->wasmetal_core__DOT___003399_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcced7fa9__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4fd522f6__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002628_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002627_)))))));
    vlSelf->wasmetal_core__DOT___003332_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002591_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002590_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb92015b3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h725e6949__0)))))))));
    vlSelf->wasmetal_core__DOT___003331_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb92015b3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h725e6949__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002591_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002590_)))))));
    vlSelf->wasmetal_core__DOT___004266_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002258_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002257_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h33748258__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c8a9440__0)))))))));
    vlSelf->wasmetal_core__DOT___004265_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h33748258__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8c8a9440__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002258_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002257_)))))));
    vlSelf->wasmetal_core__DOT___004284_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002268_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002267_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5528d6fa__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h490ddce5__0)))))))));
    vlSelf->wasmetal_core__DOT___003115_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5528d6fa__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h490ddce5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002268_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002267_)))))));
    vlSelf->wasmetal_core__DOT___003151_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001825_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001824_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h302dd625__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha7aa500a__0)))))))));
    vlSelf->wasmetal_core__DOT___003150_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h302dd625__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha7aa500a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001825_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001824_)))))));
    vlSelf->wasmetal_core__DOT___005062_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002678_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002677_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h80bd54db__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ae60ef8__0)))))))));
    vlSelf->wasmetal_core__DOT___005061_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h80bd54db__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6ae60ef8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002678_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002677_)))))));
    vlSelf->wasmetal_core__DOT___003172_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001835_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001834_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h76024217__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h10a0c0f5__0)))))))));
    vlSelf->wasmetal_core__DOT___003091_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h76024217__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h10a0c0f5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001835_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001834_)))))));
    vlSelf->wasmetal_core__DOT___003746_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002533_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002532_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hab141f26__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7f4a56d5__0)))))))));
    vlSelf->wasmetal_core__DOT___003745_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hab141f26__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7f4a56d5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002533_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002532_)))))));
    vlSelf->wasmetal_core__DOT___005080_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002668_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002667_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7762895e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70bc9fce__0)))))))));
    vlSelf->wasmetal_core__DOT___005079_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7762895e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h70bc9fce__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002668_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002667_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b88__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052087_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7762895e__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005087_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8a29f22b__0)))))))))));
    vlSelf->wasmetal_core__DOT___003764_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002543_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002542_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hea93726f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h64d4eb6a__0)))))))));
    vlSelf->wasmetal_core__DOT___003109_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hea93726f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h64d4eb6a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002543_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002542_)))))));
    vlSelf->wasmetal_core__DOT___003970_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002055_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002054_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81a5b0aa__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h51fb7abf__0)))))))));
    vlSelf->wasmetal_core__DOT___003969_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h81a5b0aa__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h51fb7abf__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002055_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002054_)))))));
    vlSelf->wasmetal_core__DOT___003988_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002065_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002064_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h78e77464__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8b07b599__0)))))))));
    vlSelf->wasmetal_core__DOT___003113_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h78e77464__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8b07b599__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002065_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002064_)))))));
    vlSelf->wasmetal_core__DOT___052355_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb342b047__0)))));
    vlSelf->wasmetal_core__DOT___052062_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h18733fd3__0)))));
    vlSelf->wasmetal_core__DOT___052100_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2876322d__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff555503f303f3ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                   << 5U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7de933ba__0))))))));
    vlSelf->wasmetal_core__DOT___052078_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he10ebbb0__0)))));
    vlSelf->wasmetal_core__DOT___052343_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc7901b89__0)))));
    vlSelf->wasmetal_core__DOT___052293_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h20122d13__0)))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff555503f303f3ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                     << 5U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbe2bd06c__0)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff555503f303f3ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                        << 5U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h75fb7e4c__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff555503f303f3ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf100045e__0))))))))));
    vlSelf->wasmetal_core__DOT___005582_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___003080_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___003079_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he6a8c031__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h61222d2d__0)))))))));
    vlSelf->wasmetal_core__DOT___005581_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he6a8c031__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h61222d2d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___003080_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___003079_)))))));
    vlSelf->wasmetal_core__DOT___004562_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002213_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002212_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb257a383__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8934d805__0)))))))));
    vlSelf->wasmetal_core__DOT___004561_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb257a383__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8934d805__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002213_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002212_)))))));
    vlSelf->wasmetal_core__DOT___004580_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002223_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002222_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h82193735__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h63e29ec3__0)))))))));
    vlSelf->wasmetal_core__DOT___003103_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h82193735__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h63e29ec3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002223_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002222_)))))));
    vlSelf->wasmetal_core__DOT___005600_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___003090_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___003089_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0def293__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h87f6cbda__0)))))))));
    vlSelf->wasmetal_core__DOT___005599_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc0def293__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h87f6cbda__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___003090_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___003089_)))))));
    vlSelf->wasmetal_core__DOT___003672_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002491_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002490_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe998686__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h395f448e__0)))))))));
    vlSelf->wasmetal_core__DOT___003671_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfe998686__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h395f448e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002491_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002490_)))))));
    vlSelf->wasmetal_core__DOT___003690_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002501_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002500_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb129d53d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3e2e569c__0)))))))));
    vlSelf->wasmetal_core__DOT___003689_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb129d53d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3e2e569c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002501_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002500_)))))));
    vlSelf->wasmetal_core__DOT___005130_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002960_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002959_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h572d5497__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1fbc0854__0)))))))));
    vlSelf->wasmetal_core__DOT___005129_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h572d5497__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1fbc0854__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002960_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002959_)))))));
    vlSelf->wasmetal_core__DOT___005148_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002950_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002949_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h128bed99__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd4bbf89e__0)))))))));
    vlSelf->wasmetal_core__DOT___005147_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h128bed99__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd4bbf89e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002950_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002949_)))))));
    vlSelf->wasmetal_core__DOT___005636_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001185_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001184_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbe8cca87__0)))))))));
    vlSelf->wasmetal_core__DOT___001330_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbe8cca87__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001185_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001184_)))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) {
        vlSelf->wasmetal_core__DOT___001164_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h81e66010__0))));
        vlSelf->wasmetal_core__DOT___001142_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc60de2b1__0))));
        vlSelf->wasmetal_core__DOT___001120_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h664f8c0a__0))));
        vlSelf->wasmetal_core__DOT___001098_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0))));
        vlSelf->wasmetal_core__DOT___001076_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb19b1393__0))));
        vlSelf->wasmetal_core__DOT___001054_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7def20ec__0))));
        vlSelf->wasmetal_core__DOT___001032_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbc0682c2__0))));
        vlSelf->wasmetal_core__DOT___001010_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h80bc039f__0))));
        vlSelf->wasmetal_core__DOT___000988_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h85029f86__0))));
        vlSelf->wasmetal_core__DOT___000976_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h397ad7fb__0))));
        vlSelf->wasmetal_core__DOT___001323_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcef8ef16__0))));
        vlSelf->wasmetal_core__DOT___000653_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h95441b9a__0))));
    } else {
        vlSelf->wasmetal_core__DOT___001164_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hac8a82be__0))));
        vlSelf->wasmetal_core__DOT___001142_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h87463cf8__0))));
        vlSelf->wasmetal_core__DOT___001120_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7685727c__0))));
        vlSelf->wasmetal_core__DOT___001098_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hca84dae7__0))));
        vlSelf->wasmetal_core__DOT___001076_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0b41010__0))));
        vlSelf->wasmetal_core__DOT___001054_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1871ad84__0))));
        vlSelf->wasmetal_core__DOT___001032_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hccb9e3d4__0))));
        vlSelf->wasmetal_core__DOT___001010_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd6ccf561__0))));
        vlSelf->wasmetal_core__DOT___000988_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha8f762bd__0))));
        vlSelf->wasmetal_core__DOT___000976_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h23462764__0))));
        vlSelf->wasmetal_core__DOT___001323_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9d577f3c__0))));
        vlSelf->wasmetal_core__DOT___000653_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h981495cf__0))));
    }
    vlSelf->wasmetal_core__DOT___052175_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2ee186c3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052159_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h81e66010__0)))))))))));
    vlSelf->wasmetal_core__DOT___005244_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001159_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001158_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81e66010__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hac8a82be__0)))))))));
    vlSelf->wasmetal_core__DOT___001169_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h81e66010__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hac8a82be__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001159_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001158_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b62__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052159_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h81e66010__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2ee186c3__0))))))));
    vlSelf->wasmetal_core__DOT___052189_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5085d456__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052146_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)))))))))));
    vlSelf->wasmetal_core__DOT___005312_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001137_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001136_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h87463cf8__0)))))))));
    vlSelf->wasmetal_core__DOT___001147_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h87463cf8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001137_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001136_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b61__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052146_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5085d456__0))))))));
    vlSelf->wasmetal_core__DOT___052188_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5ef7d401__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052186_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)))))))))));
    vlSelf->wasmetal_core__DOT___004904_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001115_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001114_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7685727c__0)))))))));
    vlSelf->wasmetal_core__DOT___001125_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7685727c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001115_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001114_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b60__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052186_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5ef7d401__0))))))));
    vlSelf->wasmetal_core__DOT___052504_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hdf96a80c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052481_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)))))))))));
    vlSelf->wasmetal_core__DOT___005040_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001093_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001092_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hca84dae7__0)))))))));
    vlSelf->wasmetal_core__DOT___001103_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hca84dae7__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001093_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001092_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b59__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052481_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hdf96a80c__0))))))));
    vlSelf->wasmetal_core__DOT___052503_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h26403b1c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052486_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb19b1393__0)))))))))));
    vlSelf->wasmetal_core__DOT___004972_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001071_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001070_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb19b1393__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb0b41010__0)))))))));
    vlSelf->wasmetal_core__DOT___001081_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb19b1393__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb0b41010__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001071_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001070_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b58__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052486_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb19b1393__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h26403b1c__0))))))));
    vlSelf->wasmetal_core__DOT___052178_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hfbb7166b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052173_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7def20ec__0)))))))))));
    vlSelf->wasmetal_core__DOT___005380_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001049_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001048_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7def20ec__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1871ad84__0)))))))));
    vlSelf->wasmetal_core__DOT___001059_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7def20ec__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1871ad84__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001049_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001048_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b57__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052173_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7def20ec__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfbb7166b__0))))))));
    vlSelf->wasmetal_core__DOT___052177_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hec62ba82__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052164_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)))))))))));
    vlSelf->wasmetal_core__DOT___005108_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001027_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001026_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hccb9e3d4__0)))))))));
    vlSelf->wasmetal_core__DOT___001037_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hccb9e3d4__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001027_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001026_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b56__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052164_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hec62ba82__0))))))));
    vlSelf->wasmetal_core__DOT___052449_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc6c0965f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052427_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h80bc039f__0)))))))))));
    vlSelf->wasmetal_core__DOT___005176_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001005_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001004_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h80bc039f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd6ccf561__0)))))))));
    vlSelf->wasmetal_core__DOT___001015_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h80bc039f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd6ccf561__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001005_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001004_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b55__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052427_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h80bc039f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc6c0965f__0))))))));
    vlSelf->wasmetal_core__DOT___003876_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000939_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000938_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6366d506__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0908881__0)))))))));
    vlSelf->wasmetal_core__DOT___000927_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6366d506__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc0908881__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000939_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000938_)))))));
    vlSelf->wasmetal_core__DOT___004092_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000909_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000908_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he74cbbd8__0)))))))));
    vlSelf->wasmetal_core__DOT___000897_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he74cbbd8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000909_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000908_)))))));
    vlSelf->wasmetal_core__DOT___052448_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2e9416a5__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052422_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h85029f86__0)))))))))));
    vlSelf->wasmetal_core__DOT___003360_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000961_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000960_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h85029f86__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha8f762bd__0)))))))));
    vlSelf->wasmetal_core__DOT___000993_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h85029f86__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha8f762bd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000961_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000960_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b54__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052422_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h85029f86__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2e9416a5__0))))))));
    vlSelf->wasmetal_core__DOT___004314_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000919_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000918_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h650b1858__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3a817888__0)))))))));
    vlSelf->wasmetal_core__DOT___000896_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h650b1858__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3a817888__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000919_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000918_)))))));
    vlSelf->wasmetal_core__DOT___052140_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc0a5660d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052123_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)))))))))));
    vlSelf->wasmetal_core__DOT___003428_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000971_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000970_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h23462764__0)))))))));
    vlSelf->wasmetal_core__DOT___000981_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h23462764__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000971_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000970_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b53__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052123_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc0a5660d__0))))))));
    vlSelf->wasmetal_core__DOT___004018_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000885_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000884_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hebb33e32__0)))))))));
    vlSelf->wasmetal_core__DOT___000873_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hebb33e32__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000885_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000884_)))))));
    vlSelf->wasmetal_core__DOT___052139_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h651ffab0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052118_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)))))))))));
    vlSelf->wasmetal_core__DOT___003948_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000949_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000948_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9d577f3c__0)))))))));
    vlSelf->wasmetal_core__DOT___000926_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9d577f3c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000949_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000948_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b52__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052118_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h651ffab0__0))))))));
    vlSelf->wasmetal_core__DOT___003720_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000895_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000894_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h57e567b8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hffc6befa__0)))))))));
    vlSelf->wasmetal_core__DOT___000872_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h57e567b8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hffc6befa__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000895_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000894_)))))));
    vlSelf->wasmetal_core__DOT___004684_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000861_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000860_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70e821ff__0)))))))));
    vlSelf->wasmetal_core__DOT___000849_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h70e821ff__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000861_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000860_)))))));
    vlSelf->wasmetal_core__DOT___004240_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000871_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000870_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb87fbc4d__0)))))))));
    vlSelf->wasmetal_core__DOT___000848_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb87fbc4d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000871_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000870_)))))));
    vlSelf->wasmetal_core__DOT___004166_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000847_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000846_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdfd359a7__0)))))))));
    vlSelf->wasmetal_core__DOT___000824_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdfd359a7__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000847_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000846_)))))));
    vlSelf->wasmetal_core__DOT___003572_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000837_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000836_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h456da093__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h49f908f3__0)))))))));
    vlSelf->wasmetal_core__DOT___000825_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h456da093__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h49f908f3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000837_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000836_)))))));
    vlSelf->wasmetal_core__DOT___003498_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000808_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000807_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfd0db41d__0)))))))));
    vlSelf->wasmetal_core__DOT___000796_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfd0db41d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000808_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000807_)))))));
    vlSelf->wasmetal_core__DOT___003646_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000818_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000817_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h90eba162__0)))))))));
    vlSelf->wasmetal_core__DOT___000795_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h90eba162__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000818_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000817_)))))));
    vlSelf->wasmetal_core__DOT___003794_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000784_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000783_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb4397905__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h636dab99__0)))))))));
    vlSelf->wasmetal_core__DOT___000772_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb4397905__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h636dab99__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000784_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000783_)))))));
    vlSelf->wasmetal_core__DOT___004610_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000794_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000793_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce8a559f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3ff40a3b__0)))))))));
    vlSelf->wasmetal_core__DOT___000771_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hce8a559f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3ff40a3b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000794_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000793_)))))));
    vlSelf->wasmetal_core__DOT___004462_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000770_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000769_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc5320df5__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hea8a286f__0)))))))));
    vlSelf->wasmetal_core__DOT___000747_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc5320df5__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hea8a286f__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000770_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000769_)))))));
    vlSelf->wasmetal_core__DOT___004388_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000760_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000759_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfcc5cb61__0)))))))));
    vlSelf->wasmetal_core__DOT___000748_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfcc5cb61__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000760_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000759_)))))));
    vlSelf->wasmetal_core__DOT___004536_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000746_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000745_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3d4b630e__0)))))))));
    vlSelf->wasmetal_core__DOT___000723_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3d4b630e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000746_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000745_)))))));
    vlSelf->wasmetal_core__DOT___004758_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000736_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000735_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb26c7187__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc72a6a37__0)))))))));
    vlSelf->wasmetal_core__DOT___000724_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb26c7187__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc72a6a37__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000736_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000735_)))))));
    vlSelf->wasmetal_core__DOT___004832_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000716_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000715_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_heda84e5a__0)))))))));
    vlSelf->wasmetal_core__DOT___000694_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_heda84e5a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000716_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000715_)))))));
    vlSelf->wasmetal_core__DOT___003288_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000706_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000705_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h13262e9c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h550ff904__0)))))))));
    vlSelf->wasmetal_core__DOT___000693_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h13262e9c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h550ff904__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000706_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000705_)))))));
    vlSelf->wasmetal_core__DOT___003208_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000682_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000681_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1512c46f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h339ccfdb__0)))))))));
    vlSelf->wasmetal_core__DOT___000665_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1512c46f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h339ccfdb__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000682_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000681_)))))));
    vlSelf->wasmetal_core__DOT___005618_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000692_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000691_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h149fa621__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfafc2bd6__0)))))))));
    vlSelf->wasmetal_core__DOT___005617_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h149fa621__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfafc2bd6__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000692_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000691_)))))));
}
