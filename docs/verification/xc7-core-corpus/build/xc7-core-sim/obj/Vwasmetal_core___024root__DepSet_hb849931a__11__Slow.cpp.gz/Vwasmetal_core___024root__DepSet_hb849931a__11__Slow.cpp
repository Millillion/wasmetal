#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__10(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__10\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044758_;
    wasmetal_core__DOT___044758_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044767_;
    wasmetal_core__DOT___044767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044770_;
    wasmetal_core__DOT___044770_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044779_;
    wasmetal_core__DOT___044779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064142_;
    wasmetal_core__DOT___064142_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064143_;
    wasmetal_core__DOT___064143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064152_;
    wasmetal_core__DOT___064152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064153_;
    wasmetal_core__DOT___064153_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064165_;
    wasmetal_core__DOT___064165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064175_;
    wasmetal_core__DOT___064175_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064176_;
    wasmetal_core__DOT___064176_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064594_;
    wasmetal_core__DOT___064594_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064595_;
    wasmetal_core__DOT___064595_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064596_;
    wasmetal_core__DOT___064596_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064597_;
    wasmetal_core__DOT___064597_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064608_;
    wasmetal_core__DOT___064608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064610_;
    wasmetal_core__DOT___064610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064611_;
    wasmetal_core__DOT___064611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064630_;
    wasmetal_core__DOT___064630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064631_;
    wasmetal_core__DOT___064631_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065110_;
    wasmetal_core__DOT___065110_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065249_;
    wasmetal_core__DOT___065249_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065250_;
    wasmetal_core__DOT___065250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065251_;
    wasmetal_core__DOT___065251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065337_;
    wasmetal_core__DOT___065337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065339_;
    wasmetal_core__DOT___065339_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065531_;
    wasmetal_core__DOT___065531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065670_;
    wasmetal_core__DOT___065670_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065743_;
    wasmetal_core__DOT___065743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065977_;
    wasmetal_core__DOT___065977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065982_;
    wasmetal_core__DOT___065982_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065983_;
    wasmetal_core__DOT___065983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066040_;
    wasmetal_core__DOT___066040_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066045_;
    wasmetal_core__DOT___066045_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066169_;
    wasmetal_core__DOT___066169_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066238_;
    wasmetal_core__DOT___066238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066347_;
    wasmetal_core__DOT___066347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066447_;
    wasmetal_core__DOT___066447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066493_;
    wasmetal_core__DOT___066493_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066569_;
    wasmetal_core__DOT___066569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066686_;
    wasmetal_core__DOT___066686_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066690_;
    wasmetal_core__DOT___066690_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066691_;
    wasmetal_core__DOT___066691_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066736_;
    wasmetal_core__DOT___066736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066821_;
    wasmetal_core__DOT___066821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066825_;
    wasmetal_core__DOT___066825_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066926_;
    wasmetal_core__DOT___066926_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067009_;
    wasmetal_core__DOT___067009_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067056_;
    wasmetal_core__DOT___067056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067122_;
    wasmetal_core__DOT___067122_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067417_;
    wasmetal_core__DOT___067417_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067418_;
    wasmetal_core__DOT___067418_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067699_;
    wasmetal_core__DOT___067699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067784_;
    wasmetal_core__DOT___067784_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067931_;
    wasmetal_core__DOT___067931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068046_;
    wasmetal_core__DOT___068046_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069123_;
    wasmetal_core__DOT___069123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069897_;
    wasmetal_core__DOT___069897_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070657_;
    wasmetal_core__DOT___070657_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128413___O;
    wasmetal_core__DOT____Vcellout___128413___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128453___O;
    wasmetal_core__DOT____Vcellout___128453___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127833___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127833___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128154___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128154___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128170___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128170___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__ = 0;
    CData/*4:0*/ __VdfgTmp_h3f3712a8__0;
    __VdfgTmp_h3f3712a8__0 = 0;
    CData/*2:0*/ __VdfgTmp_h77ef1d0d__0;
    __VdfgTmp_h77ef1d0d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0beafa3e__0;
    __VdfgTmp_h0beafa3e__0 = 0;
    CData/*5:0*/ __VdfgTmp_h015651e9__0;
    __VdfgTmp_h015651e9__0 = 0;
    // Body
    wasmetal_core__DOT___065743_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064158_))));
    vlSelf->wasmetal_core__DOT___064163_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064162_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065976_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064162_))));
    vlSelf->wasmetal_core__DOT___064150_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064149_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067008_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064149_))));
    vlSelf->wasmetal_core__DOT___064170_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064167_))));
    vlSelf->wasmetal_core__DOT___064151_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064148_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064148_))));
    vlSelf->wasmetal_core__DOT___064173_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064172_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064172_))));
    vlSelf->wasmetal_core__DOT___064174_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064171_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066237_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064171_))));
    vlSelf->wasmetal_core__DOT___064169_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064168_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064168_))));
    vlSelf->wasmetal_core__DOT___064140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064139_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066685_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064139_))));
    vlSelf->wasmetal_core__DOT___064146_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064145_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066820_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064145_))));
    vlSelf->wasmetal_core__DOT___064137_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064134_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066446_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064134_))));
    vlSelf->wasmetal_core__DOT___064141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066568_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064138_))));
    vlSelf->wasmetal_core__DOT___064147_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064144_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066735_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064144_))));
    vlSelf->wasmetal_core__DOT___064136_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064135_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066492_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064135_))));
    vlSelf->wasmetal_core__DOT___067288_ = (1U & (0xa3000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (3U 
                                                                  & (- (IData)(
                                                                               (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064588_)))))));
    vlSelf->__VdfgTmp_hb731668a__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xfe01ffffU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                            << 2U)) 
                                                        | (1U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))))));
    wasmetal_core__DOT___064630_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x80U 
                                                       >> 
                                                       (1U 
                                                        & (0x80U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))))));
    vlSelf->wasmetal_core__DOT___068866_ = (1U & (0xe1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___066173_ = (1U & (0xfe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                    << 4U) 
                                                   | (0xfU 
                                                      & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O), 3U)))));
    vlSelf->__VdfgTmp_h2e5f0189__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                         << 3U));
    vlSelf->wasmetal_core__DOT___066451_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064588_)))));
    wasmetal_core__DOT___065337_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xe000U 
                                                       >> 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                        << 2U))))));
    vlSelf->wasmetal_core__DOT___065111_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))))));
    vlSelf->wasmetal_core__DOT___066573_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe0000000U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064588_)))));
    wasmetal_core__DOT___066045_ = (1U & (0xaafc0000U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                  << 4U)) 
                                              | ((4U 
                                                  & ((0x80U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___064588_)) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064588_)) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___064588_))))));
    vlSelf->wasmetal_core__DOT___064947_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe0000000U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                          << 2U))))));
    vlSelf->wasmetal_core__DOT___064805_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (0x80U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))))));
    wasmetal_core__DOT___067931_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                       << 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                             << 1U)) 
                                                           << 1U)))))));
    wasmetal_core__DOT___067417_ = (1U & (0x1ffffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                               << 4U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))));
    wasmetal_core__DOT___066825_ = (1U & (0x53U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0xe000U 
                                                 >> 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                  << 2U)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___064588_)))));
    __VdfgTmp_h015651e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                               << 5U) | (0xfU & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O), 3U)));
    vlSelf->wasmetal_core__DOT___066497_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064588_)))));
    wasmetal_core__DOT___066690_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064588_))));
    __VdfgTmp_h77ef1d0d__0 = (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                               << 2U) | (1U & (0x80U 
                                               >> (IData)(vlSelf->wasmetal_core__DOT___064588_))));
    vlSelf->__VdfgTmp_h0ed876af__0 = (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                       << 5U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)));
    wasmetal_core__DOT___065982_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (1U 
                                                       >> 
                                                       (3U 
                                                        & (- (IData)(
                                                                     (1U 
                                                                      & (8U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064588_)))))))))));
    __VdfgTmp_h3f3712a8__0 = ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                        << 4U)) | ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                   << 3U));
    wasmetal_core__DOT___065249_ = (1U & (0xe0U >> 
                                          ((2U & ((0x80U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064588_)) 
                                                  << 1U)) 
                                           | (1U & 
                                              (8U >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))));
    wasmetal_core__DOT___067699_ = (1U & (4U >> ((2U 
                                                  & ((1U 
                                                      >> 
                                                      (3U 
                                                       & (- (IData)(
                                                                    (1U 
                                                                     & (4U 
                                                                        >> 
                                                                        ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                         << 1U))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                        << 1U))))));
    wasmetal_core__DOT___065531_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))));
    wasmetal_core__DOT___068046_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))));
    wasmetal_core__DOT___067784_ = (1U & (1U >> ((2U 
                                                  & ((0x10U 
                                                      >> 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                       << 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                        << 1U))))));
    vlSelf->__VdfgTmp_h38f5e1f6__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                         << 4U));
    vlSelf->__VdfgTmp_h88f593f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                    << 4U)));
    __VdfgTmp_h0beafa3e__0 = ((2U & ((8U >> (IData)(vlSelf->wasmetal_core__DOT___064588_)) 
                                     << 1U)) | (1U 
                                                & (0x80U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064588_))));
    vlSelf->wasmetal_core__DOT___064589_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064588_))));
    vlSelf->wasmetal_core__DOT___064034_ = (1U & (IData)(
                                                         (0xff10ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064033_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064031_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O))))))))));
    vlSelf->wasmetal_core__DOT___064219_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7fffffffff00ffULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064215_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O)) 
                                                                                | (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___033860_))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O) 
                                                                                >> 1U)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                                                >> 3U)))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x30U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O) 
                                                                        << 2U)) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128591___O) 
                                                                           << 1U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb90eb6ff__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb90eb6ff__0))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                                         << 4U)) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                                            << 2U)) 
                                                                        | ((8U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128588___O) 
                                                                                >> 1U))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc47ce573__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128587___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128588___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc47ce573__0)))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128401___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031892_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128406___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031941_)))));
    vlSelf->wasmetal_core__DOT___031945_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029483_));
    if (vlSelf->wasmetal_core__DOT__sp__05b20__05d) {
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030699_;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031945_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128465___O 
        = (((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)) 
                   << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)
                 : (IData)(vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032628_)))));
    wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036773_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h4835143f__0))));
    wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031344_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128600___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033927_)))));
    vlSelf->wasmetal_core__DOT___062881_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x18U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062873_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))));
    vlSelf->wasmetal_core__DOT___062892_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x19U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062884_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062903_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1aU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062914_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1bU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062906_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 3U))))))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))) {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033121_));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033215_));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033987_));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128497___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032949_)))));
    vlSelf->wasmetal_core__DOT___039849_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1aU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039853_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1bU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039852_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1cU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039843_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1dU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039802_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039414_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039807_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039816_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029935_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d));
    wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032887_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029766_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d));
    wasmetal_core__DOT___128170___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029403_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128170___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d));
    vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027822_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b29__05d));
    vlSelf->wasmetal_core__DOT___067478_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000358_))))));
    wasmetal_core__DOT___128154___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029242_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128154___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d));
    wasmetal_core__DOT___044758_ = (1U & (IData)((0xc8e8ecf0c8e0c8eULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (vlSelf->function_locals 
                                                       >> 0x18U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                          << 3U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                                >> 1U)) 
                                                            | (vlSelf->function_locals 
                                                               >> 0x1eU))))))));
    wasmetal_core__DOT___044770_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & (vlSelf->function_locals 
                                                          >> 0x1bU)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & (vlSelf->function_locals 
                                                                >> 0x1cU)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O)) 
                                                               | (1U 
                                                                  & (vlSelf->function_locals 
                                                                     >> 0x1dU))))))))));
    wasmetal_core__DOT___044767_ = (1U & (IData)((0xc8e8ecf0c8e0c8eULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (vlSelf->function_locals 
                                                       >> 0x15U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                                << 2U)) 
                                                            | (3U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0x1bU)))))))));
    wasmetal_core__DOT___044779_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & (vlSelf->function_locals 
                                                          >> 0x18U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O)) 
                                                         | ((4U 
                                                             & (vlSelf->function_locals 
                                                                >> 0x19U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & (vlSelf->function_locals 
                                                                     >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032215_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d));
    wasmetal_core__DOT___070657_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070655_)))))))));
    wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032695_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037205_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134215___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h09206f3f__0))));
    vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034715_));
    vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035105_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d));
    vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034911_));
    wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026282_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127841___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d));
    wasmetal_core__DOT___127833___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026186_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127833___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d));
    vlSelf->wasmetal_core__DOT___054526_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054525_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054528_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054527_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x17U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054530_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054529_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x18U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054532_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x19U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063648_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063656_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063664_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063663_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063672_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026378_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d));
    vlSelf->wasmetal_core__DOT___032826_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032825_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032823_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032822_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O)))));
    vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032820_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030799_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030733_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128341___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031116_)))));
    vlSelf->wasmetal_core__DOT___031121_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128365___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031404_)))));
    vlSelf->wasmetal_core__DOT___031409_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128453___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032496_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032495_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032494_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032493_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032427_)))));
    vlSelf->wasmetal_core__DOT___032432_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032496_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032496_))));
    vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031757_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031691_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d));
    vlSelf->wasmetal_core__DOT___065028_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064698_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065027_))));
    vlSelf->wasmetal_core__DOT___065225_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065027_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065224_))));
    vlSelf->wasmetal_core__DOT___065382_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065144_))));
    vlSelf->wasmetal_core__DOT___065487_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065486_))));
    vlSelf->wasmetal_core__DOT___065511_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065510_))));
    vlSelf->wasmetal_core__DOT___065651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065486_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065650_))));
    vlSelf->wasmetal_core__DOT___064862_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064417_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064434_))));
    vlSelf->wasmetal_core__DOT___065763_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065510_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065762_))));
    vlSelf->wasmetal_core__DOT___065020_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064688_))));
    vlSelf->wasmetal_core__DOT___064429_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064417_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064416_))));
    vlSelf->wasmetal_core__DOT___065846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065845_))));
    vlSelf->wasmetal_core__DOT___065958_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065762_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065957_))));
    vlSelf->wasmetal_core__DOT___064687_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064682_))));
    vlSelf->wasmetal_core__DOT___066029_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065845_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066028_))));
    vlSelf->wasmetal_core__DOT___064861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064427_))));
    vlSelf->wasmetal_core__DOT___066182_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065957_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066181_))));
    vlSelf->wasmetal_core__DOT___065018_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064685_))));
    vlSelf->wasmetal_core__DOT___066227_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066226_))));
    vlSelf->wasmetal_core__DOT___064428_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064427_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064426_))));
    vlSelf->wasmetal_core__DOT___066338_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066181_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066337_))));
    vlSelf->wasmetal_core__DOT___064686_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064685_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064684_))));
    vlSelf->wasmetal_core__DOT___066436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066435_))));
    vlSelf->wasmetal_core__DOT___064860_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064426_))));
    vlSelf->wasmetal_core__DOT___066502_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066337_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066501_))));
    vlSelf->wasmetal_core__DOT___065017_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064684_))));
    vlSelf->wasmetal_core__DOT___066583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066435_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066582_))));
    vlSelf->wasmetal_core__DOT___064383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064370_))));
    vlSelf->wasmetal_core__DOT___066697_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066696_))));
    vlSelf->wasmetal_core__DOT___064673_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064668_))));
    vlSelf->wasmetal_core__DOT___066750_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066749_))));
    vlSelf->wasmetal_core__DOT___065373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdbf4091d__0))))));
    vlSelf->wasmetal_core__DOT___066832_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066696_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066831_))));
    vlSelf->wasmetal_core__DOT___065012_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064668_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064671_))));
    vlSelf->wasmetal_core__DOT___066916_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066749_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066915_))));
    vlSelf->wasmetal_core__DOT___064382_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdbf4091d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064380_))));
    vlSelf->wasmetal_core__DOT___067000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066831_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066999_))));
    vlSelf->wasmetal_core__DOT___064672_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064671_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064670_))));
    vlSelf->wasmetal_core__DOT___067045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067044_))));
    vlSelf->wasmetal_core__DOT___069958_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064858_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064380_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064393_))));
    vlSelf->wasmetal_core__DOT___067130_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067129_))));
    vlSelf->wasmetal_core__DOT___065011_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064675_))));
    vlSelf->wasmetal_core__DOT___067241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067240_))));
    vlSelf->wasmetal_core__DOT___069287_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069217_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___064662_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064661_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___064405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064392_))));
    vlSelf->wasmetal_core__DOT___067280_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067129_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067279_))));
    vlSelf->wasmetal_core__DOT___064679_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064675_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064674_))));
    vlSelf->wasmetal_core__DOT___067385_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067384_))));
    vlSelf->wasmetal_core__DOT___069267_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069185_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069266_))));
    vlSelf->wasmetal_core__DOT___064356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064355_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064354_))));
    vlSelf->wasmetal_core__DOT___064856_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064392_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064403_))));
    vlSelf->wasmetal_core__DOT___067432_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067431_))));
    vlSelf->wasmetal_core__DOT___065014_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064674_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064677_))));
    vlSelf->wasmetal_core__DOT___067529_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067384_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067528_))));
    vlSelf->wasmetal_core__DOT___069218_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069217_))));
    vlSelf->wasmetal_core__DOT___065006_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064661_))));
    vlSelf->wasmetal_core__DOT___069186_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069070_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069185_))));
    vlSelf->wasmetal_core__DOT___064850_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064355_))));
    vlSelf->wasmetal_core__DOT___069119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069118_))));
    vlSelf->wasmetal_core__DOT___064663_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064659_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064658_))));
    vlSelf->wasmetal_core__DOT___064404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064402_))));
    vlSelf->wasmetal_core__DOT___067577_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067576_))));
    vlSelf->wasmetal_core__DOT___064678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064676_))));
    vlSelf->wasmetal_core__DOT___067643_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067642_))));
    vlSelf->wasmetal_core__DOT___067054_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067049_)))));
    vlSelf->wasmetal_core__DOT___065498_ = (1U & (0x3a00U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065493_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064438_))))));
    vlSelf->wasmetal_core__DOT___066924_ = (1U & (0x11f00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h14cfefd1__0))))));
    vlSelf->wasmetal_core__DOT___065392_ = (1U & (0x5ccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf00886e7__0))))));
    vlSelf->wasmetal_core__DOT___065034_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf00886e7__0))));
    vlSelf->wasmetal_core__DOT___064872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064871_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___066343_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065514_))));
    vlSelf->wasmetal_core__DOT___065518_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065514_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___069071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069070_))));
    vlSelf->wasmetal_core__DOT___064357_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064344_))));
    vlSelf->wasmetal_core__DOT___064855_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064402_))));
    vlSelf->wasmetal_core__DOT___067711_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067576_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067710_))));
    vlSelf->wasmetal_core__DOT___065013_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064639_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064676_))));
    vlSelf->wasmetal_core__DOT___067790_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067642_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067789_))));
    vlSelf->wasmetal_core__DOT___069024_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068925_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069023_))));
    vlSelf->wasmetal_core__DOT___065003_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064654_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064659_))));
    vlSelf->wasmetal_core__DOT___068993_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068876_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068992_))));
    vlSelf->wasmetal_core__DOT___064847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064332_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064345_))));
    vlSelf->wasmetal_core__DOT___064289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064276_))));
    vlSelf->wasmetal_core__DOT___067839_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067710_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067838_))));
    vlSelf->wasmetal_core__DOT___068926_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068829_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068925_))));
    vlSelf->wasmetal_core__DOT___064656_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064655_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064654_))));
    vlSelf->wasmetal_core__DOT___068830_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068729_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068829_))));
    vlSelf->wasmetal_core__DOT___068877_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068876_))));
    vlSelf->wasmetal_core__DOT___065004_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064655_))));
    vlSelf->wasmetal_core__DOT___064334_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064332_))));
    vlSelf->wasmetal_core__DOT___064643_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064639_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064638_))));
    vlSelf->wasmetal_core__DOT___067882_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067789_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067881_))));
    vlSelf->wasmetal_core__DOT___064842_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064287_))));
    vlSelf->wasmetal_core__DOT___067942_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067941_))));
    vlSelf->wasmetal_core__DOT___064998_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064638_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064641_))));
    vlSelf->wasmetal_core__DOT___068005_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067881_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068004_))));
    vlSelf->wasmetal_core__DOT___064288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064286_))));
    vlSelf->wasmetal_core__DOT___068058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067941_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068057_))));
    vlSelf->wasmetal_core__DOT___068780_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068779_))));
    vlSelf->wasmetal_core__DOT___064848_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064322_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064333_))));
    vlSelf->wasmetal_core__DOT___064642_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064641_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064640_))));
    vlSelf->wasmetal_core__DOT___068133_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068132_))));
    vlSelf->wasmetal_core__DOT___064997_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064640_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064645_))));
    vlSelf->wasmetal_core__DOT___064841_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064299_))));
    vlSelf->wasmetal_core__DOT___064311_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064298_))));
    vlSelf->wasmetal_core__DOT___068219_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068218_))));
    vlSelf->wasmetal_core__DOT___068185_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068184_))));
    vlSelf->wasmetal_core__DOT___068272_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068184_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068271_))));
    vlSelf->wasmetal_core__DOT___064649_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064644_))));
    vlSelf->wasmetal_core__DOT___068325_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068324_))));
    vlSelf->wasmetal_core__DOT___068730_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068729_))));
    vlSelf->wasmetal_core__DOT___064657_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064652_))));
    vlSelf->wasmetal_core__DOT___064844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064298_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064309_))));
    vlSelf->wasmetal_core__DOT___068381_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068271_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068380_))));
    vlSelf->wasmetal_core__DOT___064335_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064322_))));
    vlSelf->wasmetal_core__DOT___068683_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068682_))));
    vlSelf->wasmetal_core__DOT___065000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064647_))));
    vlSelf->wasmetal_core__DOT___068456_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068455_))));
    vlSelf->wasmetal_core__DOT___064648_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064646_))));
    vlSelf->wasmetal_core__DOT___064999_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064653_))));
    vlSelf->wasmetal_core__DOT___064843_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064323_))));
    vlSelf->wasmetal_core__DOT___064310_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064308_))));
    vlSelf->wasmetal_core__DOT___068633_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068632_))));
    vlSelf->wasmetal_core__DOT___068519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068518_))));
    vlSelf->wasmetal_core__DOT___068583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068582_))));
    vlSelf->wasmetal_core__DOT___068501_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068380_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068500_))));
    vlSelf->wasmetal_core__DOT___069193_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069191_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___070381_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b122__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068997_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069874_))))));
    vlSelf->wasmetal_core__DOT___068998_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068997_))));
    vlSelf->wasmetal_core__DOT___067390_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067388_))));
    wasmetal_core__DOT___069123_ = (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___067388_))));
    wasmetal_core__DOT___069897_ = (1U & (1U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___067246_))));
    vlSelf->__VdfgTmp_hd4f38404__0 = ((0xcU & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                               << 1U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066034_)));
    vlSelf->wasmetal_core__DOT___068882_ = (1U & (0x3b00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067003_))))));
    vlSelf->wasmetal_core__DOT___070279_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b114__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068587_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x7f0000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_heceac102__0))))))));
    vlSelf->wasmetal_core__DOT___068588_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068587_))));
    vlSelf->wasmetal_core__DOT___068930_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf0f0f77U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0))))));
    vlSelf->wasmetal_core__DOT___067051_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (0xf0f0f77U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0))))));
    vlSelf->wasmetal_core__DOT___065656_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (0xf0880000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0))))));
    vlSelf->wasmetal_core__DOT___067886_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065232_))));
    vlSelf->wasmetal_core__DOT___066755_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066753_))));
    vlSelf->wasmetal_core__DOT___068734_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066753_))));
    vlSelf->wasmetal_core__DOT___068189_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065770_))));
    vlSelf->wasmetal_core__DOT___065771_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065770_))));
    vlSelf->wasmetal_core__DOT___070057_ = (1U & (0x48ccc8ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067794_))))));
    vlSelf->wasmetal_core__DOT___070101_ = (1U & (0x48ccc8ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067946_))))));
    vlSelf->wasmetal_core__DOT___070019_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b97__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067648_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069295_))))));
    vlSelf->wasmetal_core__DOT___070393_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b123__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069028_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069896_))))));
    vlSelf->wasmetal_core__DOT___069029_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069028_))));
    vlSelf->wasmetal_core__DOT___070116_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b103__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068009_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069454_))))));
    vlSelf->wasmetal_core__DOT___070291_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b115__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068637_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069728_))))));
    vlSelf->wasmetal_core__DOT___070341_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b119__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068834_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069815_))))));
    vlSelf->wasmetal_core__DOT___070443_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b127__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069980_))))));
    vlSelf->wasmetal_core__DOT___069223_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069222_))));
    vlSelf->wasmetal_core__DOT___070267_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b113__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068523_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069683_))))));
    vlSelf->wasmetal_core__DOT___064840_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064836_))))))))));
    vlSelf->wasmetal_core__DOT___065145_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064836_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065144_))));
    wasmetal_core__DOT___065251_ = (1U & (0xc5U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___065248_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___064199_)))));
    wasmetal_core__DOT___064631_ = (1U & (IData)((0xbbf0f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 5U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3616a991__0)))))));
    vlSelf->wasmetal_core__DOT___064807_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3616a991__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064199_))))));
    wasmetal_core__DOT___065983_ = (1U & (0xbU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___065109_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((4U 
                                                          >> 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                           << 1U)) 
                                                         << 1U)))));
    wasmetal_core__DOT___065110_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                       << 1U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065109_))));
    vlSelf->wasmetal_core__DOT___065867_ = (1U & (0x11f00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064944_))))));
    vlSelf->wasmetal_core__DOT___064945_ = (1U & (2U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064944_))));
    vlSelf->wasmetal_core__DOT___064939_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064938_))));
    vlSelf->wasmetal_core__DOT___064193_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064192_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064191_))));
    vlSelf->wasmetal_core__DOT___065103_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065102_))));
    vlSelf->wasmetal_core__DOT___064130_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064129_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064128_))));
    vlSelf->wasmetal_core__DOT___067548_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067514_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067547_))));
    vlSelf->wasmetal_core__DOT___064617_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064191_))));
    vlSelf->wasmetal_core__DOT___065243_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065102_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065242_))));
    vlSelf->wasmetal_core__DOT___064603_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064124_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064129_))));
    vlSelf->wasmetal_core__DOT___067515_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067412_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067514_))));
    vlSelf->wasmetal_core__DOT___064188_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064181_))));
    vlSelf->wasmetal_core__DOT___065331_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065330_))));
    vlSelf->wasmetal_core__DOT___064615_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064181_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064186_))));
    vlSelf->wasmetal_core__DOT___065442_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065330_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065441_))));
    vlSelf->wasmetal_core__DOT___064131_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064125_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064124_))));
    vlSelf->wasmetal_core__DOT___067413_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067412_))));
    vlSelf->wasmetal_core__DOT___064187_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064185_))));
    vlSelf->wasmetal_core__DOT___065526_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065525_))));
    vlSelf->wasmetal_core__DOT___064600_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064125_))));
    vlSelf->wasmetal_core__DOT___067371_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067370_))));
    vlSelf->wasmetal_core__DOT___064601_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064119_))));
    vlSelf->wasmetal_core__DOT___064120_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064118_))));
    vlSelf->wasmetal_core__DOT___067227_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067116_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067226_))));
    vlSelf->wasmetal_core__DOT___067273_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067272_))));
    vlSelf->wasmetal_core__DOT___064614_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064160_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064185_))));
    vlSelf->wasmetal_core__DOT___065666_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065665_))));
    vlSelf->wasmetal_core__DOT___064121_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064115_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064114_))));
    vlSelf->wasmetal_core__DOT___067117_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067055_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067116_))));
    vlSelf->wasmetal_core__DOT___064609_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064159_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064164_))));
    vlSelf->wasmetal_core__DOT___064166_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064160_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064159_))));
    vlSelf->wasmetal_core__DOT___065861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065743_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065860_))));
    vlSelf->wasmetal_core__DOT___065744_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065665_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065743_))));
    wasmetal_core__DOT___064165_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064164_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064163_))));
    wasmetal_core__DOT___065977_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065860_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065976_))));
    wasmetal_core__DOT___064596_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064150_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064115_))));
    wasmetal_core__DOT___067056_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___067008_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___067055_))));
    wasmetal_core__DOT___064608_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064163_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064170_))));
    wasmetal_core__DOT___066040_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065976_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066039_))));
    wasmetal_core__DOT___064152_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064151_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064150_))));
    wasmetal_core__DOT___067009_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066925_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___067008_))));
    wasmetal_core__DOT___064175_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064174_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064173_))));
    wasmetal_core__DOT___066347_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066237_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066346_))));
    wasmetal_core__DOT___064611_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064169_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064174_))));
    wasmetal_core__DOT___064176_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064170_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064169_))));
    wasmetal_core__DOT___066238_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066168_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066237_))));
    wasmetal_core__DOT___066169_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066039_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066168_))));
    wasmetal_core__DOT___064597_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064146_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064151_))));
    wasmetal_core__DOT___066926_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066820_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066925_))));
    wasmetal_core__DOT___064610_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064173_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064137_))));
    wasmetal_core__DOT___066447_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066346_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066446_))));
    wasmetal_core__DOT___064142_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064141_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064140_))));
    wasmetal_core__DOT___066686_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066568_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066685_))));
    wasmetal_core__DOT___064594_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064140_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064147_))));
    wasmetal_core__DOT___064153_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064147_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064146_))));
    wasmetal_core__DOT___066736_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066685_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066735_))));
    wasmetal_core__DOT___066821_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066735_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066820_))));
    wasmetal_core__DOT___064595_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064136_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064141_))));
    wasmetal_core__DOT___064143_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064137_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064136_))));
    wasmetal_core__DOT___066569_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066492_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066568_))));
    wasmetal_core__DOT___066493_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066446_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066492_))));
    vlSelf->__VdfgTmp_h866f258c__0 = ((2U & ((0x35U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                     << 1U)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___066173_));
    wasmetal_core__DOT___065339_ = (1U & (0x80U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                  << 1U)) 
                                           | ((2U & 
                                               ((8U 
                                                 >> 
                                                 (3U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     >> 2U))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___065337_)))));
    vlSelf->__VdfgTmp_h102f49bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___065111_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | ((2U 
                                                         & ((1U 
                                                             >> 
                                                             (3U 
                                                              & (- (IData)(
                                                                           (1U 
                                                                            & (4U 
                                                                               >> 
                                                                               ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                                << 1U))))))) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___064588_))))));
    vlSelf->__VdfgTmp_hbab7bc7d__0 = (((IData)(wasmetal_core__DOT___066045_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf0f0f080ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                              << 5U) 
                                                             | (4U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                   << 2U)))))));
    vlSelf->wasmetal_core__DOT___066047_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                   | (IData)(wasmetal_core__DOT___066045_))));
    vlSelf->__VdfgTmp_h94800df3__0 = ((2U & ((0xc5U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | (((IData)(wasmetal_core__DOT___067931_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___065337_));
    vlSelf->__VdfgTmp_h5c1a0f86__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                               << 1U)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___067417_));
    wasmetal_core__DOT___067418_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                 | (IData)(wasmetal_core__DOT___067417_))));
    vlSelf->wasmetal_core__DOT___066827_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064944_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                       | (IData)(wasmetal_core__DOT___066825_)))))))));
    vlSelf->__VdfgTmp_hcb391db2__0 = ((2U & ((1U >> 
                                              ((2U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                   << 1U)) 
                                               | (IData)(wasmetal_core__DOT___067931_))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___066825_));
    vlSelf->wasmetal_core__DOT___067016_ = (1U & (IData)(
                                                         (0xbfbfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___066690_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))))))))))));
    wasmetal_core__DOT___066691_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___066690_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       (1U 
                                                        & (8U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064588_))))))));
    vlSelf->wasmetal_core__DOT___067060_ = (1U & (0xf0f0f77U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h77ef1d0d__0))));
    wasmetal_core__DOT___065670_ = (1U & (0xf0880000U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h77ef1d0d__0))));
    vlSelf->__VdfgTmp_hcbf20e6d__0 = (((IData)(wasmetal_core__DOT___064630_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x80000000ffffffffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h0ed876af__0)))));
    vlSelf->__VdfgTmp_hc6e14b62__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((0x10U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                               << 2U)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1ffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0ed876af__0)))));
    vlSelf->wasmetal_core__DOT___065450_ = (1U & (0x7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065448_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfe00000000000000ULL 
                                                                      >> (IData)(__VdfgTmp_h3f3712a8__0))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h078a1663__0))))));
    vlSelf->__VdfgTmp_h9e38c4fc__0 = ((2U & ((0x5333U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (4U 
                                                           >> 
                                                           (2U 
                                                            & ((0x10U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                 << 2U)) 
                                                               << 1U))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfe00000000000000ULL 
                                                       >> (IData)(__VdfgTmp_h3f3712a8__0)))));
    wasmetal_core__DOT___065250_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                     << 1U)) 
                                                 | (IData)(wasmetal_core__DOT___065249_))));
    vlSelf->wasmetal_core__DOT___066740_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___065249_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064588_)))));
    vlSelf->__VdfgTmp_h321017d8__0 = ((2U & ((0xc5U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | (((IData)(wasmetal_core__DOT___067699_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064805_));
    vlSelf->__VdfgTmp_h744eac81__0 = ((2U & ((1U >> 
                                              ((2U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                   << 1U)) 
                                               | (IData)(wasmetal_core__DOT___067699_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___066497_));
    vlSelf->__VdfgTmp_h50efe2fe__0 = (((IData)(wasmetal_core__DOT___065982_) 
                                       << 1U) | (1U 
                                                 & (0xbU 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___068046_) 
                                                      << 2U) 
                                                     | (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                             << 1U)) 
                                                           << 1U))))));
    vlSelf->__VdfgTmp_hf36de292__0 = (((IData)(wasmetal_core__DOT___065531_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                           << 1U)) 
                                                         << 1U)) 
                                                     | (IData)(wasmetal_core__DOT___068046_)))));
    vlSelf->__VdfgTmp_h90da4ee0__0 = ((2U & ((0xa333U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                      << 1U) 
                                                     | (IData)(wasmetal_core__DOT___067784_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064947_));
    vlSelf->__VdfgTmp_hf195595b__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((1U 
                                                    >> (IData)(wasmetal_core__DOT___067784_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff00ff00ff1fffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2e5f0189__0)))));
    vlSelf->__VdfgTmp_had7d0cfa__0 = ((2U & ((0x30aU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | (((IData)(wasmetal_core__DOT___067784_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___066573_));
    vlSelf->__VdfgTmp_h20f14479__0 = ((2U & ((0x35U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((1U 
                                                          >> (IData)(wasmetal_core__DOT___067784_)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfef0000000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0)))));
    vlSelf->__VdfgTmp_h484ca1c9__0 = ((2U & ((0xc0aU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((0x10U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                << 2U)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xffff01ffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0)))));
    vlSelf->__VdfgTmp_h83912db0__0 = ((2U & ((0x35U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((0x10U 
                                                                    >> 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                     << 2U)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___064588_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfffe000000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h88f593f0__0)))));
    vlSelf->__VdfgTmp_h73bd2015__0 = (((IData)(vlSelf->wasmetal_core__DOT___066451_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h88f593f0__0)))));
    wasmetal_core__DOT___067122_ = (1U & (0x5cU >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((1U 
                                                 >> (IData)(__VdfgTmp_h0beafa3e__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___064588_)))));
    vlSelf->wasmetal_core__DOT___067375_ = (1U & (0xf0f0f11U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h0beafa3e__0)))));
    vlSelf->wasmetal_core__DOT___065749_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_h0beafa3e__0))))));
    vlSelf->wasmetal_core__DOT___064632_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064589_))))))))))));
    vlSelf->wasmetal_core__DOT___064796_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064795_))));
    vlSelf->wasmetal_core__DOT___064072_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064034_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___064050_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064049_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064071_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064067_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064046_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064068_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064045_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064057_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064040_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064058_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064061_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064036_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064035_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064062_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064543_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064224_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___064225_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064234_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064233_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064220_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064229_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064230_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064221_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b22__05d) {
        wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
    } else {
        wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128184___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
           ^ (((IData)(wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029589_)))));
    vlSelf->wasmetal_core__DOT___029593_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128287___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030664_)))));
    vlSelf->wasmetal_core__DOT___030669_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)
                                             : (IData)(wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128413___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032003_)))));
    vlSelf->wasmetal_core__DOT___032007_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)
                                             : (IData)(wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036774_)
                  ? (IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h93f91ca8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128351___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031345_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031344_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031343_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031342_)))) 
           ^ (((IData)(wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031308_)))));
    vlSelf->wasmetal_core__DOT___031313_ = ((IData)(vlSelf->wasmetal_core__DOT___031345_)
                                             ? (IData)(wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))) {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellinp___128523___S 
        = ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                      >> 3U)) << 1U)) | (1U & (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                  >> 2U))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128522___S 
        = ((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                      >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                << 2U)) 
                                         | ((2U & (
                                                   (~ 
                                                    ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                     >> 3U)) 
                                                   << 1U)) 
                                            | (1U & 
                                               (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                   >> 2U))))));
    vlSelf->wasmetal_core__DOT___062916_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))))));
    vlSelf->wasmetal_core__DOT___062927_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062938_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062949_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029937_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128489___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032890_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032889_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032887_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032886_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032889_)
                 ? (IData)(wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032853_)))));
    vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128170___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029406_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029405_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029403_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029402_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___029405_)
                 ? (IData)(wasmetal_core__DOT___128170___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128170___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128170___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029369_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128017___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027825_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027824_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027822_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027821_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___027824_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027788_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128154___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029245_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029244_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029242_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029241_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___029244_)
                 ? (IData)(wasmetal_core__DOT___128154___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128154___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128154___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029208_)))));
    vlSelf->wasmetal_core__DOT___044747_ = ((IData)(wasmetal_core__DOT___044770_)
                                             ? ((IData)(wasmetal_core__DOT___044779_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044778_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044777_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044776_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044775_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044774_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044773_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044772_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044771_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___044769_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___044757_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044759_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044760_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044761_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044762_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044763_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044764_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044765_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044766_))
                                                 : (IData)(wasmetal_core__DOT___044767_))
                                             : (IData)(wasmetal_core__DOT___044758_));
    vlSelf->wasmetal_core__DOT____Vcellout___128433___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032218_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032217_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032214_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032217_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032181_)))));
    vlSelf->wasmetal_core__DOT___044812_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070657_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___044800_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070655_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128473___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032698_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032697_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032695_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032694_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032697_)
                 ? (IData)(wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032661_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___134215___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037208_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037207_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037205_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037204_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___037207_)
                       ? (IData)(wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__)
                       : (6U >> (IData)(vlSelf->__VdfgTmp_h08c26bfc__0))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134215___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___037172_)))));
    vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034653_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035107_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d));
    vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127841___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026285_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026284_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026282_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026281_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___026284_)
                 ? (IData)(wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127841___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026248_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127833___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026189_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026188_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026186_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026185_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___026188_)
                 ? (IData)(wasmetal_core__DOT___127833___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127833___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127833___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026152_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127849___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026381_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026380_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026378_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026377_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___026380_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026344_)))));
    vlSelf->wasmetal_core__DOT___032789_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032821_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128480___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032821_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032820_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032819_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032818_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032785_)))));
    vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030800_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d));
    vlSelf->wasmetal_core__DOT___128342___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031121_));
    vlSelf->wasmetal_core__DOT___128366___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031409_));
    vlSelf->wasmetal_core__DOT___063218_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128453___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063224_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128453___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063230_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128453___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___063236_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128453___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128454___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032497_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032432_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032497_))));
    vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031758_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d));
    vlSelf->wasmetal_core__DOT___065031_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065028_))))))));
    vlSelf->wasmetal_core__DOT___065226_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065225_))));
    vlSelf->wasmetal_core__DOT___065383_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064836_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065382_))));
    vlSelf->wasmetal_core__DOT___065488_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065487_))));
    vlSelf->wasmetal_core__DOT___065652_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065225_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065651_))));
    vlSelf->wasmetal_core__DOT___065764_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065763_))));
    vlSelf->wasmetal_core__DOT___065847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065846_))));
    vlSelf->wasmetal_core__DOT___065959_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065958_))));
    vlSelf->wasmetal_core__DOT___066030_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066029_))));
    vlSelf->wasmetal_core__DOT___066183_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065763_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066182_))));
    vlSelf->wasmetal_core__DOT___066228_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066227_))));
    vlSelf->wasmetal_core__DOT___064444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064428_))));
    vlSelf->wasmetal_core__DOT___066339_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065958_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066338_))));
    vlSelf->wasmetal_core__DOT___064694_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064687_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064686_))));
    vlSelf->wasmetal_core__DOT___066437_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066029_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066436_))));
    vlSelf->wasmetal_core__DOT___064864_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064860_))));
    vlSelf->wasmetal_core__DOT___066503_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066502_))));
    vlSelf->wasmetal_core__DOT___065019_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065018_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065017_))));
    vlSelf->wasmetal_core__DOT___066584_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066227_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066583_))));
    vlSelf->wasmetal_core__DOT___065132_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064428_))));
    vlSelf->wasmetal_core__DOT___066698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066338_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066697_))));
    vlSelf->wasmetal_core__DOT___066751_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066436_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066750_))));
    vlSelf->wasmetal_core__DOT___065374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064860_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065373_))));
    vlSelf->wasmetal_core__DOT___066833_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066832_))));
    vlSelf->wasmetal_core__DOT___066917_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066916_))));
    vlSelf->wasmetal_core__DOT___064407_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064382_))));
    vlSelf->wasmetal_core__DOT___067001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066697_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067000_))));
    vlSelf->wasmetal_core__DOT___064681_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064672_))));
    vlSelf->wasmetal_core__DOT___067046_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066750_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067045_))));
    vlSelf->wasmetal_core__DOT___070431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069958_))));
    vlSelf->wasmetal_core__DOT___067131_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067130_))));
    vlSelf->wasmetal_core__DOT___065016_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065011_))));
    vlSelf->wasmetal_core__DOT___067242_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066916_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067241_))));
    vlSelf->wasmetal_core__DOT___069937_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___069287_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065131_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064405_))));
    vlSelf->wasmetal_core__DOT___067281_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067280_))));
    vlSelf->wasmetal_core__DOT___065219_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064672_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064679_))));
    vlSelf->wasmetal_core__DOT___067386_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067385_))));
    vlSelf->wasmetal_core__DOT___069915_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___069267_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064858_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064856_))));
    vlSelf->wasmetal_core__DOT___067433_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067432_))));
    vlSelf->wasmetal_core__DOT___065481_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065011_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065014_))));
    vlSelf->wasmetal_core__DOT___067530_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067241_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067529_))));
    vlSelf->wasmetal_core__DOT___069344_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069218_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065007_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065006_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___069321_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___069266_))))));
    vlSelf->wasmetal_core__DOT___064851_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064850_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064354_))))));
    vlSelf->wasmetal_core__DOT___069288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069287_))));
    vlSelf->wasmetal_core__DOT___064664_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064663_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064662_))));
    vlSelf->wasmetal_core__DOT___064406_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064405_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064404_))));
    vlSelf->wasmetal_core__DOT___067578_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067577_))));
    vlSelf->wasmetal_core__DOT___064680_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064679_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064678_))));
    vlSelf->wasmetal_core__DOT___067644_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067385_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067643_))));
    vlSelf->wasmetal_core__DOT___065040_ = (1U & (0x3a00U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065034_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064438_))))));
    vlSelf->wasmetal_core__DOT___064873_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064872_))));
    vlSelf->wasmetal_core__DOT___069268_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069071_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069267_))));
    vlSelf->wasmetal_core__DOT___064358_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064356_))));
    vlSelf->wasmetal_core__DOT___064859_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064856_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064855_))));
    vlSelf->wasmetal_core__DOT___067712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067711_))));
    vlSelf->wasmetal_core__DOT___065015_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065013_))));
    vlSelf->wasmetal_core__DOT___067791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067790_))));
    vlSelf->wasmetal_core__DOT___069219_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069024_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069218_))));
    vlSelf->wasmetal_core__DOT___065477_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065003_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065006_))));
    vlSelf->wasmetal_core__DOT___069187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068993_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069186_))));
    vlSelf->wasmetal_core__DOT___065370_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064850_))));
    vlSelf->wasmetal_core__DOT___065130_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064404_))));
    vlSelf->wasmetal_core__DOT___067840_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067839_))));
    vlSelf->wasmetal_core__DOT___069120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068926_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069119_))));
    vlSelf->wasmetal_core__DOT___065215_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064663_))));
    vlSelf->wasmetal_core__DOT___069025_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069024_))));
    vlSelf->wasmetal_core__DOT___069072_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068877_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069071_))));
    vlSelf->wasmetal_core__DOT___065008_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065003_))));
    vlSelf->wasmetal_core__DOT___065138_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064334_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064357_))));
    vlSelf->wasmetal_core__DOT___065218_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064678_))));
    vlSelf->wasmetal_core__DOT___067883_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067882_))));
    vlSelf->wasmetal_core__DOT___065375_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064855_))));
    vlSelf->wasmetal_core__DOT___067943_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067942_))));
    vlSelf->wasmetal_core__DOT___065480_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065013_))));
    vlSelf->wasmetal_core__DOT___068006_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068005_))));
    vlSelf->wasmetal_core__DOT___064313_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064288_))));
    vlSelf->wasmetal_core__DOT___068059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067839_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068058_))));
    vlSelf->wasmetal_core__DOT___068994_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068993_))));
    vlSelf->wasmetal_core__DOT___064852_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064848_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064847_))));
    vlSelf->wasmetal_core__DOT___064651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064642_))));
    vlSelf->wasmetal_core__DOT___068134_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067882_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068133_))));
    vlSelf->wasmetal_core__DOT___065002_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064997_))));
    vlSelf->wasmetal_core__DOT___064846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064841_))));
    vlSelf->wasmetal_core__DOT___065136_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064311_))));
    vlSelf->wasmetal_core__DOT___068220_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068219_))));
    vlSelf->wasmetal_core__DOT___068186_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068185_))));
    vlSelf->wasmetal_core__DOT___068273_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068272_))));
    vlSelf->wasmetal_core__DOT___065213_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064642_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064649_))));
    vlSelf->wasmetal_core__DOT___068326_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068325_))));
    vlSelf->wasmetal_core__DOT___068927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068730_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068926_))));
    vlSelf->wasmetal_core__DOT___064665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064656_))));
    vlSelf->wasmetal_core__DOT___065368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064844_))));
    vlSelf->wasmetal_core__DOT___068382_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068185_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068381_))));
    vlSelf->wasmetal_core__DOT___064359_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064335_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064334_))));
    vlSelf->wasmetal_core__DOT___068878_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068877_))));
    vlSelf->wasmetal_core__DOT___065475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065000_))));
    vlSelf->wasmetal_core__DOT___068457_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068456_))));
    vlSelf->wasmetal_core__DOT___065212_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064657_))));
    vlSelf->wasmetal_core__DOT___064650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064649_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064648_))));
    vlSelf->wasmetal_core__DOT___065001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064999_))));
    vlSelf->wasmetal_core__DOT___065474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065004_))));
    vlSelf->wasmetal_core__DOT___065367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064848_))));
    vlSelf->wasmetal_core__DOT___064845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064843_))));
    vlSelf->wasmetal_core__DOT___065135_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064335_))));
    vlSelf->wasmetal_core__DOT___064312_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064311_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064310_))));
    vlSelf->wasmetal_core__DOT___068831_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068830_))));
    vlSelf->wasmetal_core__DOT___068634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068633_))));
    vlSelf->wasmetal_core__DOT___068731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068730_))));
    vlSelf->wasmetal_core__DOT___068520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068519_))));
    vlSelf->wasmetal_core__DOT___068781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068780_))));
    vlSelf->wasmetal_core__DOT___068584_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068583_))));
    vlSelf->wasmetal_core__DOT___068684_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068683_))));
    vlSelf->wasmetal_core__DOT___068502_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068501_))));
    vlSelf->wasmetal_core__DOT___070418_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b125__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___069123_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069939_))))));
    vlSelf->wasmetal_core__DOT___069124_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___069123_))));
    vlSelf->wasmetal_core__DOT___069899_ = (1U & (0xf040f0f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(wasmetal_core__DOT___069897_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b91__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069896_)))))));
    vlSelf->wasmetal_core__DOT___070369_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b121__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068930_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069857_))))));
    vlSelf->wasmetal_core__DOT___070090_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b101__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067886_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf8ff00ff00ff00ffULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))))));
    vlSelf->wasmetal_core__DOT___070317_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b117__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068734_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf7f00000000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))))));
    vlSelf->wasmetal_core__DOT___070163_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b106__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069521_))))));
    vlSelf->wasmetal_core__DOT___065148_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065145_))))))));
    vlSelf->wasmetal_core__DOT___065512_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065511_))));
    vlSelf->wasmetal_core__DOT___064633_ = (1U & (0x7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___064631_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___064630_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h078a1663__0))))));
    vlSelf->wasmetal_core__DOT___065985_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___065983_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___065982_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf6246da__0))))))));
    vlSelf->wasmetal_core__DOT___065533_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___065110_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___065531_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf6246da__0))))))));
    vlSelf->wasmetal_core__DOT___065113_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___065110_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064949_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064945_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064199_))))));
    vlSelf->wasmetal_core__DOT___064940_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064589_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064939_))));
    vlSelf->wasmetal_core__DOT___067421_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064130_)) 
                                                            << 1U))) 
                                                       << 2U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                      << 1U))));
    vlSelf->wasmetal_core__DOT___065244_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065243_))));
    vlSelf->wasmetal_core__DOT___064604_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064603_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___067633_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067515_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___065332_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065103_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065331_))));
    vlSelf->wasmetal_core__DOT___065443_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065243_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065442_))));
    vlSelf->wasmetal_core__DOT___064132_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064130_))));
    vlSelf->wasmetal_core__DOT___067549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067548_))));
    vlSelf->wasmetal_core__DOT___064196_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064188_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064187_))));
    vlSelf->wasmetal_core__DOT___065527_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065526_))));
    vlSelf->wasmetal_core__DOT___064963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064603_))));
    vlSelf->wasmetal_core__DOT___067516_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067515_))));
    vlSelf->wasmetal_core__DOT___064605_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064600_))));
    vlSelf->wasmetal_core__DOT___064811_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064120_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064131_))));
    vlSelf->wasmetal_core__DOT___067372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067227_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067371_))));
    vlSelf->wasmetal_core__DOT___067414_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067413_))));
    vlSelf->wasmetal_core__DOT___064619_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064615_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064614_))));
    vlSelf->wasmetal_core__DOT___065667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065442_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065666_))));
    vlSelf->wasmetal_core__DOT___064133_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064121_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064120_))));
    vlSelf->wasmetal_core__DOT___067274_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067273_))));
    vlSelf->wasmetal_core__DOT___065862_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065666_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065861_))));
    vlSelf->wasmetal_core__DOT___065745_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065526_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065744_))));
    vlSelf->wasmetal_core__DOT___064178_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064165_))));
    vlSelf->wasmetal_core__DOT___065978_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065744_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065977_))));
    vlSelf->wasmetal_core__DOT___064960_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064601_))));
    vlSelf->wasmetal_core__DOT___067228_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067227_))));
    vlSelf->wasmetal_core__DOT___064613_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064608_))));
    vlSelf->wasmetal_core__DOT___066041_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065861_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066040_))));
    vlSelf->wasmetal_core__DOT___064808_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064121_))));
    vlSelf->wasmetal_core__DOT___067118_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067009_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067117_))));
    vlSelf->wasmetal_core__DOT___064967_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064608_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064611_))));
    vlSelf->wasmetal_core__DOT___064815_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064165_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064176_))));
    vlSelf->wasmetal_core__DOT___064177_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064176_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064175_))));
    vlSelf->wasmetal_core__DOT___066239_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066040_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066238_))));
    vlSelf->wasmetal_core__DOT___066170_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065977_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066169_))));
    vlSelf->wasmetal_core__DOT___066348_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066169_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066347_))));
    vlSelf->wasmetal_core__DOT___064598_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064596_))));
    vlSelf->wasmetal_core__DOT___067057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066926_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___067056_))));
    vlSelf->wasmetal_core__DOT___064612_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064611_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064610_))));
    vlSelf->wasmetal_core__DOT___066448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066447_))));
    vlSelf->wasmetal_core__DOT___064961_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064594_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064597_))));
    vlSelf->wasmetal_core__DOT___064809_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064142_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064153_))));
    vlSelf->__VdfgTmp_he8a45048__0 = (((IData)(wasmetal_core__DOT___064153_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___064152_));
    vlSelf->wasmetal_core__DOT___066927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066736_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066926_))));
    vlSelf->wasmetal_core__DOT___066822_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066686_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066821_))));
    vlSelf->wasmetal_core__DOT___067010_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066821_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___067009_))));
    vlSelf->wasmetal_core__DOT___064599_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064595_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064594_))));
    vlSelf->wasmetal_core__DOT___064966_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064595_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064610_))));
    vlSelf->wasmetal_core__DOT___064814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064175_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064143_))));
    vlSelf->wasmetal_core__DOT___064154_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064143_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064142_))));
    vlSelf->wasmetal_core__DOT___066737_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066569_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066736_))));
    vlSelf->wasmetal_core__DOT___066570_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066447_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066569_))));
    vlSelf->wasmetal_core__DOT___066494_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066347_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066493_))));
    vlSelf->wasmetal_core__DOT___066687_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066493_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066686_))));
    vlSelf->wasmetal_core__DOT___065341_ = (1U & (IData)(
                                                         (0xcf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b6__05d) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___065339_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064944_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064199_)))))))));
    vlSelf->wasmetal_core__DOT___068320_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbab7bc7d__0))));
    vlSelf->__VdfgTmp_ha07de1bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5c1a0f86__0)))));
    vlSelf->wasmetal_core__DOT___067420_ = (1U & (IData)(
                                                         (0xbfbfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b30__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(wasmetal_core__DOT___067418_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (2U 
                                                                          & ((4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                               << 1U)) 
                                                                             << 1U))) 
                                                                        << 2U)) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                       << 1U))))))));
    vlSelf->wasmetal_core__DOT___068771_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcb391db2__0))));
    vlSelf->wasmetal_core__DOT___066692_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                   | (IData)(wasmetal_core__DOT___066691_))));
    vlSelf->__VdfgTmp_h5b5a3019__0 = (((IData)(wasmetal_core__DOT___066691_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                              << 1U))))))))))));
    vlSelf->__VdfgTmp_hbfa66a09__0 = (((IData)(vlSelf->wasmetal_core__DOT___067060_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7f00000000ULL 
                                                            >> (IData)(__VdfgTmp_h015651e9__0)))));
    vlSelf->__VdfgTmp_hc947a4ab__0 = (((IData)(wasmetal_core__DOT___065670_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff80ffff0000ffffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0)))));
    vlSelf->wasmetal_core__DOT___065672_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(wasmetal_core__DOT___065670_)))));
    vlSelf->wasmetal_core__DOT___067638_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbf20e6d__0))));
    vlSelf->wasmetal_core__DOT___069209_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6e14b62__0))));
    vlSelf->wasmetal_core__DOT___068000_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e38c4fc__0))));
    vlSelf->wasmetal_core__DOT___065253_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___065251_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___065250_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf6246da__0))))))));
    vlSelf->__VdfgTmp_h14a49668__0 = (((IData)(wasmetal_core__DOT___065250_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf8ff00ff00ff00ffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2e5f0189__0)))));
    vlSelf->__VdfgTmp_ha9829971__0 = (((IData)(vlSelf->wasmetal_core__DOT___066740_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf7f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h88f593f0__0)))));
    vlSelf->wasmetal_core__DOT___068574_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h744eac81__0))));
    vlSelf->__VdfgTmp_hc9c81b10__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf195595b__0)))));
    vlSelf->__VdfgTmp_h5362ea73__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_had7d0cfa__0)))));
    vlSelf->__VdfgTmp_hed3b8a65__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h20f14479__0)))));
    vlSelf->__VdfgTmp_hfc327362__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h484ca1c9__0)))));
    vlSelf->wasmetal_core__DOT___068452_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83912db0__0))));
    vlSelf->wasmetal_core__DOT___068529_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73bd2015__0))));
    vlSelf->__VdfgTmp_h9a4c9e67__0 = (((IData)(wasmetal_core__DOT___067122_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (3U 
                                                        & (- (IData)(
                                                                     (1U 
                                                                      & (4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                          << 1U))))))))));
    vlSelf->wasmetal_core__DOT___067123_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(wasmetal_core__DOT___067122_)))));
    vlSelf->__VdfgTmp_h5b846e26__0 = (((IData)(vlSelf->wasmetal_core__DOT___067375_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> (IData)(__VdfgTmp_h015651e9__0)))));
    vlSelf->__VdfgTmp_h3b4a166b__0 = (((IData)(vlSelf->wasmetal_core__DOT___065749_) 
                                       << 1U) | (1U 
                                                 & (0xf8ff00ffU 
                                                    >> (IData)(__VdfgTmp_h3f3712a8__0))));
    vlSelf->wasmetal_core__DOT___064806_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064796_))))))))));
    vlSelf->wasmetal_core__DOT___065104_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065103_))));
    vlSelf->wasmetal_core__DOT___064556_ = (1U & (0xcfaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                              << 1U))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064072_))))));
    vlSelf->__VdfgTmp_h25573523__0 = (((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                       << 5U) | ((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                 << 4U));
    vlSelf->wasmetal_core__DOT___066157_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064986_ = (1U & (IData)(
                                                         (0x1fff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                              << 4U)))));
    vlSelf->wasmetal_core__DOT___065098_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (- (IData)(
                                                                       (1U 
                                                                        & (4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                            << 1U)))))))))));
    vlSelf->__VdfgTmp_ha31eaa90__0 = ((2U & ((1U >> 
                                              (3U & 
                                               (- (IData)(
                                                          (1U 
                                                           & (4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                               << 1U))))))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                << 1U))));
    vlSelf->wasmetal_core__DOT___064082_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064072_))));
    vlSelf->wasmetal_core__DOT___064051_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064050_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064050_))));
    vlSelf->wasmetal_core__DOT___064052_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064049_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066249_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064049_))));
    vlSelf->wasmetal_core__DOT___064074_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064071_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___064778_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064071_))));
    vlSelf->wasmetal_core__DOT___064070_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064067_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___064979_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064067_))));
    vlSelf->wasmetal_core__DOT___064047_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064046_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066150_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064046_))));
    vlSelf->wasmetal_core__DOT___064069_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064068_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065089_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064068_))));
    vlSelf->wasmetal_core__DOT___064048_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064045_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066053_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064045_))));
    vlSelf->wasmetal_core__DOT___064060_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064057_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065267_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064057_))));
    vlSelf->wasmetal_core__DOT___064041_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064040_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065987_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064040_))));
    vlSelf->wasmetal_core__DOT___064042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064039_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065872_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064039_))));
    vlSelf->wasmetal_core__DOT___064059_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064058_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065354_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064058_))));
    vlSelf->wasmetal_core__DOT___064064_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065461_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064061_))));
    vlSelf->wasmetal_core__DOT___064037_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064036_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065774_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064036_))));
    vlSelf->wasmetal_core__DOT___064038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064035_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065676_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064035_))));
    vlSelf->wasmetal_core__DOT___064063_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064062_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065535_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064062_))));
    vlSelf->wasmetal_core__DOT___064984_ = (1U & (IData)(
                                                         (0xe000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___065359_ = (1U & (0xe0000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                      << 2U))));
    vlSelf->wasmetal_core__DOT___066155_ = (1U & (0xfe000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                      << 3U))));
    vlSelf->wasmetal_core__DOT___066058_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | ((4U 
                                                       & ((0x80U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064543_)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064543_)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->wasmetal_core__DOT___064553_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 3U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->wasmetal_core__DOT___066993_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)))));
    vlSelf->__VdfgTmp_hb1b9a71b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                  << 1U)) 
                                                                << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))))));
    vlSelf->wasmetal_core__DOT___065467_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                              << 3U)))));
    vlSelf->wasmetal_core__DOT___065684_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                       << 2U) 
                                                      | (1U 
                                                         & (0x80U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064543_)))))));
    vlSelf->wasmetal_core__DOT___065877_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                              << 4U)))));
    vlSelf->__VdfgTmp_hc1dcc953__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064543_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                               << 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___065541_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->wasmetal_core__DOT___065993_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (- (IData)(
                                                                       (1U 
                                                                        & (8U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064543_)))))))))));
    vlSelf->wasmetal_core__DOT___064786_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->__VdfgTmp_hb4f24f30__0 = ((2U & ((0x80U 
                                              >> (IData)(vlSelf->wasmetal_core__DOT___064543_)) 
                                             << 1U)) 
                                      | (1U & (8U >> (IData)(vlSelf->wasmetal_core__DOT___064543_))));
    vlSelf->__VdfgTmp_h01d11789__0 = (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                       << 4U) | (0xfU 
                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O), 3U)));
    vlSelf->__VdfgTmp_h925d74fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                    << 4U)));
    vlSelf->wasmetal_core__DOT___064544_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064543_))));
    vlSelf->wasmetal_core__DOT___064829_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x8fU 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064241_)))));
    vlSelf->wasmetal_core__DOT___064226_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064225_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___064821_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064225_))));
    vlSelf->wasmetal_core__DOT___064235_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064234_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065546_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064234_))));
    vlSelf->wasmetal_core__DOT___064236_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064233_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065452_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064233_))));
    vlSelf->wasmetal_core__DOT___064223_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064220_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___064950_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064220_))));
    vlSelf->wasmetal_core__DOT___064232_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064229_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065255_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064229_))));
    vlSelf->wasmetal_core__DOT___064231_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064230_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065343_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064230_))));
    vlSelf->wasmetal_core__DOT___064222_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065120_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064221_))));
    vlSelf->wasmetal_core__DOT___064582_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((~ 
                                                           (1U 
                                                            | (2U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                  << 1U)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x80U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064570_)))))));
    vlSelf->__VdfgTmp_h82d7bb11__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xff7f80ffffffffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                 << 3U))))))));
    vlSelf->wasmetal_core__DOT___064956_ = (1U & (0x80000000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064570_))))))));
    vlSelf->wasmetal_core__DOT___065260_ = (1U & (0xe000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x80U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064570_)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064570_))))))));
    vlSelf->__VdfgTmp_hd785ede8__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0xe7ffU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (~ 
                                                            (1U 
                                                             | (2U 
                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                   << 1U))))))))));
    vlSelf->__VdfgTmp_h4bfb58f6__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xff07f8ffffffffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                 << 3U))))))));
    vlSelf->wasmetal_core__DOT___065457_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                               << 4U) 
                                                              | ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                                 << 3U))))));
    vlSelf->__VdfgTmp_hd652459e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 4U)) 
                                                 | (0xcU 
                                                    & ((~ 
                                                        (1U 
                                                         | (2U 
                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                               << 1U)))) 
                                                       << 2U))));
    vlSelf->__VdfgTmp_h56ef19dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 4U)) 
                                                 | ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 3U)));
    vlSelf->wasmetal_core__DOT___066806_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___065972_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (~ 
                                                         (1U 
                                                          | (2U 
                                                             & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                << 1U))))))));
    vlSelf->__VdfgTmp_h1427a567__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064570_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x8fU 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                             << 2U))))))));
    vlSelf->wasmetal_core__DOT___064827_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064570_))))))));
    vlSelf->wasmetal_core__DOT___065348_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064570_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064570_))))));
    vlSelf->__VdfgTmp_h95637c8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                       << 4U) | (0xcU 
                                                 & ((~ 
                                                     (1U 
                                                      | (2U 
                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                            << 1U)))) 
                                                    << 2U)));
    vlSelf->__VdfgTmp_h1578a070__0 = (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                       << 4U) | ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                 << 3U));
    vlSelf->wasmetal_core__DOT___064571_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064570_))));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063620_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___063628_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___063636_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___063644_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029593_));
    vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030669_));
    vlSelf->wasmetal_core__DOT___063554_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128413___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032007_));
    vlSelf->wasmetal_core__DOT____Vcellout___134157___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036775_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036774_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036773_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036772_)))) 
           ^ (((IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036739_)))));
    vlSelf->wasmetal_core__DOT___036743_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036775_)
                                                   ? (IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd2526c88__0))));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031346_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031313_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))) {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O));
    } else {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___062917_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062916_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062915_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062928_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062927_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062926_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062939_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062938_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062937_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062950_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062949_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062948_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
}
