#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__11(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__11\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___052008_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b117__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b111__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b110__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b105__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b104__05d)))))))));
    vlSelf->wasmetal_core__DOT___052025_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b95__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b94__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b93__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b92__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b89__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b88__05d)))))))));
    vlSelf->__VdfgTmp_h6b18dcfd__0 = (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b33__05d));
    vlSelf->wasmetal_core__DOT___052016_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b44__05d))));
    vlSelf->wasmetal_core__DOT___052013_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b49__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___052018_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b53__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b40__05d)))))))));
    vlSelf->__VdfgTmp_hb8b9c084__0 = (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b36__05d));
    vlSelf->wasmetal_core__DOT___052017_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b61__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___064084_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b26__05d))));
    vlSelf->wasmetal_core__DOT___064083_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b24__05d))));
    vlSelf->wasmetal_core__DOT___065561_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b21__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b23__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b22__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___064085_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b21__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b23__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b22__05d))))));
    vlSelf->wasmetal_core__DOT___064095_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d))));
    vlSelf->__VdfgTmp_h835050f4__0 = (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b0__05d));
    vlSelf->__VdfgTmp_h49b76e08__0 = (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d));
    vlSelf->wasmetal_core__DOT___064090_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b10__05d))));
    vlSelf->wasmetal_core__DOT___064089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b8__05d))));
    vlSelf->wasmetal_core__DOT___064088_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b7__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___065552_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b6__05d))));
    vlSelf->wasmetal_core__DOT___052003_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___029246_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d))));
    vlSelf->wasmetal_core__DOT___026190_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035108_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d))));
    vlSelf->wasmetal_core__DOT___035107_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d))));
    vlSelf->wasmetal_core__DOT___042484_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b31__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___035105_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d))));
    vlSelf->wasmetal_core__DOT___035104_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d))));
    vlSelf->wasmetal_core__DOT___035103_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d))));
    vlSelf->wasmetal_core__DOT___042504_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___035102_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d))));
    vlSelf->wasmetal_core__DOT___035101_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d))));
    vlSelf->wasmetal_core__DOT___035100_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d))));
    vlSelf->wasmetal_core__DOT___042503_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b25__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___035099_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d))));
    vlSelf->wasmetal_core__DOT___035098_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d))));
    vlSelf->wasmetal_core__DOT___035097_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d))));
    vlSelf->wasmetal_core__DOT___042502_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___035096_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d))));
    vlSelf->wasmetal_core__DOT___035094_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d))));
    vlSelf->wasmetal_core__DOT___035093_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d))));
    vlSelf->wasmetal_core__DOT___042501_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___035092_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d))));
    vlSelf->wasmetal_core__DOT___035091_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d))));
    vlSelf->wasmetal_core__DOT___035090_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d))));
    vlSelf->wasmetal_core__DOT___045953_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___045965_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___029243_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d))));
    vlSelf->wasmetal_core__DOT___026187_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d))));
    vlSelf->wasmetal_core__DOT___042500_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___035089_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d))));
    vlSelf->wasmetal_core__DOT___035088_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d))));
    vlSelf->wasmetal_core__DOT___035087_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d))));
    vlSelf->wasmetal_core__DOT___042499_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b13__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___035086_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128330___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d))));
    vlSelf->wasmetal_core__DOT___035085_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d))));
    vlSelf->wasmetal_core__DOT___035147_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d))));
    vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___042498_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___035146_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d))));
    vlSelf->wasmetal_core__DOT___035145_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d))));
    vlSelf->wasmetal_core__DOT___052012_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___035144_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d))));
    vlSelf->wasmetal_core__DOT___042497_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___035139_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d))));
    vlSelf->wasmetal_core__DOT___035128_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035117_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d))));
    vlSelf->wasmetal_core__DOT___042494_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___035106_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d))));
    vlSelf->__VdfgTmp_hff2c11ba__0 = (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d));
    vlSelf->wasmetal_core__DOT___029232_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d))));
    vlSelf->wasmetal_core__DOT___026176_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d))));
    vlSelf->wasmetal_core__DOT___052020_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___052023_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d));
    vlSelf->wasmetal_core__DOT___045951_ = (1U & (0x7150U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___045963_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___029221_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d))));
    vlSelf->wasmetal_core__DOT___026165_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128343___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d))));
    vlSelf->wasmetal_core__DOT___053337_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d))));
    vlSelf->__VdfgTmp_h347304aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d));
    vlSelf->wasmetal_core__DOT___044145_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___044144_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___044131_ = (1U & (0xfffffffeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->__VdfgTmp_h872406d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b255__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b254__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b253__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b252__05d))));
    vlSelf->__VdfgTmp_h69f02119__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b251__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b250__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b249__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b248__05d))));
    vlSelf->__VdfgTmp_hfbc99fdd__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b239__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b238__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b237__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b236__05d))));
    vlSelf->__VdfgTmp_hee5ebf6d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b227__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b226__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b225__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b224__05d))));
    vlSelf->__VdfgTmp_h3ab327aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b191__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b190__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b189__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b188__05d))));
    vlSelf->__VdfgTmp_h210ef7f0__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b187__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b186__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b185__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b184__05d))));
    vlSelf->__VdfgTmp_hd8834afb__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b183__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b182__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b181__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b180__05d))));
    vlSelf->__VdfgTmp_h8901ecaf__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b143__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b142__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b141__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b140__05d))));
    vlSelf->__VdfgTmp_h18020398__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b135__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b134__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b133__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b132__05d))));
    vlSelf->__VdfgTmp_h768acb46__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b127__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b126__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b125__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b124__05d))));
    vlSelf->__VdfgTmp_h5f14f02d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b123__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b122__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b121__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b120__05d))));
    vlSelf->__VdfgTmp_h5ad4ffc8__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b111__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b110__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b109__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b108__05d))));
    vlSelf->__VdfgTmp_h40722c77__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b107__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b106__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b105__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b104__05d))));
    vlSelf->__VdfgTmp_h236ea405__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b247__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b246__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b245__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b244__05d))));
    vlSelf->__VdfgTmp_h38f4df47__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b243__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b242__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b241__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b240__05d))));
    vlSelf->__VdfgTmp_hcafe333f__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b235__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b234__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b233__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b232__05d))));
    vlSelf->__VdfgTmp_h7d1b01d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b231__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b230__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b229__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b228__05d))));
    vlSelf->__VdfgTmp_h51560923__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b139__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b138__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b137__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b136__05d))));
    vlSelf->__VdfgTmp_h0a192e7e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b131__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b130__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b129__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b128__05d))));
    vlSelf->__VdfgTmp_h8555f3e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b119__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b118__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b117__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b116__05d))));
    vlSelf->__VdfgTmp_h1157f8a3__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b115__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b114__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b113__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b112__05d))));
    vlSelf->__VdfgTmp_h7982dd07__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b103__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b102__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b101__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b100__05d))));
    vlSelf->__VdfgTmp_h6ec6b47d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b99__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b98__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b97__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b96__05d))));
    vlSelf->__VdfgTmp_h3885fdb9__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b223__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b222__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b221__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b220__05d))));
    vlSelf->__VdfgTmp_hcb35a5f1__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b219__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b218__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b217__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b216__05d))));
    vlSelf->__VdfgTmp_h6d99021a__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b207__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b206__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b205__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b204__05d))));
    vlSelf->__VdfgTmp_hf4526f03__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b199__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b198__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b197__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b196__05d))));
    vlSelf->__VdfgTmp_hc0d4cc40__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b179__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b178__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b177__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b176__05d))));
    vlSelf->__VdfgTmp_h6286ac7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b175__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b174__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b173__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b172__05d))));
    vlSelf->__VdfgTmp_hc66bf11b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b163__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b162__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b161__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b160__05d))));
    vlSelf->__VdfgTmp_h3b58ae94__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b159__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b158__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b157__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b156__05d))));
    vlSelf->__VdfgTmp_h51b306d7__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b155__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b154__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b153__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b152__05d))));
    vlSelf->__VdfgTmp_h28b8e598__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b147__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b146__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b145__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b144__05d))));
    vlSelf->__VdfgTmp_h71547b26__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b95__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b94__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b93__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b92__05d))));
    vlSelf->__VdfgTmp_h947ab6b4__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b91__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b90__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b89__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b88__05d))));
    vlSelf->__VdfgTmp_h43fa682b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b79__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b78__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b77__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b76__05d))));
    vlSelf->__VdfgTmp_hbdf51c76__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b71__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b70__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b69__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b68__05d))));
    vlSelf->__VdfgTmp_h0b1aa625__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b67__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b66__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b65__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b64__05d))));
    vlSelf->__VdfgTmp_hc408f28d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b215__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b214__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b213__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b212__05d))));
    vlSelf->__VdfgTmp_h1dd2dede__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b211__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b210__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b209__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b208__05d))));
    vlSelf->__VdfgTmp_h1968304e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b203__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b202__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b201__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b200__05d))));
    vlSelf->__VdfgTmp_hc7c61c07__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b195__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b194__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b193__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b192__05d))));
    vlSelf->__VdfgTmp_h47e0de34__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b171__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b170__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b169__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b168__05d))));
    vlSelf->__VdfgTmp_h29fa0da7__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b167__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b166__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b165__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b164__05d))));
    vlSelf->__VdfgTmp_hef41fa97__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b87__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b86__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b85__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b84__05d))));
    vlSelf->__VdfgTmp_h8b69f170__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b83__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b82__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b81__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b80__05d))));
    vlSelf->__VdfgTmp_h5864b2ba__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b151__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b150__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b149__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b148__05d))));
    vlSelf->__VdfgTmp_h0a9f8029__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b75__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b74__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b73__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b72__05d))));
    vlSelf->__VdfgTmp_hf75b3db8__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b63__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b62__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b61__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b60__05d))));
    vlSelf->__VdfgTmp_h05fef25b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b59__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b58__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b57__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b56__05d))));
    vlSelf->__VdfgTmp_h5ee84e09__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b55__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b54__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b53__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b52__05d))));
    vlSelf->__VdfgTmp_hac7d774c__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b30__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b29__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b28__05d))));
    vlSelf->__VdfgTmp_h35252d63__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b27__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b26__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b25__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b24__05d))));
    vlSelf->__VdfgTmp_h9adc8e2b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b19__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b18__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b17__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b16__05d))));
    vlSelf->__VdfgTmp_h6727edf3__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b51__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b50__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b49__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b48__05d))));
    vlSelf->__VdfgTmp_hc9d2c329__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b47__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b46__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b45__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b44__05d))));
    vlSelf->__VdfgTmp_h745b6463__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b39__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b38__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b37__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b36__05d))));
    vlSelf->__VdfgTmp_h41f0b476__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b35__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b34__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b33__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b32__05d))));
    vlSelf->__VdfgTmp_hefac84ff__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b23__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b22__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b21__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b20__05d))));
    vlSelf->__VdfgTmp_h5b3781b6__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b15__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b14__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b13__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b12__05d))));
    vlSelf->__VdfgTmp_h4fc63e3e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b11__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b10__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b9__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b8__05d))));
    vlSelf->__VdfgTmp_hb13e555e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b7__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b6__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b5__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b4__05d))));
    vlSelf->__VdfgTmp_hf782be94__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b43__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b42__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b41__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b40__05d))));
    vlSelf->__VdfgTmp_haf724a20__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b3__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b2__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b1__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b0__05d))));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02etrap__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b124__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b126__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b120__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_reference__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_kind__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination_index__05b30__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019773_) {
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060653_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xfff40000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060648_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___060220_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___017945_))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02etrap__05b0__05d 
                = (1U & (0x1f000000U >> (((IData)(vlSelf->wasmetal_core__DOT___058549_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x3030f0f005500ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___017947_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xf0ffbbbbU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___048705_)))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060569_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060559_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfdfU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060564_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O) 
                                                                               >> 1U))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060555_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060545_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfdfU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060550_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d 
                = (1U & (IData)((0xffffffba30303030ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060541_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060540_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060531_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xf400U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((0x80U 
                                                                        >> 
                                                                        (4U 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                                          >> 2U)) 
                                                                      | (1U 
                                                                         & (0xff4fffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060527_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060517_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfdfU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060522_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134185___O) 
                                                                               >> 2U))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060513_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060503_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfdfU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060508_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134185___O) 
                                                                               >> 1U))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060499_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060489_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfdfU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060494_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134185___O))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060617_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060607_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x1fff00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060612_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060611_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060573_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfff0ff1100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058689_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060578_))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060586_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060576_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x1fff00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060582_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060581_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060573_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfff0ff1100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058689_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060578_))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d 
                = (1U & (IData)((0xffff10ffULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059256_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059255_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059254_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((1U 
                                                                     & (IData)(
                                                                               (0xfff1ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059220_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059219_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059218_)))))))))
                                                                     ? 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                      ? 
                                                                     (0xa02U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___016505_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016502_)))))
                                                                      : (IData)(
                                                                                (0x303000000020ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016505_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016502_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016501_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))))
                                                                     : 
                                                                    (0x31U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___016505_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hb0235e8a__0)))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xd00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(
                                                                                (0xf044000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017532_)))))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059218_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (0xb0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059355_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059354_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffaa03030303ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017951_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017953_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059338_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059339_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (0xfefU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xdU 
                                                                              >> 
                                                                              ((8U 
                                                                                & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127469___O) 
                                                                                >> 1U))))))))) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                                                 ? 
                                                                                (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_)))
                                                                                 : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059339_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___059338_)))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                ? 
                                                               (0xa02U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017953_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017952_)))))
                                                                : (IData)(
                                                                          (0x303000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017953_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017952_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017951_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))))
                                                               : 
                                                              (0x31U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017953_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb0235e8a__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x70U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059344_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059343_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xb0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h450b6bb7__0)))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d 
                = (1U & (0xff4fU >> (((IData)(vlSelf->wasmetal_core__DOT___059403_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___059402_) 
                                                 << 3U) 
                                                | ((4U 
                                                    & ((0xcfaf0000U 
                                                        >> 
                                                        ((0x10U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                             << 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                        ? 
                                                                       (0xc0c5U 
                                                                        >> 
                                                                        ((8U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h8f31d0f1__0)) 
                                                                             << 3U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_he6069ba9__0))))
                                                                        : 
                                                                       (0xc0c5U 
                                                                        >> 
                                                                        ((8U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h8f31d0f1__0)) 
                                                                             << 3U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_he6069ba9__0))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                         ? 
                                                                        (0xc0c5U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((8U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9bd72b18__0))))
                                                                         : 
                                                                        (0xc0c5U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((8U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9bd72b18__0))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xff8f0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___059392_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058941_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___059248_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (0xfefU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xdU 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127469___O) 
                                                                                >> 2U))))))))) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                                                 ? 
                                                                                (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005716_)))
                                                                                 : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_))))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059390_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___059389_)))))))
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                              ? 
                                                             (0xa02U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___018103_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___018102_)))))
                                                              : (IData)(
                                                                        (0x303000000020ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018103_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018102_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))))
                                                             : 
                                                            (0x31U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb0235e8a__0)))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d 
                = (1U & (IData)((0xfffffffff0f0f020ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___059447_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059446_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___059445_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (0xfefU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xdU 
                                                                              >> 
                                                                              ((8U 
                                                                                & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005935_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7e209046__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127469___O) 
                                                                                >> 3U))))))))) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                                                 ? 
                                                                                (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005935_)))
                                                                                 : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059432_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___059431_)))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                ? 
                                                               (0xa02U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018195_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018194_)))))
                                                                : (IData)(
                                                                          (0x303000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___018195_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018194_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018193_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))))
                                                               : 
                                                              (0x31U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018195_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb0235e8a__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xff8f0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059434_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058952_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___059248_)))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d 
                = (1U & (IData)((0xfefefefeffffff00ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059484_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xef0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059473_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((0xff4fffU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x3050f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h8b14a16b__0))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xf0f335500000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf100U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha1b196f5__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f03355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcdadba0d__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0f03355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcdadba0d__0))))))))))) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             & ((1U 
                                                                 & (0xb0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))
                                                                 ? (IData)(
                                                                           (0xfff4ffffff00ffffULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018303_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018302_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018301_))))))))
                                                                 : 
                                                                (1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___018304_)))) 
                                                            & (IData)(
                                                                      (0xfffffff4ffff4444ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018258_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018257_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfefU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xdU 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005738_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5774c299__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                                                 ? 
                                                                                (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005738_)))
                                                                                 : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h14645516__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059464_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013722_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & (IData)(
                                                                                (0xc0f0ddff00005555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3835a6cf__0))))))))))))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___018266_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___016506_))
                                                                                 : (IData)(
                                                                                (0xffffff11ffffff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018265_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6c2c06b__0))))))))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060023_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060022_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xbbf0f0U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018867_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___059992_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018869_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xf0f0f0f0f0f0f01ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___060008_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060007_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059992_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018869_)
                                                                ? (IData)(
                                                                          (0xf000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018867_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                : 
                                                               (0xc04U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018868_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018867_))))))
                                                               : 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018869_)
                                                                ? 
                                                               (1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                                : 
                                                               (1U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x4f00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134162___O) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0xb0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d 
                = (1U & (IData)((0xffff10ffffff0000ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060048_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060047_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xd0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((0xb0U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134162___O) 
                                                                        >> 1U))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((1U 
                                                                & (IData)(
                                                                          (0xf0f0f0f0f0f0f01ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___060038_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060037_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060024_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___018880_)
                                                                 ? (IData)(
                                                                           (0xf000000020ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018879_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018878_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                 : 
                                                                (0xc04U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018879_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___018878_))))))
                                                                : 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___018880_)
                                                                 ? 
                                                                (1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                                 : 
                                                                (1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060073_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060072_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xbbf0f0U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018897_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060049_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018899_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xf0f0f0f0f0f0f01ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___060062_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060061_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060049_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018899_)
                                                                ? (IData)(
                                                                          (0xf000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018898_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018897_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                : 
                                                               (0xc04U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018898_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018897_))))))
                                                               : 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018899_)
                                                                ? 
                                                               (1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                                : 
                                                               (1U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x4f00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134162___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & (0xb0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d 
                = (1U & (IData)((0xffff10ffffff0000ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060095_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060094_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xd0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((0xb0U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134162___O) 
                                                                        >> 3U))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((1U 
                                                                & (IData)(
                                                                          (0xf0f0f0f0f0f0f01ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___060087_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060086_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060074_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___018915_)
                                                                 ? (IData)(
                                                                           (0xf000000020ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018914_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018913_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                 : 
                                                                (0xc04U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018914_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___018913_))))))
                                                                : 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___018915_)
                                                                 ? 
                                                                (1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                                 : 
                                                                (1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060180_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060179_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___060178_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4f00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134163___O) 
                                                                      >> 1U)) 
                                                                  | (1U 
                                                                     & (0xb0U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & (((IData)(vlSelf->wasmetal_core__DOT___018964_)
                                                                        ? 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                                         ? (IData)(
                                                                                (0xee00000f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018963_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018633_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018962_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018629_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016534_))))))))
                                                                         : 
                                                                        (1U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___018963_)))
                                                                        : 
                                                                       (1U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___018963_))) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___018382_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xfff4ff00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060164_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060163_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060162_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he1a5145e__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060205_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060204_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xf0f00077U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & (((~ (IData)(vlSelf->wasmetal_core__DOT___018984_)) 
                                                                       & (IData)(
                                                                                (0xf0fffdfff0fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018677_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018985_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h787c74f0__0)))))))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hbba2540d__0))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xf0fbbbbff00ff00ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                        << 5U) 
                                                                       | ((0x10U 
                                                                           & ((0xff4fffU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060196_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xff4f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018985_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0c4afb11__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfa9cb9e8__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018178_)))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d 
                = (1U & (0xfefe00ffU >> ((0x10U & (
                                                   (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___059560_) 
                                             << 3U) 
                                            | ((4U 
                                                & ((IData)(
                                                           (0xf0f335500000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                            ? 
                                                                           (0xc0c5U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0d37526f__0))))
                                                                            : 
                                                                           (0xc0c5U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0d37526f__0))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((0xf0f000ddU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hd5e7a9c4__0))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xf0f000ddU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd5e7a9c4__0))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((IData)(
                                                              (0xff4f00000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059552_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059551_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___059537_)))))))) 
                                                      << 1U)) 
                                                  | ((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___016504_)
                                                         ? 
                                                        (2U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___018381_))
                                                         : (IData)(
                                                                   (0xffffff00fffffff4ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018381_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018380_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0xfefU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059548_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059542_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xffff30f08aaa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x3f1b0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018082_)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059535_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059536_)))))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(
                                                                                (0xfff1ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059543_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059542_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013719_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & (IData)(
                                                                                (0xc0f0ddff00005555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3835a6cf__0))))))))))))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___018390_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___016506_))
                                                                                 : (IData)(
                                                                                (0xffffff11ffffff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86684a6a__0))))))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060257_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060256_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                           & (IData)(
                                                                     (0xffffff00fffffff4ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019043_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019042_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hde7231b3__0))))))) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT___018964_)
                                                                       ? 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                                        ? (IData)(
                                                                                (0xbb00000f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019050_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b565375__0)))))
                                                                        : 
                                                                       (1U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___019050_)))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___019050_)))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059717_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059716_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___018318_)
                                                            ? 
                                                           (0xeU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___018585_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))
                                                            : 
                                                           (0xbU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h4db98f39__0))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xfff4ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059705_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4db98f39__0)))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                ? 
                                                               (0xa02U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018587_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018586_)))))
                                                                : (IData)(
                                                                          (0x303000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___018587_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018586_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018585_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))))
                                                               : 
                                                              (0x31U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018587_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb0235e8a__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xff8f0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059708_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018613_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (0xb0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d 
                = (1U & (IData)((0x4fff4f4f00ff0000ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                         << 4U) | (
                                                   (8U 
                                                    & ((0xbU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb22cad__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff0f8808ff0fff0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060286_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060285_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff00bbbb0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127518___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___019044_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                 ? 
                                                                (0xd0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019085_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hbe486143__0)))
                                                                 : (IData)(
                                                                           (0xb0b000b00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019085_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebb22cad__0)))))))
                                                                : 
                                                               (0xdU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbe486143__0))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059769_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059768_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___018318_)
                                                            ? 
                                                           (0xeU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___018663_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018665_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))
                                                            : 
                                                           (0xbU 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha2122f26__0))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___018382_)) 
                                                                  & (IData)(
                                                                            (0xffff00fffffff4ffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018685_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2122f26__0))))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                ? 
                                                               (0xa02U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018664_)))))
                                                                : (IData)(
                                                                          (0x303000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___018665_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018664_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018663_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))))
                                                               : 
                                                              (0x31U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018665_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb0235e8a__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xff8f0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059760_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018683_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (0xb0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d 
                = (1U & ((1U & (4U >> ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                              << 1U)) 
                                       | (1U & (IData)(
                                                       (0xf0f335500000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                        ? 
                                                                       (0xc0c5U 
                                                                        >> 
                                                                        ((8U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_he7bb7b74__0)) 
                                                                             << 3U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h3a7e26d8__0))))
                                                                        : 
                                                                       (0xc0c5U 
                                                                        >> 
                                                                        ((8U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_he7bb7b74__0)) 
                                                                             << 3U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h3a7e26d8__0))))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((0xf0f000ddU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hd560ff4d__0))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (0xf0f000ddU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                             << 4U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_hd560ff4d__0)))))))))))))))
                          ? (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                              & (IData)((0xf4ff00ffULL 
                                         >> (((IData)(vlSelf->wasmetal_core__DOT___018434_) 
                                              << 5U) 
                                             | ((0x10U 
                                                 & ((0xff4fffU 
                                                     >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                    << 4U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___018432_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h69485153__0)))))))
                              ? (IData)(vlSelf->wasmetal_core__DOT___018418_)
                              : (IData)((0x20200020f0f000f0ULL 
                                         >> (((IData)(vlSelf->wasmetal_core__DOT___018413_) 
                                              << 5U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___018412_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___018411_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x70U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xe00ff00ff00ffULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & ((0xb0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                                << 5U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059586_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018428_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018427_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017463_)))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016504_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((IData)(
                                                                      (0xf0ff11ff00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___059574_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059568_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013658_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013658_)))))))))))))) 
                                                              & (IData)(
                                                                        (0xff00ff00fff0fffdULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018424_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018423_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heeceee13__0)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f0f0f0f0f0f02ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___059585_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059584_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xdddf5d55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059580_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018080_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005875_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_)))))))))))))))))
                          : (IData)(vlSelf->wasmetal_core__DOT___018418_)));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d 
                = (1U & ((0xf400U >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h90e4968a__0))) 
                         | (IData)((0xff00ff00ff00e000ULL 
                                    >> (((IData)(vlSelf->wasmetal_core__DOT___019113_) 
                                         << 5U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019112_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xfff4ff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060318_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90e4968a__0)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT___018964_)
                                                                          ? (IData)(
                                                                                (0xb00ff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019120_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea1c7f12__0))))))
                                                                          : 
                                                                         (1U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___019120_))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d 
                = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___018318_)
                              ? ((~ (4U >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))) 
                                 & (0xf0fdU >> (((IData)(vlSelf->wasmetal_core__DOT___018511_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((0xe00U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he2b184a7__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h97bdc512__0))))))
                              : ((~ (4U >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))) 
                                 & (2U >> (IData)(vlSelf->wasmetal_core__DOT___018510_))))) 
                         & ((1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                           << 1U) | 
                                          (1U & (IData)(
                                                        (0x1fff00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059636_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((0xb0U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059628_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (0x10U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_heca3be9d__0))))))))))))))
                             ? (IData)((0xfff0fff0fffdfffULL 
                                        >> (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                             << 5U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___018481_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___018480_) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((0xfdfU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((0xe00U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he2b184a7__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h97bdc512__0))))) 
                                                         << 2U)) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0xff00fff4ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018511_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((0xe00U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he2b184a7__0)) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018489_)))))))) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0x454545cf00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059648_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059647_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x33035505ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O) 
                                                                                >> 1U))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_))))))))))))))))
                             : (1U >> (IData)(vlSelf->wasmetal_core__DOT___018480_)))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d 
                = (1U & (IData)((0xb0b0ffff00ff00ffULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059625_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059624_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1fff00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059611_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xb0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h75b7aca4__0)))))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018441_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((1U 
                                                                & (IData)(
                                                                          (0xf0ff11ff00000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___059602_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059596_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006092_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013666_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013666_)))))))))))))))
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___018444_)
                                                                 ? 
                                                                (0xbU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h4740201c__0))))
                                                                 : (IData)(
                                                                           (0x1011ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018443_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018442_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6ad4dda__0))))))))
                                                                : 
                                                               (0xbU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4740201c__0)))))))))))));
            if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)))) {
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d 
                    = (1U & (0xfeU >> ((4U & ((0x3500U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3d6ee6a7__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3d6ee6a7__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058432_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128863___O) 
                                                                                >> 1U)))))))))))))))))))) 
                                              << 2U)) 
                                       | ((2U & ((IData)(
                                                         (0xf0f0fdf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059516_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059515_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11ff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcd2a3fe0__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___016506_)) 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT___018055_)
                                                                                ? 
                                                                               (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___018339_))
                                                                                : (IData)(
                                                                                (0xfff3fff5fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018339_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2800fdf__0)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059511_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x3f1b0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018082_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & (IData)(
                                                                                (0x5f3ff00003333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))))))))))))))))))) 
                                                 << 1U)) 
                                          | (1U & (0x10U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (((0xbU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___058964_)))) 
                                                            & (IData)(
                                                                      (0xff00ffcfffafffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___018338_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0bbf0cf__0)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0x11ff0fff00000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___059517_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                          << 4U) 
                                                                         | ((8U 
                                                                             & ((0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                                << 3U)) 
                                                                            | (IData)(vlSelf->__VdfgTmp_hcd2a3fe0__0)))))))))))))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d 
                    = (1U & (IData)((0xefefffef0f0fff0fULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((0x7077U 
                                             >> (IData)(vlSelf->__VdfgTmp_ha04c1ce6__0)) 
                                            << 4U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                              << 3U) 
                                             | ((4U 
                                                 & ((IData)(
                                                            (0xf00bb00ff00ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060410_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019178_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058639_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))) 
                                                    << 2U)) 
                                                | ((((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                         ? 
                                                        (0xeU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___019180_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___019179_)))
                                                         : (IData)(
                                                                   (0xffffffffffff8f88ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019180_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019179_) 
                                                                         << 4U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha04c1ce6__0))))))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf8880000U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019178_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___057776_)))))))))))))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d 
                    = (1U & (IData)((0xfff4fffffff4fff4ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                          << 5U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___019022_) 
                                           << 4U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019021_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((0x10U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((IData)(
                                                                 (0xff00bb00ff000f00ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128884___O) 
                                                                                << 2U)) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h718e5977__0))))))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0xf0f0335500000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058341_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127517___O))))))))))))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x45454545454545cfULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060241_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060240_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060239_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & (((IData)(vlSelf->wasmetal_core__DOT___018964_)
                                                                                 ? (IData)(
                                                                                (0xee000f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019037_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4809aef4__0))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___019037_))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___019044_)))))))))))))))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d 
                    = (1U & (IData)((0xfff4fffffff4fff4ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((0xbU >> (IData)(vlSelf->__VdfgTmp_h0d5a6a23__0)) 
                                            << 4U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019125_) 
                                              << 3U) 
                                             | ((4U 
                                                 & ((0x10U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00bb00ff000f00ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128871___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f0335500000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058347_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127504___O))))))))))))) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___018382_)
                                                          ? 
                                                         (2U 
                                                          >> 
                                                          (1U 
                                                           & (IData)(
                                                                     (0x10f0f0f0f0f0f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057866_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060166_))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha954d544__0)))))))))
                                                          : 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                          | (0xff000b00U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019131_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0d5a6a23__0)))))))))))))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d 
                    = (1U & (IData)((0xfff4fffffff4fff4ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((0xbU >> (IData)(vlSelf->__VdfgTmp_h8574a487__0)) 
                                            << 4U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019144_) 
                                              << 3U) 
                                             | ((4U 
                                                 & ((0x10U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00bb00ff000f00ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128871___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f0335500000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058348_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127504___O) 
                                                                                >> 1U))))))))))))) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___018382_)
                                                          ? 
                                                         (2U 
                                                          >> 
                                                          (1U 
                                                           & (IData)(
                                                                     (0x10f0f0f0f0f0f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057863_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060166_))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he026c2ed__0)))))))))
                                                          : 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                          | (0xff000b00U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019150_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8574a487__0)))))))))))))));
            } else {
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d 
                    = (1U & (0x53U >> (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                        << 2U) | ((2U 
                                                   & ((1U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018339_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xf3f5f0f0ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf2800fdf__0))))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xff11ff0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018325_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7ad6ad5d__0))))))))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d 
                    = (1U & (2U >> ((2U & ((0x7077U 
                                            >> (IData)(vlSelf->__VdfgTmp_ha04c1ce6__0)) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___019023_))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d 
                    = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019022_))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d 
                    = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                     << 1U) | (1U & 
                                               (0xbU 
                                                >> (IData)(vlSelf->__VdfgTmp_h0d5a6a23__0))))));
                vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d 
                    = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                     << 1U) | (1U & 
                                               (0xbU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8574a487__0))))));
            }
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d 
                = (1U & (IData)((0x44f4ffff00f000f0ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060403_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060388_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x45454545454545cfULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060397_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060396_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060395_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbfffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060393_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64b8144d__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019044_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d 
                = (1U & (0x4f4f00ffU >> ((0x10U & (
                                                   (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___060145_) 
                                             << 3U) 
                                            | ((4U 
                                                & (((~ 
                                                     (0x3500U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf880000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058324_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015969_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O))))))))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00aaaafc0cfc0cULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xee0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058487_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058488_))))))))))))))))))))) 
                                                    & (IData)(
                                                              (0x33ff55fff0fff0ffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                 << 5U) 
                                                                | ((0x10U 
                                                                    & ((0xff4fffU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                       << 4U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xdU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134189___O) 
                                                                                >> 1U))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018948_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (0xc0a0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc42a79ae__0)))))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((0x4f00U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134163___O)) 
                                                              | (1U 
                                                                 & (0xb0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & ((1U 
                                                         & (IData)(
                                                                   (0xf0f0f0f0f0f0f01ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060134_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060133_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___018948_)
                                                          ? (IData)(
                                                                    (0xf000000020ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018947_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                          : 
                                                         (0xc04U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018947_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___018946_))))))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___018948_)
                                                          ? 
                                                         (1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d 
                = (1U & (IData)((0xfffffffff0f0f020ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060427_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060426_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___060425_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x45454545454545cfULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___060419_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060418_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060417_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7fff7fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057784_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016516_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016521_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019044_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019019_)))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060439_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060438_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                           & (IData)(
                                                                     (0xffffff00fffffff4ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019188_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019187_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h472f3127__0))))))) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xf8880000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019185_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___017141_)))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d 
                = (1U & (IData)((0xffffffba30303030ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060267_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060266_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019058_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x10U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128884___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99986d68__0))))))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058343_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127517___O) 
                                                                                >> 2U))))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d 
                = (1U & (IData)((0xf0f0f020f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059963_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059962_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xbb0000f0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                           << 4U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018829_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059948_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018831_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xf0f0f0f0f0f0f01ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059950_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059949_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059948_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018831_)
                                                                ? (IData)(
                                                                          (0xf000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018829_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                : 
                                                               (0xc04U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018830_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018829_))))))
                                                               : 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018831_)
                                                                ? 
                                                               (1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                                : 
                                                               (1U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x70U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0x7fff7fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059060_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xb0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017463_)))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d 
                = (1U & (IData)((0xffffff220f0f0f0fULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___059991_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___059990_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xbbf0f0U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018847_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___059965_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018849_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xf0f0f0f0f0f0f01ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059979_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059978_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059965_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016506_)))))))))
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018849_)
                                                                ? (IData)(
                                                                          (0xf000000020ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018848_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018847_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                : 
                                                               (0xc04U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018848_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018847_))))))
                                                               : 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___018849_)
                                                                ? 
                                                               (1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb0235e8a__0))
                                                                : 
                                                               (1U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___016504_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00e000ff00ff00ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___059982_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059057_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d 
                = (1U & ((~ (IData)((0xee0000f0f0ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((4U >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                            << 4U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___059649_) 
                                              << 3U) 
                                             | ((4U 
                                                 & ((IData)(
                                                            (0xff000b00ff00ffULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h7d1ccc69__0))) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___018535_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))) 
                         & (IData)((0xdfff0fff00ff00ffULL 
                                    >> (((IData)(vlSelf->wasmetal_core__DOT___018521_) 
                                         << 5U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___018520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018519_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xdU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018535_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xf1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059649_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___018535_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xafcf00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059671_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7000707ff00ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059667_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006085_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xb0bbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018274_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006085_))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060281_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060280_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___018964_)
                                                                      ? (IData)(
                                                                                (0xee000f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019079_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb98c8577__0))))))
                                                                      : 
                                                                     (1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___019079_)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xffff444f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060276_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060268_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff0a3303ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127599___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                                                                >> 3U))))))))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d 
                = (1U & (IData)((0x4fff4f4f00ff0000ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                         << 4U) | (
                                                   (8U 
                                                    & ((0xbU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h48d141d4__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xefef00efU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___060294_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058344_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127518___O) 
                                                                                >> 1U))))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (0xf3f50000U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058498_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128885___O) 
                                                                                >> 1U))))))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___019044_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___016506_)
                                                                 ? 
                                                                (0xd0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019099_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h688dcf01__0)))
                                                                 : (IData)(
                                                                           (0xb0b000b00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019099_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019098_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h48d141d4__0)))))))
                                                                : 
                                                               (0xdU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h688dcf01__0))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060234_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060233_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___060232_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xd0U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016504_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x7770000ffffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018999_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060166_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((~ (IData)(
                                                                          (0xbb00f000ff00ff00ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060222_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xdddf5d55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060212_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018080_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))))) 
                                                               & (IData)(
                                                                         (0xfff4ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019000_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36195b83__0)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d 
                = (1U & ((1U & (4U >> ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                              << 1U)) 
                                       | (1U & (IData)(
                                                       (0xf0f335500000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                        ? 
                                                                       (0xc0c5U 
                                                                        >> 
                                                                        ((8U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hff2cd213__0)) 
                                                                             << 3U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h9b49e40f__0))))
                                                                        : 
                                                                       (0xc0c5U 
                                                                        >> 
                                                                        ((8U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hff2cd213__0)) 
                                                                             << 3U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h9b49e40f__0))))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((0xf0f0cc55U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9152e63a__0))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (0xf0f0cc55U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                             << 4U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h9152e63a__0)))))))))))))))
                          ? (IData)((0xff00ffffb000b0b0ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT___018550_) 
                                          << 5U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___018549_) 
                                           << 4U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___018548_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0x1fff00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059683_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xb0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018568_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0xe0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5acde712__0))))))))))))) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018554_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((~ 
                                                        ((0xdU 
                                                          >> 
                                                          ((8U 
                                                            & ((IData)(
                                                                       (0xfcfaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                                >> 3U))))))))) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & (((1U 
                                                                       & ((4U 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                              ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                              : 
                                                                             (1U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                                       ? 
                                                                      (8U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___005982_)))
                                                                       : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___019194_))))) 
                                                         & (IData)(
                                                                   (0xffff0000ffffff1fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___018570_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hdd3dcee5__0))))))))) 
                                                       & (IData)(
                                                                 (0xfff1ffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018556_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hca110094__0)))))))))))))))
                          : (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___018549_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018548_)))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060313_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060312_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff444f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060305_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060299_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00000f0f033fbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060302_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb63e733c__0))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff80808000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017113_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h483b6bbc__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d 
                = (1U & (IData)((0xffffffba30303030ULL 
                                 >> ((0x20U & ((4U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                               << 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___060359_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xbfffU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc40410bb__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x700U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((IData)(
                                                                               (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128871___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0a35847a__0))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((0xf0f03355U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058350_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127504___O) 
                                                                                >> 3U))))))) 
                                                                          << 1U)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___059744_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059743_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___059742_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xff8f0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___059735_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059729_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (0xb0U 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xfff4ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059731_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc5312148__0)))))))
                                                               ? (IData)(
                                                                         (0xf0f000f030300020ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018625_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059725_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059719_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003810_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013692_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013692_)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018622_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                               : 
                                                              (0xdU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018625_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060347_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060346_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff444f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060339_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060333_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00000f0f033fbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060336_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060335_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb63e733c__0))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xbfffbfffbfffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___057821_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h111e31ee__0))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060371_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060370_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x1f00U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((IData)(
                                                                              (0xaa0acc0cff0fff0fULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060363_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___019166_))
                                                                                 : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019167_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019166_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006178_)))))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___060361_))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff80808000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057794_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018599_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d 
                = (1U & (0xff4fff00U >> ((0x10U & (
                                                   (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___060120_) 
                                             << 3U) 
                                            | ((4U 
                                                & (((~ 
                                                     (0x3500U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x5c00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058322_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058323_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O) 
                                                                                >> 3U))))))))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00aaaafc0cfc0cULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xee0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058485_))))))))))))))))))))) 
                                                    & (IData)(
                                                              (0x33ff55fff0fff0ffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                 << 5U) 
                                                                | ((0x10U 
                                                                    & ((0xff4fffU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                       << 4U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xdU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134189___O))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018937_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((0x4f00U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134163___O) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (0xb0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & ((1U 
                                                         & (0xdU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((0xf0fe0000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060102_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0x2220a2aaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & (IData)(
                                                                                (0x3337f3ff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xf0f7ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___060107_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O))))))))))))))
                                                         ? (IData)(
                                                                   (0xe0e0e0ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018937_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0xfff1ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060102_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060096_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002634_)))))))))))))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018935_))))))))
                                                         : 
                                                        (7U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___018937_))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060386_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060385_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff444f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060373_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff0a3303ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                                                                >> 1U))))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff80808000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018632_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___059797_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059796_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___059795_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf888ffff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((0xb0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059781_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059006_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xfff4ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059783_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf7efd051__0)))))))
                                                               ? (IData)(
                                                                         (0xf0f000f030300020ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018697_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059777_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059771_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006400_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018695_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                               : 
                                                              (0xdU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018697_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060455_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060454_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff444f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060446_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060441_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff0a3303ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127605___O) 
                                                                                >> 2U))))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf8880000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060447_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___057797_)))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d 
                = (1U & (0xfefe00ffU >> ((0x10U & (
                                                   (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___059821_) 
                                             << 3U) 
                                            | ((4U 
                                                & ((0xfee0000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                 ? 
                                                                (0xc0c5U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((4U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h312e1166__0))))
                                                                 : 
                                                                (0xc0c5U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((4U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h312e1166__0))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xf0f33aa00000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_ha7b11bb8__0))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xf0f000033aaULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7b11bb8__0))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & (((IData)(
                                                               (0xf888ffff00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((0xb0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059809_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___059001_)))))))) 
                                                       & ((1U 
                                                           & (IData)(
                                                                     (0xfff4ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059811_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059810_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52593617__0))))))))
                                                           ? (IData)(
                                                                     (0xffffffff1f1fff1fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                        << 5U) 
                                                                       | ((0x10U 
                                                                           & ((IData)(
                                                                                (0xff00eeee0f0fffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0dcf7bd7__0))) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059805_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059799_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003807_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013635_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013635_)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018728_))))))))
                                                           : 
                                                          (0xf2U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xff00eeee0f0fffffULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h0dcf7bd7__0))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016503_)))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xff440f0f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059814_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xbbbU 
                                                                               >> 
                                                                               ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059000_))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058575_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059242_))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___059849_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059848_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___059847_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7f7f7f00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059036_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018054_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63ea3543__0)))))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0xf0f0f0f0f0f0f02ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059834_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059833_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & (IData)(
                                                                                (0x5f3ff00003333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))))
                                                                                 ? 
                                                                                (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_)))
                                                                                 : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019194_)))))))))
                                                               ? (IData)(
                                                                         (0xf0f000f030300020ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018759_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059829_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059823_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013652_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013652_)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018757_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                               : 
                                                              (0xdU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018759_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___059882_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059881_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___059880_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff80ff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059876_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((0xb0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018148_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018775_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((~ 
                                                                (0x10U 
                                                                 >> 
                                                                 ((4U 
                                                                   & ((IData)(
                                                                              (0xffff000000bfULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059863_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059862_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059857_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x3f1b0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018082_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffa0c00ffffccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))))))))))))))) 
                                                               & (IData)(
                                                                         (0xfff1ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018777_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018776_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018775_))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d 
                = (1U & (IData)((0xff00b000ff00ffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___059910_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059909_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___059908_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf888ffff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((0xb0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059897_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059045_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & (IData)(
                                                                         (0x444fffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059896_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059895_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((1U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                & (IData)(
                                                                                (0x5f3ff00003333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))))
                                                                                 ? 
                                                                                (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_)))
                                                                                 : (IData)(
                                                                                (0xffff0000ff755755ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))))))))))))
                                                               ? (IData)(
                                                                         (0xf00020f0f03030ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018791_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059890_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059884_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018789_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                               : 
                                                              (7U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018791_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016504_)))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d 
                = (1U & (IData)((0xffffffffe000ff00ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___060479_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060478_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00ff00ff00e000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___060469_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060468_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xef00efefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060463_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060462_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058687_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058688_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0x7fff00007fff7fffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___051320_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc0c493be__0)))))))))))))))))));
            vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d 
                = (1U & ((IData)((0xff4fULL >> (((IData)(vlSelf->wasmetal_core__DOT___059930_) 
                                                 << 5U) 
                                                | ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018812_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018814_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))) 
                         | (IData)((0xff00ff00ff00b000ULL 
                                    >> (((IData)(vlSelf->wasmetal_core__DOT___018809_) 
                                         << 5U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___018808_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x7f7f7f00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059049_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018287_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63ea3543__0)))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (((1U 
                                                                  & (1U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xffff000000bf0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059925_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059924_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018287_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018055_))))))))))))
                                                                  ? (IData)(
                                                                            (0xf00020f0f03030ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___018814_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059918_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059917_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059911_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002193_)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018812_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016500_))))))))
                                                                  : 
                                                                 (7U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018814_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___016503_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016504_))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___052916_) {
            vlSelf->wasmetal_core__DOT__load_vector__05b67__05d 
                = vlSelf->wasmetal_core__DOT__top__05b67__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b68__05d 
                = vlSelf->wasmetal_core__DOT__top__05b68__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b124__05d 
                = vlSelf->wasmetal_core__DOT__top__05b124__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b69__05d 
                = vlSelf->wasmetal_core__DOT__top__05b69__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b126__05d 
                = vlSelf->wasmetal_core__DOT__top__05b126__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b99__05d 
                = vlSelf->wasmetal_core__DOT__top__05b99__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b100__05d 
                = vlSelf->wasmetal_core__DOT__top__05b100__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b102__05d 
                = vlSelf->wasmetal_core__DOT__top__05b102__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b75__05d 
                = vlSelf->wasmetal_core__DOT__top__05b75__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b94__05d 
                = vlSelf->wasmetal_core__DOT__top__05b94__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b108__05d 
                = vlSelf->wasmetal_core__DOT__top__05b108__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b109__05d 
                = vlSelf->wasmetal_core__DOT__top__05b109__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b110__05d 
                = vlSelf->wasmetal_core__DOT__top__05b110__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b65__05d 
                = vlSelf->wasmetal_core__DOT__top__05b65__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b105__05d 
                = vlSelf->wasmetal_core__DOT__top__05b105__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b74__05d 
                = vlSelf->wasmetal_core__DOT__top__05b74__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b82__05d 
                = vlSelf->wasmetal_core__DOT__top__05b82__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b77__05d 
                = vlSelf->wasmetal_core__DOT__top__05b77__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b73__05d 
                = vlSelf->wasmetal_core__DOT__top__05b73__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b83__05d 
                = vlSelf->wasmetal_core__DOT__top__05b83__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b84__05d 
                = vlSelf->wasmetal_core__DOT__top__05b84__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b85__05d 
                = vlSelf->wasmetal_core__DOT__top__05b85__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b86__05d 
                = vlSelf->wasmetal_core__DOT__top__05b86__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b120__05d 
                = vlSelf->wasmetal_core__DOT__top__05b120__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b104__05d 
                = vlSelf->wasmetal_core__DOT__top__05b104__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b95__05d 
                = vlSelf->wasmetal_core__DOT__top__05b95__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b79__05d 
                = vlSelf->wasmetal_core__DOT__top__05b79__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b111__05d 
                = vlSelf->wasmetal_core__DOT__top__05b111__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b87__05d 
                = vlSelf->wasmetal_core__DOT__top__05b87__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b90__05d 
                = vlSelf->wasmetal_core__DOT__top__05b90__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b97__05d 
                = vlSelf->wasmetal_core__DOT__top__05b97__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b70__05d 
                = vlSelf->wasmetal_core__DOT__top__05b70__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b91__05d 
                = vlSelf->wasmetal_core__DOT__top__05b91__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b92__05d 
                = vlSelf->wasmetal_core__DOT__top__05b92__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b93__05d 
                = vlSelf->wasmetal_core__DOT__top__05b93__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b76__05d 
                = vlSelf->wasmetal_core__DOT__top__05b76__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b78__05d 
                = vlSelf->wasmetal_core__DOT__top__05b78__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b81__05d 
                = vlSelf->wasmetal_core__DOT__top__05b81__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b88__05d 
                = vlSelf->wasmetal_core__DOT__top__05b88__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b103__05d 
                = vlSelf->wasmetal_core__DOT__top__05b103__05d;
        }
        if (vlSelf->wasmetal_core__DOT___019788_) {
            vlSelf->wasmetal_core__DOT__gc_reference__05b66__05d 
                = (1U & (vlSelf->insn_x >> 2U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b74__05d 
                = (1U & (vlSelf->insn_x >> 0xaU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b90__05d 
                = (1U & (vlSelf->insn_x >> 0x1aU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b67__05d 
                = (1U & (vlSelf->insn_x >> 3U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b68__05d 
                = (1U & (vlSelf->insn_x >> 4U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b69__05d 
                = (1U & (vlSelf->insn_x >> 5U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b70__05d 
                = (1U & (vlSelf->insn_x >> 6U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b91__05d 
                = (1U & (vlSelf->insn_x >> 0x1bU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b75__05d 
                = (1U & (vlSelf->insn_x >> 0xbU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b92__05d 
                = (1U & (vlSelf->insn_x >> 0x1cU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b93__05d 
                = (1U & (vlSelf->insn_x >> 0x1dU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b94__05d 
                = (1U & (vlSelf->insn_x >> 0x1eU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b76__05d 
                = (1U & (vlSelf->insn_x >> 0xcU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b77__05d 
                = (1U & (vlSelf->insn_x >> 0xdU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b78__05d 
                = (1U & (vlSelf->insn_x >> 0xeU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b82__05d 
                = (1U & (vlSelf->insn_x >> 0x12U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b65__05d 
                = (1U & (vlSelf->insn_x >> 1U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b97__05d = 1U;
            vlSelf->wasmetal_core__DOT__gc_reference__05b73__05d 
                = (1U & (vlSelf->insn_x >> 9U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b89__05d 
                = (1U & (vlSelf->insn_x >> 0x19U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b83__05d 
                = (1U & (vlSelf->insn_x >> 0x13U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b84__05d 
                = (1U & (vlSelf->insn_x >> 0x14U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b85__05d 
                = (1U & (vlSelf->insn_x >> 0x15U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b86__05d 
                = (1U & (vlSelf->insn_x >> 0x16U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b81__05d 
                = (1U & (vlSelf->insn_x >> 0x11U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b64__05d 
                = (1U & vlSelf->insn_x);
            vlSelf->wasmetal_core__DOT__gc_reference__05b72__05d 
                = (1U & (vlSelf->insn_x >> 8U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b88__05d 
                = (1U & (vlSelf->insn_x >> 0x18U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b80__05d 
                = (1U & (vlSelf->insn_x >> 0x10U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b71__05d 
                = (1U & (vlSelf->insn_x >> 7U));
            vlSelf->wasmetal_core__DOT__gc_reference__05b95__05d 
                = (vlSelf->insn_x >> 0x1fU);
            vlSelf->wasmetal_core__DOT__gc_reference__05b79__05d 
                = (1U & (vlSelf->insn_x >> 0xfU));
            vlSelf->wasmetal_core__DOT__gc_reference__05b87__05d 
                = (1U & (vlSelf->insn_x >> 0x17U));
        }
        if (vlSelf->wasmetal_core__DOT___019792_) {
            vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b1__05d 
                = (1U & (0x3aU >> (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__decoded_table)))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b31__05d 
                = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___050924_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
            vlSelf->wasmetal_core__DOT__bulk_destination_index__05b30__05d 
                = (1U & (0xa3a0U >> ((8U & (vlSelf->insn_x 
                                            >> 0x1bU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___046221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1eU)))))));
        }
        if (vlSelf->wasmetal_core__DOT___019794_) {
            vlSelf->wasmetal_core__DOT__bulk_source_kind__05b1__05d 
                = (1U & (0x7d55U >> (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))))))));
        }
    }
    vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039860_));
    vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039859_));
    vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039858_));
    vlSelf->__VdfgTmp_h8cb32961__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d));
    vlSelf->__VdfgTmp_ha01e8f2f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    if (vlSelf->wasmetal_core__DOT___019810_) {
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT__simd_integer__02erunning) {
        if ((1U & (4U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                >> 2U))))) {
            if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d 
                    = (1U & (0xf0f0f0feU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                              << 4U) 
                                             | ((8U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019653_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___019540_)) 
                                                         << 1U)))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d 
                    = (1U & (IData)((0xff00ffeeff00fff0ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                            << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019646_) 
                                              << 3U) 
                                             | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0)))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d 
                    = (1U & (IData)((0xffeefff0ff00ff00ULL 
                                     >> ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___019596_) 
                                                << 3U) 
                                               | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0)))))));
            } else {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d 
                    = (1U & (0xceccU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 3U) | 
                                         ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 1U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019653_) 
                                              << 1U) 
                                             | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019541_))))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d 
                    = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019646_)));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d 
                    = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019596_)));
            }
            if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d 
                    = (1U & (0xf0f0f0feU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                              << 4U) 
                                             | ((8U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 3U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019635_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde6a7e42__0))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d 
                    = (1U & (0xf0f0f0feU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                              << 4U) 
                                             | ((8U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 3U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019624_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___019540_)) 
                                                         << 1U)))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d 
                    = (1U & (IData)((0xff00ffeefff0ff00ULL 
                                     >> ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   << 5U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___019604_) 
                                                << 3U) 
                                               | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0)))))));
            } else {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d 
                    = (1U & (0xecccU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 3U) | 
                                         ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 2U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019635_) 
                                              << 1U) 
                                             | (1U 
                                                & (4U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019550_))))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d 
                    = (1U & (0xecccU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 3U) | 
                                         ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 2U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019624_) 
                                              << 1U) 
                                             | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019541_))))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d 
                    = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019604_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019653_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019646_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019635_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019624_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019604_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019596_)));
        }
        if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b89__05d 
                = (1U & ((1U & (4U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             >> 2U))))
                          ? (IData)((0xff00ffeeff00fff0ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                            << 4U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019617_) 
                                              << 3U) 
                                             | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0))))))
                          : (2U >> (IData)(vlSelf->wasmetal_core__DOT___019617_))));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b25__05d 
                = (1U & ((1U & (8U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             >> 2U))))
                          ? (IData)((0xff00ffeeff00fff0ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                            << 4U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019512_) 
                                              << 3U) 
                                             | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0))))))
                          : (2U >> (IData)(vlSelf->wasmetal_core__DOT___019512_))));
        } else {
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b89__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019617_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b25__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019512_)));
        }
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b65__05d 
            = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___071695_) 
                                << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 >> 2U)) 
                                          | (1U & (
                                                   (4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))
                                                    ? 
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                     >> 1U) 
                                                    | (0xffffff32U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                         << 4U) 
                                                        | ((8U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 3U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___019540_)))))
                                                    : 
                                                   ((~ 
                                                     ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 1U)) 
                                                    | (0x7fffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___019541_)))))))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b57__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019577_)
                      ? (IData)((0xff00ffeeff00fff0ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                      << 5U) | ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 4U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019576_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0))))))
                      : (2U >> (IData)(vlSelf->wasmetal_core__DOT___019576_))));
        if ((1U & (8U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                >> 2U))))) {
            if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d 
                    = (1U & (0xf0f0f0feU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                              << 4U) 
                                             | ((8U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019561_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___019540_)) 
                                                         << 1U)))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d 
                    = (1U & (IData)((0xff00ffeeff00fff0ULL 
                                     >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 5U) | 
                                         ((0x10U & 
                                           ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                            << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019554_) 
                                              << 3U) 
                                             | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0)))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d 
                    = (1U & (IData)((0xffeefff0ff00ff00ULL 
                                     >> ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___019485_) 
                                                << 3U) 
                                               | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0)))))));
            } else {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d 
                    = (1U & (0xceccU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 3U) | 
                                         ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 1U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019561_) 
                                              << 1U) 
                                             | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019541_))))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d 
                    = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019554_)));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d 
                    = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019485_)));
            }
            if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d 
                    = (1U & (0xf0f0f0feU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                              << 4U) 
                                             | ((8U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 3U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019533_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde6a7e42__0))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d 
                    = (1U & (0xf0f0f0feU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                              << 4U) 
                                             | ((8U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 3U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019519_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___019540_)) 
                                                         << 1U)))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d 
                    = (1U & (IData)((0xff00ffeefff0ff00ULL 
                                     >> ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   << 5U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___019496_) 
                                                << 3U) 
                                               | (IData)(vlSelf->__VdfgTmp_hf7bd378e__0)))))));
            } else {
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d 
                    = (1U & (0xecccU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 3U) | 
                                         ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 2U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019533_) 
                                              << 1U) 
                                             | (1U 
                                                & (4U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019550_))))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d 
                    = (1U & (0xecccU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                          << 3U) | 
                                         ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 2U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___019519_) 
                                              << 1U) 
                                             | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019541_))))))));
                vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d 
                    = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019496_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019561_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019554_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019533_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019519_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019496_)));
            vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d 
                = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___019485_)));
        }
    }
    vlSelf->function_index = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128999___Q) 
                               << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128998___Q) 
                                             << 0x1eU) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128997___Q) 
                                                << 0x1dU) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128996___Q) 
                                                   << 0x1cU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128995___Q) 
                                                      << 0x1bU) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128994___Q) 
                                                         << 0x1aU) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128993___Q) 
                                                            << 0x19U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128992___Q) 
                                                               << 0x18U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128991___Q) 
                                                                  << 0x17U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128990___Q) 
                                                                     << 0x16U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128989___Q) 
                                                                        << 0x15U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128988___Q) 
                                                                           << 0x14U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128987___Q) 
                                                                              << 0x13U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128986___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128985___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128984___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128983___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128982___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128981___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128980___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128979___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128978___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128977___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128976___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128975___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128974___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128973___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128972___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128971___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128970___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128969___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128968___Q))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___053314_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b74__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___053317_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b90__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___053326_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b91__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___053310_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b93__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___053325_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b76__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___053324_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b69__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b65__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___053322_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b83__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b82__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___053323_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b68__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b64__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->insn_y))))));
    vlSelf->wasmetal_core__DOT__gc_reference__05b96__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039572_));
    vlSelf->wasmetal_core__DOT___053313_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b72__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___053318_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b88__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___053311_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b71__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b70__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 6U)))))));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039560_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039559_));
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039550_));
}
