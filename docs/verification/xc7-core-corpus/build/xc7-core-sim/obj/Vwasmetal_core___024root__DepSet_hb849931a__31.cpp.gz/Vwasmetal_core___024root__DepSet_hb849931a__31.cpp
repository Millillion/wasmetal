#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__38(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__38\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___012317_;
    wasmetal_core__DOT___012317_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012357_;
    wasmetal_core__DOT___012357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012358_;
    wasmetal_core__DOT___012358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012359_;
    wasmetal_core__DOT___012359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012971_;
    wasmetal_core__DOT___012971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013023_;
    wasmetal_core__DOT___013023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024185_;
    wasmetal_core__DOT___024185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024194_;
    wasmetal_core__DOT___024194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024316_;
    wasmetal_core__DOT___024316_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024325_;
    wasmetal_core__DOT___024325_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024451_;
    wasmetal_core__DOT___024451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024608_;
    wasmetal_core__DOT___024608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024617_;
    wasmetal_core__DOT___024617_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024868_;
    wasmetal_core__DOT___024868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024876_;
    wasmetal_core__DOT___024876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024881_;
    wasmetal_core__DOT___024881_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043364_;
    wasmetal_core__DOT___043364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043365_;
    wasmetal_core__DOT___043365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043366_;
    wasmetal_core__DOT___043366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043387_;
    wasmetal_core__DOT___043387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043388_;
    wasmetal_core__DOT___043388_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043389_;
    wasmetal_core__DOT___043389_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043428_;
    wasmetal_core__DOT___043428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043429_;
    wasmetal_core__DOT___043429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043430_;
    wasmetal_core__DOT___043430_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043452_;
    wasmetal_core__DOT___043452_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043453_;
    wasmetal_core__DOT___043453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043454_;
    wasmetal_core__DOT___043454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043494_;
    wasmetal_core__DOT___043494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043495_;
    wasmetal_core__DOT___043495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043516_;
    wasmetal_core__DOT___043516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043517_;
    wasmetal_core__DOT___043517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043518_;
    wasmetal_core__DOT___043518_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043753_;
    wasmetal_core__DOT___043753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043754_;
    wasmetal_core__DOT___043754_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043755_;
    wasmetal_core__DOT___043755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043777_;
    wasmetal_core__DOT___043777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043778_;
    wasmetal_core__DOT___043778_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043779_;
    wasmetal_core__DOT___043779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043820_;
    wasmetal_core__DOT___043820_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043821_;
    wasmetal_core__DOT___043821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043844_;
    wasmetal_core__DOT___043844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043845_;
    wasmetal_core__DOT___043845_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056300_;
    wasmetal_core__DOT___056300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056707_;
    wasmetal_core__DOT___056707_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056934_;
    wasmetal_core__DOT___056934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056935_;
    wasmetal_core__DOT___056935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056936_;
    wasmetal_core__DOT___056936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056949_;
    wasmetal_core__DOT___056949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056971_;
    wasmetal_core__DOT___056971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057033_;
    wasmetal_core__DOT___057033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057064_;
    wasmetal_core__DOT___057064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057206_;
    wasmetal_core__DOT___057206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057214_;
    wasmetal_core__DOT___057214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057296_;
    wasmetal_core__DOT___057296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057421_;
    wasmetal_core__DOT___057421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057427_;
    wasmetal_core__DOT___057427_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057612_;
    wasmetal_core__DOT___057612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071855_;
    wasmetal_core__DOT___071855_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071856_;
    wasmetal_core__DOT___071856_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071858_;
    wasmetal_core__DOT___071858_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071859_;
    wasmetal_core__DOT___071859_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071860_;
    wasmetal_core__DOT___071860_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071863_;
    wasmetal_core__DOT___071863_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071866_;
    wasmetal_core__DOT___071866_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071874_;
    wasmetal_core__DOT___071874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071875_;
    wasmetal_core__DOT___071875_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071877_;
    wasmetal_core__DOT___071877_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071878_;
    wasmetal_core__DOT___071878_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071879_;
    wasmetal_core__DOT___071879_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071882_;
    wasmetal_core__DOT___071882_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071885_;
    wasmetal_core__DOT___071885_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127643___O;
    wasmetal_core__DOT____Vcellout___127643___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127660___O;
    wasmetal_core__DOT____Vcellout___127660___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127692___CO;
    wasmetal_core__DOT____Vcellout___127692___CO = 0;
    CData/*0:0*/ wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_h267c01fb__0;
    __VdfgTmp_h267c01fb__0 = 0;
    // Body
    wasmetal_core__DOT___024608_ = ((IData)(vlSelf->wasmetal_core__DOT___024498_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___127705___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___012942_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___012443_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___013078_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0)))) {
        wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024442_;
        wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d;
    } else {
        wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d;
        wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024608_;
    }
    vlSelf->wasmetal_core__DOT___043815_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O)))));
    vlSelf->wasmetal_core__DOT___043489_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___071855_ = (1U & (9U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071856_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071859_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071860_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if (vlSelf->wasmetal_core__DOT___024240_) {
        wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024176_;
        wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d;
    } else {
        wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d;
        wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024307_;
    }
    vlSelf->wasmetal_core__DOT___043360_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043749_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O)))));
    wasmetal_core__DOT___071874_ = (1U & (9U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071875_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071878_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071879_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024859_));
    vlSelf->wasmetal_core__DOT___043424_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)))));
    vlSelf->wasmetal_core__DOT___043448_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h356ffba0__0)))) {
        wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d;
    } else {
        wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d;
        wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043512_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071857_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071856_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071855_)))));
    vlSelf->wasmetal_core__DOT___043839_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071855_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071856_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071860_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0)))) {
        wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d;
    } else {
        wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d;
        wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043383_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071876_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071875_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071874_)))));
    vlSelf->wasmetal_core__DOT___043773_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071874_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071875_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071879_)))));
    wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___024501_) {
        wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d;
    } else {
        wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d;
        wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)))) {
        wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d;
    } else {
        wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d;
        wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127673___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h30bed265__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024501_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h356ffba0__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024442_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h30bed265__0)))) {
        vlSelf->wasmetal_core__DOT___024447_ = wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024613_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024447_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d;
        vlSelf->wasmetal_core__DOT___024613_ = wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127639___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024244_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)) 
                              << 2U)) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___024240_)))) 
           ^ (((IData)(wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024176_)))));
    if (vlSelf->wasmetal_core__DOT___024244_) {
        vlSelf->wasmetal_core__DOT___024181_ = wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024312_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024181_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d;
        vlSelf->wasmetal_core__DOT___024312_ = wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127656___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024244_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed15da38__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024240_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024307_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127721___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
           ^ (((IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024859_)))));
    vlSelf->wasmetal_core__DOT___024863_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127689___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h30bed265__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024501_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h356ffba0__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024608_)))));
    vlSelf->wasmetal_core__DOT___012055_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___011733_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0)))) {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024447_;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024613_;
    }
    vlSelf->wasmetal_core__DOT___043816_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043491_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043490_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___071858_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071861_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071862_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071863_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))) {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024181_;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024312_;
    }
    vlSelf->wasmetal_core__DOT___043362_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043361_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043750_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___071877_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071880_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071881_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071882_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024863_));
    vlSelf->wasmetal_core__DOT___043425_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043449_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    if (vlSelf->wasmetal_core__DOT___024504_) {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043513_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071860_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071859_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071858_)))));
    vlSelf->wasmetal_core__DOT___043840_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071859_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071863_)))));
    vlSelf->wasmetal_core__DOT___043514_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071863_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071862_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071861_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)))) {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043384_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071879_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071878_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071877_)))));
    vlSelf->wasmetal_core__DOT___043385_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071882_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071881_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071880_)))));
    vlSelf->wasmetal_core__DOT___043774_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071877_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071878_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071882_)))));
    vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)))) {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024247_) {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127674___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024504_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024447_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0)))) {
        wasmetal_core__DOT___024451_ = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024617_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d;
    } else {
        wasmetal_core__DOT___024451_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d;
        wasmetal_core__DOT___024617_ = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127640___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                               << 2U) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024181_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)))) {
        wasmetal_core__DOT___024185_ = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024316_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d;
    } else {
        wasmetal_core__DOT___024185_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d;
        wasmetal_core__DOT___024316_ = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127657___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024247_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024312_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127722___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024863_)))));
    wasmetal_core__DOT___024868_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127690___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0))) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024504_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024613_)))));
    vlSelf->wasmetal_core__DOT___057260_ = (1U & (IData)(
                                                         (0xf0f3f0f5ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057256_)))))))));
    if (vlSelf->wasmetal_core__DOT___024507_) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024451_;
        wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024617_;
    }
    vlSelf->wasmetal_core__DOT___043818_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043817_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043842_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043492_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)))));
    wasmetal_core__DOT___071866_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024185_;
        wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024316_;
    }
    vlSelf->wasmetal_core__DOT___043363_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)))));
    vlSelf->wasmetal_core__DOT___043752_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043751_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043776_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071885_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
           & (IData)(wasmetal_core__DOT___024868_));
    vlSelf->wasmetal_core__DOT___043427_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043426_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043451_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043450_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)))) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043841_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071862_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071866_)))));
    vlSelf->wasmetal_core__DOT___043515_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071866_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> 
                                                            ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                 >> 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043386_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071885_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> 
                                                            ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                 >> 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))));
    vlSelf->wasmetal_core__DOT___043775_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071880_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071881_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071885_)))));
    wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___024509_) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127675___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010032_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024509_) 
                        << 2U) | ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___024507_)))) 
           ^ (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024451_)))));
    if (vlSelf->wasmetal_core__DOT___010032_) {
        vlSelf->wasmetal_core__DOT___024455_ = wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024621_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024455_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d;
        vlSelf->wasmetal_core__DOT___024621_ = wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127641___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024185_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)))) {
        vlSelf->wasmetal_core__DOT___024189_ = wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024320_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024189_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d;
        vlSelf->wasmetal_core__DOT___024320_ = wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127658___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0))) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hde45e173__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024316_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127723___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
           ^ (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024868_)))));
    vlSelf->wasmetal_core__DOT___024872_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127691___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010032_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024509_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h862c0500__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024507_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024617_)))));
    vlSelf->wasmetal_core__DOT___012024_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___010380_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))) {
        vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024455_;
        wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d;
        wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024621_;
    }
    vlSelf->wasmetal_core__DOT___043819_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O)))));
    vlSelf->wasmetal_core__DOT___043843_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043493_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___043516_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024189_;
        wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024320_;
    }
    wasmetal_core__DOT___043364_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043753_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O)))));
    wasmetal_core__DOT___043387_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043777_ = (1U & (0x8001U >> 
                                          ((0xeU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                             << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___057064_ = (1U & (IData)((0xf00bb00ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))));
    vlSelf->wasmetal_core__DOT___056872_ = (1U & (0xfdd0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                  >> 2U))))))));
    wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024872_));
    wasmetal_core__DOT___043428_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)))));
    wasmetal_core__DOT___043452_ = (1U & (0x4002U >> 
                                          ((0xeU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                             << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0)))) {
        wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d;
    } else {
        wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d;
        wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127676___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024511_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___024511_)
                 ? (IData)(wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024455_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___024511_)
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)
            : (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057276_ = (1U & (IData)(
                                                         (0xf0f3f0f5ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde86d559__0))))))));
    wasmetal_core__DOT___012358_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if (vlSelf->wasmetal_core__DOT___024256_) {
        wasmetal_core__DOT___024194_ = wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024325_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d;
    } else {
        wasmetal_core__DOT___024194_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d;
        wasmetal_core__DOT___024325_ = wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127642___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024256_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                              << 2U)) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024189_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127659___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024256_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5b180012__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7b799034__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024320_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127724___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
           ^ (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024872_)))));
    wasmetal_core__DOT___024876_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT____Vcellout___127643___O = ((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___024256_)
                                                       ? (IData)(wasmetal_core__DOT___024194_)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___024194_)));
    wasmetal_core__DOT___043820_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043844_ = (1U & (0x8001U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043494_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                << 2U)) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043517_ = (1U & (0x4002U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT____Vcellout___127660___O = (
                                                   (1U 
                                                    & (~ (IData)(vlSelf->wasmetal_core__DOT___024256_))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___024256_)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d)
                                                       : (IData)(wasmetal_core__DOT___024325_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___024325_)));
    wasmetal_core__DOT___043365_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                << 2U)) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043754_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043388_ = (1U & (0x4002U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043778_ = (1U & (0x8001U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->__VdfgTmp_hc4dae929__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                    >> 2U)));
    wasmetal_core__DOT____Vcellout___127692___CO = 
        ((((1U & (9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)
            : (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127692___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024511_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha0636656__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024621_)));
    wasmetal_core__DOT___043821_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                       >> 2U)))))));
    wasmetal_core__DOT___043845_ = (1U & (0x9000U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043495_ = (1U & (0xfef0U >> 
                                          ((0x10U & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                             << 4U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                     >> 1U)) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                          >> 2U))))))));
    wasmetal_core__DOT___043518_ = (1U & (0x1000010U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                  << 3U)) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___043366_ = (1U & (0xfef0U >> 
                                          ((0x10U & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                             << 4U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                     >> 1U)) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                          >> 2U))))))));
    wasmetal_core__DOT___043389_ = (1U & (0x1000010U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                  << 3U)) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___043779_ = (1U & (0x9000U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043755_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hc4dae929__0)))));
    wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
           & (IData)(wasmetal_core__DOT___024876_));
    wasmetal_core__DOT___043430_ = (1U & (0xffe0U >> 
                                          ((8U & (IData)(wasmetal_core__DOT____Vcellout___127692___CO)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 2U) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043429_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043454_ = (1U & (0x1004U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                  << 1U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127692___CO) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___043453_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___043801_ = (1U & ((IData)(wasmetal_core__DOT___043845_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043844_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043843_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043842_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043841_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043840_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043839_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043838_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043837_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043836_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043835_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043834_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043853_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043852_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043851_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043850_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043849_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043848_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___043847_)
                                                                     ? 
                                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043846_)) 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_ha95c81f0__0)))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___043823_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043824_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043825_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043826_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043827_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043828_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043829_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043810_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043811_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043812_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043813_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043814_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043815_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043816_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043817_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043818_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043819_))
                                                    : (IData)(wasmetal_core__DOT___043820_))
                                                   : (IData)(wasmetal_core__DOT___043821_)));
    vlSelf->wasmetal_core__DOT___043475_ = (1U & ((IData)(wasmetal_core__DOT___043518_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043517_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043516_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043515_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043514_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043513_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043512_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043511_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043510_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043509_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043508_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043507_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043525_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043524_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043523_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043522_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043521_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043520_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043519_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 3U))))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043497_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043498_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043499_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043500_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043501_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043502_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043484_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043485_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043486_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043487_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043488_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043489_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043490_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043491_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043492_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043493_))
                                                    : (IData)(wasmetal_core__DOT___043494_))
                                                   : (IData)(wasmetal_core__DOT___043495_)));
    vlSelf->wasmetal_core__DOT___043346_ = (1U & ((IData)(wasmetal_core__DOT___043389_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043388_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043387_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043386_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043385_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043384_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043383_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043382_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043381_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043380_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043379_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043378_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043396_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043395_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043394_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043393_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043392_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043391_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043390_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 3U))))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043368_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043369_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043370_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043371_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043372_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043373_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043355_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043356_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043357_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043358_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043359_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043360_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043361_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043362_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043363_))
                                                     : (IData)(wasmetal_core__DOT___043364_))
                                                    : (IData)(wasmetal_core__DOT___043365_))
                                                   : (IData)(wasmetal_core__DOT___043366_)));
    vlSelf->wasmetal_core__DOT___043735_ = (1U & ((IData)(wasmetal_core__DOT___043779_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043778_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043777_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043776_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043775_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043774_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043773_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043772_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043771_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043770_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043769_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043768_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043787_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043786_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043785_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043784_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043783_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043782_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___043781_)
                                                                     ? 
                                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043780_)) 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hb920cb05__0)))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___043757_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043758_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043759_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043760_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043761_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043762_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043763_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043744_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043745_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043746_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043747_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043748_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043749_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043750_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043751_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043752_))
                                                     : (IData)(wasmetal_core__DOT___043753_))
                                                    : (IData)(wasmetal_core__DOT___043754_))
                                                   : (IData)(wasmetal_core__DOT___043755_)));
    wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___043410_ = (1U & ((IData)(wasmetal_core__DOT___043454_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043453_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043452_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043451_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043450_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043449_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043448_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043447_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043446_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043445_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043444_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043443_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043461_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043460_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043459_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043458_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043457_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043456_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043455_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | (7U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O)))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043432_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043433_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043434_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043435_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043436_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043437_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043419_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043420_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043421_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043422_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043423_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043424_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043425_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043426_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043427_))
                                                     : (IData)(wasmetal_core__DOT___043428_))
                                                    : (IData)(wasmetal_core__DOT___043429_))
                                                   : (IData)(wasmetal_core__DOT___043430_)));
    wasmetal_core__DOT___056936_ = (1U & (0xc0aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___056949_ = (1U & (0xc0aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___057206_ = (1U & (0xcc0035U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O))))))));
    wasmetal_core__DOT___056935_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043475_)))));
    vlSelf->wasmetal_core__DOT___057477_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057489_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012954_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057339_ = (1U & (IData)(
                                                         (0xff00fff0f0eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057332_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___043735_))))))))))));
    vlSelf->wasmetal_core__DOT___057348_ = (1U & (0xf5fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___012594_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f033aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056062_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 1U)))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___057282_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___057125_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056997_ = (1U & (IData)(
                                                         (0xcfcffcee00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056993_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056941_ = (1U & (IData)(
                                                         (0xf0f055cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055964_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 3U)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O))))))))));
    vlSelf->wasmetal_core__DOT___056954_ = (1U & (IData)(
                                                         (0xf0f055cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010053_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 3U)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O))))))))));
    vlSelf->wasmetal_core__DOT___056841_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 2U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056881_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((0xf3faU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                                                >> 2U)))))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___056684_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056696_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___011275_ = (1U & (0xf5fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___010379_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf3fa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056318_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127724___O)) 
                                                                              | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056411_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f033aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x774477775f505f5fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O)))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O))))))))));
    vlSelf->wasmetal_core__DOT___056512_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    wasmetal_core__DOT___057427_ = (1U & (IData)((0xf0f000005533ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                              >> 2U))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    vlSelf->wasmetal_core__DOT___012513_ = (1U & (0xf110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xf044U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xee22fa0a00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012502_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f000005533ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))))))))));
    wasmetal_core__DOT___057214_ = (1U & (IData)((0xf0f000005533ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    vlSelf->wasmetal_core__DOT___013161_ = (1U & ((0xf3fa0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xcc35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                                >> 3U)))))))))))) 
                                                  & (IData)(
                                                            (0x57f757f755ff7777ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((0xfef0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))));
    wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057400_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057413_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057435_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057333_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___057197_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O))))))))));
    vlSelf->wasmetal_core__DOT___057190_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O))))))))));
    wasmetal_core__DOT___056971_ = (1U & (IData)((0xf000f0000ddddULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                >> 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056791_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___056808_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                             >> 2U))))))))));
    wasmetal_core__DOT___056707_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x33aa0f0f00000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xcc35U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 2U)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___056754_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___011255_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                                >> 1U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___056574_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 1U)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___056581_ = (1U & (IData)(
                                                         (0xf0f000000bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056578_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0fff0ffff2222ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056576_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___056471_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(
                                                              (0xf000f0000bbbbULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___043801_))))))))))
                                                   : 
                                                  (0xbbbb0fffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010904_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011068_))))))));
    vlSelf->wasmetal_core__DOT___056493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O)))))))))))));
    vlSelf->wasmetal_core__DOT___056518_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O))))))))));
    vlSelf->wasmetal_core__DOT___057618_ = (1U & (IData)(
                                                         (0x11fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha95c81f0__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___057612_ = (1U & (IData)((0x33aa0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                              >> 3U)))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___013023_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x33aaf0f000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xeU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 3U))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___013177_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 3U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___056934_ = (1U & (0xd0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___043410_)))));
    vlSelf->wasmetal_core__DOT___056297_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043410_)))));
    vlSelf->wasmetal_core__DOT___012896_ = (1U & (IData)(
                                                         (0xf0f0f0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057427_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfdd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                             ? 
                                                                            (0x77747777U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))
                                                                             : 
                                                                            (0x77747777U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))));
    vlSelf->wasmetal_core__DOT___012512_ = (1U & (IData)(
                                                         (0x1111000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057214_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009712_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010378_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))))))));
    wasmetal_core__DOT___024881_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127725___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
           ^ (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024876_)))));
    vlSelf->wasmetal_core__DOT___056981_ = (1U & (IData)(
                                                         (0xccaa00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ffffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056972_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___056971_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xdd11f505U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056213_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f00ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                >> 3U))))))))))))))));
    vlSelf->wasmetal_core__DOT___056712_ = (1U & (IData)(
                                                         (0xff00bb00ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056707_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056706_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___057626_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057612_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffff1000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057606_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057559_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                              ? 
                                                                             (0x888b8888U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))
                                                                              : 
                                                                             (0x888b8888U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))))))))))));
    wasmetal_core__DOT___057421_ = (1U & (0xd0U >> 
                                          (((IData)(wasmetal_core__DOT___056934_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                    >> 2U))))));
    __VdfgTmp_h267c01fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___056935_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___056934_)));
    vlSelf->wasmetal_core__DOT___012481_ = (1U & (IData)(
                                                         (0xff00b000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057206_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056934_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    vlSelf->wasmetal_core__DOT___057510_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___012971_ = (1U & (0xdf0fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(
                                                             (0xcfcffcee00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 2U))))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                          >> 2U))))))));
    vlSelf->wasmetal_core__DOT___012604_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___057296_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                                              >> 1U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___057120_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x4f00U 
                                                         >> 
                                                         ((8U 
                                                           & ((0xccfe0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O))))))) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___012359_ = (1U & (0xdf0fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(
                                                             (0xcfcffcee00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O))))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O))))))));
    wasmetal_core__DOT___057033_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                              >> 3U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___012283_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x4f00U 
                                                         >> 
                                                         ((8U 
                                                           & ((0xccfe0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                               >> 3U))))))) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___012317_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                                              >> 3U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___012331_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056836_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___011685_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056680_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056691_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xccfe0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                              >> 1U))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___056403_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___010381_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcfcffcee00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O))))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O))))))));
    wasmetal_core__DOT___056300_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___013083_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___013010_ = (1U & ((~ 
                                                   (0x10U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0xf0f0000000eeULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                             << 3U) 
                                                                            | (((IData)(
                                                                                (((IData)(wasmetal_core__DOT____Vcellout___127692___CO) 
                                                                                >> 3U) 
                                                                                ^ (IData)(wasmetal_core__DOT___024881_))) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                                                >> 3U))))))))) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xee22fa0a00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056134_))))))))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                      ? 
                                                     (1U 
                                                      >> (IData)(wasmetal_core__DOT___013023_))
                                                      : (IData)(
                                                                (0xf0fff3fff0fff5ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___013023_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hcfb94f0b__0))))))))));
    wasmetal_core__DOT___012357_ = (1U & (IData)((0xf0f033aa00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x1d1d0f55U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___056207_)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O)) 
                                                               | (1U 
                                                                  & (0xcc35U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O)))))))))))))));
    vlSelf->wasmetal_core__DOT___057073_ = (1U & (IData)(
                                                         (0xff00f000ff00ee00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057064_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc0035U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                                                >> 3U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O)))))))))))));
    vlSelf->wasmetal_core__DOT___057423_ = (1U & (IData)(
                                                         (0xff00e000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056935_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___056940_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f13551100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(wasmetal_core__DOT___056936_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h267c01fb__0))))))))));
    vlSelf->wasmetal_core__DOT___056953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f13551100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(wasmetal_core__DOT___056949_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h267c01fb__0))))))))));
    if (vlSelf->wasmetal_core__DOT___010376_) {
        if (vlSelf->wasmetal_core__DOT___010378_) {
            vlSelf->wasmetal_core__DOT___057523_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___012971_)));
            vlSelf->wasmetal_core__DOT___057060_ = 
                (1U & (1U >> (IData)(wasmetal_core__DOT___012317_)));
        } else {
            vlSelf->wasmetal_core__DOT___057523_ = 
                (1U & (0xb0U >> (((IData)(wasmetal_core__DOT___012971_) 
                                  << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                   >> 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___011068_)))));
            vlSelf->wasmetal_core__DOT___057060_ = 
                (1U & (0xbU >> (((IData)(wasmetal_core__DOT___012317_) 
                                 << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                  >> 2U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___011068_)))));
        }
    } else if (vlSelf->wasmetal_core__DOT___010378_) {
        vlSelf->wasmetal_core__DOT___057523_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___012971_)));
        vlSelf->wasmetal_core__DOT___057060_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___012317_)));
    } else {
        vlSelf->wasmetal_core__DOT___057523_ = (1U 
                                                & (0xe00U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___012971_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb6e1260e__0))));
        vlSelf->wasmetal_core__DOT___057060_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___012317_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012316_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___012315_))))));
    }
    vlSelf->wasmetal_core__DOT___057299_ = (1U & (IData)(
                                                         (0xff00bb00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057296_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057295_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___057040_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___057033_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057031_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057030_)))))))));
    vlSelf->wasmetal_core__DOT___010076_ = (1U & (IData)(
                                                         (0xff00bb00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056299_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___012354_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009691_)) 
                                                  & (IData)(
                                                            (0xfff0fffeff00ff00ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___012359_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___012358_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___012357_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012356_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))));
}
